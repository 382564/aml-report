create function getNoNIPrem(P_GrpContNo varchar2,
                                       P_RiskCode  varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select case
           when exists (select 1
                   from ldcode
                  where codetype = 'ishelarisk'
                    and code = P_RiskCode
                    and othersign = '2') then
            (select nvl(sum(prem), 0)
               from lcgrppol
              where grpcontno = P_GrpContNo
                and riskcode = P_RiskCode)
           else
            (select nvl(sum(b.prem), 0)
               from lccont a, lcpol b
              where a.contno = b.contno
                and b.riskcode = P_RiskCode
                and a.grpcontno = P_GrpContNo
                and not exists (select 1
                       from lpedoritem
                      where grpcontno = a.grpcontno
                        and contno = a.contno
                        and edortype = 'NI'))
         end
    into Result
    from dual;
  return(Result);
end getNoNIPrem;

/

