create function getAmt_type_tbl_1(ywType     in char,
                                           cwType     in CHAR,
                                           standbyflag in char,
                                           riskPeriod in char)
  return VARCHAR is
  amt_type_tbl VARCHAR(2);
begin
  --ywType?????
  --cwType?????

  if ywType = 'RE' then
    amt_type_tbl := '02';
  else
    if (ywType = 'CT' or ywType ='PT') and standbyflag = '2' then
      amt_type_tbl := '03';  --20060713,PT
    else
      if cwType = 'TB' and riskPeriod = 'L' then
        amt_type_tbl := '04';
      else
        if cwType = 'TB' and riskPeriod <> 'L' then
          amt_type_tbl := '05';
        else
          --if
          if ywType = '00' or ywType = '01' or ywType = '02' or
             ywType = '03' or ywType = '04' or ywType = '05' then
            amt_type_tbl := '08';
          else
            if ywType = '06' or ywType = '09' then
              amt_type_tbl := '09';
            else
              amt_type_tbl := '99';
            end if;
          end if;
        end if;
      end if;
    end if;
  end if;
  return(amt_type_tbl);
end getAmt_type_tbl_1;


/

