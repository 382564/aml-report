create FUNCTION connRecruit(tAgentCode in varchar2, tAgentGrade in varchar2,tManageCom in varchar2,tWageCode in varchar2,TempBegin in date,TempEnd in date) return number is
  tPayMode        varchar2(1);
  tMonthLimit     integer:=0;
  tStandMoney     number(12,3):=0;
  tBaseRate       number(12,3):=0;
  tEmployDate     date;
  tIndueFormDate  date;
  tStartDate      date;

	tGroup          varchar2(20);
  tBranchAttr     varchar2(255);
  tLinkEnd        date;
  tBaseRate1      number(12,2):=0;

  --??????

  tArrPeriod      integer:=0;
  tMons           integer:=0;
  tIntvl          integer:=0;
  tAStartBegin    date;
  tAssessPaySum   number(12,3):=0;
  tSumF23         number(12,3):=0;
  tF23            number(12,3):=0;
  tCurrPremium    number(12,3):=0;
  tIndexCalNo     varchar2(6);

  --??????
  tHalfPremium    number(12,3):=0;
  tASumPremium    number(12,3):=0;
  tHalfDate       date;
  tArrEndDate     date;
  tArrStandard    number(20,6):=0;
  tArrPremSum     number(20,6):=0;

  tAssStandSum      number(20,10):=0;
  tAssHalfStandard  number(20,10):=0;
  tAssStandardSum   number(20,10):=0;

  --???????????A04:Y-???N-???
  tJudgeFlag      varchar2(1);
  tManageComCond  varchar2(10);
  iCount          integer := 0;

  --??????
  tEDay           varchar2(2);
  tEmployMon      varchar2(2);
  tTempMon        varchar2(2);

  tYearCount      integer := 0;

  Result          number(12,3):=0;
begin

  tManageComCond := trim(tManageCom);

  --??????,?????,????
  select Count(*) into iCount from lalinkwage
  where trim(payperiodtype)='02'
  and trim(paymonth)='01'
  and tManageComCond like trim(managecom)||'%'
  and trim(agentgrade)=trim(tAgentGrade)
  and trim(wagecode)=trim(tWageCode)
  ;
  if iCount > 0 then
    select paymode,standmoney,monthlimit,BaseRate1 into tPayMode,tStandMoney,tMonthLimit,tBaseRate1 from lalinkwage
    where trim(payperiodtype)='02'
    and trim(paymonth)='01'
    and tManageComCond like trim(managecom)||'%'
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;
  else
    return 0;
  end if;

  select nvl(arrangeperiod,0),nvl(linkenddate,to_date('3000-01-01','yyyy-mm-dd')) into tArrPeriod,tLinkEnd
  from lalinkassess
  where tManageComCond like trim(managecom)||'%'
    and trim(agentgrade) = trim(tAgentGrade);

  --???????????????
  if TempBegin > tLinkEnd then
    return(0);
  end if;

 --??????????
  select employdate,indueformdate,agentgroup,startdate,agentgroup into tEmployDate,tIndueFormDate,tBranchAttr,tStartDate,tGroup from laagenttreeview
  where agentcode = trim(tAgentCode);

  tBranchAttr:=trim(getbranchattr(tGroup));

  --???????????
  if tIndueFormDate <> tEmployDate then
    return(0);
  end if;

  tJudgeFlag := doJudgeGrade(tAgentCode);
  if tJudgeFlag = 'N' then
    return(0);
  end if;

  tIntvl := tMonthLimit + tArrPeriod;

  --??????
  tEDay := to_char(tEmployDate,'dd');
  tEmployMon := to_char(tEmployDate,'mm');
  tTempMon := to_char(TempBegin,'mm');

  if to_char(TempBegin,'yyyy') = to_char(tEmployDate,'yyyy') then
    tMons := tTempMon - tEmployMon + 1;
  else
    tYearCount := to_char(TempBegin,'yyyy') - to_char(tEmployDate,'yyyy');
    tMons := 12 - tEmployMon + 1;
    tMons := tMons + tTempMon;
    tMons := tMons + (tYearCount-1)*12;
  end if;

  if tEDay > trim(getEmployLimit('EmployLimit')) then
    tMons := tMons - 1;
  end if;

  --zsj 2004-1-8 Modify
  --tMons := DateInterval(tEmployDate,add_months(TempBegin,1));


  --????
  tAStartBegin := getDate(tEmployDate,tArrPeriod,TempBegin);


  --??????????
  if tMons < tArrPeriod or tMons>tIntvl then
    return(0);
  end if;


  --?????
  tCurrPremium := gettransmoney(TempBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');


  --????
  if tPayMode = 0 then
    if tMons <= tArrPeriod then
      return(0);
    end if;

    --????????
    select baserate,monthlimit into tBaseRate,tMonthLimit from lalinkwage
    where tManageComCond like trim(managecom)||'%'
      and trim(payperiodtype)='02'
      and trim(paymonth)= trim(to_char(tMons-tArrPeriod,'09'))
      and trim(agentgrade)=trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode)
      ;


    if tMons = tIntvl then
      --??????????
      select sum(baserate) into tAssStandSum from lalinkwage
      where tManageComCond like trim(managecom)||'%'
        and trim(payperiodtype)='02'
        and trim(agentgrade)=trim(tAgentGrade)
        and trim(wagecode)=trim(tWageCode)
        ;

      tAssessPaySum := getTransMoney(tAStartBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      if tAssessPaySum >= tAssStandSum then
      --????????????????
      --??2004-02-18??,??LAWage???F23?????LAIndexInfo???T32??
        select nvl(sum(T32),0) into tSumF23 from LAIndexInfo
        where trim(indexcalno) >= trim(to_char(tAStartBegin,'yyyymm'))
          and trim(indexcalno) < trim(to_char(TempBegin,'yyyymm'))
          and trim(indextype)='01'
          and trim(agentcode) = trim(tAgentCode)
          ;

        Result := tStandMoney - tSumF23;
      else
        if tCurrPremium >= tBaseRate then
          Result := tStandMoney/tMonthLimit;
        else
          Result := 0;
        end if;
      end if;
    else
      if tCurrPremium >= tBaseRate then
        Result := tStandMoney/tMonthLimit;
      else
        Result := 0;
      end if;
    end if;
  end if;


  tArrEndDate := getDate(tEmployDate,tArrPeriod,TempEnd);
  --????
  if tPayMode = 1 then
    --?????
    if tMons = tArrPeriod then
      tArrPremSum := Gettransmoney(tEmployDate,tArrEndDate,tBranchAttr,tAgentGrade,tAgentCode,'P');
      select sum(BaseRate) into tArrStandard from lalinkwage
      where trim(payperiodtype)='01'
      and tManageComCond like trim(managecom)||'%'
        and trim(agentgrade)=trim(tAgentGrade)
        and trim(wagecode)=trim(tWageCode)
        ;

      if tArrPremSum >= tArrStandard then
        Result := tStandMoney * 0.3;
      else
        Result := 0;
      end if;
    end if;

    --?????????
    if tMons = tArrPeriod + tMonthLimit/2 then
      select sum(BaseRate) into tAssHalfStandard from lalinkwage
      where trim(payperiodtype)='02'
        and trim(paymonth) >= '01'
        and trim(paymonth) <= trim(to_char(tMonthLimit/2,'09'))
        and tManageComCond like trim(managecom)||'%'
        and trim(agentgrade) = trim(tAgentGrade)
        and trim(wagecode) = trim(tWageCode)
        ;

      tHalfPremium := getTransMoney(tAStartBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      if tHalfPremium >= tAssHalfStandard then
        Result := tStandMoney * 0.5;
      else
        Result := 0;
      end if;
    end if;

    --????
    if tMons = tIntvl then
      select sum(BaseRate) into tAssStandardSum from lalinkwage
      where trim(payperiodtype)='02'
      and tManageComCond like trim(managecom)||'%'
        and trim(agentgrade) = trim(tAgentGrade)
        and trim(wagecode) = trim(tWageCode)
        ;

      tHalfDate := getDate(tEmployDate,tArrPeriod+tMonthLimit/2-1,TempBegin);
      tIndexCalNo := to_char(tHalfDate,'yyyymm');
      --??2004-02-18??,??LAWage???F23?????LAIndexInfo???T32??
      select nvl(T32,0) into tF23 from laindexinfo
      where trim(indextype)='01'
      and trim(indexcalno) = trim(tIndexCalNo)
      and trim(agentcode) = trim(tAgentCode)
      ;

      tASumPremium := getTransMoney(tAStartBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      if tASumPremium >= tAssStandardSum then
        if tF23 <> 0 then
          Result := tStandMoney * 0.2;
        else
          Result := tStandMoney * 0.7;
        end if;

        tIndexCalNo := to_char(tArrEndDate,'yyyymm');
        --??2004-02-18??,??LAWage???F23?????LAIndexInfo???T32??
        select nvl(T32,0) into tF23 from laindexinfo
        where trim(indextype)='01'
          and trim(indexcalno) = trim(tIndexCalNo)
          and trim(agentcode) = trim(tAgentCode)
          ;
        if tF23 = 0 then
          Result := Result + tStandMoney*0.3;
        end if;
      else
        Result := 0;
      end if;
    end if;

  end if;

  return(Result);
end connRecruit;


/

