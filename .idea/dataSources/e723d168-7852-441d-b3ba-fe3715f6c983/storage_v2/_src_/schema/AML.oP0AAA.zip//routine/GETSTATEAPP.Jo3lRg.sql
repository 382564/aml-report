create function getStateApp(p_appflag in lcpol.appflag%type,
                                       p_contno  in lccont.contno%type)
  return varchar is
  Result    varchar(10);
  AppResult varchar(10);
begin
  if P_appflag = '1' then
    AppResult := '已生效';
  elsif P_appflag = 'B' then
    AppResult := '已生效';
  elsif P_appflag = 'F' then
    AppResult := '退保';
  elsif P_appflag = '4' then
    select case
             when exists (select b.codename
                     from lccontstate a, ldcode b
                    where b.codetype = 'contterminatereason'
                      and a.statereason = b.code
                      and statetype = 'Terminate'
                      and a.contno = P_contno
                      and code in ('11', '04', '01')) then
              (select b.codename
                 from lccontstate a, ldcode b
                where b.codetype = 'contterminatereason'
                  and a.statereason = b.code
                  and statetype = 'Terminate'
                  and a.contno = P_contno
                  and code in ('11', '04', '01')
                  and rownum = 1)
             else
              '退保'
           end
      into AppResult
      from dual;
  else
    AppResult := '未生效';
  end if;
  Result := AppResult;
  return(Result);
end getStateApp;

/

