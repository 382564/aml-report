create function         FEENOTOAPPNTNO(HTDT varchar2, FEENO char)
  return varchar2 is
  rAppntno varchar2(40) default '000000';
begin
  ---LCGet
  select nvl(max(appntno), '000000')
    into rAppntno
    from (
          --一般领取

          --当othernotype=1,otherno直接为客户号appntno.
          select l.appntno appntno
            from ljaget l
           where l.othernotype = '1'
             and l.paymode = '1'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          --当othernotype=2,otherno为生存领取对应的合同号
          select c.appntno appntno
            from ljaget l, lccont c
           where l.othernotype = '2'
             and c.contno = l.otherno
             and l.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          --当othernotype=4,otherno为暂收退费的印刷号
          select c.appntno
            from ljtempfee t, ljaget g, lccont c
           where t.tempfeeno = g.otherno
             and t.othernotype = '4'
             and g.paymode = '1'
             and c.prtno = t.otherno
             and c.grpcontno = '00000000000000000000'
             and g.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and g.actugetno = FEENO
          union all

          ---当othernotype=5,由ljagetclaim和appntno
          select c.appntno
            from ljagetclaim l, ljaget a, lccont c
           where a.actugetno = l.actugetno
             and c.contno = l.contno
             and a.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and a.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          ---当othernotype=6,otherno为溢交退费对应的合同号
          select c.appntno appntno
            from ljaget l, lccont c
           where l.othernotype = '6'
             and c.contno = l.otherno
             and l.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          ---当othernotype=7,otherno红利给付对应的合同号
          select c.appntno appntno
            from ljaget l, lccont c
           where l.othernotype = '7'
             and c.contno = l.otherno
             and l.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          ---当othernotype=9,otherno续期回退对应的合同号
          select c.appntno appntno
            from ljaget l, lccont c
           where l.othernotype = '9'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.paymode = '1'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          --当oternotype=10,otherno为保全对应的保全受理号
          select c.appntno
            from ljaget l, lpedormain m, lccont c
           where l.othernotype = '10'
             and l.paymode = '1'
             and l.otherno = m.edoracceptno
             and m.contno = c.contno
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.actugetno = FEENO
          union all

          --  暂缴费
          --tempfeetype=1为新单收费,othernotype=0交费对应的个单合同号
          select c.appntno
            from ljtempfee l, ljtempfeeclass f, lccont c
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '1'
             and l.othernotype = '0'
             and f.paymode = '1'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno = FEENO

          --tempfeetype=1为新单收费,othernotype=1为交费时对应的集体合同号, 在此处不考虑
          union all
           select c.appntno
            from ljtempfee l, ljtempfeeclass f, lcgrpcont c
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '1'
             and l.othernotype = '1'
             and f.paymode = '1'
             and c.grpcontno = l.otherno
             and c.grpcontno <> '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
            and l.tempfeeno = FEENO
          --tempfeetype=1为新单收费,othernotype=4新单交费对应的个、团单的印刷号
          union all
          select c.appntno
            from ljtempfee l, ljtempfeeclass f, lccont c
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '1'
             and l.othernotype = '4'
             and f.paymode = '1'
             and c.prtno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno = FEENO
          --tempfeetype=2为续期催收交费,othernotype=0交费对应的个单合同号
          union all
          select c.appntno
            from ljtempfee l, ljtempfeeclass f, lccont c
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '2'
             and l.othernotype = '0'
             and f.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and c.contno = l.otherno
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno = FEENO


          --tempfeetype=4为保全交费,othernotype=10
          union all
          select c.appntno
            from ljtempfee l, lccont c, lpedormain p, ljtempfeeclass f
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '4'
             and f.paymode = '1'
             and l.othernotype = '10'
             and p.edoracceptno = l.otherno
             and c.contno = p.contno
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno = FEENO

          --tempfeetype=6为理赔收费/tempfeetype=3预收交费,othernotype=2.(理赔收费对应的理赔赔案号)
          union all
          select c.appntno
              from ljtempfee l,ljtempfeeclass f,lccont c,ljagetclaim g
             where l.tempfeeno=f.tempfeeno
             and l.tempfeetype in('6','3')
             and l.othernotype='2'
             and f.paymode='1'
             and g.otherno=l.otherno
             and c.contno=g.contno
             and c.grpcontno = '00000000000000000000'
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno=FEENO

          --tempfeetye=8 续期非催收交费 othernotype=0
          union all
          select c.appntno
            from ljtempfee l, ljtempfeeclass f, lccont c
           where l.tempfeeno = f.tempfeeno
             and l.tempfeetype = '8'
             and l.othernotype = '0'
             and f.paymode = '1'
             and c.grpcontno = '00000000000000000000'
             and c.contno = l.otherno
             and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
             and l.tempfeeno = FEENO);

  return rAppntno;
end FEENOTOAPPNTNO;


/

