create procedure DeleteMenuDIR(P_REFNODE IN VARCHAR2) is
  V_REFNODECODE VARCHAR2(5);
  V_NODECODE VARCHAR2(5);
  V_NODENAME VARCHAR2(30);
  V_PARENTNODECODE VARCHAR2(5);
  V_NODESTR VARCHAR2(200);
  V_PARENTNODE_OF_REFNODE VARCHAR2(5);
  V_LEN integer;
  V_P integer;
  V_CHILDCNT integer;
  childMenu sys_refcursor;
  t_LDMenu LDMenu%ROWTYPE;
begin
  V_PARENTNODECODE := '0';
  V_NODESTR := P_REFNODE;
  V_LEN := length(V_NODESTR);

  loop
    V_P := instr(V_NODESTR, '->');
    if V_P > 0 then
      V_NODENAME := substr(V_NODESTR, 1, V_P - 1);
    else
      V_NODENAME := V_NODESTR;
    end if;

    select NodeCode into V_NODECODE from LDMenu where NodeName = V_NODENAME and ParentNodeCode = V_PARENTNODECODE;

    V_PARENTNODECODE := V_NODECODE;
    if V_P > 0 then
      V_NODESTR := substr(V_NODESTR, V_P + 2, V_LEN);
    end if;
  exit when V_P = 0;
  end loop;

  V_REFNODECODE := V_NODECODE;

  select Parentnodecode into V_PARENTNODE_OF_REFNODE from LDMenu where NodeCode = V_REFNODECODE;

  
  select count(*) into V_CHILDCNT from LDMenu where Parentnodecode = V_REFNODECODE;
  if V_CHILDCNT > 0 then
    open childMenu for 
      select * from LDMenu where Parentnodecode = V_REFNODECODE;
      loop 
        fetch  childMenu INto t_LDMenu;
        exit when childMenu%notfound;
        DeleteMenuDir(P_REFNODE || '->' || t_LDMenu.NodeName);
      END LOOP;
    close childMenu;
  end if;
  select count(*) into V_CHILDCNT from LDMenu where Parentnodecode = V_REFNODECODE;
  if V_CHILDCNT = 0 then
  
    UPDATE LDMENU
       SET CHILDFLAG = CHILDFLAG - 1
     WHERE NODECODE = V_PARENTNODE_OF_REFNODE;

    DELETE FROM LDMENUGRPTOMENU
     WHERE NODECODE = V_REFNODECODE;

    DELETE FROM LDMENU
     WHERE NODECODE = V_REFNODECODE;

    IF NOT SQL%NOTFOUND THEN
      commit;
      dbms_output.put_line('Delete Success!' || P_REFNODE || '删除成功!' || '菜单编码:' || V_REFNODECODE);
    ELSE
      ROLLBACK;
      dbms_output.put_line('Error! Delete Error! ' || P_REFNODE || '删除失败!');
    END IF;
  else
    -- have child node
    ROLLBACK;
    dbms_output.put_line('Error! Delete Error! ' || P_REFNODE || ' Have childnode! ');
  end if;
exception when others then
  rollback;
  dbms_output.put_line('Error! Delete Error! ' || P_REFNODE);
END DeleteMenuDIR;


/

