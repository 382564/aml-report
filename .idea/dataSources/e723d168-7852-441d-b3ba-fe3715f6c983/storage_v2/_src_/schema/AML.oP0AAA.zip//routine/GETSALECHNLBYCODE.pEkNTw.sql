create function getsaleChnlBycode(tnoType in varchar2,
                                             tno     in varchar2)
  return varchar2 is
  Result    varchar2(100);
  tSaleChnl varchar2(20);
  tContType varchar2(20);
begin
  --获得保单号
  if tnoType = '0' then
    --投保单号
    select conttype
      into tContType
      from (select conttype, prtno
              from lccont
            union
            select conttype, prtno from lbcont)
     where prtno = tno
       and rownum = 1;

    if tContType = '1' then
      --?个单
      select salechnl
        into tSaleChnl
        from (select salechnl, prtno
                from lccont
              union
              select salechnl, prtno from lbcont)
       where prtno = tno
         and rownum = 1;
    else
      --团单
      select salechnl
        into tSaleChnl
        from (select salechnl, prtno
                from lcgrpcont
              union
              select salechnl, prtno from lbgrpcont)
       where prtno = tno
         and rownum = 1;
    end if;
  elsif tnoType = '1' then
    --?个单号
    select salechnl
      into tSaleChnl
      from (select salechnl, contno
              from lccont
            union
            select salechnl, contno from lbcont)
     where contno = tno;
  else
    --团单号
    select salechnl
      into tSaleChnl
      from (select salechnl, grpcontno
              from lcgrpcont
            union
            select salechnl, grpcontno from lbgrpcont)
     where grpcontno = tno;
  end if;
  Result := tSaleChnl;
  return(Result);
end getsaleChnlBycode;


/

