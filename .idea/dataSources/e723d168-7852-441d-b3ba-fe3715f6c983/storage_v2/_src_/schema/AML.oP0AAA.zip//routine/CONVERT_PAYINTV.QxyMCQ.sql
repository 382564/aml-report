create FUNCTION convert_payintv(PayIntv smallint, GetYear smallint) return smallint is
  Result smallint;
begin
 case
when PayIntv=0 then Result:=0;
when PayIntv=1 then Result:=GetYear;
when PayIntv=12 then Result:=GetYear;
end case;
  return(Result);
end convert_payintv;


/

