create function getissuecont(t_PrtSeq in loprtmanager.prtseq%type) return CHAR is
  t_IssueCont          lcgrpissuepol.issuecont%type;
  s_IssueCont          lcgrpissuepol.issuecont%type;
  t_PrtCode           loprtmanager.code%type;
  t_row_lcgrpissuepol    lcgrpissuepol%rowtype;

  cursor t_cursor_lcgrpissuepol is
  select * from lcgrpissuepol where prtseq=t_PrtSeq;

begin
   t_PrtCode:='';
   t_IssueCont:=null;

   select code
   into t_PrtCode
   from loprtmanager where prtseq=t_PrtSeq;

   if (t_PrtCode='54') then
      t_IssueCont:='';
      open t_cursor_lcgrpissuepol;
      loop
          fetch t_cursor_lcgrpissuepol into t_row_lcgrpissuepol;
          exit when t_cursor_lcgrpissuepol%notfound;
          s_IssueCont:=t_IssueCont;
          select s_IssueCont||t_row_lcgrpissuepol.IssueCont||''
          into t_IssueCont
          from dual;
      end loop;
   else
      t_IssueCont:=null;
   end if;
   return(t_IssueCont);
end getIssueCont;


/

