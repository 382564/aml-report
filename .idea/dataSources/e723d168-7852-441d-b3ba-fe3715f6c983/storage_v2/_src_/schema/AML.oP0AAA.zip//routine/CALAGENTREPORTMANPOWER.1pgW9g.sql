create function calAgentReportManpower(tComCode in varchar2, IndexCalNo in varchar2,tAgentGrade in varchar2,Caltype in varchar2) return  integer is
  Result integer;
  --??????????????
begin
  if (Caltype='00') then
  --????
  select count(a.agentcode) into Result from laagent a,lastatsegment b where a.branchtype='1'
  and a.employdate<=b.startdate and (a.agentstate <= '02' or (a.agentstate>='03' and a.outworkdate>b.startdate))
  and a.managecom like tComCode||'%' and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode
  and state = '1') and b.yearmonth=IndexCalNo and b.stattype='5';
  elsif (Caltype='01') then
  --???????
     if(tAgentGrade='ADDSUM') then
     select count(a.agentcode) into Result from laagent a,latree b,lastatsegment d where a.branchtype='1'
     and a.managecom like tComCode||'%' and a.agentcode=b.agentcode
     and d.startdate<=a.employdate and a.employdate<=d.enddate
     and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state='1') and d.stattype='5'
     and d.yearmonth=IndexCalNo;
     else
     select count(a.agentcode) into Result from laagent a,latree b,lastatsegment d where a.branchtype='1'
     and a.managecom like tComCode||'%' and a.agentcode=b.agentcode and b.agentgrade=tAgentGrade
     and d.startdate<=a.employdate and a.employdate<=d.enddate
     and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state='1') and d.stattype='5'
     and d.yearmonth=IndexCalNo;
     end if;
  elsif (Caltype='02') then
  --???????
     if(tAgentGrade='ADDSUM') then
     select count(a.agentcode) into Result from laagent a,latree b,lastatsegment d where a.branchtype='1'
     and a.managecom like tComCode||'%' and a.agentcode=b.agentcode and a.agentstate >= '03'
     and d.startdate<=a.outworkdate and a.outworkdate<=d.enddate
     and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state='1')
     and d.stattype='5' and d.yearmonth=IndexCalNo;
     else
     select count(a.agentcode) into Result from laagent a,latree b,lastatsegment d where a.branchtype='1'
     and a.managecom like tComCode||'%' and a.agentcode=b.agentcode and b.agentgrade=tAgentGrade and a.agentstate >= '03'
     and d.startdate<=a.outworkdate and a.outworkdate<=d.enddate
     and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state='1')
     and d.stattype='5' and d.yearmonth=IndexCalNo;
     end if;

  elsif (CalType='03') then
  --???????
     if(tAgentGrade='ADDSUM') then
     select count(a.agentcode) into Result from laagent a,lastatsegment b,latree d where a.branchtype='1'
     and a.agentcode=d.agentcode and a.employdate<=b.enddate
     and (a.agentstate <= '02' or (a.agentstate>='03' and a.outworkdate>b.enddate))
     and a.managecom like tComCode||'%' and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode
     and state = '1') and b.stattype='5'
     and b.yearmonth=IndexCalNo;
     else
     select count(a.agentcode) into Result from laagent a,lastatsegment b,latree d where a.branchtype='1'
     and a.agentcode=d.agentcode and d.agentgrade=tAgentGrade and a.employdate<=b.enddate
     and (a.agentstate <= '02' or (a.agentstate>='03' and a.outworkdate>b.enddate))
     and a.managecom like tComCode||'%' and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode
     and state = '1') and b.stattype='5'
     and b.yearmonth=IndexCalNo;
     end if;

  elsif (Caltype='04') then
  --???????
  select count(a.agentcode) into Result from laagent a,lastatsegment b
  where a.branchtype='1' and trim(a.quafno) is not null and a.employdate<=b.enddate
  and (a.agentstate <= '02' or (a.agentstate>='03' and a.outworkdate>b.enddate))
  and a.managecom like tComCode||'%'
  and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state = '1')
  and b.yearmonth=IndexCalNo and b.stattype='5';

  elsif (Caltype='05') then
  --???????
  select count(a.agentcode) into Result from laagent a,lastatsegment b
  where a.branchtype='1' and trim(a.DevNo1) is not null and a.employdate<=b.enddate
  and (a.agentstate <= '02' or (a.agentstate>='03' and a.outworkdate>b.enddate))
  and a.managecom like tComCode||'%'
  and not exists (select 'X' from labranchgroup where agentgroup=a.branchcode and state = '1')
  and b.yearmonth=IndexCalNo and b.stattype='5';
  end if;
  return(Result);
end calAgentReportManpower;


/

