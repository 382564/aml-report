create function chgpayintv236(payintv in varchar2) return varchar2
is
tR varchar2(20);
begin
 if payintv = '0' then
  tR := '0';
 else
  tR := '12';
 end if;

 return(tR);
end;


/

