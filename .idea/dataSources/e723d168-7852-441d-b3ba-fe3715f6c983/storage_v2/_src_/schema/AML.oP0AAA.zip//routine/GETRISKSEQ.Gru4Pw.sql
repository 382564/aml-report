create function getriskseq(tPolNo  in VARCHAR,
                                      tContNo in VARCHAR) return CHAR is
  result integer;
tCount Integer;
riskeq Char(1);

Begin

 Select Count(1)  Into tCount From lcpol Where polno = tPolNo And polno = mainpolno;

 If tCount = 1 Then
   riskeq := '1';
  Else
   riskeq := '2';
  End If;

 Return riskeq;
end getriskseq;


/

