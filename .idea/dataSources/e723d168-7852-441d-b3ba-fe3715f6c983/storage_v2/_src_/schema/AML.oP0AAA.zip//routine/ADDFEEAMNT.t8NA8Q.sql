create FUNCTION AddFeeAMNT( mAddFeeKind in varchar2,mRiskCode in varchar2,mPolNo in varchar2,mSuppRiskCore in NUMBER) return LCPrem.Prem%Type is
    tAddFeeAmnt LCPrem.Prem%Type;
	t_sql LMCalMode.calsql%TYPE ;
    t_cursor NUMBER;
    t_count NUMBER;
    t_temp NUMBER;
    t_temp_SumAmnt  LCPrem.Prem%Type;
    CURSOR t_CalSQLSet IS
		select calsql
		from  lmcalmode
		where type = 'K' and riskcode=mRiskCode;
begin
  tAddFeeAmnt := 0 ;
  t_count := 0 ;
  t_temp_SumAmnt := 0 ;
  t_sql := '' ;

  --????????????????
  select count(*) into t_count
  from  lmcalmode
  where type = 'K' and riskcode = mRiskCode ;

IF t_count = 1 THEN
  --??????
    t_cursor := DBMS_SQL.OPEN_CURSOR;
  FOR  t_CalSQL IN t_CalSQLSet LOOP  --????SQL??
       --DBMS_OUTPUT.PUT_LINE(trim(t_CalSQL.calsql));
       --?SQL??"?polno?"??????????
       t_sql := REPLACE(trim(t_CalSQL.calsql),'?polno?',mPolNo) ;
       t_sql := REPLACE(trim(t_sql),'?suppriskcore?',mSuppRiskCore) ;
       t_sql := REPLACE(trim(t_sql),'?addfeekind?',mAddFeeKind) ;
       DBMS_OUTPUT.PUT_LINE(t_sql);
       DBMS_SQL.PARSE(t_cursor, t_sql, DBMS_SQL.native);
       --???????????t_temp_SumAmnt?
       DBMS_SQL.DEFINE_COLUMN(t_cursor,1,t_temp_SumAmnt);
       --????SQL??
       t_temp := DBMS_SQL.EXECUTE(t_cursor);
       LOOP
       --?????????? t_temp_SumAmnt,?????
         IF DBMS_SQL.FETCH_ROWS(t_cursor)>0 THEN
           DBMS_SQL.COLUMN_VALUE(t_cursor,1,t_temp_SumAmnt);
           IF t_temp_SumAmnt > 0 THEN
                tAddFeeAmnt := tAddFeeAmnt +  t_temp_SumAmnt;
            END IF;
         ELSE
           EXIT;
         END IF;
      END LOOP;
 END LOOP;
   DBMS_SQL.CLOSE_CURSOR(t_cursor);
ELSE
  --????????????-1
  tAddFeeAmnt := -1 ;
END IF ;

 --DBMS_OUTPUT.PUT_LINE(' ???????? done !');
  return(tAddFeeAmnt);

END;


/

