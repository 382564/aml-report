create function getLFCEndo_Fee(startdate in date,enddate in date,tManageCom in varchar) return char is
  Result_Endo varchar2(10);
  pragma autonomous_transaction;
 begin


 Declare
 v_cvalidate date;
 v_insuyearflag char(1);
 v_years   integer;
 v_PayIntv integer;
 v_PayEndYear integer;
 v_payendyearflag char(1);
 v_SaleChnl char(2);
 v_AgentCom char(20);
 v_agentcode char(10);
 v_mult  number(20,5);
 v_amnt  number(12,2);
 v_riskperiod char(1);

 c_actugetno         Char(20);
 c_Endorsementno     Char(20);
 c_feeoperationtype  Char(6);
 v_riskcode          varchar2(10);
 c_polno             Char(20);
 d_getmoney          Number(12,2);
 c_managecom         Char(10);
 c_enteraccdate      Date;
 c_contno            Char(20);
 v_Edorvalidate      Date;
 v_startdate        Date;
 v_enddate          Date;


 v_cursor_lfcendo lfcendo_fee%rowtype;



 cursor v_cursor_ljagetendorse is

 --????????????????????????????
Select a.actugetno,a.Endorsementno,a.feeoperationtype,a.riskcode,a.polno,a.managecom ,a.enteraccdate,Sum(getmoney)
 from ljagetendorse a
 where 1=1
     --and contno = 'WH010521351000072'
     and a.makedate >= startdate
     and a.makedate <= enddate
     and a.managecom like tManageCom||'%'
     And a.feeoperationtype <> 'RB'
     --And a.actugetno = '370450000005805'
     and exists(select 1 from lpedoritem  b
          where 1=1
     and b.managecom like tManageCom||'%'
          And b.edorstate = '0'
          and b.edorvalidate <= startdate
          and b.edorno =a.endorsementno
          )
     And a.feeoperationtype <> 'RE'
      Group By a.actugetno,a.Endorsementno,a.feeoperationtype,a.riskcode,a.polno,a.managecom ,a.enteraccdate

----?????????????
Union

Select a.actugetno,a.Endorsementno,a.feeoperationtype,a.riskcode,a.polno,a.managecom ,a.enteraccdate,Sum(getmoney)
 from ljagetendorse a
 where 1=1
     and managecom like tManageCom||'%'
     --And a.actugetno = '370450000005805'
     and exists(select 1 from lpedoritem  b
          where 1=1
     and managecom like tManageCom||'%'
     And a.feeoperationtype <> 'RB'
          And b.edorstate = '0'
          and b.edorvalidate >= startdate
          and b.edorvalidate <= enddate
          and b.edorno =a.endorsementno
          )
          And a.feeoperationtype <> 'RE'
      Group By a.actugetno,a.Endorsementno,a.feeoperationtype,a.riskcode,a.polno,a.managecom ,a.enteraccdate
;

 begin

 execute immediate  'truncate table lfcendo_fee';

 --???
 select getLFCprem_2(startdate ,enddate ,tManageCom) into Result_Endo from dual;
 --???0???
 select getLFCprem_4(startdate ,enddate ,tManageCom) into Result_Endo from dual;

open v_cursor_ljagetendorse;

 loop
 fetch v_cursor_ljagetendorse Into c_actugetno,c_Endorsementno,c_feeoperationtype,v_riskcode,c_polno,c_managecom,c_enteraccdate,d_getmoney;
 exit when v_cursor_ljagetendorse%notfound;

 Begin
   Select contno,cvalidate,years,insuyearflag,PayIntv,PayEndYear,payendyearflag,SaleChnl,AgentCom,agentcode
          ,mult,amnt
   Into c_contno,v_cvalidate,v_years,v_insuyearflag,v_PayIntv,v_PayEndYear,v_payendyearflag,v_SaleChnl,v_AgentCom,v_agentcode
          ,v_mult,v_amnt
   from lcpol
   where polno = c_polno;


 --dep_name????

    v_cursor_lfcendo.dept_name :=  trim(getCode('com',c_managecom));

   --???
    v_cursor_lfcendo.entno := c_endorsementno;


    --????
     v_cursor_lfcendo.gp_type := 'P';


     -- ???
     v_cursor_lfcendo.polno := c_contno;


     --???
     v_cursor_lfcendo.certno := c_contno;


     --????
     v_cursor_lfcendo.brno := getriskseq(c_polno, c_contno);


     --????
     v_cursor_lfcendo.plan_code := v_riskcode;

     --???? ?????????????
     If v_cursor_lfcendo.brno = '2' then
        Select cvalidate Into v_cvalidate From lcpol Where polno = mainpolno And contno = c_contno;
     End If;

		 Begin

				 Select Edorvalidate
				 Into v_Edorvalidate
				 From Lpedoritem
				 Where edorno = c_endorsementno And Rownum = 1;

     Exception
			 When No_Data_Found Then
				 Null;
		 End;
     v_cursor_lfcendo.pol_yr := Getcuryear(v_Edorvalidate,v_cvalidate);


     --????(?)
     v_cursor_lfcendo.period := ChangeDateToMonth(v_years, v_insuyearflag);


     --??
     v_cursor_lfcendo.prem_type := trim(getCode('payintv', to_char(v_PayIntv)));


     --????(?)
     v_cursor_lfcendo.Prem_Term := changeDateToMonth(v_PayEndYear, v_payendyearflag);


   --??????
     v_cursor_lfcendo.Busi_Src_Type := trim(getCode('salechnl', v_SaleChnl));


   --??????
     v_cursor_lfcendo.Agt_Code := v_AgentCom;

     --?????

     v_cursor_lfcendo.AgentNo := ChangeAgentcode(v_agentcode);


   --????
     v_cursor_lfcendo.POS_Type := trim(getCode('edortype', c_feeoperationtype));

  -- ????
		 Begin
			 Select Riskperiod Into v_Riskperiod From Lmriskapp Where Riskcode = v_Riskcode And Rownum = 1;
		 Exception
			 When No_Data_Found Then
				 Null;
		 End;

     v_cursor_lfcendo.Amt_Type := getAmtype_Endo_Fee(c_endorsementno,c_feeoperationtype,'',v_RiskCode);

     --??
     v_cursor_lfcendo.CurNo := '01';



     --??????????
     v_cursor_lfcendo.Amt_Incured_cnvt := d_getmoney;



     --?????
     v_cursor_lfcendo.Units := v_mult;


     --?????
     v_cursor_lfcendo.Sum_Ins := v_amnt;


		 --????(????)
     v_cursor_lfcendo.Proc_date := v_Edorvalidate;


     --???(????)
     v_cursor_lfcendo.Gained_date := c_enteraccdate;


   insert into lfcendo_fee values v_cursor_lfcendo;
   commit;
Exception
 When no_data_found Then
  Null;
 End;
end loop;

close v_cursor_ljagetendorse;
return Result_Endo;
 end;
end getLFCEndo_Fee;


/

