create FUNCTION chgpayintv(payintv in number) return number
is
tR number;
begin
 if payintv = 0 then
  tR := 0;
 else
  tR := 12;
 end if;

 return(tR);
end;


/

