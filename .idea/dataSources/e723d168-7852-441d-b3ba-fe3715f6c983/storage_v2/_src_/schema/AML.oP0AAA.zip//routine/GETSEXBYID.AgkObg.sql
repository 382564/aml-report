create Function getSexByID(v_idno in varchar2) Return varchar2 is
  Result varchar2(10);

  v_length Number;

  v_Num   char(1);

  v_mod  Number;

begin
  select length(v_idno) into v_length from dual;
  if v_length=18 then
    select substr(v_idno,17,1) into v_Num from dual;
  else if v_length=15 then
    select substr(v_idno,15) into v_Num from dual;
  else
    return -1;
  END IF;
  END IF;

  select mod(v_Num,2) into v_mod from dual;

  if(v_mod=0) then
    Result:='1';
  else
    Result:='0';
  END IF;
return(Result);
End getSexByID;


/

