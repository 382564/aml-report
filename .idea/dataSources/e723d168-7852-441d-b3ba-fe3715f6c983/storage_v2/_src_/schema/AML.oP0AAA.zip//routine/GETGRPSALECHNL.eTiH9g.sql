create function GETGRPSALECHNL(tPm in VARCHAR, tAgentCode in VARCHAR) return VARCHAR is
  rCode VARCHAR(20) ;
  tCodeType VARCHAR(20);
  tACType VARCHAR(20);
  tCode VARCHAR(20);
begin
  tCodeType := 'salechnl';
  if   trim(tPm)= '03'  or trim(tPm)='3' then
     select  actype into tACType from  lacom where   agentcom=tAgentCode;
     tCode :=getCode('actype',tACType);
     rCode :=getCode('agentsale',tCode);
  else
     if trim(tPm) ='2' or trim(tPm)='02' then
        rCode := '01';
     else
        rCode :=' ';
     end if;
  end if;

  return(rCode);
end GETGRPSALECHNL;


/

