create function getContNoByActugetno_769(p_actugetno   varchar2,
                                                    p_otherno     varchar2,
                                                    p_othernotype varchar2)
  return varchar2 is
  --tempContNo INTEGER;
  Result varchar2(20);
begin
  -- 暂收费退费
   -- 暂收费退费
    if p_othernotype = '4' then
      select nvl(lcco.contno, '')
        into Result
        from ljtempfee ljt, lccont lcco
       where ljt.tempfeeno = p_otherno
         and lcco.prtno = ljt.otherno
         and rownum = 1;
    -- 保单网点
  elsif p_othernotype in ('3', '10') then
    select case
             when lja.grpcontno <> '00000000000000000000' then
              lja.grpcontno
             else
              lja.contno
           end
      into Result
      from ljagetendorse lja, lccont lcc
     where lja.actugetno = p_actugetno
       and lja.contno = lcc.contno
       and rownum = 1;

    -- 理赔付费
  elsif p_othernotype = '5' then
    select lpc.contno
      into Result
      from ljagetclaim lpc
     where lpc.actugetno = p_actugetno
       and rownum = 1;
    -- 溢缴退费  个险溢交退费
  elsif p_othernotype = '6' then
    select p_otherno into Result from dual;
    -- 溢缴退费  团险溢交退费
  elsif p_othernotype = '8' then
    select p_otherno into Result from dual;
    -- 网销手续费支付
  elsif p_othernotype = '12' then
    select p_otherno into Result from dual;
  else
    select p_otherno into Result from dual;
  end if;
  return(Result);
end getContNoByActugetno_769;

/

