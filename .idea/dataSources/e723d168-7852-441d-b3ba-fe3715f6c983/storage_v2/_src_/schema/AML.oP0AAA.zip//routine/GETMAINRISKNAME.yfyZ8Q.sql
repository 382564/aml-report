create Function getMainRiskName(v_code in varchar2) Return varchar2 is
  Result varchar2(100);

  v_doublemainriskflag Number;

begin
  select case
           when exists (select 1
                   from ldcode
                  where codetype = 'DoublemainRisk'
                    and code = v_code) then
            1
           else
            0
         end
    into v_doublemainriskflag
    from dual;
  if v_doublemainriskflag=1 then
    select codename into Result from ldcode where codetype = 'DoublemainRisk' and code = v_code;
  else
    select count(1) into v_doublemainriskflag from lmriskapp where riskcode=v_code;
    if v_doublemainriskflag = 0 then
      select contplanname into Result  from ldplan where contplancode = v_code;
      else
      select riskname into Result from lmriskapp where riskcode=v_code;
      end if;
  END IF;
return(Result);
End getMainRiskName;

/

