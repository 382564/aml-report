create function getagentcodecount(contno1 in lcpol.contno%type,
                                             paycount1 in ljapayperson.paycount%type)
  return number is
  agentcodecount number(16);
begin
  select count(*)
  into agentcodecount
  from (select grpcontno contno,
               agentcode,
               busirate,
               trunc(modifydate, 'dd') startdate,
               date '2050-1-1' enddate
          from lacommisiondetail
        union all
        select grpcontno,
               agentcode,
               busirate,
               trunc(modifydate, 'dd') startdate,
               trunc(makedate2, 'dd') enddate
          from lacommisiondetailb) lm,
       (select agentcode,
               upagent,
               startdate,
               case
                 when lead(startdate - 1, 1)
                  over(order by agentcode, startdate) < startdate then
                  startdate
                 else
                  lead(startdate - 1, 1) over(order by agentcode, startdate)
               end enddate
          from (select agentcode, upagent, trunc(startdate, 'dd') startdate
                  from latree
                union all
                select agentcode, upagent, trunc(startdate, 'dd') startdate
                  from latreeb
                 order by startdate)
        union all
        select agentcode,
               upagent,
               trunc(startdate, 'dd') startdate,
               date '2050-1-1' enddate
          from latree) lt,
       ljapayperson lj,
       ljapay lja,
       lcpol p,
       laagent a,
       labranchgroup b
 where lj.payno = lja.payno
   and p.payintv = '12'
   and lm.contno = lj.contno
   and lm.contno = contno1
   and lj.paycount = paycount1
   and lm.agentcode = lt.agentcode
   and lm.agentcode = a.agentcode
   and a.agentgroup = b.agentgroup
   and lj.polno = p.polno
   and lja.othernotype in ('2','10')
   and lj.paycount>=2
   and lj.makedate > lt.startdate
   and lj.makedate <= lt.enddate
   and lj.makedate > lm.startdate
   and lj.makedate <= lm.enddate;
return(agentcodecount);
end getagentcodecount;


/

