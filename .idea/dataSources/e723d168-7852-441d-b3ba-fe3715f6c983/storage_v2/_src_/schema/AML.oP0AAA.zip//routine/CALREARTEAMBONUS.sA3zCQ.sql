create FUNCTION CALREARTEAMBONUS (tAgentCode in varchar2, tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,TempBegin in date,TempEnd in date) return number is
  FYC1   number := 0;
  FYC2   number := 0;
  FYC3   number := 0;
  FYC4   number := 0;
  tFYC   number := 0;

  Result number;
  tDrawRate  number := 0;
  tCalBegin date := add_months(TempBegin,1);

  cursor d1_View is
   select branchattr from labranchgroup
    where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
              and CommBreakFlag='0'
              and (AgentGrade='A04' or AgentGrade='A05')
              and months_between(tCalBegin,startdate)<=12
              and trim(RearAgentCode)= trim(tAgentCode)
          )
          and EndFlag<>'Y'
          and branchlevel='01';

  cursor d2_View is
      select branchattr from labranchgroup
      where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
              and CommBreakFlag='0'
              and (AgentGrade='A04' or AgentGrade='A05')
              and months_between(tCalBegin,startdate)>12
              and trim(RearAgentCode)=trim(tAgentCode)
          )
          and EndFlag<>'Y'
          and branchlevel='01';

  cursor i1_View is
    select branchattr from labranchgroup
    where exists
          ( select 'X' from LATreeAccessory a
            where a.agentcode = labranchgroup.branchmanager
            and a.CommBreakFlag='0'
         		and (a.AgentGrade='A04' or a.AgentGrade='A05')
         		and months_between(tCalBegin,a.startdate)<=12
         		and exists
             ( select 'Y' from latreeaccessory
               where agentcode = a.rearagentcode
                 and (agentgrade='A04' or agentgrade = 'A05')
                 and commbreakflag = '0' and RearAgentCode= trim(tAgentCode))
          )
          and EndFlag<>'Y'
          and branchlevel='01';

  cursor i2_View is
      select branchattr from labranchgroup
      where exists
          ( select 'X' from LATreeAccessory a
            where a.agentcode = labranchgroup.branchmanager
            and a.CommBreakFlag='0'
         		and (a.AgentGrade='A04' or a.AgentGrade='A05')
         		and months_between(tCalBegin,a.startdate)>12
         		and exists
             ( select 'Y' from latreeaccessory
               where agentcode = a.rearagentcode
                 and (agentgrade='A04' or agentgrade = 'A05')
                 and commbreakflag = '0' and RearAgentCode= trim(tAgentCode))
          )
          and EndFlag<>'Y'
          and branchlevel='01';

--???????
begin

  --???????
  for v_View in d1_View Loop
   ---tjj change 0308---
    ---tBranchAttr:= getbranchattr(v_View.branchcode);

    select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
    and payyear=0
    and caldate >= TempBegin
    and caldate <= TempEnd
    and trim(branchattr) = trim(v_View.branchattr)
    ;

    FYC1 := FYC1 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
  where drawStart = 0
    and drawEnd = 12
    and trim(AreaType)=trim(tAreaType)
    and trim(RearType)='01'
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;
  FYC1 := FYC1 * tDrawRate;


  --???????
  tFYC := 0;
  tDrawRate := 0;
  for v_View in d2_View Loop
  ---tjj change 0308---
    ---tBranchAttr:= getbranchattr(v_View.branchcode);

    select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
    and payyear=0
    and caldate >= TempBegin
    and caldate <= TempEnd
    and trim(branchattr) = trim(v_View.branchattr)
    ;

    FYC2 := FYC2 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
  where drawStart = 13
    and trim(AreaType)=trim(tAreaType)
    and trim(RearType)='01'
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;
  FYC2 := FYC2 * tDrawRate;


  --???????
  tFYC := 0;
  tDrawRate := 0;
  for v_View in i1_View Loop
    ---tjj change 0308---
   --- tBranchAttr:= getbranchattr(v_View.branchcode);
    select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
    and payyear=0
    and caldate >= TempBegin
    and caldate <= TempEnd
    and trim(branchattr) = trim(v_View.branchattr)
    ;

    FYC3 := FYC3 + tFYC;
  end Loop;

  select nvl(drawrate,0) into tDrawRate from lawageradix
  where drawStart = 0
    and drawEnd = 12
    and trim(AreaType)=trim(tAreaType)
    and trim(RearType)='02'
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;
  FYC3 := FYC3 * tDrawRate;


  --???????
  tFYC := 0;
  tDrawRate := 0;
  for v_View in i2_View Loop
     ---tjj change 0308---
    ---tBranchAttr:= getbranchattr(v_View.branchcode);
    select nvl(sum(fyc),0) into tFYC from lacommision
    where commdire = '1'
    and payyear=0
    and caldate >= TempBegin
    and caldate <= TempEnd
    and trim(branchattr) = trim(v_View.branchattr)
    ;

    FYC4 := FYC4 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
  where trim(RearType)='02'
    and drawStart = 13
    and trim(AreaType)=trim(tAreaType)
    and trim(agentgrade)=trim(tAgentGrade)
    and trim(wagecode)=trim(tWageCode)
    ;
  FYC4 := FYC4 * tDrawRate;

  Result := FYC1 + FYC2 + FYC3 + FYC4;
  return(Result);
end CALREARTEAMBONUS;


/

