create function getCommisionRate(cRiskcode in varchar2,
                                            cPayintv  in number,
                                            cPayyear  in number,
                                            cPayCount in number)
  return number is
  Result number;
begin
  if cPayintv = 0 then
    select nvl(max(rate),0)
      into Result
      from laratecommision
     where riskcode = cRiskcode
       and PAYINTV = cPayintv;
  else
    select nvl(max(rate),0)
      into Result
      from laratecommision
     where riskcode = cRiskcode
       and PAYINTV = cPayintv
       and year = cPayyear
       and curyear = cPayCount;
  end if;
  return(Result);
end getCommisionRate;

/

