create function getFXAmnt(P_ContNo varchar2,P_RiskCode varchar2,P_Age varchar2) return number is
  v_SumAmnt number;

  v_Num NUMBER;
  v_Sum1 NUMBER;
  v_Sum2 NUMBER;
  ---主险保费
  v_Prem NUMBER;
  ---结算利率
  v_Rate NUMBER;

begin
  v_SumAmnt := 0;
  v_Sum1 := 0;
  v_Sum2 := 0;
  select nvl(rate, 0)
    into v_Rate
    from (select rate
            from lminsuaccrate
           where riskcode = P_RiskCode
             and ratestate = '1'
           order by baladate desc)
   where rownum = 1;

   select nvl(prem, 0)
    into v_Prem
    from (select prem
            from lcpol l
           where contno = P_ContNo
             and l.polno = l.mainpolno)
   where rownum = 1;

   --判断年龄
  IF P_Age >=0 and P_Age <= 8 THEN
    v_Num := 9;
    v_Sum1 := v_Prem * 0.12 * (1-0.015) * 0.05 *  Power((1+ v_Rate),10);
    FOR i IN 1 .. v_Num LOOP

    v_Sum2 := v_Sum2 + v_Prem * 0.12*0.05*Power((1+v_Rate),10-i);

    END LOOP;
  ELSE IF P_Age >=9 and P_Age <= 17 THEN
    v_Num := 17-P_Age;
    v_Sum1 := v_Prem * 0.12 * (1-0.015) * 0.05 * Power((1+ v_Rate),18-P_Age);
    FOR i IN 1 .. v_Num LOOP

    v_Sum2 := v_Sum2 + v_Prem * 0.12*0.05*Power((1+v_Rate),18-P_Age-i);
    END LOOP;

  ELSE
    return(0);
  END IF;
  END IF;

  v_SumAmnt := v_Sum1 + v_Sum2;

  return(round(v_SumAmnt,2));
end getFXAmnt;

/

