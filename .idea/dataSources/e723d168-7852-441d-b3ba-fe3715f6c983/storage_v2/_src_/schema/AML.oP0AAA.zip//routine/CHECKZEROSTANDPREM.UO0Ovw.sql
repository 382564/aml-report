create function checkZeroStandPrem(tManageCom in VARCHAR2,tBranchType in VARCHAR2,tIndexCalNo in VARCHAR2) return integer IS
-------------------P#QiJG7qSP1#7Q2;N*0#,1j1#N*0---------------------------
  ADDCOUNT   INTEGER;
begin
  select count(*) into ADDCOUNT from lacommision
  where wageno=tIndexCalNo
  and  branchtype=tBranchType
  and  commdire<>'2'
  and  payyear<1
  and  transmoney<>0
  --add by jiaqiangli 2008-01-17 141812???????
  and  standprem=0 and riskcode not in ('241801','241802','141812')
  and  managecom like concat(tManageCom,'%')
  ;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkZeroStandPrem;


/

