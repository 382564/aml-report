create function Coincide_Equals_PayAndGet(p_actugetno in varchar2,
                                                     tBusType    in varchar2)
  return integer is
  Result        integer;
  v_Sumgetmoney integer;
  v_Sumpaymoney integer;
begin
  /*
  Result--表示收付大小情况
  --0收付相当
  --1付大于收
  ---1附小于收
  */
  begin
    select abs(a.sumgetmoney)
      into v_Sumgetmoney
      from ljaget a
     where a.actugetno = p_actugetno
       and a.othernotype = tBusType;
  exception
    when no_data_found then
      v_Sumgetmoney := 0;
    when others then
      v_Sumgetmoney := 0;
  end;
  begin
    select abs(a.sumactupaymoney)
      into v_Sumpaymoney
      from ljapay a
     where a.payno = p_actugetno
       and a.othernotype = tBusType;
  exception
    when no_data_found then
      v_Sumpaymoney := 0;
    when others then
      v_Sumpaymoney := 0;
  end;
  if v_Sumgetmoney > v_Sumpaymoney then
    Result := 1;
  elsif v_Sumgetmoney < v_Sumpaymoney then
    Result := -1;
  else
    Result := 0;
  end if;
  return(Result);
end Coincide_Equals_PayAndGet;


/

