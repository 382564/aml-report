create FUNCTION GetEmployAge(v_EmployDate IN DATE,v_indexcalno in varchar2)
RETURN integer IS
	v_EmployAge integer := 0;
  v_EmployMonth varchar2(6);
BEGIN

  select yearmonth into v_EmployMonth from lastatsegment where stattype = '5'
  and startdate <= v_EmployDate and v_EmployDate <= enddate;

  select months_between(to_date(v_indexcalno,'YYYYMM'),to_date(v_EmployMonth,'YYYYMM'))+1 into v_EmployAge from dual;

	RETURN v_EmployAge;
END;


/

