create function getUWGrade(tRiskSort1 in char,
    tRiskAmnt1 in number,
    tRiskSort2 in char,
    tRiskAmnt2 in number,
    tRiskSort4 in char,
    tRiskAmnt4 in number,
    tRiskSort6 in char,
    tRiskAmnt6 in number) return varChar2 is

  tUWGrade char(6);--?????????
  --minUWGrade char(6);--???????
  --maxUWGrade char(6);--???????

  tUWGrade1 char(6);--?????????
  tempUWGrade1 char(6);--?????????
  ttempUWGrade1 char(6);--?????????
  tUWGrade2 char(6);--?????????
  tempUWGrade2 char(6);--?????????
  ttempUWGrade2 char(6);--?????????
  tUWGrade4 char(6);--?????????
  tempUWGrade4 char(6);--?????????
  ttempUWGrade4 char(6);--?????????
  tUWGrade6 char(6);--?????????
  tempUWGrade6 char(6);--?????????
  ttempUWGrade6 char(6);--?????????


begin
  DBMS_OUTPUT.PUT_LINE('Begin');

  /* ????????*/
  select trim(min(uwpopedom))
    into tempUWGrade1
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort1 and maxamnt >= tRiskAmnt1;

  select trim(max(uwpopedom))
    into ttempUWGrade1
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort1 and maxamnt >= tRiskAmnt1;

   if ttempUWGrade1='X' then tUWGrade1:='A';
   else tUWGrade1 :=tempUWGrade1;
   end if;

   /* ????????*/
   select trim(min(uwpopedom))
    into tempUWGrade2
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort2 and maxamnt >= tRiskAmnt2;

   select trim(max(uwpopedom))
    into ttempUWGrade2
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort2 and maxamnt >= tRiskAmnt2;

   if ttempUWGrade2='X' then tUWGrade2:='A';
   else tUWGrade2 :=tempUWGrade2;
   end if;

   /* ????????*/
   select trim(min(uwpopedom))
    into tempUWGrade4
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort4 and maxamnt >= tRiskAmnt4;

   select trim(max(uwpopedom))
    into ttempUWGrade4
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort4 and maxamnt >= tRiskAmnt4;

   if ttempUWGrade4='X' then tUWGrade4:='A';
   else tUWGrade4 :=tempUWGrade4;
   end if;

   /* ????????*/
   select trim(min(uwpopedom))
    into tempUWGrade6
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort6 and maxamnt >= tRiskAmnt6;

   select trim(max(uwpopedom))
    into ttempUWGrade6
    from LDUWGradePerson
   where uwtype = '1'
     and uwkind = tRiskSort6 and maxamnt >= tRiskAmnt6;

   if ttempUWGrade6='X' then tUWGrade6:='A';
   else tUWGrade6 :=tempUWGrade6;
   end if;

  --????????? greatest??
  SELECT greatest(tUWGrade1,tUWGrade2,tUWGrade4,tUWGrade6) value into tUWGrade  from dual;

  DBMS_OUTPUT.PUT_LINE('grade--'||tUWGrade);
  return tUWGrade;

end getUWGrade;


/

