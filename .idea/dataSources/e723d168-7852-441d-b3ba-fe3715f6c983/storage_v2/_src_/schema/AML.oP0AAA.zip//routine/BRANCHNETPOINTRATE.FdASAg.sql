create FUNCTION BranchNetPointRate(
       TempBegin date, --????
       TempEnd date,   --????
       tBranchattr LACommision.Branchattr%TYPE --?????
       ) return number as   --???????
v_Rate number;--?????
v_count number;

begin

 select count(distinct AgentCom) into v_count from LAComToAgent where
   agentcom in (select agentcom from lacom where sellflag='Y' and CalFlag='Y') and
   agentgroup in (select agentgroup from labranchgroup where branchattr like substr(tBranchattr,0,8)||'%');

if v_count=0 then
  v_count:=10000000000;
  end if;

select nvl(
(select count(distinct AgentCom) from LACommision where
BranchAttr like substr(tBranchattr,0,8)||'%'
and tmakedate >=TempBegin  And tmakedate <=TempEnd )
/v_count, 0) into v_Rate from ldsysvar where sysvar = 'onerow';

return v_Rate;
End BranchNetPointRate;


/

