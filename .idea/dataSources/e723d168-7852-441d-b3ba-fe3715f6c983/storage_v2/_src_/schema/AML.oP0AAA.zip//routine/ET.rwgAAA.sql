create FUNCTION ET(tGrpContNo in char, tEdorType in char)
  return number is
  t_flag   number;
  t_count1 number;
  t_count2 number;

begin
  t_flag   := 0;
  t_count1 := 0;
  t_count2 := 0;

   --t_flag ??????????????,1????,0?????
  select case
           when exists
            (select 'X'
                   from dual
                  where tEdorType in
                        ('EA','XT','XS','IC','CT','BC')) then
            1
           else
            0
         end
    into t_flag
    from dual;

  --??????????,???????,????1
  if t_flag = 1 then
    return(1);
  end if;

  select count(*) into t_count1 from lcgrppol where grpcontno = tGrpContNo;

 --???????????????????????

 select count(*)
   into t_count2
   from lmriskedoritem
  where edorcode = tEdorType
    and riskcode in
        (select riskcode from lcgrppol where grpcontno = tGrpContNo);

  --????????????????????????
  if t_count1 = t_count2 then
    return(1);
  else
    return(0);
  end if;

end ET;


/

