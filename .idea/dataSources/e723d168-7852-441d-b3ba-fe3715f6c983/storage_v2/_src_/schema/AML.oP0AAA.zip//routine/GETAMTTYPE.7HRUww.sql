create function GETAMTTYPE(tType in VARCHAR, tValue in VARCHAR) return VARCHAR is
  rAmtType VARCHAR(2);
begin
    if  trim(lower(tType)) = 'prem'  then
         if  trim(tValue) ='1'  then
             rAmtType := '01';
          else
             rAmtType := '02';
          end if;
    end if;
  return(rAmtType);
end GETAMTTYPE;


/

