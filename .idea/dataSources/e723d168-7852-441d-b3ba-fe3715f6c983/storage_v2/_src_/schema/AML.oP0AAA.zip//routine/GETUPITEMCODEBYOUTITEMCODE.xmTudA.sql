create function getUpItemCodeByOutItemCode(tOutItemCode in varchar2,tNewOldFlag in varchar2) return LFItemRela.ItemCode%type as
tUpItemCode LFItemRela.UpItemCode%type;
begin
select UpItemCode into tUpItemCode from LFItemRela where trim(OutItemCode)= trim(tOutItemCode) and trim(newoldflag)=trim(tNewOldFlag);
return(tUpItemCode);
end;


/

