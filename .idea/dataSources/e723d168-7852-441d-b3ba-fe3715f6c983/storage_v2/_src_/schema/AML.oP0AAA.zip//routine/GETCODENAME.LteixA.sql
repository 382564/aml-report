create FUNCTION GetCodeName(tcode ldcode.code%Type, tcodetype in ldcode.codetype%Type) return ldcode.codename%Type is
Result ldcode.codename%Type ;
begin
--??????????LDCODE???????
  select codename into Result from ldcode where code=tcode and codetype=tcodetype;
  return(Result);
end;


/

