create function calcurvalidate (tpolno in varchar2,tcurrentdate in date )
    return date
is
    v_cvalidate date;
    v_comparedate date;
begin
    select cvalidate into v_cvalidate from lcpol where polno = tpolno;
    v_comparedate:= add_months(v_cvalidate,12);
    WHILE v_comparedate<=tcurrentdate loop
          v_cvalidate:= add_months(v_cvalidate,12);
          v_comparedate:= add_months(v_cvalidate,12);
    END LOOP;
    return v_cvalidate;
end calcurvalidate;


/

