create function getStandPrem(cPayIntv  in lcpol.payintv%type,
                                        cPayYears in lcpol.payyears%type,
                                        cPrem     in lcpol.prem%type,
                                        cPolNo    in lcpol.polno%type)
  return number is
  Result     number;
  cTransPrem number;
  /*Ag001_20150312_李萌萌_修改标准保费计算函数，增加趸交处理，保费乘以0.1，注释险种费率计算规则*/
  --cStandPremRate number;
begin
  if cPayIntv = 1 then
    --月缴
    cTransPrem := cPrem * 12;
  elsif cPayIntv = 3 then
    --季缴
    cTransPrem := cPrem * 4;
  elsif cPayIntv = 6 then
    --半年缴
    cTransPrem := cPrem * 2;
  elsif cPayIntv = 0 then
    --半年缴
    cTransPrem := cPrem * 0.1;
  else
    --年缴
    cTransPrem := cPrem;
  end if;
  --cStandPremRate := getStandPremRate(cPayIntv, cPayYears, cPolNo);
  Result := round(nvl(cTransPrem, 0), 2);
  return(Result);
end getStandPrem;


/

