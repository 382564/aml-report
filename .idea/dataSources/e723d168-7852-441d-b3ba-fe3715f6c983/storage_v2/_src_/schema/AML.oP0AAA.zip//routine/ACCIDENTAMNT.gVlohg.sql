create function ACCIDENTAMNT( tInsuredNo in varchar2 ) return LCPol.Amnt%TYPE is
    tLifeAmnt LCPol.Amnt%TYPE;
 t_sql LMCalMode.calsql%TYPE ;
    t_cursor NUMBER;
    t_temp NUMBER;
    t_temp_SumAmnt  LCPol.Amnt%TYPE ;
    CURSOR t_CalSQLSet IS
  select calsql
  from  lmcalmode
  where type = 'I';

begin
  tLifeAmnt := 0 ;
  t_temp_SumAmnt := 0 ;
  t_sql := '' ;
  t_cursor := DBMS_SQL.OPEN_CURSOR;

  FOR  t_CalSQL IN t_CalSQLSet LOOP  --????SQL??
       --DBMS_OUTPUT.PUT_LINE(trim(t_CalSQL.calsql));
       --?SQL??"?polno?"??????????
       t_sql := REPLACE(trim(t_CalSQL.calsql),'?insuredno?',tInsuredNo) ;
       --DBMS_OUTPUT.PUT_LINE(t_sql);
       DBMS_SQL.PARSE(t_cursor, t_sql, DBMS_SQL.native);
       --???????????t_temp_SumAmnt?
       DBMS_SQL.DEFINE_COLUMN(t_cursor,1,t_temp_SumAmnt);
       --????SQL??
       t_temp := DBMS_SQL.EXECUTE(t_cursor);
       LOOP
         --?????????? t_temp_SumAmnt,?????
         IF DBMS_SQL.FETCH_ROWS(t_cursor) > 0 THEN
           DBMS_SQL.COLUMN_VALUE(t_cursor,1,t_temp_SumAmnt);
            IF t_temp_SumAmnt > 0 THEN
                tLifeAmnt := tLifeAmnt +  t_temp_SumAmnt;
            END IF;
        ELSE
          EXIT;
        END IF;
      END LOOP;

 END LOOP;

  --DBMS_OUTPUT.PUT_LINE(' ???????? done !');
  DBMS_SQL.CLOSE_CURSOR(t_cursor);
  return(tLifeAmnt);

END;


/

