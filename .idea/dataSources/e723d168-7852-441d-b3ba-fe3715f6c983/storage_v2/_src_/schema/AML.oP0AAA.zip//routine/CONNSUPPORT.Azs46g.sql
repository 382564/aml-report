create function ConnSupport(tAgentGrade in varchar2, tManageCom in varchar2, tWageCode in varchar2,tAgentCode in varchar2,TempBegin in date,TempEnd in date) return number is
  tMonthLimit     number(12,2):=0;
  tStandMoney     number(20,10):=0;
  tEmployDate     date;
  tIndueFormDate  date;

  tGroup          varchar2(20);
  tBranchAttr     varchar2(255);
  tStartDate      date;
  tPremiumSum     number(20,10):=0;
  tIntvl          integer:=0;
  tArrPeriod      integer:=0;
  tLinkEnd        date;
  tEDay           varchar2(2);
  tSendMons       integer:=0;
  tBaseRate       number(20,10):=0;
  tTempMon        varchar2(2);
  tEmployMon      varchar2(2);
  tArrSum         number(20,10):=0;
  LoopCount       integer:=0;
  tBeforeDate     varchar2(6);
  tF22            number(20,10):=0;
  tSumF22         number(20,10):=0;
  tArrStandMoney  number(20,10):=0;
  tAssessDate     date;
  tTempDate       date;

  tArrStandSum    number(20,10):=0;
  tArrPaySum      number(20,10):=0;
  tIndexCalNo     varchar2(6);
  tIndexCalNo1    varchar2(6);
  tBaseRate1      number(20,10):=0;


  --???????
  tAssStandSum    number(20,10):=0;
  tAssPaySum      number(20,10):=0;

  --?????????A04
  tJudgeFlag      varchar2(1);
  tManageComCond  varchar2(10);
  iCount          integer := 0;
  tYearCount      integer := 0;

  --??????
  tEmployLimit    varchar2(2);

  tAreaType       varchar2(2);

  ResultRepay          number(20,10):=0;
  ResultCurrMonth      number(20,10):=0;

  --???????????????
  tYearMonth      varchar2(6);

  --????:2006-08-28 LL
  --????:????????????????
  --          ???:????10??? ; ???:?????????
  tVersionType    varchar2(2);    --???????

begin
  --??:2006-04-11 LL
  --???????????????????,??????????????
  tYearMonth := to_char(TempBegin,'yyyymm');
  select count(*) into iCount from laauthorization a
             where a.authtype = '01' and a.branchtype = '1' and a.code1 = tAgentCode
             and a.code2 = tYearMonth and a.code3 = tAgentGrade ;

  if iCount <= 0 then
    return 0;
  end if;

  tManageComCond := trim(tManageCom);

  --??????????
  select employdate,indueformdate,agentgroup,startdate into tEmployDate,tIndueFormDate,tGroup,tStartDate from laagenttreeview
  where agentcode = trim(tAgentCode);

  tBranchAttr:=trim(getbranchattr(tGroup));

  --???????????
  if tIndueFormDate <> tEmployDate then
    return(0);
  end if;
  --??:2006-03-13 LL ????
  --??????????????
  tJudgeFlag := doJudgeGrade(tAgentCode);
  if tJudgeFlag = 'N' then
    return(0);
  end if;

  tAreaType:=Calagentareatype(tAgentCode,twagecode ,tManageCom );

  --??:2004-12-20 LL
  --????
  select count(*) into iCount from lalinkassess
  where managecom like substr(tManageComCond,1,6)||'%'
  and agentgrade = tAgentGrade
  and areatype=tAreaType
  ;

  if iCount <= 0 then
    return 0;
  end if;

  --???????????
  select nvl(arrangeperiod,0),nvl(linkenddate,to_date('3000-01-01','yyyy-mm-dd')) into tArrPeriod,tLinkEnd
  from lalinkassess
  where managecom like substr(tManageComCond,1,6)||'%'
  and agentgrade = tAgentGrade
  and areatype=tAreaType
  ;

  --???????????????
  if TempBegin > tLinkEnd then
    return(0);
  end if;

  --????:2006-08-28 LL
  --????:????????????????
  --          ???:????10??? ; ???:?????????
  select count(*) into iCount from ldcoderela where trim(relatype) = 'agentedition'
          and trim(code1)=substr(tManageCom,1,4);
  if iCount <= 0 then
    return 0;
  end if;

  select trim(code2) into tVersionType from ldcoderela where trim(relatype) = 'agentedition'
          and trim(code1)=substr(tManageCom,1,4);

  if tVersionType = '01' then
    --?????
    tEDay := to_char(tEmployDate,'dd');

    --???????
    tTempMon := to_char(TempBegin,'mm');
    tEmployMon := to_char(tEmployDate,'mm');

    tEmployLimit := trim(getEmployLimit('EmployLimit'));
    --??15?????,?????,??????
    --tongmeng 2005-12-30 modify
    --?????????
    if(to_char(TempBegin,'yyyy') = to_char(tEmployDate,'yyyy')) then
        if tTempMon = tEmployMon then
            if tEDay > tEmployLimit then
                return(0);
            end if;
        end if;
    end if;

    if to_char(TempBegin,'yyyy') = to_char(tEmployDate,'yyyy') then
      tSendMons := tTempMon - tEmployMon + 1;
    else
      tYearCount := to_char(TempBegin,'yyyy') - to_char(tEmployDate,'yyyy');
      tSendMons := 12 - tEmployMon + 1;
      tSendMons := tSendMons + tTempMon;
      tSendMons := tSendMons + (tYearCount-1)*12;
    end if;
    if tEDay > tEmployLimit then
      tSendMons := tSendMons - 1;
    end if;
  else
    --??????
    tSendMons := NAGetEmpMonIntv(tAgentCode,TempBegin);
  end if;

  if tSendMons <= 0 then
    return(0);
  end if;

  --?LAlinkwage???????????????
  select count(*) into iCount from lalinkwage
      where trim(payperiodtype)='01'
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = trim(tAgentGrade)
      and wagecode = trim(tWageCode)
      and areatype=tAreaType
        ;
  if iCount <= 0 then
    return 0;
  end if;

  --????:2006-03-13 LL
  --????:?????????????????????
  if tSendMons < tArrPeriod then
    return(0);
  end if;

  -- ?????????????(??????????2??)
  if tSendMons = tArrPeriod then
    select count(*) into iCount from lalinkwage
      where trim(payperiodtype)='01'
        and trim(paymonth)= trim(to_char(tSendMons,'09'))
        and managecom like substr(tManageComCond,1,6)||'%'
        and agentgrade = tAgentGrade
        and wagecode = tWageCode
        and areatype=tAreaType
        ;
    if iCount <= 0 then
      return 0;
    end if;

    select BaseRate,MonthLimit,StandMoney,BaseRate1 into tArrStandMoney,tMonthLimit,tStandMoney,tBaseRate1 from lalinkwage
    where trim(payperiodtype)='01'
      and trim(paymonth)=trim(to_char(tSendMons,'09'))
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = tAgentGrade
      and wagecode = tWageCode
      and areatype=tAreaType
      ;

    if tSendMons = tArrPeriod then
      select sum(baserate),sum(standmoney) into tArrStandSum,tArrPaySum from lalinkwage
      where trim(payperiodtype)='01'
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = trim(tAgentGrade)
        and wagecode = trim(tWageCode)
        and areatype=tAreaType
        ;
    end if;
  --???????????,?????????????
  else
    --????:2006-03-16 LL
    --????:??????????0
    select count(*) into iCount from LALinkWage
    where trim(payperiodtype)='02'
      and trim(paymonth)=trim(to_char(tSendMons-tArrPeriod,'09'))
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = trim(tAgentGrade)
      and wagecode = trim(tWageCode)
      and areatype=tAreaType
      ;

    if iCount <= 0 then
      return 0;
    end if;

    --??tAgentGrade,tManageCom,tWageCode ?LALinkWage??????????
    select StandMoney,BaseRate,MonthLimit,BaseRate1 into tStandMoney,tBaseRate,tMonthLimit,tBaseRate1 from LALinkWage
    where trim(payperiodtype)='02'
      and trim(paymonth)=trim(to_char(tSendMons-tArrPeriod,'09'))
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = trim(tAgentGrade)
      and wagecode = trim(tWageCode)
      and areatype=tAreaType
      ;

    if tSendMons = tMonthLimit+tArrPeriod then
      select sum(BaseRate),sum(StandMoney) into tAssStandSum,tAssPaySum from LALinkWage
      where trim(payperiodtype)='02'
      and managecom like substr(tManageComCond,1,6)||'%'
      and agentgrade = trim(tAgentGrade)
        and wagecode = trim(tWageCode)
        and areatype=tAreaType
        ;
    end if;
  end if;


  --???????
  tIntvl := tMonthLimit + tArrPeriod;


  --??????????????????
  if tSendMons > tIntvl  then
    return(0);
  end if;


  --??????????
  tAssessDate:= getDate(tEmployDate,tArrPeriod,TempBegin);


  --?????
  if tSendMons = 1 then
    tPremiumSum := getNewtransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
  else
    tPremiumSum := getNewtransmoney(TempBegin,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
  end if;

  --????:2006-03-13 LL
  --????:?????????????,??????????,??????,????
  --          ???100%
  if tSendMons = tArrPeriod then
    if tSendMons = tArrPeriod then
      tArrSum := getNewtransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      if tArrSum >= tArrStandSum then
        --????????????????
        LoopCount := tArrPeriod - 1;
        for tCount in 1..LoopCount loop
          tTempDate := add_months(TempBegin,-tCount);
          tBeforeDate := to_char(tTempDate,'yyyymm');
          ---??2004-02-18??,??LAWage???F22?????LAIndexInfo???
          ---T31??
          select nvl(T31,0) into tF22 from laindexinfo
          where indextype='01'
            and trim(indexcalno) = trim(tBeforeDate)
            and agentcode = trim(tAgentCode)
            ;
          tSumF22 := tSumF22 + tF22;
        end loop;
        ResultRepay := (tArrPaySum - tSumF22) * 0.8;
        --return(Result);
      else
      ResultRepay:=0;    --caigang 2004-04-28??
      end if;            --
      end if;

      --????:2006-03-13 LL
      --????:????????????????
      ResultCurrMonth := 0;
  end if;


  --??????????
  if tSendMons>tArrPeriod and tSendMons<=tIntvl then
    --????:2006-03-15 LL
    --????:?????????????????????????80%;???????
    --          ??????????????,??????80%??????
    if tSendMons = tIntvl then
      --????:2006-03-14 LL
      --????:??????????????????????80%
      if tArrPeriod > 0 then
        tArrSum := getNewtransmoney(tAssessDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      else
        tArrSum := getNewtransmoney(tEmployDate,TempEnd,tBranchAttr,tAgentGrade,tAgentCode,'P');
      end if;
      if tArrSum >= tAssStandSum then
        --????????????????
        tIndexCalNo := to_char(tAssessDate,'yyyymm');
        tIndexCalNo1 := to_char(TempEnd,'yyyymm');
        ---??2004-02-18??,??LAWage???F22?????LAIndexInfo???
          ---T31??
        select nvl(sum(T31),0) into tSumF22 from laindexinfo
        where indextype='01'
          and trim(IndexCalNo)>=trim(tIndexCalNo)
          and trim(IndexCalNo)<=trim(tIndexCalNo1)
          and agentcode=trim(tAgentCode)
          ;
        --???80%
        ResultRepay := (tAssPaySum - tSumF22/0.8) * 0.8;
      else
      ResultRepay:=0;
      end if;
    else
      ResultRepay:=0;
    end if;

    --????:2006-03-13 LL
    --????:????????????????????????80%
    if tPremiumSum >= tBaseRate then
       ResultCurrMonth := tStandMoney * 0.8;
    else
       /*if tPremiumSum/(tBaseRate) >= tBaseRate1 then
         ResultCurrMonth := tStandMoney * tPremiumSum/tBaseRate * 0.8;
       else
         ResultCurrMonth := 0;
       end if;
       */
       --????:2006-03-14 LL
       --????:??????????????
       ResultCurrMonth := 0 ;
    end if;

  end if;
 if (ResultCurrMonth>ResultRepay) then
 return ResultCurrMonth;
 else
 return ResultRepay;
 end if;
end ConnSupport;


/

