create function chgamnt619(type in varchar2,insured in varchar2) return number
is
tR number(1);
begin
 if instr( insured, type ) > 0 then
  tR := '1';
 else
  tR := '0';
 end if;

 return(tR);
end;


/

