create function getDate(StartDate in date, intvl in integer,TempBegin in date) return date is
  tDay      varchar2(2);
  tTempDay  varchar2(2);
  tIntvl    integer:=0;
  tEmployLimit  varchar2(2);
  Result    date;
begin
  tEmployLimit := trim(Getemploylimit('EmployLimit'));
  tIntvl := intvl;
  tDay := to_char(StartDate,'dd');
  tTempDay := to_char(TempBegin,'dd');
  if tTempDay = '01' then
    if tDay > tEmployLimit then
      tIntvl := tIntvl+1;
    end if;
    Result := getMonthStart( StartDate,tIntvl,'1');
  else
    if tDay <= tEmployLimit then
      tIntvl := tIntvl-1;
    end if;
    Result := getMonthEnd( StartDate,tIntvl,'1');
  end if;

  return(Result);
end getDate;


/

