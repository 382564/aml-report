create procedure cal_prip(startdate in varchar2,
                                     enddate   in varchar2,
                                     busstype  in varchar2,
                                     massage  out varchar2) is
  v_sql   varchar2(12000);
  v_code  ldcode1.code%type;
  v_code1 ldcode1.code1%type;

  type t_code1_calsql is record(
    code   ldcode1.code%type,
    code1  ldcode1.code1%type,
    calsql varchar2(12000));
  v_code1_calsql t_code1_calsql;

  type t_lmcalmode_prip is record(
    calcode lmcalmode_prip.calcode%type,
    calsql1 varchar2(12000));

  v_lmcalmode_prip t_lmcalmode_prip;

  type t_sql_cur is ref cursor;
  v_sql_cur t_sql_cur;

begin

  v_sql := 'delete from TEMP_LCPOLTRANSACTION';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LAAGENT';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LASALES';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCBNF';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCCONT';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCINSUREACC';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCINSURED';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCPRODINSURELA';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LCPRODUCT';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LJAGETLIVBENE';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LJAPAY';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LJDIVDISTRIB';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LJTEMPFEE';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LLBNF';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LLCLAIMPOLICY';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LMPRODUCT';
  execute immediate v_sql;

  v_sql := 'delete from TEMP_LJAGET';
  execute immediate v_sql;

  open v_sql_cur for
    select calcode, (concat(concat(calsql1, calsql2), calsql3))
      from lmcalmode_prip
     where --calcode in ('prip01', 'prip47')
          --and calcode not in ('prip16','prip23','prip44','prip47','prip43')
          calcode like 'prip%' and calcode  not in ('prip99'，'prip01')
          --calcode = 'prip40'
       and type = 'HH'
     order by calcode;

  loop
    fetch v_sql_cur
      into v_lmcalmode_prip;
    exit when v_sql_cur%notfound;

    v_sql := v_lmcalmode_prip.calsql1;
    v_sql := REPLACE(trim(v_sql), '?STARTDATE?', trim(startdate));
    v_sql := REPLACE(trim(v_sql), '?ENDDATE?', trim(enddate));

    DBMS_OUTPUT.put_line('Message: ' || v_lmcalmode_prip.calcode);
    --DBMS_OUTPUT.put_line ('Message: ' || v_sql);

    execute immediate v_sql;

    commit;
  end loop;

  if busstype = 'HH' then
    open v_sql_cur for
      select code,
             code1,
             (select (concat(concat(calsql1, calsql2), calsql3))
                from lmcalmode_prip
               where calcode = ldcode1.codename)
        from ldcode1
       where codetype = 'pr_busstype_relation'
         and code <> '01'
         and ldcode1.codename <> 'HH0010'
       order by codename;

    loop
      fetch v_sql_cur
        into v_code1_calsql;
      exit when v_sql_cur%notfound;
      v_code  := v_code1_calsql.code;
      v_code1 := v_code1_calsql.code1;
      v_sql   := v_code1_calsql.calsql;
      v_sql   := REPLACE(trim(v_sql), '?STARTDATE?', trim(startdate));
      v_sql   := REPLACE(trim(v_sql), '?ENDDATE?', trim(enddate));
      v_sql   := REPLACE(trim(v_sql), '?busstype?', trim(v_code));

      DBMS_OUTPUT.put_line('Message: ' || v_code1_calsql.code1);
      --DBMS_OUTPUT.put_line ('Message: ' || v_sql);

      execute immediate v_sql;
    end loop;
  else
    open v_sql_cur for
      select code1,
             (select calsql from lmcalmode where calcode = ldcode1.codename)
        from ldcode1
       where codetype = 'pr_busstype_relation'
         and code <> '01'
       order by code, code1;

    loop
      fetch v_sql_cur
        into v_code1_calsql;
      exit when v_sql_cur%notfound;
      v_code1 := v_code1_calsql.code1;
      v_sql   := v_code1_calsql.calsql;
      v_sql   := REPLACE(trim(v_sql), '?STARTDATE?', trim(startdate));
      v_sql   := REPLACE(trim(v_sql), '?ENDDATE?', trim(enddate));
      execute immediate v_sql;
    end loop;

  end if;

  commit;
  if (v_sql_cur%isopen) then
    close v_sql_cur;
  end if;
exception
  when others then
    massage := SUBSTR(SQLERRM, 1, 200);
    DBMS_OUTPUT.put_line('Message: ' || SQLERRM);
    rollback;
    if (v_sql_cur%isopen) then
      close v_sql_cur;
    end if;
end cal_prip;

/

