create function fnc_345_1(c_contno char,c_PolNo char,c_insuredno char,c_caseno char) return number  is
  Result number;
  t_customer1 lcinsured.insuredno%TYPE;
  t_customer2 lcinsured.insuredno%TYPE;
  t_count1 number;
  t_count2 number;
  temp1 number;
begin
  result :=0;
  --???????????,????????????
  select insuredno into t_customer1 from lcinsured where relationtomaininsured ='00' and contno=c_contno ;
  select insuredno into t_customer2 from lcinsured where relationtomaininsured ='07' and contno=c_contno ;
  select nvl(count('X'),0) into temp1 from dual where c_insuredno in (t_customer1,t_customer2);
  --????????????????????,???0
  if temp1=1 and ( t_customer1 is not null) and (t_customer2 is not null) then
     --????????????
     select nvl(count(1),0) into t_count1  from llcase a, LLAppClaimReason b where a.caseno=c_caseno and a.caseno=b.caseno  and b.reasoncode in ('102')  and a.customerno in (t_customer1,t_customer2);
     --??????,?????????????
     if t_count1 =2 then
     --??????,???1
         if  c_insuredno=t_customer1 then
             return(1);
         else
             return(0);
         end if;
     end if;
     --??????????????,???0
     if t_count1=0 then
        return(0);
     end if;
     --??????????????????,???????????,??????????
     if t_count1=1 then
         select nvl(count(1),0) into t_count1  from llcase a, LLAppClaimReason b where a.caseno=c_caseno and a.caseno=b.caseno  and b.reasoncode in ('102')  and a.customerno =t_customer1;
         select nvl(count(1),0) into t_count2 from llclaim,llclaimdetail where llclaim.clmno=llclaimdetail.clmno and llclaimdetail.polno=c_PolNo and llclaimdetail.getdutykind ='102' and (llclaim.clmstate='50' or llclaim.clmstate='60') and llclaimdetail.customerno=t_customer2;
         if t_count1=1 and t_count2=1 then
            result :=1;
         else
             t_count1:=0;
             t_count2:=0;
             select nvl(count(1),0) into t_count1  from llcase a, LLAppClaimReason b where a.caseno=c_caseno and a.caseno=b.caseno  and b.reasoncode in ('102') and a.customerno=b.customerno and a.customerno =t_customer2;
             select nvl(count(1),0) into t_count2 from llclaim,llclaimdetail where llclaim.clmno=llclaimdetail.clmno and llclaimdetail.polno=c_PolNo and llclaimdetail.getdutykind ='102' and (llclaim.clmstate='50' or llclaim.clmstate='60') and llclaimdetail.customerno=t_customer1;
             if t_count1=1 and t_count2=1 then
                result:=1;
             else
                 result:=0;
             end if;
         end if;
     end if;
  else
     result:=0;
  end if ;

  return(Result);
end fnc_345_1;


/

