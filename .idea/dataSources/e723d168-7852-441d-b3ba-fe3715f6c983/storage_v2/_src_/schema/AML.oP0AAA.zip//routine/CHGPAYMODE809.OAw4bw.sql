create function chgpaymode809(paymode in varchar2) return varchar2
is
tR varchar2(20);
begin
 if paymode = '0' then
  tR := '12';
 end if;
 if paymode = '1' then
  tR := '1.08';
 end if;
 if paymode = '3' then
  tR := '3.24';
 end if;
 if paymode = '6' then
  tR := '6.24';
 end if;
 if paymode = '12' then
  tR := '12';
 end if;

 return(tR);
end;


/

