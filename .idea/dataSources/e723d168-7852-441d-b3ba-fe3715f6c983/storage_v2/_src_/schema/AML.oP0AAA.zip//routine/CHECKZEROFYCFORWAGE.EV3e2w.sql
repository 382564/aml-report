create function checkZeroFYCForWage(tManageCom in VARCHAR2,tBranchType in VARCHAR2,tIndexCalNo in VARCHAR2) return integer IS
-------------------?????????0,FYC?0---------------------------
  ADDCOUNT   INTEGER;
begin
return 1;
  select count(*) into ADDCOUNT from lacommision
  where wageno=tIndexCalNo
  and  branchtype=tBranchType
  and  commdire<>'2'
  and  payyear<1
  and  transmoney<>0
  and  fyc=0
  and  managecom like concat(tManageCom,'%')
  ;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkZeroFYCForWage;


/

