create FUNCTION fnc_zt3_2(payendyear in number) return varchar2
is
tR varchar2(20);
begin

  tR := 1;

		if payendyear >= 20 then
			tR := 0.3;
		end if;
		if payendyear >= 10 and payendyear < 20 then
			tR := 0.35;
		end if;
		if payendyear < 10 then
			tR := 0.55;
		end if;
	return(tR);
end;


/

