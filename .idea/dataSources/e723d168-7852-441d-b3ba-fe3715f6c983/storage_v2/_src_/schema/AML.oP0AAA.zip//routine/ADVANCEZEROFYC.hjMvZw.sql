create FUNCTION AdvanceZeroFYC (
       tagentcode in VARCHAR2,
       tempbegin in date,
       tempend in date) RETURN INTEGER IS
-----------------????????????-----------------
  ZEROMONCOUNT INTEGER;
  DIRWAGE NUMBER(12,6):=0;
  COMPAREDATE date;
  startdate   date;
BEGIN

  ZEROMONCOUNT := 0;
  startdate:=tempbegin;
  Comparedate:=add_months(startdate,1);

  WHILE Comparedate<=tempend loop
    ---?????FYC
    SELECT sum(nvl(directwage,0)) INTO DIRWAGE FROM lacommision
     WHERE agentcode=tagentcode and (commdire='1' or (commdire='2' and transtype not in ('CT','PT'))) and p6=0 and
     signdate >=startdate and signdate<=Comparedate and payyear<1;
    IF DIRWAGE > 0 THEN
      ZEROMONCOUNT := 0;
    ELSE
      ZEROMONCOUNT := ZEROMONCOUNT + 1;  --????
    END IF;
    startdate:=add_months(startdate,1);
    Comparedate:=add_months(startdate,1);
  END LOOP;
  RETURN ZEROMONCOUNT;
END AdvanceZeroFYC;


/

