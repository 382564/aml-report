create function fnc_271(ClmNo1 number,DutyFeeStaNo1 number) return number is
  Result number;
  fee number;
  LimitDate Date;
  StartDate Date;
  EndDate Date;
  MixDutyFeeStaNo number;
begin
  select min(DutyFeeStaNo) into MixDutyFeeStaNo from LLClaimDutyFee where clmno=ClmNo1;
  select (select StartDate from LLClaimDutyFee where clmno=ClmNo and DutyFeeStaNo=MixDutyFeeStaNo ) into LimitDate from Dual;
  select StartDate into StartDate from Llclaimdutyfee where clmno=ClmNo and DutyFeeStaNo=DutyFeeStaNo1;
  select EndDate into EndDate from Llclaimdutyfee where clmno=ClmNo and DutyFeeStaNo=DutyFeeStaNo1;
  select OriSum into fee from Llclaimdutyfee where clmno=ClmNo and DutyFeeStaNo=DutyFeeStaNo1;

  if LimitDate>EndDate then
    if fee>20 then
      select 20*(EndDate-StartDate+1) into Result from Dual;
    else
      select fee*(EndDate-StartDate+1) into Result from Dual;
    end if ;
  else
    if StartDate>LimitDate then
      select 0 into Result from Dual;
    else
      if fee>20 then
        select 20*(LimitDate-StartDate)/(EndDate-StartDate) into Result from Dual;
      else
        select fee*(LimitDate-StartDate)/(EndDate-StartDate) into Result from Dual;
      end if;
    end if;
   end if;
  return(Result);
end fnc_271;


/

