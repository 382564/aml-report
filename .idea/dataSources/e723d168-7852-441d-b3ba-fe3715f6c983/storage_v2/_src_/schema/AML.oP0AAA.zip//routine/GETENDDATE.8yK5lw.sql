create function GETENDDATE(cDate DATE) return date is
  rDate DATE;
begin
  rDate :=cDate;
	if cDate >= '2100-01-01' then
	    rDate :='9999-01-01';
	end if;
  return(rDate);
end GETENDDATE;


/

