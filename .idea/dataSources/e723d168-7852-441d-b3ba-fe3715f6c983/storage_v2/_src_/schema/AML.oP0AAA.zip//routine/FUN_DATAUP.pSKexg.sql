create function fun_dataup(contno Char) return char is
  Result char(10);
  v_contno Char(20);
  v_riskcode varchar2(10);
  v_cdutycode Char(10);
  v_cdutycode2 Char(10);
  v_contplancode varchar2(20);
  v_mult Number(20,5);
  pragma autonomous_transaction;
Begin
   --???
   Declare
         Cursor c_contno Is
         select distinct contno from lcpol
          where riskcode in (152009,157009,228009,272009,276009,281009,282009,315009,330009,333009,292009,311009,328009,322009,345009,228008)
          and conttype='2'
          and mult>1
          and appflag='1'
          and makedate>=date'2007-4-30'
          and grpcontno='00000000000000000000'
          And contno In ('97000000076321','GZ96009053','SD002042','SD002048','SD002050','SD002051','SD002052','SD002053','SD60001153','SD60001154','SD60001155','SD60002054','SD60002090','SD60002091','SD60002092','SD60002093','SD60002205','SD60002445','SD60002446','SD60004597','SD60004852','SD60009548','SD60010007','SD60010016','SD60010502','SD60010517','SD60010528','SD60010538','SD60010543','SD60010569','SD60012691','SD60012692','SD60016872','SD60016878','SD70002043','SD70002044','SD70002082','SD70007572','SD70007573','SD7001005 ','SD70010521','SD70010566','SD70010593','SD70010607','SD70010622','SD70010651','SD70010669','SD70010699','SD70010715','SD70010751','SD70010776','SD70010828','SD70010832','SD70010836','SD70010898','SD70011016','SD70011072','SD70011075','SD70011103','SD70011104','SD70011113','SD70011118','SD70011127','SD70011165','SD70011169','SD70011183','SD70011202','SD70011209','SD70011218','SD70013004','SDWF2171','ZS97004705');
        Begin
           Open c_contno;
           Loop
           Fetch c_contno Into v_contno;
           exit when c_contno%notfound;
                 --??lcpol
                 update lcpol set standprem=prem where contno=v_contno;
                 Select mult Into v_mult From lcpol where contno=v_contno And rownum=1;
                 select contplancode Into v_contplancode from lcinsured where contno=v_contno and rownum=1;
                --???1
                     declare
                       cursor c_riskcode is
                       select riskcode from ldplandutyparam
                       where contplancode=v_contplancode and calfactor ='Amnt';
                     begin
                        open c_riskcode;
                          loop
                          fetch c_riskcode into v_riskcode;
                          exit when c_riskcode%notfound;
                                --??lcpol
                                update lcpol
                                set Amnt = v_mult * (select sum(calfactorvalue)
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and riskcode = v_riskcode
                                                        and calfactor = 'Amnt'),
                                    RiskAmnt = v_mult * (select sum(calfactorvalue)
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and riskcode = v_riskcode
                                                        and calfactor = 'Amnt')
                                where contno = v_contno and riskcode = v_riskcode;
                          end loop;
                          close c_riskcode;
                     end;
                 --???2
                 declare
                       cursor c_dutycode is
                       select dutycode from ldplandutyparam
                       where contplancode=v_contplancode and calfactor ='Prem';
                     begin
                        open c_dutycode;
                          loop
                          fetch c_dutycode into v_cdutycode;
                          exit when c_dutycode%notfound;
                                --??lcprem
                                update lcprem
                                set standprem = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode
                                                        and calfactor = 'Prem'),
                                prem = v_mult * (select calfactorvalue
                                                  from ldplandutyparam
                                                 where contplancode = v_contplancode
                                                   and dutycode = v_cdutycode
                                                   and calfactor = 'Prem'),
                                sumprem = v_mult * (select calfactorvalue
                                                     from ldplandutyparam
                                                    where contplancode = v_contplancode
                                                      and dutycode = v_cdutycode
                                                      and calfactor = 'Prem')
                                where contno = v_contno and dutycode =v_cdutycode;
                                --??lcduty
                                update lcduty
                                set standprem = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode
                                                        and calfactor = 'Prem'),
                                prem = v_mult * (select calfactorvalue
                                                  from ldplandutyparam
                                                 where contplancode = v_contplancode
                                                   and dutycode = v_cdutycode
                                                   and calfactor = 'Prem'),
                                sumprem = v_mult * (select calfactorvalue
                                                     from ldplandutyparam
                                                    where contplancode = v_contplancode
                                                      and dutycode = v_cdutycode
                                                      and calfactor = 'Prem'),
                                floatrate=1.0

                                where contno = v_contno and dutycode = v_cdutycode;
                                --??ljapayperson
                                update ljapayperson
                                set sumduepaymoney = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode
                                                        and calfactor = 'Prem'),
                                 sumactupaymoney = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode
                                                        and calfactor = 'Prem')
                              where contno = v_contno  and dutycode = v_cdutycode;
                          end loop;
                          close c_dutycode;
                     end;
                     --???3
                     declare
                       cursor c_dutycode2 is
                       select dutycode from ldplandutyparam
                       where contplancode=v_contplancode and calfactor ='Amnt';
                     begin
                        open c_dutycode2;
                          loop
                          fetch c_dutycode2 into v_cdutycode2;
                          exit when c_dutycode2%notfound;
                                --??lcduty
                                update lcduty
                                set Amnt = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode2
                                                        and calfactor = 'Amnt'),
                                   RiskAmnt = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode2
                                                        and calfactor = 'Amnt')
                                where contno = v_contno and dutycode = v_cdutycode2;
                                --??lcget
                                update lcget
                                set standmoney = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode2
                                                        and calfactor = 'Amnt'),
                                 actuget = v_mult * (select calfactorvalue
                                                       from ldplandutyparam
                                                      where contplancode = v_contplancode
                                                        and dutycode = v_cdutycode2
                                                        and calfactor = 'Amnt')
                              where contno = v_contno  and dutycode = v_cdutycode2;
                          end loop;
                          close c_dutycode2;
                     end;
       End Loop;
       Close c_contno;
       End;
       commit;
  return(Result);
end fun_dataup;


/

