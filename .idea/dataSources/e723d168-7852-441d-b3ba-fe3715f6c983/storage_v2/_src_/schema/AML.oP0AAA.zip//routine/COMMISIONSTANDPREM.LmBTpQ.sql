create function CommisionStandPrem(cBranchType in varchar2, cRiskCode in varchar2, cPayIntv in integer)
return number is
  dStandPrem    number(12,2);
begin
  select a.standprem into dStandPrem From(
  select 0.25 standprem from ldsysvar where cBranchType = '1' and cRiskCode = '112205' and cPayIntv <> 0
    and sysvar = 'onerow'
  union
  select 0.08 standprem from ldsysvar where cBranchType = '1' and cRiskCode = '112205'
    and cPayIntv = 0 and sysvar = 'onerow'
  union
  select 1 standprem from ldsysvar where cBranchType = '1' and cRiskCode <> '112205'
    and (cPayIntv <> 0 or (select riskperiod from lmriskapp Where riskcode = cRiskCode) = 'M')
    and sysvar = 'onerow'
  union
  select 0.1 standprem from ldsysvar where cBranchType = '1' and cRiskCode <> '112205'
    and cPayIntv = 0 and (select riskperiod from lmriskapp Where riskcode = cRiskCode) <> 'M'
    and sysvar = 'onerow'
  ) a;
  return(dStandPrem);
end CommisionStandPrem;


/

