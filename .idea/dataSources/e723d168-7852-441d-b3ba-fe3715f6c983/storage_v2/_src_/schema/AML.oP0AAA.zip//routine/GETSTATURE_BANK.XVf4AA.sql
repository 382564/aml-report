create function Getstature_bank(ContNo1 char, CustomerNo1 char) return number is
  Result number;
begin
  select distinct ImpartParam into Result from LCCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 And Impartver='03' and Impartcode='001' and ImpartParamNo='1';
  return(Result);
end Getstature_bank;


/

