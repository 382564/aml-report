create function FNC_205(n_fee number,d_injuryDate date,d_startDate date,d_getStartDate date,d_getEndDate date) return number is
  Result number;
begin
Result:=0;                               --?Result??
if  d_injuryDate<= d_startDate and d_getStartDate<=d_injuryDate and d_getEndDate>=d_injuryDate then
      	select n_fee into Result from Dual;
end if;
  return(Result);
end FNC_205;


/

