create function CHANGEAGENTCODE(AgentCode in CHAR) return CHAR is
  Result char(15);
  temp1  integer := 0;
  temp2  integer := 0;
  accu   integer := 1;
  --verify char(10);
  charac varchar2(20);
begin
  --verify := '35000054  ';
  loop
    exit when accu = 9;
    charac := substr(AgentCode, accu, 1);
    if charac > '9' then
      if charac > 'Z' then
        if temp1 = 0 then
          temp1 := 1;
        else
          temp2 := 1;
        end if;
      else
        if temp1 = 0 then
          temp1 := 2;
        else
          temp2 := 2;
        end if;
      end if;
    end if;
    accu := accu + 1;
  end loop;

  if (temp1 = 0 and temp2 = 0) or (temp1 = 2 and temp2 = 1) or
     (temp1 = 2 and temp2 = 0) then
    Result := AgentCode;
  else
    if temp1 = 1 and temp2 = 0 then
      Result := '6' || AgentCode;
    else
      if temp1 = 1 and temp2 = 1 then
        Result := '7' || AgentCode;
      else
        if temp1 = 1 and temp2 = 2 then
          Result := '8' || AgentCode;
        else
          if temp1 = 2 and temp2 = 2 then
            Result := '9' || trim(AgentCode);
          end if;
        end if;
      end if;
    end if;
  end if;
  return(Result);
end CHANGEAGENTCODE;


/

