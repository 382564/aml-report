create function getContNoCall(dStartDate in DATE,dEvlDateEnd in DATE,vManComCode in VARCHAR2) return integer is
  Result integer;
  pragma autonomous_transaction;
begin

declare

v_callCenter_contno char(20);
v_row_SelCont SELCONT_callCenter%rowtype;

cursor v_sel_lccont is
select contno from lccont where
modifydate between dStartDate and dEvlDateEnd
and managecom like vManComCode || '%';

cursor v_sel_lpedorapp is
select otherno from lpedorapp where
confdate between dStartDate and dEvlDateEnd
and managecom like vManComCode || '%';

cursor v_sel_lccontstate is
select contno from lccontstate a where
modifydate between dStartDate and dEvlDateEnd
and exists (select 1 from lccont where contno = a.contno and managecom like vManComCode || '%');

cursor v_sel_lcpol is
select contno from lcpol where
modifydate between dStartDate and dEvlDateEnd
and managecom like vManComCode || '%';




  begin

  execute immediate 'delete from  SELCONT_callCenter ';
  commit;

  open v_sel_lccont;
  loop
      fetch v_sel_lccont into v_callCenter_contno;
      exit when v_sel_lccont%NOTFOUND;

      v_row_SelCont.ContNo := v_callCenter_contno;
      v_row_SelCont.default2 := 'lcc';
      v_row_SelCont.default3 := vManComCode;
      insert into SELCONT_callCenter  values v_row_SelCont;
      commit;
  end loop;
  close v_sel_lccont;

  open v_sel_lcpol;
  loop
      fetch v_sel_lcpol into v_callCenter_contno;
      exit when v_sel_lcpol%NOTFOUND;
      v_row_SelCont.ContNo := v_callCenter_contno;
      v_row_SelCont.default2 := 'lpl';
      v_row_SelCont.default3 := vManComCode;
      insert into SELCONT_callCenter  values v_row_SelCont;
      commit;
  end loop;
  close v_sel_lcpol;

    open v_sel_lpedorapp;
  loop
      fetch v_sel_lpedorapp into v_callCenter_contno;
      exit when v_sel_lpedorapp%NOTFOUND;
      v_row_SelCont.ContNo := v_callCenter_contno;
      v_row_SelCont.default2 := 'lpe';
      v_row_SelCont.default3 := vManComCode;
      insert into SELCONT_callCenter  values v_row_SelCont;
      commit;
  end loop;
  close v_sel_lpedorapp;



    open v_sel_lccontstate;
  loop
      fetch v_sel_lccontstate into v_callCenter_contno;
      exit when v_sel_lccontstate%NOTFOUND;

      v_row_SelCont.ContNo := v_callCenter_contno;
      v_row_SelCont.default2 := 'lcs';
      v_row_SelCont.default3 := vManComCode;
      insert into SELCONT_callCenter  values v_row_SelCont;
      commit;
  end loop;
  close v_sel_lccontstate;

  end;

  commit;

  return(Result);

exception
   when others then
   dbms_output.put_line('????:getContNoCall??????' || ' ???????: ' || sqlerrm);
   return('E???????: ' || sqlerrm);
end getContNoCall;


/

