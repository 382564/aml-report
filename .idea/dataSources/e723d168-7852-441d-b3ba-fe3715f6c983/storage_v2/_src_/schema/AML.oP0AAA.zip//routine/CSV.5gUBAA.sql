create FUNCTION CSV (tInsuredYear in INTEGER,tPolNo in varchar2)
  return number is
  --tInsuredYear:保单年度
  --tPolNo:保单险种号码--保单号
  tCashValue number;--现金价值
  Result number;
  tSex varchar2(1);--被保人性别
  tAge number;--投保时的被保人年龄
  tInsuyear Integer;--保险年龄年期
  tInsuyearFlag Varchar2(2);--保险年龄年期标志
  tPayEndYear Integer;--终交年龄年期
  tPayEndYearFlag varchar2(2);--终交年龄年期标志
  tDuration Integer;--期间(当insuyearflag=A时，处于0~insuyear-age,貌似可以理解为'保单年度-1')
  tRiskCode varchar2(10);--险种代码
  tAmnt NUMBER;--保额
  tSQL varchar2(500);--执行的sql语句

begin

   select a.insuredSex,
          a.insuredAppAge,
          a.Insuyear,
          a.InsuyearFlag,
          a.PayEndYear,
          a.PayEndYearFlag,
          a.RiskCode,
          a.Amnt
     into
          tSex,
          tAge,
          tInsuyear,
          tInsuyearFlag,
          tPayEndYear,
          tPayEndYearFlag,
          tRiskCode,
          tAmnt
     from lcpol a
    WHERE a.polno = tPolNo;
  tDuration:=tInsuredYear-1;
  if(nvl(tRiskCode,0) in('131202','125502','131203','125001','321501','125501')) then
    tSQL:='SELECT CashValue+NetPrem FROM CV_'||tRiskCode||' WHERE (Sex,Age,Insuyear,InsuyearFlag,PayEndYear,PayEndYearFlag,Duration)=(select :tSex,:tAge,:tInsuyear,:tInsuyearFlag,:tPayEndYear,:tPayEndYearFlag,:tDuration from dual)';
     execute immediate tSQL into tCashValue using tSex ,tAge, tInsuyear,tInsuyearFlag, tPayEndYear , tPayEndYearFlag , tDuration;
  ELSIF(nvl(tRiskCode,0) IN ('131201')) THEN
    tSQL:='SELECT CashValue+AdjNetPrem FROM CV_'||tRiskCode||' WHERE (Sex,Age,Insuyear,InsuyearFlag,PayEndYear,PayEndYearFlag,Duration)=(select :tSex,:tAge,:tInsuyear,:tInsuyearFlag,:tPayEndYear,:tPayEndYearFlag,:tDuration from dual)';
     execute immediate tSQL into tCashValue using tSex ,tAge, tInsuyear,tInsuyearFlag, tPayEndYear , tPayEndYearFlag , tDuration;
	ELSIF(nvl(tRiskCode,0) IN ('125503')) THEN
	  SELECT a.sex,
		      floor(months_between(b.cvalidate,a.birthday)/12)+ tDuration
		INTO   tSex,
		       tAge 
		FROM ldperson a , lcpol b 
		WHERE a.customerno = b.appntno AND b.polno = tPolNo;
	  tSQL:='SELECT CashValue+NetPrem FROM CV_'||tRiskCode||' WHERE (Sex,Age,Insuyear,InsuyearFlag,PayEndYear,PayEndYearFlag,Duration)=(select :tSex,:tAge,:tInsuyear,:tInsuyearFlag,:tPayEndYear,:tPayEndYearFlag,:tDuration from dual)';
		execute immediate tSQL into tCashValue using tSex ,tAge, tInsuyear,tInsuyearFlag, tPayEndYear , tPayEndYearFlag , tDuration;        
  else
    tCashValue:=0;
  end if;

  IF(nvl(tRiskCode,0) IN('131202','125501')) THEN
      select nvl((tCashValue*tAmnt/10000),0) into result from dual;
  ELSE
      select nvl((tCashValue*tAmnt/1000),0) into result from dual;
  end if;
  return(result);

  EXCEPTION
  when OTHERS then
    return 0; --执行不成功

end CSV;


/

