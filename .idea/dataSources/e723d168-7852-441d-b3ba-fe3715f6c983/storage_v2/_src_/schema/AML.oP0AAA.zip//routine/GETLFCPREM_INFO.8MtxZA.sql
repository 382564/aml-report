create Function Getlfcprem_Info(Startdate In Date, Enddate In Date, Tmanagecom In Varchar) Return Char Is
	Result_Endo Varchar2(10);
	Pragma Autonomous_Transaction;
Begin

	Declare
		v_Cvalidate      Date;
		v_Insuyearflag   Char(1);
		v_Years          Integer;
		v_Payintv        Integer;
		v_Payendyear     Integer;
		v_Payendyearflag Char(1);
		v_Salechnl       Char(2);
		v_Agentcom       Char(20);
		v_Agentcode      Char(10);
		v_Mult           Number(20, 5);
		v_Amnt           Number(12, 2);
		c_Contno           Char(20);
    v_signdate         Date;
    v_paytodate        Date;
    v_payenddate       Date;

		v_Row_Lfcprem      Lfcprem_Info%Rowtype;
		v_Row_Ljapayperson Ljapayperson%Rowtype;

		Cursor v_Cursor_Ljapayperson Is
			Select *
			From Ljapayperson a
			Where 1 = 1
					  --and contno = 'XJ010536141000118'
						And a.enteraccdate >= Startdate And a.enteraccdate <= Enddate And a.Managecom Like Tmanagecom || '%' And
						a.Paytype = 'ZC'
            --And contno = 'HF020526111000119'
            ;

	Begin

		Execute Immediate 'truncate table lfcPrem_info';

		Open v_Cursor_Ljapayperson;

		Loop
			Fetch v_Cursor_Ljapayperson
				Into v_Row_Ljapayperson;
			Exit When v_Cursor_Ljapayperson%Notfound;

			Begin

				Select Contno, Cvalidate, Years, Insuyearflag, Payintv, Payendyear, Payendyearflag, Salechnl, Agentcom,
							 Agentcode, Mult, Amnt,signdate,paytodate,payenddate
				Into c_Contno, v_Cvalidate, v_Years, v_Insuyearflag, v_Payintv, v_Payendyear, v_Payendyearflag, v_Salechnl,
						 v_Agentcom, v_Agentcode, v_Mult, v_Amnt,v_signdate,v_paytodate,v_payenddate
				From Lcpol
				Where Polno = v_Row_Ljapayperson.Polno;

				--dep_name????

				v_Row_Lfcprem.Dept_Name := Trim(Getcode('com', v_Row_Ljapayperson.Managecom));

				--????
				v_Row_Lfcprem.Gp_Type := 'P';

				-- ???
				v_Row_Lfcprem.Polno := v_Row_Ljapayperson.Contno;

				--???
				v_Row_Lfcprem.Certno := v_Row_Ljapayperson.Contno;

				--????
        Begin
				v_Row_Lfcprem.Brno := Getriskseq(v_Row_Ljapayperson.Polno, v_Row_Ljapayperson.Contno);

        Exception When no_data_found Then
         Null;
        End;

				--????
				v_Row_Lfcprem.Plan_Code := v_Row_Ljapayperson.Riskcode;

				--??????
        Begin
				v_Row_Lfcprem.Busi_Src_Type := Trim(Getcode('salechnl', v_Salechnl));

        Exception When no_data_found Then
         Null;
        End;


				--????
				v_Row_Lfcprem.Prem_Psns := '1';

				--????(?)
				v_Row_Lfcprem.Period := Changedatetomonth(v_Years, v_Insuyearflag);

				--????(?)
        If v_payintv <> 0 Then
				v_Row_Lfcprem.Prem_Term := Changedatetomonth(v_Payendyear, v_Payendyearflag);
        Else
				v_Row_Lfcprem.Prem_Term := 0;
        End If;


				--??
				v_Row_Lfcprem.Units := v_Mult;

				--??
				v_Row_Lfcprem.Sum_Ins := v_Amnt;

				--????
				v_Row_Lfcprem.Curno := '01';

				--???????????
				v_Row_Lfcprem.Tot_Prem_Cnvt := v_Row_Ljapayperson.Sumactupaymoney;

				--????
				v_Row_Lfcprem.Prem_Times := v_Row_Ljapayperson.Paycount;

				--???? ????
         If v_Row_Lfcprem.brno = '2' then
            Select cvalidate Into v_cvalidate From lcpol Where polno = mainpolno And contno = c_contno;
         End If;

        If v_Row_Ljapayperson.lastpaytodate > '1899-12-31' Then
        	v_Row_Lfcprem.Pol_Yr := Getcuryear(v_Row_Ljapayperson.lastpaytodate,v_Cvalidate);
        Else
   				v_Row_Lfcprem.Pol_Yr := '1';
        End if;
				--??
				v_Row_Lfcprem.Prem_Type := Trim(Getcode('payintv', To_Char(v_Payintv)));

				--??????
				v_Row_Lfcprem.Agt_Code := v_Agentcom;

				--?????????
				v_Row_Lfcprem.Proc_Rate := 0;

				--?????
				v_Row_Lfcprem.Agentno := Changeagentcode(v_Row_Ljapayperson.Agentcode);

				--??????
        Begin
				v_Row_Lfcprem.Com_Rate := Nvl(Getrate(v_Row_Ljapayperson.Riskcode,v_Years, v_Insuyearflag), 0);
			  Exception When no_data_found Then
         v_Row_Lfcprem.Com_Rate := 0;
        End;

				-- ????
				v_Row_Lfcprem.Amt_Type := Getamttype('prem', To_Char(v_Row_Ljapayperson.Paycount));

				--????
        If v_Row_Ljapayperson.lastpaytodate = '1899-12-31' Then
				   v_Row_Lfcprem.Pay_To_Date := v_cvalidate;
        Else
           v_Row_Lfcprem.Pay_To_Date := v_Row_Ljapayperson.lastpaytodate;
        End If;

				--????
				v_Row_Lfcprem.Payment_Date := v_Row_Ljapayperson.enteraccdate;

				--????
				v_Row_Lfcprem.Gained_Date := v_Row_Ljapayperson.enteraccdate;

				--????
				v_Row_Lfcprem.Pol_Pay_To_Date := Getenddate(v_Row_Ljapayperson.Curpaytodate);

				--????
        If v_Payintv <> 0 Then
				 v_Row_Lfcprem.Pol_Paid_Up_Date := Getenddate(v_payenddate);
          Else
         v_Row_Lfcprem.Pol_Paid_Up_Date := v_Row_Ljapayperson.enteraccdate;
        End If;

				Insert Into Lfcprem_Info Values v_Row_Lfcprem;
				Commit;
			Exception
				When No_Data_Found Then
					Null;
			End;
		End Loop;

		Close v_Cursor_Ljapayperson;
    Commit;
		Return Result_Endo;
	End;
End Getlfcprem_Info;


/

