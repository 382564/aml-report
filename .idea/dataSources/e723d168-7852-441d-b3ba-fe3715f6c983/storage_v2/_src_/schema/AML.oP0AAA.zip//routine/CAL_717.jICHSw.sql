create function cal_717(Je_gf number) return number is
  Result number;
begin
  if Je_gf<=5000 then Result:=Je_gf*0.7 ;
  end if;
  if Je_gf>5000 and Je_gf<=10000 then Result:=(Je_gf-5000)*0.75+3500 ;
  end if;
  if Je_gf>10000 and Je_gf<=20000 then Result:=(Je_gf-10000)*0.8+3500+3750 ;
  end if;
  if Je_gf>20000 and Je_gf<=40000 then Result:=(Je_gf-20000)*0.9+8000+3500+3750 ;
  end if;
  if Je_gf>40000 then Result:=(Je_gf-40000)*0.95+18000+8000+3500+3750 ;
  end if;
  return(Result);
end cal_717;


/

