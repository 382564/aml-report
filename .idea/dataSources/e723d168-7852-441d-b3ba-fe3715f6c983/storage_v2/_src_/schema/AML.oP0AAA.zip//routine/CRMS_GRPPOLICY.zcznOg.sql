create PROCEDURE CRMS_GRPPOLICY( TSTRATDATE IN VARCHAR2,
                                            TENDDATE   IN VARCHAR2,
                                            TCUSTOMERNO IN VARCHAR2,
                                            ERRORMSG   OUT VARCHAR2) AS

  TMDATE  DATE; --月末
  TCDATE  DATE; --月初
  TEDATE  DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF(TCUSTOMERNO IS NOT NULL ) THEN
  BEGIN
    --可能会有主键冲突，所以需要先删除，再提数
    DELETE FROM MID_CR_Policy A
     WHERE A.CONTNO IN (SELECT C.GRPCONTNO FROM LCGRPCONT C  WHERE C.APPNTNO = TCUSTOMERNO);
    --开始提数
    INSERT INTO MID_CR_Policy
      SELECT DISTINCT a.grpcontno ContNo,
                '02' ContType,
                A.Managecom locId,
               (SELECT sum(lc.prem) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) PREM,
               (SELECT sum(lc.amnt) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) AMNT,
                x.payintv payMethod,
                a.appflag ContStatus,
                a.cvalidate effectiveDate,
                lc.enddate expireDate,
                '' accountNo,
                (SELECT sum(lc.sumprem) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) SumPrem,
                '' mainYearPrem,
                decode(X.payintv,'1',X.prem*12,'12',X.prem,'3',X.prem*4,'6',X.prem*2, '') YEARPREM,
                a.agentcode AgentCode,
                '' grpFlag,
                '团险核心' Channel,
                '人身' insSubject,
                (SELECT lm.Risktype3
                   FROM lmriskapp lm
                  WHERE lm.riskcode = X.riskcode) INVESTFLAG,
                NULL remainAccount,
                (SELECT DECODE(c.payendyearflag,'A',c.payendyear,'Y',c.payendyear,'M',c.payendyear/12,'D',c.payendyear/365) FROM lcpol c WHERE c.grpcontno=a.grpcontno AND c.polno = c.mainpolno AND ROWNUM=1) PayPeriod,
               a.salechnl SaleChnl,
                a.peoples2 InsuredPeoples,
                TRUNC(SYSDATE, 'dd') MAKEDATE,
                TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
  FROM LCGRPCONT A,lcgrppol x,lcpol lc
 WHERE A.APPFLAG <> '0'
 AND A.GRPCONTNO = X.GRPCONTNO
   AND LC.GRPCONTNO = A.GRPCONTNO
   AND LC.ENDDATE = (SELECT MAX(ENDDATE) FROM LCPOL WHERE GRPCONTNO = A.GRPCONTNO)
   AND A.GRPCONTNO IN (SELECT C.GRPCONTNO FROM LCGRPCONT C WHERE C.APPNTNO = TCUSTOMERNO) ;--有保单号时，只通过保单号查询
    COMMIT;
  END;

  ELSE --没有客户号，通过时间查询
  BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST (TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,TO_DATE(TENDDATE, 'yyyy-MM-dd')) INTO TMDATE FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Policy C WHERE C.CONTNO IN (SELECT a.Grpcontno FROM LCGRPCONT A
         WHERE A.APPFLAG <> '0'
               AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND TMDATE);--没有客户号时，通过时间查询
        --开始提数
        INSERT INTO MID_CR_Policy
        SELECT DISTINCT a.grpcontno ContNo,
                '02' ContType,
                A.Managecom locId,
                (SELECT sum(lc.prem) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) PREM,
               (SELECT sum(lc.amnt) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) AMNT,
                --x.prem Prem,
               --x.amnt Amnt,
                x.payintv payMethod,
                a.appflag ContStatus,
                x.cvalidate effectiveDate,
                lc.enddate expireDate,
                '' accountNo,
                (SELECT sum(lc.sumprem) FROM lcgrppol lc  WHERE lc.grpcontno = A.Grpcontno) SumPrem,
                '' mainYearPrem,
                decode(X.payintv,'1',X.prem*12,'12',X.prem,'3',X.prem*4,'6',X.prem*2, '') YEARPREM,
                a.agentcode AgentCode,
                '' grpFlag,
                '团险核心' Channel,
                '人身' insSubject,
                (SELECT lm.Risktype3
                   FROM lmriskapp lm
                  WHERE lm.riskcode = X.riskcode) INVESTFLAG,
                NULL remainAccount,
                 (SELECT DECODE(c.payendyearflag,'A',c.payendyear,'Y',c.payendyear,'M',c.payendyear/12,'D',c.payendyear/365) FROM lcpol c WHERE c.grpcontno=a.grpcontno AND c.polno = c.mainpolno AND ROWNUM=1) PayPeriod,
               a.salechnl SaleChnl,
                a.Peoples2 InsuredPeoples,
                TRUNC(SYSDATE, 'dd') MAKEDATE,
                TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCGRPCONT A,lcgrppol x,LCPOL LC
         WHERE A.APPFLAG <> '0'
         AND A.GRPCONTNO = X.GRPCONTNO
           AND LC.GRPCONTNO = A.GRPCONTNO
         AND LC.ENDDATE = (SELECT MAX(ENDDATE) FROM LCPOL WHERE GRPCONTNO = A.GRPCONTNO)
              AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND TMDATE;
--没有客户号时，通过时间查询
        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE WHEN TEDATE=TMDATE THEN TMDATE+1 ELSE LEAST(ADD_MONTHS(TCDATE, 1) - 1,TEDATE) END INTO TMDATE FROM DUAL; --下月月末
      END LOOP; --结束循环
      END ;
  END IF ;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_GRPPOLICY;


/

