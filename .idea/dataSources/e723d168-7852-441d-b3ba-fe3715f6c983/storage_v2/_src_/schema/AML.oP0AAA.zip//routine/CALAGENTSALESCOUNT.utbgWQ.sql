create function         calAgentSalesCount(cAgentCode      in varchar2,
                                              cStartYearMonth in varchar2,
                                              cEndYearMonth   in varchar2)
  return number is Result number;
begin
  select nvl(sum(inner_query.counts),0) into Result 
    from (select case when lag(p.insuredno) over(order by p.riskcode, p.insuredno, p.polno) = p.insuredno
                      and lag(p.riskcode) over(order by p.riskcode, p.insuredno, p.polno) = p.riskcode
                      then
                        0
                      else 
                        d.busirate
                 end as counts
            from lcpol p, lacommisiondetail d
           where p.contno = d.grpcontno
             and p.polno = p.mainpolno
             and p.appflag in ('1', '4')
             and not exists (select 1 from lpedoritem where edortype = 'WT' and edorstate = '0' and contno = p.contno)
             and not exists (select 1 from lmriskapp where riskperiod = 'S' and riskcode = p.riskcode)
             and d.agentcode = cAgentCode
             and p.signdate between to_date(cStartYearMonth,'yyyyMM') and last_day(to_date(cEndYearMonth,'yyyyMM'))
    ) inner_query;
  if Result is null then
    Result := 0;
  end if;
  return Result;
end;


/

