create function calworktime(s_StartDate date,
                                       s_StartTime varchar2,
                                       s_EndDate   date,
                                       s_EndTime   varchar2) return number is
  Result      number(16, 0);
  tDaytime    number(16, 0);
  tCalDate    LDWorkCalendar.caldate%type;
  tAMBegin    number; --??????,????;
  tAMEnd      number; --??????,????;
  tAMWorkTime LDWorkCalendar.Amworktime%type;
  tPMBegin    number; --??????,????;
  tPMEnd      number; --??????,????;
  tPMWorkTime LDWorkCalendar.Pmworktime%type;
  tWorkTime   LDWorkCalendar.worktime%type;
  tStartTime  number;
  tEndTime    number;
  tTimepara   number; --????,??????1440,?,?86400;
begin
  Result := 0;
  if s_StartDate > s_EndDate or
     (s_StartDate = s_EndDate and s_StartTime > s_EndTime) then
    Result := calworktime(s_EndDate, s_EndTime, s_StartDate, s_StartTime);
  else
    tTimepara  := 86400;
    tStartTime := to_number(to_date(s_StartTime, 'hh24:mi:ss') -
                            to_date('00:00:00', 'hh24:mi:ss')) * tTimepara; --????,????
    tEndTime   := to_number(to_date(s_EndTime, 'hh24:mi:ss') -
                            to_date('00:00:00', 'hh24:mi:ss')) * tTimepara; --????,????
    declare
      cursor c_rearrate is
        select CalDate,
               to_number(to_date(AMBegin, 'hh24:mi:ss') -
                         to_date('00:00:00', 'hh24:mi:ss')) * tTimepara,
               to_number(to_date(AMEnd, 'hh24:mi:ss') -
                         to_date('00:00:00', 'hh24:mi:ss')) * tTimepara,
               AMWorkTime,
               to_number(to_date(PMBegin, 'hh24:mi:ss') -
                         to_date('00:00:00', 'hh24:mi:ss')) * tTimepara,
               to_number(to_date(PMEnd, 'hh24:mi:ss') -
                         to_date('00:00:00', 'hh24:mi:ss')) * tTimepara,
               PMWorkTime,
               WorkTime
          from LDWorkCalendar
         where caldate >= s_StartDate
           and caldate <= s_EndDate
           and DateType = 'Y'
         order by caldate;
    begin
      open c_rearrate;
      --????
      loop
        tDaytime := 0;
        fetch c_rearrate
          into tCalDate, tAMBegin, tAMend, tAMWorkTime, tPMBegin, tPMEnd, tPMWorkTime, tWorkTime;
        if c_rearrate%notfound then
          exit;
        else
          if tCalDate = s_StartDate then
            if tStartTime < tAMBegin then
              tStartTime := tAMBegin;
            end if;
            if tStartTime between tAMEnd and tPMBegin then
              tStartTime := tPMBegin;
            end if;
          end if; --??????,??????
          if tCalDate = s_EndDate then
            if tEndTime > tPMEnd then
              tEndTime := tPMEnd;
            end if;
            if tEndTime between tAMEnd and tPMBegin then
              tEndTime := tAMEnd;
            end if;
          end if; --??????,??????
          if tCalDate = s_StartDate and tCalDate < s_EndDate then
            --??????????????
            if tStartTime = tAMBegin then
              --?????????????,????????
              tDaytime := tWorkTime;
            elsif tStartTime > tAMBegin and tStartTime <= tAMEnd then
              --???????
              select tPMWorkTime + round(tAMEnd - tStartTime)
                into tDaytime
                from dual;
            elsif tStartTime = tPMBegin then
              --???????????????
              tDaytime := tPMWorkTime;
            elsif tStartTime > tPMBegin and tStartTime <= tPMEnd then
              --???????
              select round(tPMEnd - tStartTime) into tDaytime from dual;
            end if;
          elsif tCalDate = s_StartDate and tCalDate = s_EndDate then
            --?????????????
            if tStartTime < tEndTime then
              if tStartTime between tAMBegin and tAMEnd and
                 tEndTime between tAMBegin and tAMEnd then
                --?????????????
                select round(tEndTime - tStartTime)
                  into tDaytime
                  from dual;
              elsif tStartTime between tPMBegin and tPMEnd and
                    tEndTime between tPMBegin and tPMEnd then
                --?????????????
                select round(tEndTime - tStartTime)
                  into tDaytime
                  from dual;
              elsif tStartTime between tAMBegin and tAMEnd and
                    tEndTime between tPMBegin and tPMEnd then
                --???????,???????;
                select round(tAMEnd - tStartTime + tEndTime - tPMBegin)
                  into tDaytime
                  from dual;
              end if;
            end if;
          elsif tCalDate > s_StartDate and tCalDate < s_EndDate then
            --???????????????
            tDaytime := tWorkTime;
          elsif tCalDate > s_StartDate and tCalDate = s_EndDate then
            --????????,?????
            if tEndTime > tAMBegin and tEndTime < tAMEnd then
              --???????
              select round(tEndTime - tAMBegin) into tDaytime from dual;
            elsif tEndTime = tAMEnd then
              --?????????????
              tDaytime := tAMWorkTime;
            elsif tEndTime >= tPMBegin and tEndTime < tPMEnd then
              --???????
              select tAMWorktime + round(tEndTime - tPMBegin)
                into tDaytime
                from dual;
            elsif tEndTime = tPMEnd then
              --?????????????
              tDaytime := tWorkTIme;
            end if;
          end if;
        end if;
        Result := Result + tDaytime;
      end loop;
      close c_rearrate;
      --????
    end;
  end if;

  if Result = 0 then
    Result := 1;
  end if;

  return(Result);
end calworktime;


/

