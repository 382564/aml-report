create function fnc_281_2(c_cureType char ,n_daysInHos number,n_fee number,d_injuryDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
begin

Result:=0;                               --?Result??

select (d_lcgetEndDate+30) into d_limitDate from dual ;	--???????????????
-------------------------------------------------------------------------------------------------------------
if d_lcgetStartDate<=d_startDate and d_startDate<d_limitDate and d_injuryDate<=d_startDate then   --????,????????????????
  if d_endDate<d_limitDate then       --?????????????????,??????????????
      	select least(n_fee,300) into Result from Dual;
  else                                 --?????????????
      	select least(n_fee*(d_limitDate-d_startDate)/(n_daysInHos+1),300) into Result from Dual;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_281_2;


/

