create function CHANGDATETOYEAR(cDate in INTEGER, cFlag in CHAR) return INTEGER is
  rDate INTEGER ;
begin
  if (cFlag='A' or cFlag='Y' or cFlag is NULL) and cDate<120 then
		rDate:=cDate;
		return rDate;
	end if;
	if cFlag='M' and cDate<1440 then
		rDate:=cDate/12;
		return rDate;
	end if;

	if cFlag='D' and cDate<43800 then
	 	rDate:=cDate/365;
	 	return rDate;
	end if;
	 if (cFlag='A' or cFlag='Y' or cFlag is NULL) and cDate >120 then
		rDate:=9999;
		return rDate;
	end if;
end CHANGDATETOYEAR;


/

