create function fnc_237_2(c_contNo char,c_polno char,c_insuredNo char,n_daysInHos number,n_fee number,d_accidentDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
  c_havaPre number;
  c_havaNext number;
begin

Result:=0;                               --?Result??

c_havaPre:=0;

c_havaNext:=0;

                                         --???????????
select nvl(Count(*),0) into c_havaPre from lcpol where 1=1 and appflag in ('1','4') and insuredno=c_insuredNo and enddate=(select getstartdate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --???????????
select nvl(Count(*),0) into c_havaNext from lcpol where 1=1 and appflag in ('1','4') and insuredno=c_insuredNo and getstartdate=(select enddate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --??????????,????????????  (???????)
select add_months(d_lcgetEndDate,1) into d_limitDate from dual ;

-------------------------------------------------------------------------------------------------------------


if d_accidentDate<=d_startDate then     --??????,???????????????

-------------------------------------------------------------------------------------------------------------
--??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate  and c_havaNext=0 and d_startDate<d_limitDate then

    if d_endDate<=d_limitDate then       --??????????????(??????d_limitDate?????,??????????????)
        	select n_fee into Result from Dual;
    else                                 --??????????????
        	select n_fee*(d_limitDate-d_startDate)/n_daysInHos into Result from Dual;
    end if;

  end if ;
-------------------------------------------------------------------------------------------------------------
--?????????????????????????? --
  if d_lcgetStartDate<=d_startDate and  d_startDate <d_lcgetEndDate and  c_havaNext<>0 then

    if d_endDate<=d_lcgetEndDate then   --???????(??????d_lcgetEndDate?????,??????????????)
        	select n_fee into Result from Dual;
    else                                  --???? ,????????
        	select n_fee*(d_lcgetEndDate-d_startDate)/n_daysInHos into Result from Dual;
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
  --??????????????,?????????,????????????,????????--
  if  d_startDate<d_lcgetStartDate and  d_lcgetStartDate<d_endDate and  d_endDate <=d_lcgetEndDate and c_havaPre<>0 then
      	select n_fee*(d_endDate-d_lcgetStartDate)/n_daysInHos into Result from Dual;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_237_2;


/

