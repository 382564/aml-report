create function cal_727_1(Je_gf number) return number is
  Result number;
begin
  if Je_gf<=40000 then Result:=Je_gf*0.9 ;
  end if;
  if Je_gf>40000 then Result:=(Je_gf-40000)*0.95+36000;
  end if;
  return(Result);
end cal_727_1;


/

