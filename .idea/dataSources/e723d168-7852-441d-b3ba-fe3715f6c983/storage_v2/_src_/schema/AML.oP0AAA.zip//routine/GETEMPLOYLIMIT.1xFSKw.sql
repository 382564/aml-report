create function getEmployLimit(tVarType in varchar2) return varchar2 is
  Result varchar2(2);
begin
  select trim(varvalue) into Result from lasysvar
  where trim(vartype) = trim(tVarType);

  return(Result);
end getEmployLimit;


/

