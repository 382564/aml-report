create function GETPLAN_TYPE_TBL(cRiskType in char, cRiskType1 in char) return VARCHAR is
  mRiskType VARCHAR(3);
begin

	if cRiskType='L' then
	--??
		mRiskType :='210';
	end if;

	if cRiskType='A' then
	--???
	   mRiskType :='220';
	end if;

	if cRiskType='H'  then
	--???
		mRiskType :='230';
	end if;

	if cRiskType1='2' then
	--??
	   mRiskType :='211';
    end if;

	if cRiskType1='3' then
	--??
	   mRiskType :='212';
    end if;

	if cRiskType1='3' then
	--??
	   mRiskType :='212';
    end if;

	return(mRiskType);
end GETPLAN_TYPE_TBL;


/

