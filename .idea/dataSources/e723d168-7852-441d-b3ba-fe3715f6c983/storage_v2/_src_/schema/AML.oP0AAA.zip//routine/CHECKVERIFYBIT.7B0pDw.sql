create function checkverifybit(idno     in varchar2,
                                          birthday in date,
                                          sex      in varchar2)
  return varchar2 is
  result      varchar2(1) := '0';
  checknumber int;
  birthdayVar varchar2(10);
  sexVar      int;
  verifybit   char(1);
begin
  --新身份证号
  if length(idno) = 18 then
    birthdayVar := substr(idno, 7, 8);
    sexVar      := to_number(substr(idno, 17, 1));
    --识别码校验 start
    checknumber := substr(idno, 1, 1) * 7 + substr(idno, 2, 1) * 9 +
                   substr(idno, 3, 1) * 10 + substr(idno, 4, 1) * 5 +
                   substr(idno, 5, 1) * 8 + substr(idno, 6, 1) * 4 +
                   substr(idno, 7, 1) * 2 + substr(idno, 8, 1) * 1 +
                   substr(idno, 9, 1) * 6 + substr(idno, 10, 1) * 3 +
                   substr(idno, 11, 1) * 7 + substr(idno, 12, 1) * 9 +
                   substr(idno, 13, 1) * 10 + substr(idno, 14, 1) * 5 +
                   substr(idno, 15, 1) * 8 + substr(idno, 16, 1) * 4 +
                   substr(idno, 17, 1) * 2;
    checknumber := mod(checknumber, 11);
    case checknumber
      when 0 then
        verifybit := '1';
      when 1 then
        verifybit := '0';
      when 2 then
        verifybit := 'X';
      when 3 then
        verifybit := '9';
      when 4 then
        verifybit := '8';
      when 5 then
        verifybit := '7';
      when 6 then
        verifybit := '6';
      when 7 then
        verifybit := '5';
      when 8 then
        verifybit := '4';
      when 9 then
        verifybit := '3';
      when 10 then
        verifybit := '2';
      else
        null;
    end case;
    if verifybit <> substr(idno, 18, 1) then
      return '1';
    end if;
    --识别码校验 end
    --旧身份证号
  elsif length(idno) = 15 then
    birthdayVar := '19' || substr(idno, 7, 6);
    sexVar      := to_number(substr(idno, 15, 1));
  else
    return '1';
  end if;
  if to_date(birthdayVar, 'YYYYMMDD') <> birthday then
    return '1';
  end if;
  if MOD(sexVar, 2) <> case
       when sex = '0' then
        1
       when sex = '1' then
        0
       else
        MOD(sexVar, 2)
     end then
    return '1';
  end if;
  return result;
exception
  when others then
    return '1';

end checkverifybit;


/

