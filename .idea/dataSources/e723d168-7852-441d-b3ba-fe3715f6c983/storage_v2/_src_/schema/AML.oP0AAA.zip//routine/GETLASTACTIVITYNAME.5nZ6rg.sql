create function getlastactivityname(P_MissionID varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select activityname
    into Result
    from (select (select activityname
                    from lwactivity
                   where activityid = b.activityid) activityname
            from lbmission b
           where activityid in ('0000001098', '0000001001', '0000001095',
                  '0000001095', '0000001110', '0000001099')
             and missionid = P_MissionID
           order by to_char(outdate, 'YYYY-MM-DD') || ' ' || outtime desc)
   where rownum = 1;
  return(Result);
end getlastactivityname;

/

