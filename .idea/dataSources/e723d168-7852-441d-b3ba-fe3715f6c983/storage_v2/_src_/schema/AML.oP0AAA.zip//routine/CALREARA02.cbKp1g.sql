create FUNCTION "CALREARA02" (tAgentCode in varchar2, TempBegin in date,TempEnd in date) return number is
  Result number := 0;
  tFYC   number := 0;
  /*tIYear varchar2(4) := 0;
  tNYear varchar2(4) := 0;
  tIMon  varchar2(2) := 0;
  tNMon  varchar2(2) := 0;*/
  tIntvl  integer := 0;
  --tLastGrade varchar2(3);

  cursor c_View is
    select * from laagenttreeview
    where trim(agentgrade) > 'A01' and trim(introagency) = tAgentCode;

begin

  for v_View in c_View loop

    --zsj--modified--2004-2-34
    /*tIYear := to_char(v_View.indueformdate,'yyyy');
    tNYear := to_char(TempBegin,'yyyy');
    tIMon := to_char(v_View.indueformdate,'mm');
    tNMon := to_char(TempBegin,'mm');

    if tIYear = tNYear then
      tIntvl := tNMon - tIMon + 1;
    else
      tIntvl := 12 - tIMon + 1;
      tIntvl := tIntvl + tNMon;
    end if;*/

    tIntvl := dateinterval(TempBegin,v_View.indueformdate);

    if tIntvl <= 12 then
      select nvl(sum(directwage),0) into tFYC from lacommision
      where trim(CommDire) = '1'
           and caldate >= TempBegin
           and caldate <= TempEnd
           and payyear < 1
           and trim(AgentCode) = v_View.agentcode;
      --????????
      --if v_View.indueformdate <> v_View.employdate then
        Result := Result + tFYC;
      --end if;
    end if;
  end loop;

  return(Result);
end CALREARA02;


/

