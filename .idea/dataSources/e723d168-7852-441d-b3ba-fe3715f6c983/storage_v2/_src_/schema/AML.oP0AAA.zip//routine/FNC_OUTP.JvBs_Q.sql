create FUNCTION FNC_OUTP(
--F_TYPE        CHAR,
                                   C_POLNO       CHAR,
                                   C_GETDUTYCODE CHAR,
                                   C_DUTYCODE    CHAR,
                                   C_CASENO      CHAR,
                                   C_GrpContNo   CHAR,
                                   C_RiskCode    CHAR,
                                   C_GetDutyKind CHAR) RETURN NUMBER IS
  RESULT NUMBER;
  /*??*/
  LCDuty_Amnt                             NUMBER;--??
  --CalFactorValue      NUMBER;         --?????????
  LCClaimCtrl_DefaultValue                NUMBER;--???????
  LLCaseReceipt_Fee                       NUMBER;--????
  C_CurSor      NUMBER;
  C_FeeItemCode  LLCaseReceipt.FeeItemCode%TYPE;
  C_InsuredNo    LLCaseReceipt.CustomerNo%TYPE;
  C_PubLMFlag char;
  --C_FeeType   char;
  C_FactorType  char;--?????????
  --C_LimDays   NUMBER;--????
  --C_InsDays   NUMBER;--????
  C_LimAmnt   NUMBER;--????
  C_Visits    NUMBER;--????,?????????,????????
  C_Rate      NUMBER;--????
  /*?????????*/
 CURSOR t_CaseReSet IS
    select LLCaseReceipt.ClmNo,
           LLCaseReceipt.CaseNo,
           LLCaseReceipt.RgtNo,
           LLCaseReceipt.FeeItemCode,
           sum(LLCaseReceipt.Fee),
           LLCaseReceipt.CustomerNo,
           count(1)
      from LLCaseReceipt
     where LLCaseReceipt.ClmNo = C_CASENO
       and LLCaseReceipt.FeeItemType='H'
       and substr(FeeItemCode,0,2)=(select clmfeecode from LMDutyGetFeeRela  where getdutycode=C_GETDUTYCODE
          and getdutykind=C_GetDutyKind)  group by ClmNo,CaseNo,RgtNo,FeeItemCode,CustomerNo;
BEGIN
  RESULT    := 0; --?Result??
  C_CurSor := DBMS_SQL.OPEN_CURSOR;
  FOR t_LLCaseReceipt IN t_CaseReSet LOOP
  C_FeeItemCode := 0;
  C_FeeItemCode :=t_LLCaseReceipt.FeeItemCode;
  C_InsuredNo   :=t_LLCaseReceipt.CustomerNo;
  LCClaimCtrl_DefaultValue :=0;

  /*OUTP ????????B,??
   select * from lmriskparamsdef  where riskcode='OUTP';
   paramstype??Rate?Visits,Amnt
   */
   /*????????*/
    select nvl(sum(a.fee),0),count(1)
   into  LLCaseReceipt_Fee,C_Visits
   from LLCaseReceipt a
   where 1=1
    and a.clmno = C_CASENO
    and a.FeeItemCode=C_FeeItemCode;

    /*????????*/
    select count(1)
     into C_FactorType
     from lmriskparamsdef
     where riskcode=C_RiskCode and othercode=C_FeeItemCode
     and paramstype='Amnt';

     if C_FactorType=0 then
          C_LimAmnt :=0;
     else

       select count(1)
       into  C_FactorType
       from lccontplandutyparam b
        where b.grpcontno = C_GrpContNo
        and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
        and b.riskcode=C_RiskCode
        and b.dutycode=C_DUTYCODE
        and b.calfactor=(select paramscode from lmriskparamsdef
           where riskcode=C_RiskCode and othercode=C_FeeItemCode
           and paramstype='Amnt');
       if  C_FactorType=0 then
          C_LimAmnt :=0;
        else
       select nvl(b.calfactorvalue,0)
       into  C_LimAmnt
       from lccontplandutyparam b
        where b.grpcontno = C_GrpContNo
        and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
        and b.riskcode=C_RiskCode
        and b.dutycode=C_DUTYCODE
        and b.calfactor=(select paramscode from lmriskparamsdef
           where riskcode=C_RiskCode and othercode=C_FeeItemCode
           and paramstype='Amnt');
      end if;
     end if;

   /*????????*/
     select count(1)
     into C_FactorType
     from lmriskparamsdef
     where riskcode=C_RiskCode and othercode=C_FeeItemCode
     and paramstype='Rate';

     if C_FactorType=0 then
          C_Rate :=0;
     else

       select count(1)
       into  C_FactorType
       from lccontplandutyparam b
        where b.grpcontno = C_GrpContNo
        and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
        and b.riskcode=C_RiskCode
        and b.dutycode=C_DUTYCODE
        and b.calfactor=(select paramscode from lmriskparamsdef
           where riskcode=C_RiskCode and othercode=C_FeeItemCode
           and paramstype='Rate');
        if C_FactorType=0 then
         C_Rate :=0;
         else
        select nvl(b.calfactorvalue,0)/100
       into  C_Rate
       from lccontplandutyparam b
        where b.grpcontno = C_GrpContNo
        and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
        and b.riskcode=C_RiskCode
        and b.dutycode=C_DUTYCODE
        and b.calfactor=(select paramscode from lmriskparamsdef
           where riskcode=C_RiskCode and othercode=C_FeeItemCode
           and paramstype='Rate');
     end if;
     end if;

   if  C_Rate*LLCaseReceipt_Fee <=C_LimAmnt then
   RESULT :=RESULT+C_Rate*LLCaseReceipt_Fee;
   else
   RESULT :=RESULT+C_LimAmnt;
   end if;
   /*?????????*/
   select count(1)
   into C_PubLMFlag
   from lcdutyclmctrlrela
   where dutycode=C_DUTYCODE
   and grpcontno =C_GrpContNo
   and dutycalfactator=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Amnt');

   if C_PubLMFlag>0 then
   select nvl(b.DefaultValue,0)
   into LCClaimCtrl_DefaultValue
   from lcdutyclmctrlrela a,LCClaimCtrl b
   where a.dutycode=C_DUTYCODE
   and a.grpcontno =C_GrpContNo
   and a.dutycalfactator=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Amnt')
   and a.claimctrlcode=b.claimctrlcode;

   if LCClaimCtrl_DefaultValue < RESULT then
   RESULT :=LCClaimCtrl_DefaultValue;
   else
   RESULT :=RESULT;
   end if;

   end if;
  END LOOP;
  DBMS_SQL.CLOSE_CURSOR(C_CurSor);


  /*??LCGet??Amnt*/
  select nvl(amnt,0)
  into LCDuty_Amnt
  from LCDuty
  where polno=C_POLNO
    and dutycode=C_DUTYCODE;

  if LCDuty_Amnt< RESULT  then
  RESULT :=LCDuty_Amnt;
  else
  RESULT :=RESULT;
  end if;

  RETURN(RESULT);
END FNC_OUTP;


/

