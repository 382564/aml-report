create function checkEmpolydate(tAgentCode in VARCHAR2,tIndexCalNo in VARCHAR2) return integer IS
-------------------?????????????---------------------------
  TEMPLOYDATE   varchar2(6);
  tBranchType   varchar2(2);
begin
  select to_char(employdate,'yyyymm'),branchtype into TEMPLOYDATE,tBranchType from laagent
  where agentcode=tAgentCode;
 if (tBranchType<>'1')
 then return 1;
 else

  if (TEMPLOYDATE>tIndexCalNo)
  then return -1;
  else
  return 1;
  end if;
 end if;
end checkEmpolydate;


/

