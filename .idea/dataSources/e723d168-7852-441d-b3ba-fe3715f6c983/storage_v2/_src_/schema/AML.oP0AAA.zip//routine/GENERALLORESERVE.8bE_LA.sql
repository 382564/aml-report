create procedure generalloreserve(tENDDATE date) is
	lo             loreserve%rowtype;
	tLastYearStart date;
	tThisYearStart date;
	tNextYearStart date;
	tPingGuDate    date;
	tPingGuMonth   date;
	tCurrentTime   date := sysdate;
	tCurrentDate   date := trunc(tCurrentTime);
	tbranchtype    laagent.branchtype%type;
	tname          laagent.name%type;
	nflag          number;
	CURSOR pol_cursor is
		select a.*, rownum from lcpol a where signdate < tENDDATE;

begin
	case to_char(tENDDATE, 'DD')
		when 1 then
			tPingGuDate := tENDDATE - 1;
		else
			tPingGuDate := last_day(tENDDATE);
	end case;
	tPingGuMonth   := TRUNC(tPingGuDate, 'MONTH');
	tLastYearStart := TRUNC(ADD_MONTHS(tPingGuDate, -12), 'YEAR');
	tThisYearStart := TRUNC(tPingGuDate, 'YEAR');
	tNextYearStart := TRUNC(ADD_MONTHS(tPingGuDate, 12), 'YEAR');

	insert into loreserve_rec values ('loreserve start with date '||tPingGuDate, sysdate);
	commit;
	begin
		dbms_utility.exec_ddl_statement('alter table loreserve drop constraint pk_loreserve');
	exception
		when others then
			null;
	end;
	begin
		dbms_utility.exec_ddl_statement('drop index pk_loreserve');
	exception
		when others then
			null;
	end;
	dbms_utility.exec_ddl_statement('truncate table loreserve');
	--  delete from loreserve;
	--  delete from loreserve_rec;
	--  commit;

	insert into loreserve_rec values ('loreserve delete history', sysdate);
	commit;
	for pol in pol_cursor loop
		begin
			lo := null;
			--    dbms_output.put_line(pol.rownum || '  ' || pol.polno);
			if (pol.rownum mod 10000 = 0) then
				insert into loreserve_rec
				values
					('loreserve run to ' || to_char(pol.rownum), sysdate);
				commit;
			end if;
			if (pol.appflag = '4') then
				begin
					select 'T' || state, statereason, startdate
						into lo.polstatus, --0.???(????) 1.??
								 lo.stopreason,
								 lo.stopdate
						from lccontstate a
					 where a.polno = pol.polno
						 and a.contno = pol.contno
						 and statetype = 'Terminate'
						 and startdate <= tCurrentDate /*???????????????,????*/
						 and enddate is null
						 and rownum <= 1;
				exception
					when NO_DATA_FOUND then
						begin
							select 'T' || state, statereason, startdate
								into lo.polstatus, --0.??? 1.??
										 lo.stopreason,
										 lo.stopdate
								from lccontstate a
							 where a.polno = '000000'
								 and a.contno = pol.contno
								 and statetype = 'Terminate'
								 and startdate <= tCurrentDate /*???????????????*/
								 and enddate is null
								 and rownum <= 1;
						exception
							when NO_DATA_FOUND then
								lo.polstatus := 'T1'; /*???????????????,???????????*/
								insert into loreserve_rec
								values
									('loreserve error polstatus with ' || pol.polno, sysdate);
						end;
				end;

				begin
					select deathdate
						into lo.deaddate
						from ldperson
					 where customerno = pol.insuredno;
				exception
					when NO_DATA_FOUND then
						null;
				end;

				lo.invaliddate := pol.paytodate;

			elsif (pol.appflag = '1') then
				begin
					select 'A' || state
						into lo.polstatus /*0.?? 1.??*/
						from lccontstate a
					 where a.polno = pol.polno
						 and a.contno = pol.contno
						 and statetype = 'Available'
						 and startdate <= tCurrentDate /*???????????????*/
						 and enddate is null
						 and rownum <= 1;
				exception
					when NO_DATA_FOUND then
						begin
							select 'A' || state
								into lo.polstatus --0.?? 1.??
								from lccontstate a
							 where a.polno = '000000'
								 and a.contno = pol.contno
								 and statetype = 'Available'
								 and startdate <= tCurrentDate /*???????????????*/
								 and enddate is null
								 and rownum <= 1;
						exception
							when NO_DATA_FOUND then
								lo.polstatus := 'A0'; /*???????????????,???????????*/
								insert into loreserve_rec
								values
									('loreserve error polstatus with ' || pol.polno, sysdate);
						end;
				end;

				SELECT NVL(SUM(sumactupaymoney), 0)
					into lo.thispayprem
					FROM ljapayperson
				 WHERE polno = pol.polno
					 AND paytype = 'ZC'
					 AND confdate BETWEEN tThisYearStart AND tNextYearStart - 1
					 AND paycount >= 2;

				SELECT NVL(SUM(sumactupaymoney), 0)
					into lo.lastpayprem
					FROM ljapayperson
				 WHERE polno = pol.polno
					 AND paytype = 'ZC'
					 AND confdate BETWEEN tLastYearStart AND tThisYearStart - 1
					 AND paycount >= 1;

			else
				goto end_loop;
			end if;
			lo.agentcom       := pol.agentcom;
			lo.amnt           := pol.amnt;
			lo.cvalidate      := pol.cvalidate;
			lo.floatrate      := pol.floatrate;
			lo.groupno        := pol.grppolno;
			lo.years          := pol.insuyear;
			lo.insuyearflag   := pol.insuyearflag;
			lo.lastrevdate    := pol.lastrevdate;
			lo.makedate       := pol.makedate;
			lo.managecom      := pol.managecom;
			lo.managefeerate  := pol.managefeerate;
			lo.occupationtype := pol.occupationtype;
			lo.enddate        := pol.enddate;
			lo.payyears       := pol.payendyear;
			lo.payendyearflag := pol.payendyearflag;
			lo.payintv        := pol.payintv;
			lo.paytodate      := pol.paytodate;
			lo.polno          := pol.polno;
			lo.contno         := pol.contno;
			lo.riskcode       := pol.riskcode;
			lo.salechnl       := pol.salechnl;
			lo.signdate       := pol.signdate;
			lo.YearIdx        := TRUNC(MONTHS_BETWEEN(tENDDATE, pol.cvalidate) / 12);
			lo.CalYear        := extract(year from tENDDATE);
			lo.modifydate     := tCurrentTime;

			if (pol.riskcode = '121301') then
				lo.insuredno := pol.appntno;
				begin
					select (TRUNC(MONTHS_BETWEEN(pol.cvalidate, appntbirthday) / 12)),
								 appntbirthday,
								 appntsex
						into lo.insuredappage, lo.insuredbirthday, lo.insuredsex
						from lcappnt
					 where contno = pol.contno
						 and appntno = pol.appntno;
				exception
					when NO_DATA_FOUND then
						null;
				end;
			else
				lo.insuredno       := pol.insuredno;
				lo.insuredappage   := pol.insuredappage;
				lo.insuredbirthday := pol.insuredbirthday;
				lo.insuredsex      := pol.insuredsex;
			end if;

			begin
				select state
					into lo.autopayflag
					from lccontstate a
				 where a.contno = pol.contno
					 and statetype = 'PayPrem'
					 and startdate <= tENDDATE
					 and enddate is null
					 and rownum <= 1;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				lo.TransSaleChnl := pol.salechnl;
				if (pol.salechnl = '01') then
					begin
						select branchtype, name
							into tbranchtype, tname
							from laagent
						 where agentcode = pol.agentcode;
						if (tbranchtype = '2' and 'LB' = substr(tname, 1, 2)) then
							lo.TransSaleChnl := '07';
						end if;
					exception
						when NO_DATA_FOUND then
							null;
					end;
				elsif (pol.grppolno = '00000000000000000000' and
							(pol.salechnl = '05' or pol.salechnl = '06' or
							pol.salechnl = '08' or pol.salechnl = '09')) then
					if ((length(pol.agentcom) = 13 or length(pol.agentcom) = 16) and
						 (substr(pol.agentcom, 1, 2) = '86' and
						 substr(pol.agentcom, 9, 1) = '8')) then
						lo.TransSaleChnl := '07';
					end if;
				end if;
			end;

			begin
				select sum(money)
					into lo.cuml_partsurrender
					from lcinsureacctrace
				 where polno = pol.polno
					 and moneytype = 'TB'
					 and exists (select 1
									from lpedoritem
								 where edortype = 'OP'
									 and contno = lcinsureacctrace.contno); /*????????*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				select customgetpoldate
					into lo.customgetpoldate
					from lccont
				 where contno = pol.contno;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				select freestartdate
					into lo.freestartdate
					from lcprem
				 where freeflag = '1'
					 and rownum = 1
					 and polno = pol.polno; /*??????:FreeStartDate*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT NVL(SUM(prem), 0)
					into lo.standprem
					FROM lcprem
				 WHERE polno = pol.polno
					 AND payplancode not like '000000%'
					 AND length(dutycode) = 6; /*??*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT NVL(SUM(prem), 0)
					into lo.otherprem
					FROM lcprem
				 WHERE polno = pol.polno
					 AND payplancode like '000000%'
					 AND payplantype = '03'; /*????:OccPrem*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT NVL(SUM(prem), 0)
					into lo.occprem
					FROM lcprem
				 WHERE polno = pol.polno
					 AND payplancode like '000000%'
					 AND payplantype = '02'; /*????:OccPrem*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT NVL(SUM(prem), 0)
					into lo.healthprem
					FROM lcprem
				 WHERE polno = pol.polno
					 AND payplancode like '000000%'
					 AND payplantype = '01'; /*????:HealthPrem*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				select freeflag
					into lo.freeflag
					from lcprem
				 where freeflag = '1'
					 and polno = pol.polno
					 and rownum = 1; /*??????*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT NVL(SUM(sumgetmoney), 0)
					into lo.shouldgetmoney
					FROM ljaget a
				 WHERE a.otherno = pol.polno
					 AND confdate IS NULL; /*??????:SouldGetMoney*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin

				SELECT TRUNC(MONTHS_BETWEEN(MIN(getstartdate), lo.insuredbirthday) / 12),
							 MIN(getstartdate)
					into lo.revgetage, lo.revgetdate
					FROM lcget
				 WHERE polno = pol.polno
					 AND getdutycode IN
							 (SELECT getdutycode FROM lmdutyget WHERE gettype2 = '1');
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT SUM(summoney)
					into lo.expmoney
					FROM lcget
				 WHERE polno = pol.polno
					 AND getdutycode IN
							 (SELECT getdutycode FROM lmdutyget WHERE gettype1 = '0'); /*??????:ExpMoney*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT SUM(summoney)
					into lo.totalmoney
					FROM lcget
				 WHERE polno = pol.polno; /*??????:TotalMoney*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT SUM(summoney)
					into lo.annmoney
					FROM lcget
				 WHERE polno = pol.polno
					 AND getdutycode IN
							 (SELECT getdutycode FROM lmdutyget WHERE gettype1 = '1'); /*??????:AnnMoney*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT SUM(case
										 when getdutykind in
													('101', '201', '102', '202', '103', '203') then
											pay
									 end),
							 SUM(case
										 when getdutykind IN
													('104', '204', '100', '200', '105', '205') then
											pay
									 end)
					into lo.deathmoney, lo.medmoney
					FROM ljagetclaim
				 WHERE polno = pol.polno
					 and FeeFinaType <> 'CM'; /*????????*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT SUM(case feefinatype
										 when 'TB' then
											getmoney
									 end),
							 SUM(case feefinatype
										 when 'TF' then
											getmoney
									 end)
					into lo.surmoney, lo.getmoney
					FROM ljagetendorse
				 WHERE polno = pol.polno;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT COUNT(*)
					into lo.smokingflag
					FROM lccustomerimpart
				 WHERE contno = pol.contno
					 AND impartcode = '020'
					 AND impartver = '001'
					 AND customernotype = 'I'; /*??????:SmokingFlag*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				SELECT actype
					into lo.actype
					FROM lacom
				 WHERE agentcom = pol.agentcom; /*??????:ACType*/
			exception
				when NO_DATA_FOUND then
					null;
			end;

			begin
				select sum(amnt)
					into lo.bonusamnt
					from lcduty
				 where length(dutycode) = 10
					 and substr(dutycode, 7, 1) = '1'
					 and polno = pol.polno;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			--???
			if (pol.riskcode = '314301' or pol.riskcode = '314302') then
				begin
					select sum(insuaccbala)
						into lo.av_last_cal
						from lcinsureacc
					 where polno = pol.polno; /*????????*/
				exception
					when NO_DATA_FOUND then
						null;
				end;

				begin
					select max(baladate)
						into lo.acval_cal_date
						from lcinsureacc
					 where polno = pol.polno; /*??????*/
				exception
					when NO_DATA_FOUND then
						null;
				end;

				begin
					select sum(money)
						into lo.av_boy
						from lcinsureacctrace
					 where polno = pol.polno
						 and contno = pol.contno
						 and paydate <= tThisYearStart; /*??????*/
				exception
					when NO_DATA_FOUND then
						null;
				end;

				begin
					select sum(money)
						into lo.av_bom
						from lcinsureacctrace
					 where polno = pol.polno
						 and contno = pol.contno
						 and paydate <= tPingGuMonth; /*??????*/
				exception
					when NO_DATA_FOUND then
						null;
				end;

				begin
					select sum(getmoney), max(makedate)
						into lo.tbmoney, lo.tbmdate
						from ljagetendorse
					 where contno = pol.contno
						 and polno = pol.contno
						 and makedate between tPingGuMonth and tPingGuDate
						 and FEEOPERATIONTYPE = 'OP';
				exception
					when NO_DATA_FOUND then
						null;
				end;
			end if;

			begin
				--???
				lo.revgetmoney := 0;
				lo.revgetintv  := 0;
				select count(1)
					into nflag
					from lmriskduty
				 where dutycode in
							 (select dutycode
									from lmdutygetrela
								 where getdutycode in (select getdutycode
																				 from lmdutyget
																				WHERE gettype2 = '1'))
					 and riskcode = pol.riskcode;
				if nflag > 0 then
					SELECT NVL(SUM(standmoney), 0), MIN(getintv)
						into lo.revgetmoney, lo.revgetintv
						FROM (SELECT /*+use_nl(lmdutyget,lcget)*/
									 polno,
									 standmoney,
									 getintv,
									 RANK() OVER(PARTITION BY polno ORDER BY getstartdate) AS RANK
										FROM lcget
									 WHERE getdutycode IN
												 (SELECT getdutycode
														FROM lmdutyget
													 WHERE gettype2 = '1'))
					 WHERE RANK = 1
						 AND polno = pol.polno;
				end if;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			if (pol.riskcode = '212401' AND pol.managecom LIKE '8613%' AND
				 pol.managefeerate = 0.0136 and pol.cvalidate between date
					'2004-01-01' AND date '2005-05-11') then
				lo.managefeerate := 0.03;
			end if;

			--?????????getdutykind
			begin
				if (pol.riskcode in ('212401', '212402')) then
					select getdutykind
						into lo.getdutykind
						from lcget b
					 where polno = pol.polno
						 and exists (select getdutycode
										from lmdutyget m
									 where m.type = '0'
										 and m.getdutycode = b.getdutycode)
						 and rownum = 1;
				end if;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			--????????: ??=??????(????)??+??????(????)??+??????????
			begin
				if (pol.riskcode = '212402') then
					select nvl(sum(insuaccbala), 0)
						into lo.amnt
						from lcinsureacc
					 where insuaccno in ('000001', '000002', '000003')
						 and polno = pol.polno;
				end if;
			exception
				when NO_DATA_FOUND then
					null;
			end;

			lo.TotalMoney := nvl(lo.AnnMoney, 0) + nvl(lo.DeathMoney, 0) +
											 nvl(lo.MedMoney, 0) + nvl(lo.ExpMoney, 0);

			--??
			insert into loreserve values lo;
		exception
			when others then
				insert into loreserve_rec
				values
					('loreserve error with ' || pol.polno, sysdate);
				commit;
		end;
		<<end_loop>>
		null;
	END LOOP;
	begin
		insert into loreserve_rec values ('loreserve record end', sysdate);
		dbms_utility.exec_ddl_statement('alter table LORESERVE add constraint pk_loreserve primary key (POLNO)');
	exception
		when others then
			null;
	end;
	insert into loreserve_rec values ('loreserve end', sysdate);
	commit;
	dbms_output.put_line('done');
end;


/

