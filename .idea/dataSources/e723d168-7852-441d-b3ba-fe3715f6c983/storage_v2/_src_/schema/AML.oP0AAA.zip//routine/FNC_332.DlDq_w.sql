create function fnc_332(tMainPolNo char, tMult char)
  return number is
  Result number;

  t_riskcode number;
begin

  --t_riskcode??????????
  t_riskcode := 0;
  select riskcode into t_riskcode from lcpol where PolNo = tMainPolNo;

  if t_riskcode = '00608000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((PayIntv <> '0' and InsuYear in ('10', '15') and
           tMult <= 2 * mult)
        or (PayIntv <> '0' and InsuYear = '20' and tMult <= 4 * mult));
  end if;

  if t_riskcode = '00609000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and PayIntv = '0'
       and InsuYear = '5'
       and tMult <= 2 * mult;
  end if;

  if t_riskcode = '00613000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((PayIntv = '0' and InsuYear = '20' and tMult <= 8 * mult)
        or (PayIntv = '0' and InsuYear in ('15', '10') and
           tMult <= 4 * mult));
  end if;

  if t_riskcode = '00629000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((InsuYear in ('20', '30') and tMult <= 8 * mult)
        or (InsuYear in ('10', '15') and tMult <= 4 * mult));
  end if;
  return(result);
end fnc_332;


/

