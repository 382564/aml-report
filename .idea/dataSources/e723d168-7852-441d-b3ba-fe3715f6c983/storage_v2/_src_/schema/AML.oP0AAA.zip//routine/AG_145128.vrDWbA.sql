create FUNCTION AG_145128(GetAge in char, GetIntv in char,GetCount in char) return integer is
  flag integer;
begin
  flag:=0;
  if GetAge=45 then
     if GetIntv=12 then
        if GetCount in (11,16,19) or GetCount>=21 then
           flag:=1;
        end if;
     end if;
     if GetIntv=1 then
        if GetCount in (121,181,217) or mod((GetCount-241),12)=0 and GetCount>=241 then
           flag:=1;
        end if;
     end if;
  end if;
  if GetAge=50 then
     if GetIntv=12 then
        if GetCount in (11,14) or GetCount>=16 then
           flag:=1;
        end if;
     end if;
     if GetIntv=1 then
        if GetCount in (121,157) or mod((GetCount-181),12)=0 and GetCount>=181 then
           flag:=1;
        end if;
     end if;
  end if;
  if GetAge=55 then
     if GetIntv=12 then
        if GetCount=11 or GetCount>=13 then
           flag:=1;
        end if;
     end if;
     if GetIntv=1 then
        if GetCount=121 or mod((GetCount-145),12)=0 and GetCount>=145 then
           flag:=1;
        end if;
     end if;
 end if;
 if GetAge>=60 then
     if GetIntv=12 then
        if GetCount>=11 then
           flag:=1;
        end if;
     end if;
     if GetIntv=1 then
        if mod((GetCount-121),12)=0 and GetCount>=121 then
           flag:=1;
        end if;
     end if;
 end if;
  return(flag);
end AG_145128;


/

