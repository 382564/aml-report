create FUNCTION calSumMoney(
       tAgentCode in varchar2,
       tWageNo in varchar2)
       return number is
  Result number;
  --????????
begin
  select T30-T8+T39 into Result
  from laindexinfo
  where indextype='01' and trim(indexcalno)=tWageNo and trim(agentcode) = tAgentCode;

  if (Result<0) then
   Result := 0;
  end if;

  return(Result);
end calSumMoney;


/

