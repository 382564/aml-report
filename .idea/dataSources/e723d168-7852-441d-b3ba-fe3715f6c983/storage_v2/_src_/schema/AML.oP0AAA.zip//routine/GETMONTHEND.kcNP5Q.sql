create FUNCTION getMonthEnd(StartDate in date, intvl in integer,tStatType in varchar2) return date is
  tTempDate date;
  tNewDate  varchar2(10);
  tIntvl    integer:=0;

  Result    date;
  begin
  tIntvl := intvl;
  tTempDate := add_months(StartDate,tIntvl);
--  select EndDate into tNewDate from LAStatSegment where startdate<=tTempDate and tTempDate<=EndDate and StatType= trim(tStatType);
  tNewDate := to_char(last_day(tTempDate),'yyyy-mm-dd');
  Result := to_date(tNewDate,'yyyy-mm-dd');

  return(Result);
end getMonthEnd;


/

