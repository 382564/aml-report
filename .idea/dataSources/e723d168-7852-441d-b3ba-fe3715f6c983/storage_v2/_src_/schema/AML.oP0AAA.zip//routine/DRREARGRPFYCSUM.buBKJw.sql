create FUNCTION DRREARGRPFYCSUM (ACODE in VARCHAR2,AGROUP in VARCHAR2,YEARMONTH in VARCHAR2,SDATE in DATE,EDATE in DATE) return NUMBER is
----------------????????FYC---------------
  FYCSUM NUMBER;
begin
  FYCSUM := 0;
  SELECT NVL(SUM(FYC),0) INTO FYCSUM FROM LACOMMISION
   WHERE PAYYEAR < 1 and CALDATE >= SDATE AND CALDATE <= EDATE AND TRIM(BRANCHCODE) = AGROUP
     ;
  DECLARE
    CAGENT  VARCHAR2(10);
    CGROUP  VARCHAR2(12);
    --CGRADE  VARCHAR2(3);
  CURSOR C_REARGROUPFYC IS
    select distinct AgentCode, TRIM(AGENTGROUP)
      from Latreeaccessory
     where AgentGrade in ('A04', 'A05') AND
       AgentCode not in (select AgentCode from LATree where AgentGrade >= 'A06' and
          AgentCode not in (select AgentCode from Latreeb where TRIM(indexcalno) = YEARMONTH and AgentGrade = 'A05'))
       and AgentCode not in (select AgentCode from laagent where agentState in ('03', '04', '05'))
       and TRIM(rearAgentCode) = ACODE ;
  BEGIN
    OPEN C_REARGROUPFYC;
    LOOP
      FETCH C_REARGROUPFYC INTO CAGENT,CGROUP;
      EXIT WHEN C_REARGROUPFYC%NOTFOUND;
      FYCSUM := FYCSUM + DRREARGRPFYCSum(CAGENT,CGROUP,YEARMONTH,SDATE,EDATE);
    END LOOP;
    CLOSE C_REARGROUPFYC;
  END;
  RETURN FYCSUM;
end DRREARGRPFYCSum;


/

