create FUNCTION getComCodeISC2ByCompany(tCompany in varchar2) return LFComToISCCom.ComCode%type
as
tComCodeISC2 LFFinXml.FinComCode%type;
begin
select nvl(comcodeisc2,tCompany) into tComCodeISC2 from LFComToISCCom where trim(comcodeisc)= trim(tCompany) and rownum=1;

return(tComCodeISC2);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
    tComCodeISC2 := tCompany;
  return(tComCodeISC2);
end;


/

