create function checkPEdorStart(P_EdorAcceptNo varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select case
           when exists (select 1
                   from LPEdorBatchAccept
                  where EdorAcceptNo = P_EdorAcceptNo) then
            '0000000001'
           else
            '0000000002'
         end
    into Result
    from dual;
  return(Result);
end checkPEdorStart;

/

