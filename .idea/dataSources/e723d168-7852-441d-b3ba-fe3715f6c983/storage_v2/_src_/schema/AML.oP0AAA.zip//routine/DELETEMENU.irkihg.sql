create procedure DeleteMenu(P_REFNODE IN VARCHAR2) is
  V_REFNODECODE ldmenu.nodecode%type;
  V_NODECODE ldmenu.nodecode%type;
  V_NODENAME VARCHAR2(30);
  V_PARENTNODECODE ldmenu.nodecode%type;
  V_NODESTR VARCHAR2(200);
  V_PARENTNODE_OF_REFNODE ldmenu.nodecode%type;
  V_LEN integer;
  V_P integer;
  V_CHILDCNT integer;
begin
  V_PARENTNODECODE := '0';
  V_NODESTR := P_REFNODE;
  V_LEN := length(V_NODESTR);

  loop
    V_P := instr(V_NODESTR, '->');
    if V_P > 0 then
      V_NODENAME := substr(V_NODESTR, 1, V_P - 1);
    else
      V_NODENAME := V_NODESTR;
    end if;

    select NodeCode into V_NODECODE from LDMenu where NodeName = V_NODENAME and ParentNodeCode = V_PARENTNODECODE;

    V_PARENTNODECODE := V_NODECODE;
    V_NODESTR := substr(V_NODESTR, V_P + 2, V_LEN);
  exit when V_P = 0;
  end loop;

  V_REFNODECODE := V_NODECODE;

  select Parentnodecode into V_PARENTNODE_OF_REFNODE from LDMenu where NodeCode = V_REFNODECODE;

  select count(*) into V_CHILDCNT from LDMenu where Parentnodecode = V_REFNODECODE;

  if V_CHILDCNT = 0 then
    UPDATE LDMENU
       SET CHILDFLAG = CHILDFLAG - 1
     WHERE NODECODE = V_PARENTNODE_OF_REFNODE;

    DELETE FROM LDMENUGRPTOMENU
     WHERE NODECODE = V_REFNODECODE;

    DELETE FROM LDMENU
     WHERE NODECODE = V_REFNODECODE;

    IF NOT SQL%NOTFOUND THEN
      COMMIT;
      dbms_output.put_line('Delete Success!' || P_REFNODE || ' ????!' || '???:' || V_REFNODECODE);
    ELSE
      ROLLBACK;
      dbms_output.put_line('Error! Delete Error! ' || P_REFNODE || ' ????!');
    END IF;
  else
    -- have child node
    ROLLBACK;
    dbms_output.put_line('Error! Delete Error! ' || P_REFNODE || ' Have childnode! ');
  end if;

exception when others then
  rollback;
  dbms_output.put_line('Error! Delete Error! ' || P_REFNODE);
END DeleteMenu;


/

