create FUNCTION CALDIRMNGSDY(tLevel in varchar2,tAgentCode in varchar2,tAgentGrade in varchar2, tAgentgroup in varchar2,tAttr in varchar2,TempBegin in varchar2,TempEnd in varchar2,tAreaType varchar2,tWageCode varchar2) return number is
  tFYC       number := 0;
  tRate      number := 0;
  tGroup     varchar2(20);
  tBranchAttr varchar2(255);
  Result     number := 0;

begin

  --???tlevel='T';?:'D'
  if tAgentGrade >= 'A06' and tLevel='T' then
    select trim(branchcode) into tGroup from laagent
    where trim(AgentCode) = trim(tAgentCode);
     ---tjj change 0101---
    tBranchAttr:= trim(getbranchattr(tGroup));

    if tAgentGrade >= 'A08' then
      tFYC := nvl(caldirgroupfyc(tAgentCode,'A04',tGroup,tBranchAttr,TempBegin,TempEnd,tAreaType),0);
    else
      tFYC := nvl(caldirgroupfyc(tAgentCode,tAgentGrade,tGroup,tBranchAttr,TempBegin,TempEnd,tAreaType),0);
    end if;
  else
    tFYC := nvl(caldirgroupfyc(tAgentCode,tAgentGrade,tAgentGroup,tAttr,TempBegin,TempEnd,tAreaType),0);
  end if;


  if tFYC = 0 then
    return(0);
  end if;

  select nvl(drawrate,0) into tRate from lawageradix
  where trim(wagecode) = trim(tWageCode)
        and trim(AreaType) = trim(tAreaType)
        and FYCMin  <=tFYC
        and (FYCMax > tFYC or FYCMax is null)
        and trim(agentgrade)   = trim(tAgentGrade)
        ;

  Result := tFYC * tRate;
  return(Result);
end CALDIRMNGSDY;


/

