create function getRiskRateVersion(
       --?????
       tScanDate date,   --????
       --tongmeng 2005-09-20 add
       --??????
       tSignDate date,
       tRiskCode laratecommision.riskcode%type,
       tBranchType lacommision.branchtype%type
       ) return varchar as   --???????
result varchar(2);
begin
if (tRiskCode='112203' and (tBranchType='1' or tBranchType='4' or tBranchType='5' or tBranchType='8' or tBranchType='9' or tBranchType='99'))
then
if (tScanDate>to_date('2004-08-25','yyyy-MM-dd'))
then
   result:='12';
 else
  result:='11';
end if;
else
  result:='11';
end if;

if(tBranchType='1' or tBranchType='4' or tBranchType='5' or tBranchType='8' or tBranchType='9' or tBranchType='99') then
     if (tRiskCode='112204' or tRiskCode='112201')
     then
         if (tSignDate>=to_date('2005-09-20','yyyy-MM-dd'))
         then
               result:='12';
         else
               result:='11';
          end if;
     end if;
end if;

-- add by jiaqiangli 2007-09-19 111504??????
if(tBranchType='1' or tBranchType='4' or tBranchType='5' or tBranchType='8' or tBranchType='9' or tBranchType='99') then
     if (tRiskCode='111504') then
         if (tSignDate >= to_date('2007-09-26','YYYY-MM-DD')) then
               result:='12';
         else
               result:='11';
         end if;
     end if;
end if;

return result;

End getRiskRateVersion;


/

