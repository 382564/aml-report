create function AMOUNT(vAgentCode  in varchar2,
                                  vIndexCalNo in varchar2,
                                  vbranchtype in varchar2,
                                  vAgentgrade in varchar2)

 return number is
  Result        number := 0;
  FirstPensions number := 0;
  attend        number := 0;
  money         number := 0;
begin
  select nvl(sum(FirstPension), 0)
    into FirstPensions
    from LAIndexInfo a
   where a.agentcode = vAgentCode
     and branchtype = vbranchtype
     and indextype = '00'
     and IndexCalNo = vIndexCalNo;
  select case
           when FirstPensions >= 1500 and FirstPensions < 3000 then
            0.3
           when FirstPensions >= 3000 and FirstPensions < 6000 then
            0.6
           when FirstPensions >= 6000 and FirstPensions < 12000 then
            0.8
           when FirstPensions >= 12000 and FirstPensions < 30000 then
            1
           when FirstPensions >= 30000 then
            1.1
           else
            0
         end
    into attend
    from dual;
  if vAgentgrade = 'A01' then
    money := round(FirstPensions * attend * 0.9, 2);
  elsif vAgentgrade = 'A02' then
    money := round(FirstPensions * attend * 1, 2);
  else
    money := round(FirstPensions * attend * 1.1, 2);
  end if;
  if money > 80000 then
    Result := 80000;
  else
    Result := money;
  end if;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
end;

/

