create function CountWorkDays(StartDate in Date, EndDate in Date)
  return number is
  Result      number := 0;
  NaturalDays number := 0;
begin
  NaturalDays := EndDate - StartDate + 1; --自然日天数
  with NaturalDayTable as
   (select StartDate + rownum - 1 Day
              from dual
            connect by rownum <= NaturalDays) --构建自然日序列
  select sum(decode(nvl(b.workdateflag,defautWorkDay(a.Day)),'Y',1,0))
    into Result
    from NaturalDayTable a, LDCalendar b
   where a.Day = b.commondate(+);
  return(Result);
exception
  when others then
    return 0;
end CountWorkDays;


/

