create FUNCTION calSPSurNewDevBonus(vAgentCode   IN VARCHAR2,
                                               vAgentGrade  IN VARCHAR2,
                                               vIndexCalNo  IN VARCHAR2,
                                               vBeginMonths IN NUMBER,
                                               vEndMonths   IN NUMBER,
                                               vPreceptNo   IN VARCHAR2,
                                               vDelItemCode IN VARCHAR2,
                                               vItemCode    IN VARCHAR2)
  RETURN NUMBER IS
  RESULT       NUMBER := 0;
  tSql         VARCHAR2(5000) := '';
  tsqlfordel   VARCHAR2(2000) := '';
  resultfordel NUMBER := 0;
  tBeginWageNo VARCHAR2(10);
  tEndWageNo   VARCHAR2(10);
BEGIN
  tBeginWageNo := to_char(add_months(to_date(vIndexCalNo, 'YYYYMM'),
                                     vBeginMonths - vEndMonths),
                          'YYYYMM');
  tEndWageNo   := vIndexCalNo;

  -- 计算已发金额（即要扣除的金额）
  SELECT 'select nvl(sum(' || getOtherItemPlace(vDelItemCode) ||
         '),0) from LABONUSINDEXINFO where LABONUSINDEXINFO.agentcode = ''' ||
         vAgentCode || ''' and LABONUSINDEXINFO.indexcalno <= ''' ||
         tEndWageNo || ''' and LABONUSINDEXINFO.indexcalno >= ''' ||
         tBeginWageNo ||
         ''' and exists(select (1) from laitemtoprecept where PreceptNo = LABONUSINDEXINFO.preceptno and PreceptNo = ''' ||
         vPreceptNo || ''')'
    INTO tsqlfordel
    FROM dual;
  EXECUTE IMMEDIATE tsqlfordel
    INTO resultfordel;

  --计算应发金额
  SELECT '
  SELECT nvl(MAX(LABONUSRADIX.RewardMoney), 0) AS RM
    FROM LABONUSRADIX, LABONUSINDEXINFO
   WHERE LABONUSINDEXINFO.agentcode = ''' || vAgentCode || '''
     AND LABONUSINDEXINFO.indexcalno = ''' || vIndexCalNo || '''
     AND LABONUSRADIX.preceptno = ''' || vPreceptNo || '''
     AND LABONUSRADIX.agentgrade = ''' || vAgentGrade || '''
     AND LABONUSRADIX.itemcode = ''' || vItemCode || '''
     AND LABONUSRADIX.StartMonth = ' || vBeginMonths || '
     AND LABONUSRADIX.EndMonth = ' || vEndMonths || ' ' ||
         MAX(SYS_CONNECT_BY_PATH(sql1, ' AND ')) || ''
    INTO tSql
    FROM (SELECT rownum AS rowno,
                 (case (select 'Y' from LABonusIndex where indexcode in ('IND002','IND003') and rcolname = b.rcolname) when 'Y' 
                  then
                  '(select sum(LABONUSINDEXINFO. ' || b.rcolname || ') 
                  from LABONUSINDEXINFO where agentcode = ''' || vAgentCode || ''' 
                  and preceptno = ''' || vPreceptNo || ''' 
                  and indexcalno = ''' || vIndexCalNo || ''') >= LABONUSRADIX.' || b.icolname 
                  else 
                  '(select sum(LABONUSINDEXINFO. ' || b.rcolname || ') 
                  from LABONUSINDEXINFO where agentcode = ''' || vAgentCode || ''' 
                  and preceptno = ''' || vPreceptNo || ''' 
                  and indexcalno >=''' || tBeginWageNo || ''' 
                  and indexcalno <= ''' || tEndWageNo || ''') >= LABONUSRADIX.' || b.icolname 
                  end) AS sql1
            FROM LAIndexToItem a, LABonusIndex b
           WHERE a.indexcode = b.indexcode
             AND a.preceptno = vPreceptNo
             AND a.agentgrade = vAgentGrade
             AND a.itemcode = vItemCode) t
  CONNECT BY PRIOR t.rowno = t.rowno - 1
   START WITH t.rowno = 1;
  EXECUTE IMMEDIATE tSql
    INTO RESULT;

  --计算通算金额（已发-应发）
  RESULT := CASE
              WHEN resultfordel < RESULT THEN
               RESULT - resultfordel
              ELSE
               0
            END;
  RESULT := round(RESULT, 2);

  RETURN(RESULT);
END calSPSurNewDevBonus;


/

