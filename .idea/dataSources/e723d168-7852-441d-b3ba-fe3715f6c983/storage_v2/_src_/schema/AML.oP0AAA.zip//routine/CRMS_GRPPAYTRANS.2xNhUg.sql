create PROCEDURE CRMS_GRPPAYTRANS(TSTRATDATE  IN VARCHAR2,
                                             TENDDATE    IN VARCHAR2,
                                             TCUSTOMERNO IN VARCHAR2,
                                             ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Trans D
       WHERE D.TRANSNO IN (SELECT C.PAYNO
                             FROM LCGRPCONT A, LJAPAY C
                            WHERE A.APPFLAG <> '0'
                              AND A.GRPCONTNO = C.OTHERNO
                              AND A.APPNTNO = TCUSTOMERNO
                           UNION
                           SELECT C.PAYNO
                             FROM LJAPAY C, LPEDORITEM LP, LCGRPCONT B
                            WHERE LP.EDORACCEPTNO = C.OTHERNO
                              and LP.grpcontno = B.grpcontno
                              AND C.APPNTNO = TCUSTOMERNO);
      --开始提数
      INSERT INTO MID_CR_Trans
        SELECT C.PAYNO TRANSNO,
               A.GRPCONTNO ContNo,
               '02' ContType,
               A.Salechnl TransMethod,
               c.othernotype transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMACTUPAYMONEY PAYAMT,
               '1' PAYWAY,
               (SELECT D.PAYMODE
                  FROM LJTEMPFEECLASS D, LJTEMPFEE E
                 WHERE E.OTHERNO = A.grpcontno
                   AND E.TEMPFEENO = D.TEMPFEENO
                   AND ROWNUM = 1) PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               CASE
                 WHEN C.OTHERNOTYPE = '10' THEN
                  A.HANDLERNAME
                 ELSE
                  C.Operator
               END OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCGRPCONT A, LJAPAY C
         WHERE A.APPFLAG <> '0'
           AND A.GRPCONTNO = C.OTHERNO
           and A.GRPCONTNO <> '00000000000000000000'
           AND A.APPNTNO = TCUSTOMERNO --有客户号时，只通过客户号查询
        union
        SELECT C.PAYNO TRANSNO,
               A.GRPCONTNO ContNo,
               '02' ContType,
               (SELECT apptype
                  FROM lpedorapp
                 WHERE edoracceptno = B.edoracceptno) transmethod,
               c.othernotype transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMACTUPAYMONEY PAYAMT,
               '1' PAYWAY,
               (SELECT D.PAYMODE
                  FROM LJTEMPFEECLASS D, LJTEMPFEE E
                 WHERE E.OTHERNO = A.grpcontno
                   AND E.TEMPFEENO = D.TEMPFEENO
                   AND ROWNUM = 1) PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               CASE
                 WHEN C.OTHERNOTYPE = '10' THEN
                  A.HANDLERNAME
                 ELSE
                  C.Operator
               END OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM lpedoritem b, LJAPAY C, LCGRPCONT A
         WHERE b.edoracceptno = C.OTHERNO
           and b.grpcontno = a.grpcontno
           and A.GRPCONTNO <> '00000000000000000000'
           and b.uwflag ='9'
           AND A.APPNTNO = TCUSTOMERNO; --有客户号时，只通过客户号查询
      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Trans D
         WHERE D.TRANSNO IN (SELECT C.PAYNO
                               FROM LCGRPCONT A, LJAPAY C
                              WHERE A.APPFLAG <> '0'
                                AND A.GRPCONTNO = C.OTHERNO
                                AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                    TCDATE AND TMDATE
                             UNION
                             SELECT C.PAYNO
                               FROM LJAPAY C, LPEDORITEM LP, LCGRPCONT B
                              WHERE LP.EDORACCEPTNO = C.OTHERNO
                                and LP.grpcontno = B.grpcontno
                                AND LP.Edorvalidate BETWEEN
                                    TCDATE AND TMDATE); --没有客户号时，通过时间查询
        --开始提数
        INSERT INTO MID_CR_Trans
          SELECT distinct C.PAYNO TRANSNO,
                 A.GRPCONTNO ContNo,
                 '02' ContType,
                 A.Salechnl TransMethod,
                 c.othernotype transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMACTUPAYMONEY PAYAMT,
                 '1' PAYWAY,
                 (SELECT D.PAYMODE
                    FROM LJTEMPFEECLASS D, LJTEMPFEE E
                   WHERE E.OTHERNO = A.grpcontno
                     AND E.TEMPFEENO = D.TEMPFEENO
                     AND ROWNUM = 1) PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 C.Operator OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCGRPCONT A, LJAPAY C
           WHERE A.APPFLAG <> '0'
             AND A.GRPCONTNO = C.OTHERNO
             and A.GRPCONTNO <> '00000000000000000000'
              AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE --没有客户号时，通过时间查询
          union
          SELECT distinct C.PAYNO TRANSNO,
                 A.GRPCONTNO ContNo,
                 '02' ContType,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = B.edoracceptno) transmethod,
                  c.othernotype transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMACTUPAYMONEY PAYAMT,
                 '1' PAYWAY,
                 (SELECT D.PAYMODE
                    FROM LJTEMPFEECLASS D, LJTEMPFEE E
                   WHERE E.OTHERNO = A.grpcontno
                     AND E.TEMPFEENO = D.TEMPFEENO
                     AND ROWNUM = 1) PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 A.HANDLERNAME OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM lpedoritem b, LJAPAY C, LCGRPCONT A
           WHERE b.edoracceptno = C.OTHERNO
             and b.grpcontno = a.grpcontno
             and A.GRPCONTNO <> '00000000000000000000'
             and b.uwflag ='9'
             AND b.Edorvalidate BETWEEN TCDATE AND
                 TMDATE; --没有客户号时，通过时间查询
        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_GRPPAYTRANS;


/

