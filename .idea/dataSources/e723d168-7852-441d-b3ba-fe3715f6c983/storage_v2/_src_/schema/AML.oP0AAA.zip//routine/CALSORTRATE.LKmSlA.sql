create function calSortRate(begin_Date   varchar2,
                                       insuyear     number,
                                       insuyearflag varchar2) return number is
  Result      number;
  count_month number;
begin
  Result := 0;
  if insuyear=1 and insuyearflag = 'Y' then
    Result := 1;
  end if;
  if insuyearflag = 'M' then
    if insuyear = 12 then
      Result := 1;
    elsif insuyear = 11 then
      Result := 0.95;
    elsif insuyear = 10 then
      Result := 0.9;
    elsif insuyear = 9 then
      Result := 0.85;
    elsif insuyear = 8 then
      Result := 0.8;
    elsif insuyear = 7 then
      Result := 0.75;
    elsif insuyear = 6 then
      Result := 0.65;
    elsif insuyear = 5 then
      Result := 0.55;
    elsif insuyear = 4 then
      Result := 0.45;
    elsif insuyear = 3 then
      Result := 0.35;
    elsif insuyear = 2 then
      Result := 0.25;
    elsif insuyear = 1 then
      Result := 0.15;
    end if;
  end if;
  if insuyearflag = 'D' then
    select months_between((to_date(begin_Date, 'YYYY-MM-DD') + insuyear),
                          to_date(begin_Date, 'YYYY-MM-DD'))
      into count_month
      from dual;
    if count_month>12 then
      Result := 0; 
    elsif count_month > 11 then
      Result := 1;
    elsif count_month > 10 then
      Result := 0.95;
    elsif count_month > 9 then
      Result := 0.9;
    elsif count_month > 8 then
      Result := 0.85;
    elsif count_month > 7 then
      Result := 0.8;
    elsif count_month > 6 then
      Result := 0.75;
    elsif count_month > 5 then
      Result := 0.65;
    elsif count_month > 4 then
      Result := 0.55;
    elsif count_month > 3 then
      Result := 0.45;
    elsif count_month > 2 then
      Result := 0.35;
    elsif count_month > 1 then
      Result := 0.25;
    else
      Result := 0.15;
    end if;
  end if;

  return(Result);
end calSortRate;


/

