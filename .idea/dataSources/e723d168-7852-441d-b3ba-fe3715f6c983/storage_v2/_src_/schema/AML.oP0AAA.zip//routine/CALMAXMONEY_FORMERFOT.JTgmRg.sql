create function CALMAXMONEY_FormerFOT(getno in varchar2) return varchar2 is
  Result varchar2(40);
  money ljagetclaim.pay%type;
  t_feefinatype ljagetclaim.feefinatype%type;
  t_MONEY ljagetclaim.pay%type default '';
  CURSOR t_SUMMONEY IS
  select sum(abs(pay))   from ljagetclaim where actugetno =getno and pay <>0 and feefinatype<>'HK' group by  feefinatype;
begin
  money := 0;
 ---按照赔付方式查询出最大的赔付金额

  open t_SUMMONEY;
  loop
    fetch t_SUMMONEY into t_MONEY;
     if money<t_MONEY then money:=t_MONEY;
     end if;
    exit when t_SUMMONEY%notfound;
  end loop;
  close t_SUMMONEY;
  ---按照最大的赔付金额，查询出赔付类型
  select feefinatype into t_feefinatype from ( select sum(abs(pay)) pay  ,feefinatype from ljagetclaim where actugetno =getno
    and pay <>0 and feefinatype<>'HK' group by  feefinatype)where pay=money and rownum=1;

  --按照赔付类型，来判断此次赔付，贷款抵扣为哪个科目（对于有最大赔付金额还不足贷款的暂时不考虑，目前业务只有一次赔付对应一个赔付类型）
 if t_feefinatype = 'SWPK' then
    --死亡赔款
    Result := 'SSYL';
  elsif t_feefinatype = 'SCPK' then
    --伤残赔款
    Result := 'SSYL';
  elsif t_feefinatype = 'YLPK' then
    --医疗赔款
    Result := 'SSYL';
  elsif t_feefinatype = 'DQPK' then
    --短期赔款
    Result := 'PKZC';
  elsif t_feefinatype = 'TB' then
    --短期赔款
    Result := 'TB';
   elsif t_feefinatype = 'TF' then
    --短期赔款
    Result := 'TF';
  else
    Result := '0000';
  end if;

  return(Result);
end CALMAXMONEY_FormerFOT;


/

