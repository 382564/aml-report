create FUNCTION gethelaprem_02(p_grpcontno VARCHAR2,
                                          p_riskcode  VARCHAR2,
                                          p_uwflag    VARCHAR2)
  RETURN VARCHAR2 IS
  RESULT VARCHAR2(20);
BEGIN
  SELECT CASE
           WHEN EXISTS (SELECT 1
                   FROM ldcode
                  WHERE codetype = 'ishelarisk'
                    AND code = p_riskcode
                    AND othersign = '2') THEN
            (SELECT nvl(SUM(prem), 0)
               FROM lcgrppol
              WHERE grpcontno = p_grpcontno
                AND riskcode = p_riskcode)
           ELSE
            CASE
              WHEN p_uwflag = '1' THEN
               (SELECT nvl(SUM(prem), 0)
                  FROM lcpol
                 WHERE riskcode = p_riskcode
                   AND grpcontno = p_grpcontno
                   AND appflag = '1')
              WHEN p_uwflag = '2' THEN
               (SELECT nvl(SUM(prem), 0)
                  FROM lcpol
                 WHERE riskcode = p_riskcode
                   AND grpcontno = p_grpcontno
                   AND (uwflag = '9' OR uwflag = 'z')
                   AND appflag = '1')
              ELSE
               (SELECT nvl(SUM(prem), 0)
                  FROM lcpol
                 WHERE riskcode = p_riskcode
                   AND grpcontno = p_grpcontno
                   AND appflag = '1')
            END
         END + nvl((SELECT SUM(-realmoney)
                     FROM lppttrace
                    WHERE grpcontno = p_grpcontno
                      AND riskcode = p_riskcode),
                   0)
    INTO RESULT
    FROM dual;
  RETURN(RESULT);
END gethelaprem_02;

/

