create function         getPremRate(p_polno in varchar2)
  return number is
  v_RiskPeriod varchar2(1);
  v_RiskCode varchar2(20);
  v_PayIntv int;
  Result number;
begin
   
  select riskcode into v_Riskcode from lcpol where polno = p_polno;
  select RiskPeriod
    into v_RiskPeriod
    from lmriskapp
   where riskcode = v_Riskcode;
   select payintv into v_PayIntv from lcpol where polno = p_polno;
   
   if v_PayIntv = 0 and v_RiskPeriod = 'L' then
     Result:=0.1;
    else
     Result := 1;
		end if;
  return(Result);
end getPremRate;


/

