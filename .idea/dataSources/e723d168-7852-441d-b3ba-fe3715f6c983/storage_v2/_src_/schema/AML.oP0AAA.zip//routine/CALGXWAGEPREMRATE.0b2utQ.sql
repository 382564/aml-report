create procedure calgxWagePremRate(tBranchType in varchar2,
                                              tBranchType2 in varchar2) is
  tSysdate date;
  tSysTime varchar2(10);
begin
  tSysdate := trunc(sysdate);
  tSysTime := to_char(Sysdate, 'HH24:MI:SS');
  DECLARE
    tcommisionsn varchar2(20);
    tFYCRate     number;
    tFYC         number;

    CURSOR gx_FYCRate IS

      select a.commisionsn, round(nvl(a.transmoney * b.Rate, 0), 2), b.Rate
        from lacommision a, LARateCommision b
       where a.RiskCode = b.RiskCode
         and a.payyears = b.F01
         and a.BranchType = b.BranchType
         and a.BranchType2 = b.BranchType2
         and a.BranchType = tBranchType
         and a.BranchType2 = tBranchType2
         and get_age(a.cvalidate, sysdate) = 0
         and b.CurYear = '1';
  BEGIN
    OPEN gx_FYCRate;
    LOOP
      FETCH gx_FYCRate
        INTO tcommisionsn, tFYC, tFYCRate;
      EXIT WHEN gx_FYCRate%NOTFOUND;
      update lacommision a
         set FYCRate      = tFYCRate,
             FYC          = tFYC,
             a.modifydate = tSysdate,
             a.modifytime = tSysTime
       where a.branchtype = tBranchType
         and a.commisionsn = tcommisionsn;
      commit;

    END LOOP;
    CLOSE gx_FYCRate;
  END;
end calgxWagePremRate;

/

