create FUNCTION DestAgentGradeB08(
       tAreaType laagentpromradix1.areatype%TYPE, --????
       tChannelType laplan.plancond1%TYPE, --????
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE, -- ?????
       tIndexCalNo integer   --????
       ) return varchar2 as   --???????
v_Grade varchar2(10);--??????
begin
select DestAgentGrade into v_Grade from LAAgentPromRadix1 where
MarkEnd>(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and MarkBegin<=(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and AgentGrade=tAgentGrade and AreaType =tAreaType and ChannelType = tChannelType;
--??????(?,?,??)



 return v_Grade;
End DestAgentGradeB08;


/

