create function GetEdition(tManageCom in varchar2,tBranchType in varchar2 ) return varchar2 is
  Result varchar2(4);
begin
/*
function:?????
parameter:
           tManageCom  ????(?????)
           tBranchType ????
author:zhanggl
date: 2006-12-27
*/

  --??????????
  if (trim(tBranchType)='4') then
    select trim(code2) into Result from ldcoderela where relatype='comtoareatype' and trim(code1)=substr(tManageCom,0,6) and trim(code3)=trim(tBranchType);
  else
    select trim(code2) into Result from ldcoderela where relatype='comtoareatype' and trim(code1)=substr(tManageCom,0,4) and trim(code3)=trim(tBranchType);
  end if;
  return(Result);
end GetEdition;


/

