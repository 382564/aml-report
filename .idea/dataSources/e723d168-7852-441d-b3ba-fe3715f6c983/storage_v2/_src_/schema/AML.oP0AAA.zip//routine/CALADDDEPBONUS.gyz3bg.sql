create FUNCTION CALADDDEPBONUS (tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2,tAreaType in varchar2,TempBegin in date,TempEnd in date) return number is
  FYC1     number := 0;
  FYC2     number := 0;
  FYC3     number := 0;
  FYC4     number := 0;
  tFYC     number := 0;
  Result   number := 0;

  tDrawRate   number := 0;
  tCalBegin date := add_months(TempBegin,1);

  cursor d1_View is
    select branchattr from labranchgroup
    where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
        and CommBreakFlag = '0'
        and months_between(tCalBegin,startdate)<=12
        and (AgentGrade ='A06' or AgentGrade ='A07')
        and trim(RearAgentCode) = trim(tAgentCode)
       )
       and EndFlag<>'Y'
       and branchlevel='02';

  cursor d2_View is
    select branchattr from labranchgroup
     where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
          and CommBreakFlag = '0'
           and months_between(tCalBegin,startdate)>12
           and (AgentGrade   ='A06' or AgentGrade ='A07')
           and trim(RearAgentCode) = trim(tAgentCode)
        )
        and EndFlag<>'Y'
        and branchlevel='02';


  cursor i1_View is
    select branchattr from labranchgroup
     where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
            and CommBreakFlag ='0'
                 and months_between(tCalBegin,startdate)<=12
                 and RearAgentCode in
                 (select distinct AgentCode from latreeaccessory
                  where CommBreakFlag ='0'
                  and (AgentGrade = 'A06' or AgentGrade = 'A07'
                  and trim(RearAgentCode) = trim(tAgentCode))
                 )
                 and (AgentGrade = 'A06' or AgentGrade = 'A07')
           )
           and EndFlag<>'Y'
           and branchlevel='02' ;

  cursor i2_View is
    select branchattr from labranchgroup
     where exists
          ( select 'X' from LATreeAccessory
            where agentcode = labranchgroup.branchmanager
            and CommBreakFlag ='0'
                 and months_between(tCalBegin,startdate)>12
                 and RearAgentCode in
                 (select distinct AgentCode from latreeaccessory
                  where CommBreakFlag ='0'
                    and (AgentGrade = 'A06' or AgentGrade = 'A07')
                    and trim(RearAgentCode) = trim(tAgentCode)
                 )
                 and (AgentGrade = 'A06' or AgentGrade = 'A07')
           )
           and EndFlag<>'Y'
           and branchlevel='02' ;

begin

  --???????????????????FYC
  for v_View in d1_View Loop
    select nvl(sum(fyc),0) into tFYC from lacommision
    where CommDire = '1'
          and payyear < 1
          and caldate >= TempBegin
          and caldate <= TempEnd
          and trim(BranchAttr) like concat(trim(v_View.branchattr),'%');

    FYC1 := tFYC + FYC1;
  end LOOP;
  select nvl(drawrate,0) into tDrawRate from lawageradix
    where trim(AreaType)=trim(tAreaType)
      and trim(RearType)='01'
      and drawStart = 0
      and drawEnd = 12
      and trim(agentgrade)=trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode);
  FYC1 := FYC1 * tDrawRate;


  --???????????????????FYC
  tFYC := 0;
  tDrawRate := 0;
  for v_View in d2_View Loop
    select nvl(sum(fyc),0) into tFYC from lacommision
    where CommDire = '1'
          and payyear < 1
          and caldate >= TempBegin
          and caldate <= TempEnd
          and trim(BranchAttr) like concat(trim(v_View.branchattr),'%');


    FYC2 := FYC2 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
    where trim(AreaType)=trim(tAreaType)
      and trim(RearType)='01'
      and drawStart = 13
      and trim(agentgrade)=trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode);
  FYC2 := FYC2 * tDrawRate;


  --???????????????????FYC
  tFYC := 0;
  tDrawRate := 0;
  for v_View in i1_View Loop
    select nvl(sum(fyc),0) into tFYC from lacommision
    where CommDire = '1'
          and payyear < 1
          and caldate >= TempBegin
          and caldate <= TempEnd
          and trim(BranchAttr) like concat(trim(v_View.branchattr),'%');

    FYC3 := FYC3 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
    where trim(AreaType)=trim(tAreaType)
      and trim(RearType)='02'
      and drawStart = 0
      and drawEnd = 12
      and trim(agentgrade)=trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode);
  FYC3 := FYC3 * tDrawRate;


  --???????????????????FYC
  tFYC := 0;
  tDrawRate := 0;
  for v_View in i2_View Loop
   select nvl(sum(fyc),0) into tFYC from lacommision
    where CommDire = '1'
          and payyear < 1
          and caldate >= TempBegin
          and caldate <= TempEnd
          and trim(BranchAttr) like concat(trim(v_View.branchattr),'%');


    FYC4 := FYC4 + tFYC;
  end Loop;
  select nvl(drawrate,0) into tDrawRate from lawageradix
    where trim(AreaType)=trim(tAreaType)
      and trim(RearType)='02'
      and drawStart = 13
      and trim(agentgrade)=trim(tAgentGrade)
      and trim(wagecode)=trim(tWageCode);
  FYC4 := FYC4 * tDrawRate;

  Result :=  FYC1 + FYC2 + FYC3 + FYC4;

  return(Result);
end CALADDDEPBONUS;


/

