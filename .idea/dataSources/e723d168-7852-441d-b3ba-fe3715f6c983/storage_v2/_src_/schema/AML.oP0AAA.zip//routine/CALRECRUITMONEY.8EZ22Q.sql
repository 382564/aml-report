create function calRecruitMoney(vAgentCode  in varchar2,
                                           vIndexCalNo in varchar2,
                                           vbranchtype in varchar2)

 return number is
  Result         number := 0;
  RearMoney      number := 0;
  RearMoney2     number := 0;
  RearAgentNum   number := 0;
  RearAgentRate  number := 0;
  RearAgentRate2 number := 0;
  vYears         varchar2(6);
  vMonth         varchar2(6);
  tMonth         varchar2(6);
  tfalg          varchar2(6);
  vstartdate     date;
  venddate       date;
begin
  --招募奖金=一代增员FYC*一代奖金系数+二代增员FYC*二代奖金系数
  --（按月发放，FYC提取当月，分红系数以上一个自然季所获计算）（奖金系数时只与绩优人次标准相关，职级无需关注）
  --绩优人力 FTC大于或等于3000的
  select substr(vIndexCalNo, 0, 4), substr(vIndexCalNo, 5, 6)
    into vYears, vMonth
    from dual;

  if vMonth = '01' or vMonth = '02' or vMonth = '03' then
    tMonth := '01';
  elsif vMonth = '04' or vMonth = '05' or vMonth = '06' then
    tMonth := '04';
  elsif vMonth = '07' or vMonth = '08' or vMonth = '09' then
    tMonth := '07';
  else
    tMonth := '10';

  end if;
  select add_months(to_date(vYears || tMonth, 'yyyymm'), -3),
         add_months(last_day(to_date(vYears || tMonth, 'yyyymm')), -1)
    into vstartdate, venddate
    from dual;

  select count(1)
    into tfalg
    from LAIndexInfo
   where FirstPension >= 3000
     and agentcode = vAgentCode
     and indextype = '00'
     and last_day(to_date(IndexCalNo, 'yyyymm')) between vstartdate and
         venddate;
  if tfalg > 0 then
    select count(1)
      into RearAgentNum
      from LAIndexInfo a, LARearRelation R
     where r.AgentCode = a.agentcode
       and r.RearLevel = '00'
       and r.RearFlag = '0'
       and r.rearedgens = '1'
       and branchtype = vbranchtype
       and r.RearAgentCode = vAgentCode
       and FirstPension >= 3000
       and indextype = '00'
       and a.AgentCode <> r.RearAgentCode
       and last_day(to_date(IndexCalNo, 'yyyymm')) between vstartdate and
           venddate;

    if RearAgentNum >= 3 and RearAgentNum < 6 then
      RearAgentRate  := 0.12;
      RearAgentRate2 := 0.04;
    elsif RearAgentNum >= 6 and RearAgentNum < 11 then
      RearAgentRate  := 0.2;
      RearAgentRate2 := 0.08;
    elsif RearAgentNum >= 11 then
      RearAgentRate  := 0.24;
      RearAgentRate2 := 0.12;
    else
      RearAgentRate  := 0;
      RearAgentRate2 := 0;
    end if;
    select round(nvl(sum(FirstPension) * RearAgentRate, 0), 2)
      into RearMoney
      from LAIndexInfo a, LARearRelation R
     where r.AgentCode = a.agentcode
       and r.RearLevel = '00'
       and r.RearFlag = '0'
       and r.rearedgens = '1'
       and branchtype = vbranchtype
       and a.IndexCalNo = vIndexCalNo
       and r.RearAgentCode = vAgentCode;

    select round(nvl(sum(FirstPension) * RearAgentRate2, 0), 2)
      into RearMoney2
      from LAIndexInfo a, LARearRelation R
     where r.AgentCode = a.agentcode
       and r.RearLevel = '00'
       and r.RearFlag = '0'
       and r.rearedgens = '2'
       and branchtype = vbranchtype
       and IndexCalNo = vIndexCalNo
       and r.RearAgentCode = vAgentCode;

    Result := RearMoney + RearMoney2;
  end if;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
end;

/

