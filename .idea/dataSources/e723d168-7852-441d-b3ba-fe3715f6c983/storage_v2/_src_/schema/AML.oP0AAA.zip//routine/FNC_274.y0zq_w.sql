create function fnc_274(n_fee number) return number is
  Result number;

begin

  if n_fee>0 and n_fee<=1000 then Result:=0;
  end if;
  if n_fee>1000 and n_fee<=5000 then Result:=(n_fee-1000)*0.6;
  end if;
  if n_fee>5000 and n_fee<=20000 then Result:=(n_fee-5000)*0.7+4000*0.6;
  end if;
  if n_fee>20000 and n_fee<=40000 then Result:=(n_fee-20000)*0.8+15000*0.7+4000*0.6;
  end if;
  if n_fee>40000 then Result:=(n_fee-40000)*0.9+20000*0.8+15000*0.7+4000*0.6;
  end if;

  return(Result);

end fnc_274;


/

