create function fnc_operator(contplancode char) return char is
  Result   Char(10);
  num Number;  --???????????
  num2 Number; --??????????????
  num3 Number; --?????????????
begin
  Select count(*) into num  From lwmission Where  missionprop1=contplancode;

  --1.??????lw???
  if num>0 Then

      Select Count(*) Into num2 From  lwmission Where missionprop1=contplancode And activityid ='0000002801';
      --?????????,????????????????
      If num2>0 Then
  		   Select createoperator into Result From lwmission Where  missionprop1=contplancode;
      End If;
      --??????????;
      If num2=0 Then
         Select defaultoperator into Result From lwmission Where  missionprop1=contplancode;
      End If;

  End If;

  --2.????????lb??
  If num=0 Then

      Select count(*) Into num3 From lbmission Where  missionprop1=contplancode And activityid ='0000002803';
      If num3 >0 Then
         Select defaultoperator into Result From lbmission Where  missionprop1=contplancode And activityid ='0000002803';
      End If;
      If num3=0 Then
          --????????????????????????????,?0000002801????
          If contplancode Like '86%'Then
              Select createoperator into Result From lbmission Where  missionprop1=contplancode And activityid ='0000002801';
          Else
              Select defaultoperator into Result From lbmission Where  missionprop1=contplancode And activityid ='0000002802';
          End If;
      End If;

  end if;
  return(Result);

end fnc_operator;


/

