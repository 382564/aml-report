create FUNCTION fnc_zt3_5(payendyear in number) return varchar2
is
tR varchar2(20);
begin

  tR := 1;

    if payendyear>=5 then tR := 0.6;
    end if;
    if payendyear>=3 and payendyear<5 then tR := 0.65;
    end if;
    return(tR);
end fnc_zt3_5;


/

