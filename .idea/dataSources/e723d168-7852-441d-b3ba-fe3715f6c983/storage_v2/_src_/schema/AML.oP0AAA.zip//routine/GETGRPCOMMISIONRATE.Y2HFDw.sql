create function getGrpCommisionRate(cRiskcode in varchar2,
                                               cPayintv  in number,
                                               cPayyear  in number,
                                               cPayCount in number)
  return number is
  Result number;
begin
  Result := 0;

  return(Result);
end getGrpCommisionRate;

/

