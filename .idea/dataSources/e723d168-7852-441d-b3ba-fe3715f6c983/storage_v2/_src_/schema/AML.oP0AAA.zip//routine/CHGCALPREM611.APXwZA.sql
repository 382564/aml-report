create FUNCTION chgcalprem611(GetDutyKind in varchar2) return number
is v_tR number;
begin
	if GetDutyKind = '1' then
		v_tR := 30;
	end if;
	if GetDutyKind = '2' then
		v_tR := 0.12;
	end if;
	if GetDutyKind = '3' then
		v_tR := 2.5;
	end if;

	return(v_tR);
end;


/

