create FUNCTION DestAgentGradeC(
       tAreaType laagentpromradix1.areatype%TYPE, --????
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE, -- ?????
       tIndexCalNo integer   --????
       ) return varchar2 as   --???????
v_Grade varchar2(10);--??????


begin

if(substr(tAgentGrade,0,1)='B' or substr(tAgentGrade,0,1)='C') then

select DestAgentGrade into v_Grade from LAAgentPromRadix1 where
MarkEnd>(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and MarkBegin<=(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and AgentGrade=tAgentGrade and AreaType =tAreaType ;--??????(??????)

else

select DestAgentGrade into v_Grade from LAAgentPromRadix2 where
MarkEnd>(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and MarkBegin<=(select T27 from LAIndexInfo where IndexCalNo=tIndexCalNo and AgentCode=tAgentCode)
and AgentGrade=tAgentGrade and AreaType =tAreaType ;--??????(??????)

end if;

 if v_Grade is null then
 v_Grade:='00';
 end if;


 return v_Grade;
End DestAgentGradeC;


/

