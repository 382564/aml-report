create function DistrictBaseWage(tagentgrade in varchar, twagecode in varchar,tcomcode in varchar,tareatype in varchar2) return number is
  Result number(12,4):=0;
  cWage number(12,4):=0;--???
  cCom ldcom.comareatype%type;
  cComRate number(12,4):=0;--????
begin
  select nvl(sum(drawreward),0) into cWage from lawageparam2 where wagecode=twagecode and paracode='WP0075'
  and associateobj=tagentgrade and areatype=tareatype;

  select nvl(sum(comcitysize),1) into cCom from ldcom where trim(comcode)=tcomcode ;

  select nvl(sum(drawreward),1) into cComRate from lawageparam2 where wagecode=twagecode and paracode='WP0031'
  and associateobj=trim(cCom) and areatype=tareatype;
  Result := cWage*cComRate;
  return(Result);
end DistrictBaseWage;


/

