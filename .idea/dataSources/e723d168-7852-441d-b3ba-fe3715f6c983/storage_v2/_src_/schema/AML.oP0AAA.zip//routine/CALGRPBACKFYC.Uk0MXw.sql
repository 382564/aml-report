create FUNCTION CALGRPBACKFYC (SDATE IN DATE,EDATE IN DATE,ACODE IN VARCHAR2,AGRADE IN VARCHAR2,YEARMONTH in VARCHAR2) return number is
--------- ??????????????FYC???? --------

  BACKFLAG     VARCHAR2(1);    --???
  SUMFYC       NUMBER;         --????FYC?
begin
  --?????????
  IF AGRADE < 'A04' THEN
    RETURN 0;
  END IF;
  --????????????(?)?????FYC
  SUMFYC := 0;
  DECLARE
    REAREDCODE     VARCHAR2(10);   -- ??????
    REAREDGROUP    VARCHAR2(12);   -- ?????????
    REAREDGRADE    VARCHAR2(3);    -- ???????
    --NOWGRADE       VARCHAR2(3);    -- ?????????
    RATE           NUMBER;         -- ???? 100% || 50%
    GROUPFYC       NUMBER;         -- ???????????FYC
    OLDAGENTCODE   VARCHAR2(10);
    --v_INDEXCAL       VARCHAR2(6);
    v_BEGINDATE    DATE;
    v_ENDDATE      DATE;
    v_REARSTATE    VARCHAR2(3);    --????????? OLD:?? NEW:????
  CURSOR C_SUMBACKFYC IS
    --??ACODE??????????
    SELECT DISTINCT A.AGENTCODE,A.AGENTGROUP,A.AGENTGRADE,'NEW'
      FROM LATREEACCESSORY A
     WHERE A.AGENTGRADE IN ('A04','A05') AND
     NOT EXISTS (SELECT B.* FROM LATREEB B WHERE trim(B.INDEXCALNO) = YEARMONTH
                               AND B.AGENTCODE = A.AGENTCODE AND A.AGENTGRADE in ('A03','A02'))
     and trim(A.REARAGENTCODE) = ACODE
     UNION
     SELECT DISTINCT A.AGENTCODE,A.AGENTGROUP,A.AGENTGRADE,'OLD'
     FROM LATREEACCESSORYB A
     WHERE NOT (A.STARTDATE > EDATE OR A.ENDDATE < SDATE)
     AND A.AGENTGRADE = 'A04' and A.REARAGENTCODE = ACODE
     ORDER BY AGENTCODE,AGENTGRADE;
  BEGIN
    OPEN C_SUMBACKFYC;
    OLDAGENTCODE := '00';
    LOOP
      FETCH C_SUMBACKFYC INTO REAREDCODE,REAREDGROUP,REAREDGRADE,v_REARSTATE;
      EXIT WHEN C_SUMBACKFYC%NOTFOUND;
      --??????????
      IF v_REARSTATE = 'NEW' THEN
        SELECT NVL(BACKCALFLAG,0) INTO BACKFLAG FROM LATREEACCESSORY
         WHERE AGENTGRADE = REAREDGRADE and AGENTCODE = REAREDCODE;
      ELSE
        SELECT NVL(BACKCALFLAG,0) INTO BACKFLAG FROM LATREEACCESSORYB
         WHERE AGENTGRADE = REAREDGRADE
         AND NOT (STARTDATE > EDATE OR ENDDATE < SDATE)
         and AGENTCODE = REAREDCODE ;
      END IF;
      IF BACKFLAG = '1' THEN
        IF OLDAGENTCODE <> REAREDCODE THEN                -- 1
            OLDAGENTCODE := REAREDCODE;
            --??????????????
            /*SELECT TRIM(MAX(INDEXCALNO)) INTO v_INDEXCAL FROM LAASSESS
             WHERE TRIM(AGENTCODE) = TRIM(REAREDCODE) AND MODIFYFLAG = '03'
             AND TRIM(AGENTGRADE1) = TRIM(REAREDGRADE);
            v_BEGINDATE := ADD_MONTHS(TO_DATE(v_INDEXCAL,'YYYY-MM'),1);               --??
            */
            IF v_REARSTATE = 'NEW' THEN
              SELECT FOUNDDATE INTO v_BEGINDATE FROM LABRANCHGROUP
              WHERE TRIM(AGENTGROUP) = TRIM(REAREDGROUP);
            ELSE
              SELECT FOUNDDATE INTO v_BEGINDATE FROM LABRANCHGROUPB
              WHERE TRIM(AGENTGROUP) = TRIM(REAREDGROUP);
            END IF;
            --v_ENDDATE := ADD_MONTHS(ADD_MONTHS(TO_DATE(v_INDEXCAL,'YYYY-MM'),1)-1,3); --??
            v_ENDDATE := ADD_MONTHS(v_BEGINDATE,3)-1; --??
            IF v_ENDDATE <= EDATE AND v_ENDDATE > SDATE THEN
              IF v_ENDDATE <= EDATE THEN
                RATE := 1;                    --?????????STARTDATE--ENDDATE? 100%
                IF v_BEGINDATE < SDATE THEN
                  v_BEGINDATE := SDATE;
                END IF;
                SELECT NVL(SUM(FYC),0) INTO GROUPFYC FROM LACOMMISION
                 WHERE CALDATE >= v_BEGINDATE AND CALDATE <= v_ENDDATE
                   AND PAYYEAR < 1 AND BRANCHCODE = REAREDGROUP;
                GROUPFYC := GROUPFYC * RATE;
                SUMFYC := SUMFYC + GROUPFYC;
              END IF;
              IF v_ENDDATE < EDATE THEN --??????????STARTDATE--ENDDATE?
                RATE := 0.5;                         --?????50%
                v_BEGINDATE := v_ENDDATE +1;
                v_ENDDATE := ADD_MONTHS(v_ENDDATE,3);
                IF v_ENDDATE > EDATE THEN
                  v_ENDDATE := EDATE;
                END IF;
                SELECT NVL(SUM(FYC),0) INTO GROUPFYC FROM LACOMMISION
                 WHERE CALDATE >= v_BEGINDATE AND CALDATE <= v_ENDDATE
                   AND PAYYEAR < 1 AND BRANCHCODE = REAREDGROUP;
                GROUPFYC := GROUPFYC * RATE;
                SUMFYC := SUMFYC + GROUPFYC;
              END IF;
           ELSIF v_BEGINDATE <= SDATE AND EDATE <= v_ENDDATE THEN
                RATE := 1;                    --?????????STARTDATE--ENDDATE? 100%
                v_BEGINDATE := SDATE;
                v_ENDDATE := EDATE;
                SELECT NVL(SUM(FYC),0) INTO GROUPFYC FROM LACOMMISION
                 WHERE CALDATE >= v_BEGINDATE AND CALDATE <= v_ENDDATE
                   AND PAYYEAR < 1 AND BRANCHCODE = REAREDGROUP;
                GROUPFYC := GROUPFYC * RATE;
                SUMFYC := SUMFYC + GROUPFYC;
           ELSIF v_ENDDATE < SDATE AND ADD_MONTHS(v_ENDDATE,3) <= EDATE AND ADD_MONTHS(v_ENDDATE,3) > SDATE THEN --?????????STARTDATE--ENDDATE? 100%
              v_BEGINDATE := v_ENDDATE + 1;
              v_ENDDATE := ADD_MONTHS(v_ENDDATE,3);
              IF v_BEGINDATE < SDATE THEN
                v_BEGINDATE := SDATE;
              END IF;
              RATE := 0.5;                         --?????50%
              SELECT NVL(SUM(FYC),0) INTO GROUPFYC FROM LACOMMISION
               WHERE CALDATE >= v_BEGINDATE AND CALDATE <= v_ENDDATE
                AND PAYYEAR < 1 AND BRANCHCODE = REAREDGROUP;
              GROUPFYC := GROUPFYC * RATE;
              SUMFYC := SUMFYC + GROUPFYC;
           ELSIF v_ENDDATE < SDATE AND v_ENDDATE+1 <= SDATE AND EDATE <= ADD_MONTHS(v_ENDDATE,3) THEN
              RATE := 0.5;                         --?????50%
              v_BEGINDATE := SDATE;
              v_ENDDATE := EDATE;
              SELECT NVL(SUM(FYC),0) INTO GROUPFYC FROM LACOMMISION
               WHERE CALDATE >= v_BEGINDATE AND CALDATE <= v_ENDDATE
                AND PAYYEAR < 1 AND BRANCHCODE = REAREDGROUP;
              GROUPFYC := GROUPFYC * RATE;
              SUMFYC := SUMFYC + GROUPFYC;
           END IF;
         END IF;
       END IF;
    END LOOP;
    CLOSE C_SUMBACKFYC;
  END;
  return SUMFYC;
end CALGRPBACKFYC;


/

