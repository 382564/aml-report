create FUNCTION DateInterval(cStartDate in Date, cEndDate in Date) return integer is
-- ?????????? (??15??????) --
  iMonthCount integer;
  sLimitBase  integer;
  dBeginDate  Date;
  dEndDate    Date;
begin
  iMonthCount := 0;
  IF cStartDate >= cEndDate THEN
    return 0;
  END IF;
  --IF to_char(cStartDate,'YYYYMM') = to_char(cEndDate,'YYYYMM') THEN
    --iMonthCount := 1;
  --ELSE
    Select trim(varvalue) into sLimitBase From LASysvar
     Where vartype = 'EmployLimit';

    IF TO_CHAR(cStartDate,'DD') > sLimitBase THEN
      dBeginDate := trunc(add_months(cStartDate,1),'MM');  --1?
    ELSE
      dBeginDate := trunc(cStartDate,'MM');
    END IF;
    dEndDate := add_months(trunc(cEndDate,'MM'),1);
    --dEndDate := trunc(cEndDate,'MM');
    iMonthCount := months_between(dEndDate,dBeginDate);
  --END IF;
  return(iMonthCount);
end DateInterval;


/

