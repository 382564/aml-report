create function getSmsState(sContNo in char,sPolNo in char) return char is
  vResI char;
  pragma autonomous_transaction;
 begin


 declare

 vContNo char(20);
 vPolNo  char(20);
 vStateType varchar2(10);
 vStateReason varchar2(10);
 v_row_LCContstate LCContState%rowtype;

 --
 vAvailable char(1) :='';
 vTerminate char(1):='';
 vLost      char(1):='';
 vPayPrem   char(1):='';
 vLoan      char(1):='';
 vBankLoan  char(1):='';
 vRPU       char(1):='';
 vCount     integer := 0;
 vTCount    integer := 0;
 vResI      char(7);
 sql_stmt    VARCHAR2(300);
 sql_stmt_2    VARCHAR2(300);
 --
 tAvailable char(10):='Available';
 tTerminate char(10):='Terminate';
 tLost      char(10):='Lost';
 tPayPrem   char(10):='PayPrem';
 tLoan      varchar(10):='Loan';
 tBankLoan  char(10):='BankLoan';
 tRPU       char(10):='RPU';
 vState     CHAR(10) := '0';
 tType      char(10);

 cursor v_CurSor_LCContState is
 select statetype ,state,statereason
 from lccontstate
 where 1=1
 and contno = vContNo
 and PolNo =vPolNo
 ;

 begin
 vContNo := trim(sContNo);
 vPolNo  := trim(sPolNo);



 sql_stmt := 'select count(1) from lccontstate a
              where  contno = :vContNo
              and polno = :vPolNo
              and statetype = :tType
              and state = :vState
              and enddate is null '
              ;


  sql_stmt_2 := 'select count(1) from lccontstate a
              where  contno = :vContNo
              and statetype = :tType
              and state = :vState
              and enddate is null '
              ;
 --???
  tType :=tAvailable;

 --ExeCute immediate sql_stmt into vCount using vContNo,vPolNo, tType,vState;
         select count(1) into vCount from lccontstate a
              where  contno = vContNo
              and polno = vPolNo
              and statetype = tType
              and state = vState
              and enddate is null
              ;
    if vCount <> 0 then
      vAvailable := '0';
      else
      vAvailable := '1';
    end if;


 -- ???

 --ExeCute immediate sql_stmt into vCount using vContNo,vPolNo,tType,vState;

    begin
      select StateReason into vStateReason from lccontstate a
      where contno = vContNo
      and polno = vPolNo
      and StateType = 'Terminate'
      and state = '1'
      and enddate is null
      and rownum = 1;
        vStateReason :=trim(vStateReason);

        if vStateReason = '01' then
          vTerminate := '1';
        end if;

        if vStateReason = '02' then
          vTerminate := '2';
        end if;

        if vStateReason = '03' then
          vTerminate := '3';
        end if;

        if vStateReason = '04' then
          vTerminate := '4';
        end if;

        if vStateReason = '05' then
          vTerminate := '5';
        end if;

        if vStateReason = '06' then
          vTerminate := '6';
        end if;

        if vStateReason = '07' then
          vTerminate := '7';
        end if;
      EXCEPTION WHEN NO_DATA_FOUND THEN

      vTerminate := '0';

      END;

  -- ???

   -- ExeCute immediate sql_stmt_2 into vCount using vContNo,tLost,vState;
            select count(1) into vCount from lccontstate a
              where contno = vContNo
              and 1=1
              and statetype = tLost
              and state = vState
              and enddate is null
              ;
    if vCount = 0 then
      vLost := '0';
    else
      vLost := '1';
    end if;

 -- ???

   --ExeCute immediate sql_stmt_2 into vCount using vContNo,tPayPrem,vState;
         select count(1) into vCount from lccontstate a
              where  contno = vContNo
              and 1=1
              and statetype = tPayPrem
              and state = vState
              and enddate is null
              ;
    if vCount = 0 then
      vPayPrem := '0';
    else
      vPayPrem := '1';
    end if;

 -- ???

    --ExeCute immediate sql_stmt_2 into vCount using vContNo,tLoan,vState;

         select count(1) into vCount from lccontstate a
              where  contno = vContNo
              and 1=1
              and statetype = 'Loan'
              and state = '1'
              and enddate is null
              ;
    if vCount = 0 then
      vLoan := '0';
    else
      vLoan := '1';
    end if;

 -- ???

    --ExeCute immediate sql_stmt_2 into vCount using vContNo,tBankLoan,vState;
         select count(1) into vCount from lccontstate a
              where  contno = vContNo
              and 1=1
              and statetype = tBankLoan
              and state = vState
              and enddate is null
              ;
    if vCount = 0 then
      vBankLoan := '0';
    else
      vBankLoan := '1';
    end if;

 -- ???

   -- ExeCute immediate sql_stmt_2 into vCount using vContNo,tRPU,vState;
         select count(1) into vCount from lccontstate a
              where  contno = vContNo
              and 1=1
              and statetype = tRPU
              and state = vState
              and enddate is null
              ;
    if vCount = 0 then
      vRPU := '0';
    else
      vRPU := '1';
    end if;




    vResI := vAvailable||vTerminate||vLost||vPayPrem||vLoan||vBankLoan||vRPU;

 return vResi;

 end;
end getSmsState;


/

