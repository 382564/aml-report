create function getItemCodeByOutItemCode(tOutItemCode in varchar2,tNewOldFlag in varchar2) return LFItemRela.ItemCode%type as
tItemCode LFItemRela.ItemCode%type;
begin
select ItemCode into tItemCode from LFItemRela where trim(OutItemCode)= trim(tOutItemCode) and trim(newoldflag)=trim(tNewOldFlag);
return(tItemCode);
end;


/

