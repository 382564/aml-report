create FUNCTION BankPointRate(
       TempBegin date, --????
       TempEnd date,   --????
       tAgentcode LACommision.Agentcode%TYPE --?????
       ) return number as   --???????
v_Rate number;--?????
v_count number; --????????

begin

  select count(distinct AgentCom) into v_count from LAComToAgent where agentcom in (select agentcom
  from lacom where sellflag='Y' and CalFlag='Y') and AgentCode=tAgentCode ;

  if v_count=0 then
  v_count:=10000000000;
  end if;


select nvl(
 (select count(distinct AgentCom) from LACommision where
  tmakedate>=TempBegin And tmakedate<=TempEnd
  and  AgentCode=tAgentcode )/v_count,0)
  into v_Rate from ldsysvar
  where sysvar = 'onerow' ;

return v_Rate;
End BankPointRate;


/

