create FUNCTION B2NV2 (b IN BLOB)
   RETURN NVARCHAR2
IS
   res            CLOB;
   b_len          number  := dbms_lob.getlength(b) ;
   dest_offset1   NUMBER  := 1;
   src_offset1    NUMBER  := 1;
   amount_c       INTEGER := DBMS_LOB.lobmaxsize;
   blob_csid      NUMBER  := DBMS_LOB.default_csid;
   lang_ctx       INTEGER := DBMS_LOB.default_lang_ctx;
   warning        INTEGER;
BEGIN

if  b_len  > 0  then
   DBMS_LOB.createtemporary (res, TRUE);
   DBMS_LOB.OPEN (res, DBMS_LOB.lob_readwrite);
   DBMS_LOB.converttoclob (res,
                           b,
                           amount_c,
                           dest_offset1,
                           src_offset1,
                           blob_csid,
                           lang_ctx,
                           warning
                          );
else
select   empty_clob()  into  res  from  dual ;
end if ;
   RETURN substr((substr(dbms_lob.substr(res,4000),instr(dbms_lob.substr(res,4000),'</CONTROL>')+10)),0,600);
END b2nv2;


/

