create function         CSNMTOMONEY(HTDT varchar2, CSNM char,payno varchar2)
    return varchar2 is
    money varchar2(40) default '000000';
  begin
    ---LCGet
    select nvl(max(sumgetmoney), '000000')

      into money
      from (
            --一般领取

            --当othernotype=1,otherno直接为客户号appntno.
            select l.sumgetmoney
              from ljaget l
             where l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and l.actugetno=payno
               and l.otherno = CSNM
            union all

            --当othernotype=2,otherno为生存领取对应的合同号
            select l.sumgetmoney
              from ljaget l, lccont c
             where l.othernotype = '2'
             and l.actugetno=payno
               and c.contno = l.otherno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            --当othernotype=4,otherno为暂收退费的印刷号
            select g.sumgetmoney
              from ljtempfee t, ljaget g, lccont c
             where t.tempfeeno = g.otherno
             and g.actugetno=payno
               and t.othernotype = '4'
               and c.prtno = t.otherno
               and c.appntno = CSNM
            union all

            ---当othernotype=5,由ljagetclaim和appntno
            select a.sumgetmoney
              from ljagetclaim l, ljaget a, lccont c
             where a.actugetno = l.actugetno
               and c.contno = l.contno
               and a.actugetno=payno
               and a.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            ---当othernotype=6,otherno为溢交退费对应的合同号
            select l.sumgetmoney
              from ljaget l, lccont c
             where l.othernotype = '6'
               and c.contno = l.otherno
               and l.actugetno=payno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            ---当othernotype=7,otherno红利给付对应的合同号
            select l.sumgetmoney
              from ljaget l, lccont c
             where l.othernotype = '7'
             and l.actugetno=payno
               and c.contno = l.otherno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            ---当othernotype=9,otherno续期回退对应的合同号
            select l.sumgetmoney
              from ljaget l, lccont c
             where l.othernotype = '9'
             and l.actugetno=payno
               and c.contno = l.otherno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            --当oternotype=10,otherno为保全对应的保全受理号
            select l.sumgetmoney
              from ljaget l, lpedormain m, lccont c
             where l.othernotype = '10'
               and l.otherno = m.edoracceptno
               and m.contno = c.contno
               and l.actugetno=payno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            union all

            --  暂缴费
            --tempfeetype=1为新单收费,othernotype=0交费对应的个单合同号
            --tempfeetype=1为新单收费,othernotype=1为交费时对应的集体合同号, 在此处不考虑
              select l.paymoney sumgetmoney
              from ljtempfee l, lcgrpcont c
             where c.grpcontno = l.otherno
             and l.Tempfeeno=payno
               and l.Confmakedate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM
            --tempfeetype=1为新单收费,othernotype=4新单交费对应的个、团单的印刷号
            --tempfeetype=2为续期催收交费,othernotype=0交费对应的个单合同号
            --tempfeetye=8 续期非催收交费 othernotype=0
             union all
            select l.paymoney sumgetmoney
              from ljtempfee l, lccont c
             where c.contno = l.otherno
             and l.Tempfeeno=payno
               and l.Confmakedate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM

            --tempfeetype=4为保全交费,othernotype=10
            union all
            select l.paymoney sumgetmoney
              from ljtempfee l, lccont c, lpedormain p
             where l.tempfeetype = '4'
               and l.othernotype = '10'
               and p.edoracceptno = l.otherno
               and c.contno = p.contno
               and l.Tempfeeno=payno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.appntno = CSNM

            --tempfeetype=6为理赔收费/tempfeetype=3预收交费,othernotype=2.(理赔收费对应的理赔赔案号)
            union all
            select l.paymoney sumgetmoney
              from ljtempfee l, lccont c, ljagetclaim g
             where l.othernotype = '2'
               and g.otherno = l.otherno
               and l.confdate = to_date(HTDT, 'yyyy-mm-dd')
               and c.contno = g.contno
               and l.Tempfeeno=payno
               and c.appntno = CSNM);

    return money;
  end CSNMTOMONEY;


/

