create FUNCTION BranchCONTINUE_RATE (
SDATE IN DATE,
EDATE IN DATE,
tBranchAttr IN VARCHAR2) RETURN NUMBER
IS
-----------?????--------------
--??:??--??????60??PAYINTV(????)
--      ??--???????????????-?????????
 v_AVERAGERATE     NUMBER(12,2);       --?????
 SUMCOUNT          INTEGER;            --?????(???????)(???????????????)
 SUMPREM           NUMBER;             --?????
 SUMINVALIDCOUNT   INTEGER;            --????????????
 SUMINVALIDPREM    NUMBER;             --??????????????
 v_GRACEDAYS       INTEGER;            --??? = 60?
 v_BEGINDATE       DATE;               --????????
 v_ENDDATE         DATE;
BEGIN
  v_GRACEDAYS := 60 - 1;
  /**
   * PAYINTV = 0 : ????
   * FLAG = 1 : ??????? 2:?????
   * FEEOPERATIONTYPE = "RE" : ???????
   * PAYYEARS = 1 ??????
   */
  /*v_BEGINDATE := TRUNC(SDATE,'MM');
  v_ENDDATE := ADD_MONTHS(v_BEGINDATE,1) - 1;*/
  v_BEGINDATE := SDATE - v_GRACEDAYS;
  v_ENDDATE := EDATE - v_GRACEDAYS;

  --??:2004-04-12 LL
  --? GETPOLDATE ?? CValiDate

  --??????????
  SELECT NVL(SUM(TRANSMONEY),0),NVL(SUM(calcount),0) INTO SUMPREM,SUMCOUNT FROM LACOMMISION
   WHERE PAYCOUNT = 1 AND CommDire='1' and branchtype='1'
    AND NOT (PAYYEARS = 1 AND PAYINTV = 12 )
    AND PAYINTV <> 0 and CValiDate >= ADD_MONTHS(v_BEGINDATE,-PAYINTV)
    AND CValiDate <= ADD_MONTHS(v_ENDDATE,-PAYINTV)
    AND branchattr like tBranchAttr||'%' ;

  IF SUMPREM = 0 THEN
    RETURN 0;
  END IF;


  --??????????????,--????????????
  SELECT NVL(SUM(TRANSMONEY),0),NVL(SUM(calcount),0) INTO SUMINVALIDPREM,SUMINVALIDCOUNT FROM LACOMMISION
   WHERE CValiDate >= ADD_MONTHS(v_BEGINDATE,-PAYINTV)
    AND CValiDate <= ADD_MONTHS(v_ENDDATE,-PAYINTV)
    AND NOT (PAYYEARS = 1 AND PAYINTV = 12 )
    AND PAYCOUNT = 2 AND trim(branchattr) like tBranchAttr||'%'
     AND CommDire='1' and branchtype='1' AND PAYINTV <> 0
    AND POLNO NOT IN (SELECT POLNO FROM LJAGETENDORSE
    WHERE GETDATE BETWEEN SDATE AND EDATE AND FEEOPERATIONTYPE = 'RE');


  IF SUMPREM > 0 AND SUMCOUNT > 0 THEN
    v_AVERAGERATE := SUMINVALIDPREM/SUMPREM*0.5 + SUMINVALIDCOUNT/SUMCOUNT*0.5;
  ELSIF SUMCOUNT = 0 THEN
    v_AVERAGERATE := SUMINVALIDPREM/SUMPREM*0.5;
  END IF;

  RETURN(v_AVERAGERATE);

END;


/

