create function AgentCalStandPrem
(sRiskCode in VARCHAR2, sPayYears in VARCHAR2,sPayIntv in VARCHAR2,
sBranchType in VARCHAR2)
return number is
  Result number;

  tFlag CHAR(2); --??????
  tStandPremRate number(10,4);
  tRate number(10,4);
  tTempBranchtype CHAR(2);--????????????????
begin
  /*  ??????????
   *  @param sRiskCode:????   sPayYears:????
   *         sPayIntv:????    sBranchType:????
   *         sAgentCom:????
   *  @return Result:????
  */

  --?:

  --   2.???????????311501????????????,?????
  --   ???????????.

  tStandPremRate := 0.00;
  tRate := 0.00;

  tTempBranchtype :='0';--????0


  --?????????,????????
  begin

  select trim(f01),rate,branchtype into tFlag,tRate,tTempBranchtype
  from laratestandprem where
  riskcode = sRiskCode;

  exception

  when NO_DATA_FOUND or TOO_MANY_ROWS then

      tStandPremRate := 0.00;

      Result := tStandPremRate;
      return(Result);

  end;

  --??????
  if(tTempBranchtype = '1' ) then
        --????????????
        if(tFlag = '01') then
             --??
             if(sPayIntv = '0' or sPayIntv = '-1') then
                 tStandPremRate := tRate;
             --??
             else
                  tStandPremRate := tRate * sPayYears;
                  if(tStandPremRate>1.00) then
                      tStandPremRate :=1.00;
                  end if;
             end if;
        end if;
        if(tFlag = '00') then
            tStandPremRate := tRate;
        end if;
  end if;

  --??
  if(tTempBranchtype = '2') then
      --tongmeng 2006-06-26
      --?????????????,sBranchType ??'1'
      --?????241801,241802??,????50%
      --tongmeng 2006-07-12
      --???????
      --??????
/*      if(sBranchType ='1' ) then
        if(sRiskCode = '241801' or sRiskCode='241802') then
           tStandPremRate := 0.5;
        else
           tStandPremRate := tRate;
        end if;
      else */
       tStandPremRate := tRate;
--      end if;
  end if;
  --??
  if(tTempBranchtype = '3') then
        tStandPremRate := tRate;

        --??????????????????????????????
        --??????????
        --tongmeng 2007-01-17 modify
        --?????????????
        if(sRiskCode = '312201' or sRiskCode = '312202' or sRiskCode = '312203') then
            if(sPayIntv = '0' or sPayIntv = '-1') then
                tStandPremRate := 0.05;
            else
                tStandPremRate := 0.2;
            end if;
         end if;

  end if;

  Result := tStandPremRate;
  return(Result);
end AgentCalStandPrem;


/

