create FUNCTION fnc_107_1(payendyear in varchar2,interval in varchar2,paytimes in varchar2) return varchar2
is
tR varchar2(20);
begin

  tR := '1';
  if(interval = '0') then
		if payendyear = '0' then
			tR := '0.85';
		end if;
		if payendyear = '10' then
			tR := '0.45';
		end if;
		if payendyear = '15' then
			tR := '0.4';
		end if;
		if payendyear = '20' then
			tR := '0.3';
		end if;
		if payendyear = '30' then
			tR := '0.3';
		end if;
	end if;
	if(interval = '1') then
	 if(paytimes >= '2') then
	  if payendyear = '0' then
			tR := '0.85';
		end if;
		if payendyear = '10' then
			tR := '0.625';
		end if;
		if payendyear = '15' then
			tR := '0.55';
		end if;
		if payendyear = '20' then
			tR := '0.475';
		end if;
		if payendyear = '30' then
			tR := '0.45';
		end if;
	 end if;
	 if(paytimes = '1') then
	  if payendyear = '0' then
			tR := '0.85';
		end if;
		if payendyear = '10' then
			tR := '0.45';
		end if;
		if payendyear = '15' then
			tR := '0.4';
		end if;
		if payendyear = '20' then
			tR := '0.3';
		end if;
		if payendyear = '30' then
			tR := '0.3';
		end if;
	 end if;
	end if;


	return(tR);
end;


/

