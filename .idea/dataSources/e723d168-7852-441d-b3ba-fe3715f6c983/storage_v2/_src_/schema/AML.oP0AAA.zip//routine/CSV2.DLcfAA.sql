create FUNCTION CSV2 (tInsuredYear in integer,
                                 tPolNo in varchar2,
                                 tRiskCode1 in varchar2,
                                 tRiskCode2 in varchar2 )
  return number is
  --tInsuredYear:保单年度
  --tPolNo:保单险种号码--保单号
  tCashValue number;--现金价值(tPolNo)
  tCashValue1 number;--现金价值
  tCashValue2 number;--现金价值
  Result number;
  tSex varchar2(1);--被保人性别
  tAge number;--投保时的被保人年龄
  tInsuyear Integer;--保CSV2险年龄年期
  tInsuyearFlag Varchar2(2);--保险年龄年期标志
  tPayEndYear Integer;--终交年龄年期
  tPayEndYearFlag varchar2(2);--终交年龄年期标志
  tDuration Integer;--期间(当insuyearflag=A时，处于0~insuyear-age,貌似可以理解为‘保单年度-1’)
  tRiskCode varchar2(10);--险种代码
  tAmnt NUMBER;--保额
  tSQL varchar2(500);--执行的sql语句

begin

   select a.insuredSex ,
          a.insuredAppAge  ,
          a.Insuyear  ,
          a.InsuyearFlag ,
          a.PayEndYear  ,
          a.PayEndYearFlag  ,
          a.RiskCode,
          a.Amnt
     into
          tSex ,
          tAge,
          tInsuyear,
          tInsuyearFlag,
          tPayEndYear ,
          tPayEndYearFlag ,
          tRiskCode,
          tAmnt
     from lcpol a
    WHERE a.polno = tPolNo;
  tDuration:=tInsuredYear-1;
  if(
          nvl(tRiskCode1,0) in('131202','125501','121203','125504')and
          nvl(tRiskCode2,0) in('131202','125501','121203','125504')
    ) then
    tSQL:='SELECT CashValue + NETPREM  FROM CV_'||tRiskCode1||' WHERE (Sex,Age,Insuyear,InsuyearFlag,PayEndYear,PayEndYearFlag,Duration)=(select :tSex,:tAge,:tInsuyear,:tInsuyearFlag,:tPayEndYear,:tPayEndYearFlag,:tDuration from dual)';
    execute immediate tSQL into tCashValue1 using tSex ,tAge, tInsuyear,tInsuyearFlag, tPayEndYear , tPayEndYearFlag , tDuration;
    tSQL:='SELECT CashValue + NETPREM FROM CV_'||tRiskCode2||' WHERE (Sex,Age,Insuyear,InsuyearFlag,PayEndYear,PayEndYearFlag,Duration)=(select :tSex,:tAge,:tInsuyear,:tInsuyearFlag,:tPayEndYear,:tPayEndYearFlag,:tDuration from dual)';
    execute immediate tSQL into tCashValue2 using tSex ,tAge, tInsuyear,tInsuyearFlag, tPayEndYear , tPayEndYearFlag , tDuration;

  else
    tCashValue1:=0;
    tCashValue2:=0;
  end if;
  
  select (nvl(tCashValue1,0)+nvl(tCashValue2,0)) into tCashValue from dual;
  
  IF(nvl(tRiskCode1,0) IN('131202','125501')) THEN
      select nvl((tCashValue*tAmnt/10000),0) into result from dual;
  ELSE
      select nvl((tCashValue*tAmnt/1000),0) into result from dual;
  end if;

  return(result);

  EXCEPTION
  when OTHERS then
    return 0; --执行不成功

end CSV2;


/

