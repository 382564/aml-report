create function getRearCode(
tAscript in latree.ascriptseries%type,tRelaLevel in char)
return  latree.agentcode%type is
Result latree.agentcode%type;


tTempRelaLevel char(2);
begin
  if(tRelaLevel = '01')then
    if(instr(tAscript,':')<>0) then
      Result := nvl(substr(tAscript,0,instr(tAscript,':')-1),' ');
    else
      Result := nvl(tAscript,' ');
    end if;
  else
    if(tRelaLevel = '02')then
        tTempRelaLevel := '01';
    elsif(tRelaLevel = '03')then
        tTempRelaLevel := '02';
    elsif(tRelaLevel = '04')then
        tTempRelaLevel := '03';
    end if;
    if(instr(tAscript,':')<>0) then
       Result := nvl(getRearCode(nvl(substr(tAscript,instr(tAscript,':')+1),' '),tTempRelaLevel),' ');
    else
       Result := '';
    end if;
  end if;

return(Result);
end getRearCode;


/

