create function getManageComName(cManageCom ldcom.comcode%type) return varchar2 is
  Result varchar2(120);

  cComCode ldcom.comcode%Type;
  cName1 ldcom.Name%Type;
  cName2 ldcom.Name%Type;
  cName3 ldcom.Name%Type;

Begin

  If cManageCom Is Null Then
     Result:='';
  Else
    If length(cManageCom)>=4  Then
       cComCode:=Substr(cManageCom, 1, 4);
       Select Name Into cName1 From ldcom Where comcode=cComCode;
    End If;
     If cName1 Is Null Then
        Result:='';
     Else
        Result:=cName1;
        If length(cManageCom)>=6  Then
           cComCode:=Substr(cManageCom, 1, 6);
           Select Name Into cName2 From ldcom Where comcode=cComCode;
        End If;
        If  cName2 Is Null Then
           return(Result);
        Else
           Result:=Concat(trim(cName1), trim(cName2));
           If length(cManageCom)>=8  Then
               cComCode:=Substr(cManageCom, 1, 8);
               Select Name Into cName3 From ldcom Where comcode=cComCode;
           End If;
           If cName3 Is Null Then
               return(Result);
           Else
               Result:=Concat(trim(Result), trim(cName3));
           End If;
        End If;
     End If;
  End if;

  return(Result);
end getManageComName;


/

