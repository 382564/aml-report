create function GetPrem( tRiskCode in varchar2,tSumPrem in varchar2,tInsuredCount in varchar2,tInsuredGrade in varchar2,tPlanCode in varchar2) return varchar2 is
    tPrem NUMBER;
begin
  tPrem :=0;
IF trim(tRiskCode) = '241801' THEN
IF trim(tPlanCode) = 'A' THEN
  IF (tInsuredGrade = '00' or tInsuredGrade is null) THEN
     tPrem:= tSumPrem*2.40/(tInsuredCount+2.40);
  END IF;
  IF (tInsuredGrade != '00' And tInsuredGrade is not null) THEN
     tPrem:= tSumPrem/(tInsuredCount+2.40);
  END IF;
END IF;

IF trim(tPlanCode) = 'B' THEN
  IF (tInsuredGrade = '00' or tInsuredGrade is null) THEN
     tPrem:= tSumPrem*2.50/(tInsuredCount+2.50);
  END IF;
  IF (tInsuredGrade != '00' And tInsuredGrade is not null) THEN
     tPrem:= tSumPrem/(tInsuredCount+2.50);
  END IF;
END IF;
END IF;


--241805?????????????????????
IF trim(tRiskCode) = '241805' THEN
IF trim(tPlanCode) = 'A' THEN
  IF (tInsuredGrade = '00' or tInsuredGrade is null) THEN
     tPrem:= tSumPrem/(tInsuredCount*3/7+1);
  END IF;
  IF (tInsuredGrade != '00' And tInsuredGrade is not null) THEN
     tPrem:= tSumPrem/(tInsuredCount+7/3);
  END IF;
END IF;

IF trim(tPlanCode) = 'B' THEN
  IF (tInsuredGrade = '00' or tInsuredGrade is  null) THEN
     tPrem:= tSumPrem*2.50/(tInsuredCount+2.50);
  END IF;
  IF (tInsuredGrade != '00' And tInsuredGrade is not null) THEN
     tPrem:= tSumPrem/(tInsuredCount+2.50);
  END IF;
END IF;
END IF;

IF trim(tRiskCode) not in ( '241801','241805') THEN
tPrem:= tSumPrem;
END IF;

IF tPrem<1 THEN
return TO_CHAR(tPrem,'0D99');
END IF;

return trim(TO_CHAR(tPrem,'9999999999D99'));
END;


/

