create function GETRISKGSEQ(tGContNo in VARCHAR,
                                       tGPolNo  in VARCHAR) return CHAR is
  Result CHAR;
  temp   INTEGER := 1;
  polno  lcgrppol.grppolno%type;

  cursor lcgrppol_count is
    select grppolno
      from LCGRPPol
     where grpcontno = tGContNo
     order by grpPolNo;
  --??????????????
begin

  open lcgrppol_count;

  loop
    fetch lcgrppol_count into polno;
    exit when lcgrppol_count%NOTFOUND;

    if polno <> tGPolNo then
      temp := temp + 1;
    end if;
  end loop;
  result := to_char(temp);
  return(Result);
end GETRISKGSEQ;


/

