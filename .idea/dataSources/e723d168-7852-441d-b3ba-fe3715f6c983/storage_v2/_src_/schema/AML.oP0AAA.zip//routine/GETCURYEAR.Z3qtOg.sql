create function GETCURYEAR(cDate in DATE,Cvalidate In Date) return integer is
  rDate integer;
begin
  rDate :=trunc(months_between(cDate,Cvalidate )/12);
   If rDate <= 0 Then
     Return(1);
   End If;
  return(rDate+1);

end GETCURYEAR;


/

