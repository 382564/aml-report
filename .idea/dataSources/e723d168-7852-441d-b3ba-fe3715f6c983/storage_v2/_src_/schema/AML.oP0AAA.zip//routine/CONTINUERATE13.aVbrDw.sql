create FUNCTION ContinueRate13(tWageNo in varchar2,tgroupcode in VARCHAR2) return number is
------???????
 v_AVERAGERATE     NUMBER(12,2);       --?????
 SUMPREM           NUMBER;             --?????
 SUMINVALIDPREM    NUMBER;             --??????????????
 SDate Date;
 EDate Date;
BEGIN
  /* FEEOPERATIONTYPE = "RE" : ???????
   * PAYYEARS = 1 ??????
   */

  SDate:=add_months(to_date(tWageNo,'YYYYMMDD'),-13);
  EDate:=to_date(twageno,'YYYYMMDD');
  --- ?????13???????????????
  SELECT NVL(SUM(TRANSMONEY),0) INTO SUMPREM FROM LACOMMISION
   WHERE
   TRIM(BRANCHATTR) LIKE (SELECT CONCAT(TRIM(BRANCHATTR),'%') FROM LABRANCHGROUP
                          WHERE trim(AGENTGROUP) = tGroupCode)
   AND PAYCOUNT = 1 AND TRIM(FLAG) = '0' AND PAYINTV <> 0
   AND CValiDate>=SDate
   AND CValiDate<=EDate;

 IF SUMPREM = 0 THEN
    RETURN -1;
  END IF;



  --??????????????
  SELECT NVL(SUM(TRANSMONEY),0) INTO SUMINVALIDPREM FROM LACOMMISION
   WHERE TRIM(BRANCHATTR) LIKE (SELECT CONCAT(TRIM(BRANCHATTR),'%') FROM LABRANCHGROUP
                                WHERE trim(AGENTGROUP) =tGroupCode)
   AND PAYCOUNT = 2 AND TRIM(FLAG) = '0' AND PAYINTV <> 0
   AND CValiDate >=SDate
   AND CValiDate <=EDate
   AND trim(POLNO) NOT IN (SELECT trim(POLNO) FROM LJAGETENDORSE
                           WHERE GETDATE BETWEEN SDATE AND EDATE
                           AND TRIM(FEEOPERATIONTYPE) = 'RE');



  IF SUMPREM>0 THEN
    v_AVERAGERATE := SUMINVALIDPREM/SUMPREM;
  END IF;

  RETURN(v_AVERAGERATE);
end ContinueRate13;


/

