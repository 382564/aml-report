create function calAgentIncomeTax(v_Commission in number, v_ManageCom in varchar2)
  return number is
  Tax number;
  v_Sales_Tax number;
begin
  v_Sales_Tax := calAgentSalesTax(v_Commission, v_ManageCom);

  if (v_Commission * 0.6 - v_Sales_Tax) <= 4000 then
    Tax := (v_Commission * 0.6 - v_Sales_Tax - 800) * 0.2;
  elsif (v_Commission * 0.6 - v_Sales_Tax) * 0.8 <= 20000 then
    Tax := (v_Commission * 0.6 - v_Sales_Tax) * 0.16;
  elsif (v_Commission * 0.6 - v_Sales_Tax) * 0.8 < 50000 then
    Tax := (v_Commission * 0.6 - v_Sales_Tax) * 0.24 - 2000;
  else
    Tax := (v_Commission * 0.6 - v_Sales_Tax) * 0.32 - 7000;
  end if;
  
  if Tax < 0 then
    Tax := 0;
  end if;
  
  return round(Tax,2);
end calAgentIncomeTax;


/

