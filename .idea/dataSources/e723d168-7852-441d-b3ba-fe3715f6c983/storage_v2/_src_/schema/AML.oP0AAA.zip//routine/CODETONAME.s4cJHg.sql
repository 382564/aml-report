create FUNCTION codetoname(tCodeType in varchar2,tCode in varchar2) return varchar2 is
  Result varchar2(100);
begin
  select trim(codename) into Result from ldcode where trim(codetype) = tCodeType and trim(code) = tCode;
  return(Result);
end codetoname;


/

