create FUNCTION FNC_DENT(
--F_TYPE        CHAR,
                                   C_POLNO       CHAR,
                                   C_GETDUTYCODE CHAR,
                                   C_DUTYCODE    CHAR,
                                   C_CASENO      CHAR,
                                   C_GrpContNo   CHAR,
                                   C_RiskCode    CHAR,
                                   C_GetDutyKind CHAR) RETURN NUMBER IS
  RESULT NUMBER;
  /*??*/
  LCDuty_Amnt                             NUMBER;--??
  CalFactorValue      NUMBER;         --?????????
  LCClaimCtrl_DefaultValue                NUMBER;--???????
  LLCaseReceipt_Fee                       NUMBER;--????
  C_CurSor      NUMBER;
  C_FeeItemCode  LLCaseReceipt.FeeItemCode%TYPE;
  C_InsuredNo    LLCaseReceipt.CustomerNo%TYPE;
  C_PubLMFlag char;
  C_FeeType   char;
  C_Rate   NUMBER;--????
  C_InsDays   NUMBER;--????
  C_LimAmnt   NUMBER;--????
  /*?????????*/
 CURSOR t_CaseReSet IS
    select LLCaseReceipt.ClmNo,
           LLCaseReceipt.CaseNo,
           LLCaseReceipt.MainFeeNo,
           LLCaseReceipt.FeeDetailNo,
           LLCaseReceipt.RgtNo,
           LLCaseReceipt.FeeItemType,
           LLCaseReceipt.FeeItemCode,
           LLCaseReceipt.Fee,
           LLCaseReceipt.CustomerNo
      from LLCaseReceipt
     where LLCaseReceipt.ClmNo = C_CASENO
       and LLCaseReceipt.FeeItemType='H'
       and substr(FeeItemCode,0,2)=(select clmfeecode from LMDutyGetFeeRela  where getdutycode=C_GETDUTYCODE
          and getdutykind=C_GetDutyKind);
BEGIN
  RESULT    := 0; --?Result??
  C_CurSor := DBMS_SQL.OPEN_CURSOR;
  FOR t_LLCaseReceipt IN t_CaseReSet LOOP
  C_FeeItemCode := 0;
  C_FeeItemCode :=t_LLCaseReceipt.FeeItemCode;
  C_InsuredNo   :=t_LLCaseReceipt.CustomerNo;
  LCClaimCtrl_DefaultValue :=0;

  /*??????(A??),????????(B??)?
   ????????Sugical Fees-Major operation,?????????????;??????,
   ??Daily Room per day limit?Maxinum number of days ??????,???????,
   ???????(B1??),????????????(B2??)*/
   select othersign
   into C_FeeType
   from ldcode where 1=1
   and codetype='llmmahospfeetype'
   and code=C_FeeItemCode;

   /*A?????*/
   if C_FeeType='A' then
  /*??????*/
  select nvl(sum(a.fee),0),nvl(sum(b.calfactorvalue),0)
   into  LLCaseReceipt_Fee,CalFactorValue
   from LLCaseReceipt a, lccontplandutyparam b, llregister d
  where a.rgtno = d.rgtno
    and b.grpcontno = d.grpcontno
    and a.feeitemcode = b.calfactor
    and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
    and a.clmno = C_CASENO
    and a.FeeItemCode=C_FeeItemCode;
   if LLCaseReceipt_Fee > CalFactorValue then
   RESULT :=RESULT+CalFactorValue;
   else
   RESULT :=RESULT+LLCaseReceipt_Fee;
   end if;

   /*?????????*/
   select count(1)
   into C_PubLMFlag
   from lcdutyclmctrlrela
   where dutycode=C_DUTYCODE
   and grpcontno =C_GrpContNo
   and dutycalfactator=C_FeeItemCode;

   if C_PubLMFlag>0 then
   select nvl(b.DefaultValue,0)
   into LCClaimCtrl_DefaultValue
   from lcdutyclmctrlrela a,LCClaimCtrl b
   where a.dutycode=C_DUTYCODE
   and a.grpcontno =C_GrpContNo
   and a.dutycalfactator=C_FeeItemCode
   and a.claimctrlcode=b.claimctrlcode;

   if LCClaimCtrl_DefaultValue < RESULT then
   RESULT :=LCClaimCtrl_DefaultValue;
   else
   RESULT :=RESULT;
   end if;
   end if;
   /*B??????*/
   else

   /*????????*/
    select nvl(sum(a.fee),0),nvl(sum(a.daycount),0)
   into  LLCaseReceipt_Fee,C_InsDays
   from LLCaseReceipt a
   where 1=1
    and a.clmno = C_CASENO
    and a.FeeItemCode=C_FeeItemCode;

   /*????????*/
   select nvl(b.calfactorvalue,0)/100
   into  C_Rate
   from lccontplandutyparam b
    where b.grpcontno = C_GrpContNo
    and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
    and b.riskcode=C_RiskCode
    and b.dutycode=C_DUTYCODE
    and b.calfactor=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Rate');

    /*????????*/
   select nvl(b.calfactorvalue,0)
   into  C_LimAmnt
   from lccontplandutyparam b
    where b.grpcontno = C_GrpContNo
    and b.contplancode=(select contplancode from lcinsured where insuredno=C_InsuredNo and grpcontno=C_GrpContNo)
    and b.riskcode=C_RiskCode
    and b.dutycode=C_DUTYCODE
    and b.calfactor=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Amnt');

   if  LLCaseReceipt_Fee*C_Rate <=C_LimAmnt then
   RESULT :=RESULT+LLCaseReceipt_Fee*C_Rate;
   else
   RESULT :=RESULT+C_LimAmnt;
   end if;
   /*?????????*/
   select count(1)
   into C_PubLMFlag
   from lcdutyclmctrlrela
   where dutycode=C_DUTYCODE
   and grpcontno =C_GrpContNo
   and dutycalfactator=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Amnt');

   if C_PubLMFlag>0 then
   select nvl(b.DefaultValue,0)
   into LCClaimCtrl_DefaultValue
   from lcdutyclmctrlrela a,LCClaimCtrl b
   where a.dutycode=C_DUTYCODE
   and a.grpcontno =C_GrpContNo
   and a.dutycalfactator=(select paramscode from lmriskparamsdef
       where riskcode=C_RiskCode and othercode=C_FeeItemCode
       and paramstype='Amnt')
   and a.claimctrlcode=b.claimctrlcode;

   if LCClaimCtrl_DefaultValue < RESULT then
   RESULT :=LCClaimCtrl_DefaultValue;
   else
   RESULT :=RESULT;
   end if;

   end if;
   end if;
  END LOOP;
  DBMS_SQL.CLOSE_CURSOR(C_CurSor);


  /*??LCGet??Amnt*/
  select nvl(amnt,0)
  into LCDuty_Amnt
  from LCDuty
  where polno=C_POLNO
    and dutycode=C_DUTYCODE;

  if LCDuty_Amnt< RESULT  then
  RESULT :=LCDuty_Amnt;
  else
  RESULT :=RESULT;
  end if;

  RETURN(RESULT);
END FNC_DENT;


/

