create Function         ctrlSigUWButton(t_ContNo in lccont.contno%type) return VARCHAR2 is
  t_str_arr         VARCHAR2(1000);

  t_result          VARCHAR2(100);
  begin

  ----------uwButton2,影像资料查询
  select count(*) into t_result
  from es_doc_relation where bussno= t_Contno and bussnotype='11' and rownum=1;
  t_str_arr:='uwButton2'||'|'||t_result;

  --------- uwButton4,问题件查询
  select count(*) into t_result
  from lcissuepol where contno=t_Contno and backobjtype<>'8' and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwButton4'||'|'||t_result;

  --------- uwButton3,核保审核通知函查询
  select count(*) into t_result
  from lcissuepol where contno=t_Contno and backobjtype='8' and state='2' and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwButton3'||'|'||t_result;

  --------- uwButton5,财务交费信息查询
  select count(*) into t_result
  from ljtempfee where otherno=t_Contno and othernotype in('6','7','4') and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwButton5'||'|'||t_result;

  ---------?? uwButton7,????
 select count(*) into t_result from lcuwsub
 where contno = t_Contno and autouwflag = '2' and passflag is not null and rownum = 1;
/* union
 select count(*)  from lccuwsub
 where contno = t_Contno and autouwflag = '2' and passflag is not null and rownum = 1;*/

 select nvl(sum(A.x),0) into t_result from (
 select  count(*) x from lcuwsub
 where contno = t_Contno and autouwflag = '2' and passflag is not null and rownum = 1
 union
 select count(*) x from lccuwsub
 where contno = t_Contno and autouwflag = '2' and passflag is not null and rownum = 1
 ) A;

 t_str_arr:=t_str_arr||'^'||'uwButton7'||'|'||t_result;

  ---------?? uwButton8,????????
  select count(*) into t_result
  from lccont where contno=t_Contno and forceuwreason is not null;
  t_str_arr:=t_str_arr||'^'||'uwButton8'||'|'||t_result;

  --------- uwButton9,投保人健康告知查询
  select count(*) into t_result
  from lccustomerimpart a where
  --and a.impartver = '02' and a.impartcode<>'000' and a.customernotype='0'
  a.impartver in ('A001','C001','A01','A002','C002','A141') and a.customernotype='0'
  and a.customerno = (select appntno from lccont where contno = t_Contno) and rownum=1 ;
  t_str_arr:=t_str_arr||'^'||'uwButton9'||'|'||t_result;

   ---------?? uwButton30,???????????
  select count(*) into t_result
  from (select 1 from lcpol where contno<> t_Contno
  and (appntno = (select appntno from lccont where contno = t_Contno) or insuredno = (select appntno from lccont where contno = t_Contno))
  and conttype='1' and appflag in ('1','4')
  union
  select 1 from lcpol where contno<> t_Contno
  and (appntno = (select appntno from lccont where contno = t_Contno) or insuredno = (select appntno from lccont where contno = t_Contno))
  and conttype='1' and appflag ='0'
  union
  select 1 from lcpol where contno<> t_Contno
  and (appntno = (select appntno from lccont where contno = t_Contno) or insuredno = (select appntno from lccont where contno = t_Contno))
  and conttype='2')
  where 1=1 and rownum=1 ;
  t_str_arr:=t_str_arr||'^'||'uwButton30'||'|'||t_result;

  ---------?? uwButton10,?????????
  select count(*) into t_result from lcpenotice
  where customerno in (select appntno from lcappnt where contno=t_Contno) and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwButton10'||'|'||t_result;

   ---------?? uwButton11,?????????
  select count(*) into t_result from lcpol a
  where a.polno in
  (
     select i.polno from lcpol i where
       i.InsuredNo   =  (select appntno from lcappnt where contno = t_Contno)
      or
      (
         i.appntno = (select appntno from lcappnt where contno = t_Contno)
         and i.riskcode in ('121301')
      )
    union
    select polno from lcinsuredrelated
      where lcinsuredrelated.customerno = (select appntno from lcappnt where contno = t_Contno)
   )
  and a.uwflag not in ('1', '2', 'a')
  and not exists (select 'X' from lccont where ContNo = a.contno and uwflag in ('1', '2', 'a'))
  and rownum = 1;
  t_str_arr:=t_str_arr||'^'||'uwButton11'||'|'||t_result;

  ---------?? uwButton12,??????????
  select count(a.contno) into t_result from lccont a, lcinsured b where 1 = 1
  and a.contno = b.contno and a.appflag in ('1', '4') and a.salechnl in ('1', '3', '5')
  and b.insuredno in (select appntno from lcappnt where contno = t_Contno);
   t_str_arr:=t_str_arr||'^'||'uwButton12'||'|'||t_result;

  ---------?? uwButton13,??????????
  select count(a.contno) into t_result from lccont a, lcinsured b where 1 = 1
  and a.contno = b.contno and a.appflag ='0' and a.salechnl in ('1', '3', '5')
  and b.insuredno in (select appntno from lcappnt where contno = t_Contno);
  t_str_arr:=t_str_arr||'^'||'uwButton13'||'|'||t_result;

  ---------?? uwButton15,投保人既往保全
  select count(*)  into t_result from LPEdorMain a
  where a.contno in ( select c.contno from lccont c
        where (appntno = (select appntno from lcappnt where contno=t_Contno)
          or insuredno = (select appntno from lcappnt where contno=t_Contno))
  );
  t_str_arr:=t_str_arr||'^'||'uwButton15'||'|'||t_result;

  ---------?? uwButton14,投保人既往理赔
   select max(countsum) into t_result from
   (
     select count(a.rgtno) as countsum from llregister a, llcase b
     where a.rgtno = b.caseno
     and b.CustomerNo=(select appntno from lcappnt where contno=t_Contno)
     union
     select count(a.rptno) as countsum from llreport a, llsubreport b
     where a.rptno = b.subrptno  and  a.rgtflag = '10'
     and b.CustomerNo =(select appntno from lcappnt where contno=t_Contno)
   );
   t_str_arr:=t_str_arr||'^'||'uwButton14'||'|'||t_result;

  ---------?? uwButton20,??????
  select count(*)  into t_result from LCReinsureReport where contno = t_Contno and rownum = 1;
   t_str_arr:=t_str_arr||'^'||'uwButton20'||'|'||t_result;

  --------- uwButton21,查询体检结果
  select decode(sum(A.a),0,0,1) into t_result from (
  select count(*) a  from lcpenotice a
  where 1 = 1 and a.ContNo = t_Contno  and a.printflag is not null and rownum=1
  union
  select count(*) a  from es_doc_relation where subtype='7104121'
  and bussno=(select prtno from lccont where contno = t_Contno) and rownum=1
  union
  select count(*) a  from es_doc_main where subtype='UR205' and doccode=(select prtno from lccont where contno = t_Contno)
 ) A;
  t_str_arr:=t_str_arr||'^'||'uwButton21'||'|'||t_result;
  t_str_arr:=t_str_arr||'^'||'uwButtonHospital'||'|'||t_result;

  ---------?? uwButton22,??????
  select count(*)  into t_result
   from lcrreport where 1 = 1 and contno = t_Contno and replyflag is not null and rownum = 1;
  t_str_arr:=t_str_arr||'^'||'uwButton22'||'|'||t_result;
  --
  ---------?? uwButton23,??????
  select count(*)  into t_result
   from LCApplyRecallPol where 1 = 1 and prtno = t_Contno and rownum = 1;
  t_str_arr:=t_str_arr||'^'||'uwButton28'||'|'||t_result;

  select count(*) into t_result
  from lwmission w,lcinsured b where w.activityid='0000001100' and w.missionprop18 in ('1','2','3','4','5','7')
  and w.MissionProp2=b.contno
  and b.insuredno in (select insuredno from lcinsured where contno = t_Contno) and rownum=1 ;
  t_str_arr:=t_str_arr||'^'||'uwButton55'||'|'||t_result;

  --tongmeng 2009-05-11 add
  --???? ---????????
  select count(*)  into t_result from lcprem a where contno=t_Contno and a.payplancode like '000000%';
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoAddFee'||'|'||t_result;

  --???? --????????
   select count(*)  into t_result from lccspec a where contno=t_Contno ;
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoSpec'||'|'||t_result;

  --???? --????????
  --ShowQueryInfoClaim
   select count(*)  into t_result from LLClaimPolicy a where contno=t_Contno ;
   t_str_arr:=t_str_arr||'^'||'ShowQueryInfoClaim'||'|'||t_result;
  --???? --????????
  --ShowQueryInfoEdor
   select count(*)  into t_result from LPEdorMain a where contno=t_Contno ;
   t_str_arr:=t_str_arr||'^'||'ShowQueryInfoEdor'||'|'||t_result;

   --被保人健康告知查询
  select count(*) into t_result
  from lccustomerimpart a where a.contno = t_Contno
  --and a.impartver = '02' and a.impartcode<>'000' and a.customernotype='0'
  and a.impartver in ('A001','C001','A01','A002','C002','A141') and a.customernotype='1'
  and a.customerno in (select insuredno from lcinsured where contno = t_Contno) and rownum=1 ;
  t_str_arr:=t_str_arr||'^'||'indButton1'||'|'||t_result;
  --ShowQueryInfoChange ????????
  select count(*) into t_result
  from lcinduwmaster where contno= t_Contno and uwidea is not null and rownum=1;
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoChange'||'|'||t_result;

  ----------?? uwButton2,??????
  ----------?? ??????????????
  select count(*) into t_result
  from es_doc_relation where bussno= (select prtno from lccont where contno = t_Contno) and bussnotype='11' and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwButton2'||'|'||t_result;


   --??????
   select decode(nvl(sum(A.x),0),0,0,1) into t_result
   from (
  select 1 x from lwmission where MissionProp2=(select prtno from lccont where contno= t_Contno) and missionprop18='6' and activityid='0000001100' and rownum=1
  union
  select 1 x from lbmission where MissionProp2=(select prtno from lccont where contno= t_Contno) and missionprop18='6' and activityid='0000001100' and rownum=1
  ) A;
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoUW'||'|'||t_result;


  --?????????
  select count(*) into t_result
  from LCIssueMistake where contno= t_Contno  and rownum=1;
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoQuest'||'|'||t_result;

  --????????
  /* select count(*) into t_result
  from lwmission where MissionProp2= t_Contno  and activityid='0000001100' and rownum=1;
  t_str_arr:=t_str_arr||'^'||'ReportButton'||'|'||t_result;*/

  --??????
  select count(*) into t_result
  from lcpenotice where contno= t_Contno  and rownum=1;
  t_str_arr:=t_str_arr||'^'||'ShowQueryInfoPe'||'|'||t_result;

  ----------?? uwScanQuery,??????????
  select count(*) into t_result
  from es_doc_relation where bussno= (select prtno from lccont where contno = t_Contno) and subtype='UR202' and rownum=1;
  t_str_arr:=t_str_arr||'^'||'uwScanQuery'||'|'||t_result;

  ----------????
  return(t_str_arr);
End ctrlSigUWButton;


/

