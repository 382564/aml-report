create function CreateDH(Num in Integer) return varchar2 is
  Result varchar2(100);
  i Integer;

begin
  i :=1;
  WHILE i<=Num loop
    result := result||',';
    i := i + 1;
  end loop;

  return(Result);
end CreateDH;


/

