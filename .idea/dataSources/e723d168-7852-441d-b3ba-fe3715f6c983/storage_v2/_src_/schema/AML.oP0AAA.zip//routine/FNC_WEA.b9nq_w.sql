create FUNCTION FNC_WEA(C_GETDUTYCODE CHAR,
                                   C_CASENO      CHAR,
                                   C_GetDutyKind CHAR) RETURN NUMBER IS
  RESULT NUMBER;
  LLCaseReceipt_Fee     NUMBER;
    select nvl(sum(LLCaseReceipt.Fee),0)
       into LLCaseReceipt_Fee
      from LLCaseReceipt
     where LLCaseReceipt.ClmNo = C_CASENO
       and LLCaseReceipt.FeeItemType='H'
       and substr(FeeItemCode,0,2)=(select clmfeecode from LMDutyGetFeeRela  where getdutycode=C_GETDUTYCODE
          and getdutykind=C_GetDutyKind);
  RESULT :=LLCaseReceipt_Fee;
  RETURN(RESULT);
END FNC_WEA;


/

