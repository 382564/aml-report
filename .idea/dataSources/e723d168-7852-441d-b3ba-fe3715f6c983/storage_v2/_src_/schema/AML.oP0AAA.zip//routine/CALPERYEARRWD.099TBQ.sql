create FUNCTION CALPERYEARRWD
(tAgentCode in varchar2,
tAgentGrade in varchar2,
YearMark in varchar2,
YearBegin in varchar2,YearEnd in varchar2,tAreaType in varchar2,tWagecode in varchar2) return number is
  tFYC   number := 0;
  tRate  number := 0;
  tMons  number := 0;
  Result number := 0;
begin

  if YearMark<>'1' then
    return(Result);
  end if;

  select nvl(sum(fyc),0) into tFYC from lacommision
  where caldate >= to_date(YearBegin,'yyyy-mm-dd')
        and caldate <= to_date(YearEnd,'yyyy-mm-dd')
        and payyear < 1
        and trim(agentcode) = tAgentCode
        ;

  select nvl(drawrate,0) into tRate from lawageradix
  where fycmin < tFYC
        and (fycmax >= tFYC or fycmax is null)
        and trim(AgentGrade) = tAgentGrade
        and trim(AreaType)=tAreaType
        and trim(wagecode) =tWageCode
        ;

  Result := tFYC * tRate;

  if tAgentGrade = 'A01' then
    select NVL(months_between(IndueformDate,EmployDate),0) into tMons from laagenttreeview
    where trim(agentcode) = tAgentCode;

    if tMons = 0 then
      Result := 0;
    end if;

    if tMons >= 7 then
      Result := 0;
    end if;
  end if;

  return(Result);
end CALPERYEARRWD;


/

