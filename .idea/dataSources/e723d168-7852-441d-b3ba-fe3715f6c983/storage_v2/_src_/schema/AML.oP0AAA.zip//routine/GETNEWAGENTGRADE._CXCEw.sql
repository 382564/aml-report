create function getNewAgentgrade(tAgentGrade in latree.agentgrade%TYPE) return varChar2 is
  Result latree.agentgrade%TYPE;
  sCount int;
  sAgentGrade latree.agentgrade%TYPE;
begin
     select count(*) into sCount from laagentgrade where
     gradecode like 'A%' and branchtype='1'
     and gradecode =tAgentGrade;

     if(sCount<=0) then
     sAgentGrade := '00';
     else
     select gradecode1 into sAgentGrade from laagentgrade where
     gradecode like 'A%' and branchtype='1'
     and gradecode =tAgentGrade;
     end if;

     Result := sAgentGrade;

  return Result;
end getNewAgentgrade;


/

