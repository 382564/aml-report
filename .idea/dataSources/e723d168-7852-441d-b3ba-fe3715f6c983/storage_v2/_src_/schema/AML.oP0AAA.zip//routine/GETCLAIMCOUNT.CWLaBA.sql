create function GETCLAIMCOUNT(tCaseNo in VARCHAR) return integer is
  rCount INTEGER;
begin
  SELECT count(caseno) into rCount FROM llclaimpolicy where caseno =tCaseNo  group by ClmNo;
  return(rCount);
end GETCLAIMCOUNT;


/

