create function calAgentAreaType(
       tAgentcode laagent.AgentCode%TYPE,
       twagecode laindexvscomm.wagecode%TYPE,
       tManageCom laagent.managecom%TYPE
       ) return varchar2 is

tEmploydate    Date;
result         varchar2(2);
begin
if (twagecode='W00058' or twagecode='W00059' or twagecode='W00060')
then
  select employdate into tEmploydate from laagent where agentcode=tAgentCode;

  if (substr(tManageCom,1,6)='863309' or substr(tManageCom,1,6)='863308' or substr(tManageCom,1,6)='863305')
  then
    if (tEmploydate < '2005-03-01')
    then
       return '11';
    else
       return '12';
    end if;
  end if;

   if (substr(tManageCom,1,6)='865100') then
     if (tEmploydate < '2005-01-01') then
        return '11';
     else
        return '12';
     end if;
   end if;

   if (tEmploydate >= '2004-11-03' and (substr(tManageCom,1,4)= '8632' or substr(tManageCom,1,4)= '8633'))
   then result:='12';
   else
   result:='11';
   end if;
else
  Select trim(code2) into result From LDCodeRela Where RelaType = 'comtoareatype' and trim(code1) = substr(tManageCom,1,4);
  --return 'S';
end if;





return (result);
end calAgentAreaType;


/

