create FUNCTION calBankTax(
       tAgentCode in varchar2,
       tWageNo in varchar2)
       return number is
  tMoney number(12,2);
  tManageCom Latax.Managecom%TYPE;
  Result number;
--?????????
begin
  select T30 into tMoney
     from Laindexinfo
     where trim(IndexCalNo)=trim(tWageNo) and indextype='01' and trim(AgentCode)=trim(tAgentCode) ;

  select ManageCom into tManageCom
    from LAAgent
    where trim(AgentCode)=trim(tAgentCode);

  select (tMoney-CalValue1)*taxrate-CalValue2 into Result
    from latax
    where tManageCom like trim(ManageCom)||'%' and TaxType='04'
    and basemin<=tMoney-CalValue1 and BaseMax>=tMoney-CalValue1;
  return(Result);
end calBankTax;


/

