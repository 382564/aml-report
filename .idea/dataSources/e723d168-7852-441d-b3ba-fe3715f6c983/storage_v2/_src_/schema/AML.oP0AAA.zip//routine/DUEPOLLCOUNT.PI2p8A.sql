create FUNCTION DuePollCount(tagentcode in varchar2, tstardate in date,tpaycount in integer,tenddate in date) return number is
  Result latollwageradix.receive2%type;
  cSumDueCount integer:=0;--??
  cSumActuCount integer:=0;--??
begin
  if tPayCount<4 then
     select count(sumDuePayMoney) into cSumDueCount from ljspayperson a,lacommisiondetail b
     where trim(a.agentcode) = tagentcode
     and trim(a.PayCount)=tPayCount and trim(a.LastPayToDate)>=tstardate-60 and a.lastpaytodate<=tenddate-60
     and b.poltype='1' and a.contno=b.grpcontno;

     select count(transMoney) into cSumActuCount from LACommision where trim(agentcode) = tagentcode and trim(PayCount)=tPayCount and trim(LastPayToDate)>=tstardate-60
     and calcdate is null and transtype<>'FX' and lastpaytodate<=tenddate and p6='1';--?????????

  else
      select count(sumDuePayMoney) into cSumDueCount from ljspayperson a,lacommisiondetail b
      where trim(a.agentcode) = tagentcode
      and trim(a.PayCount)>=tPayCount and trim(a.LastPayToDate)>=tstardate-60 and a.lastpaytodate<=tenddate-60
      and b.poltype='1' and a.contno=b.grpcontno;

      select count(transMoney) into cSumActuCount from LACommision where trim(agentcode) = tagentcode and trim(PayCount)>=tPayCount and trim(LastPayToDate)>=tstardate-60
      and calcdate is null and transtype<>'FX' and lastpaytodate<=tenddate and p6='1';--?????????
  end if;

  Result:= cSumDueCount+cSumActuCount;

  return(Result);
end DuePollCount;


/

