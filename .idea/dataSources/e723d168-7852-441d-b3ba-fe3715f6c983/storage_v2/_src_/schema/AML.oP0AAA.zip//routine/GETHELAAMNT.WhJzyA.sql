create function getHelaAmnt(P_GrpContNo varchar2,
                                       P_RiskCode  varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select case
           when exists (select 1
                   from ldcode
                  where codetype = 'ishelarisk'
                    and code = P_RiskCode
                    and othersign = '1') then
            (select sum(t.amnt * t.contplaninsured * t.payday)
               from (select c.contplancode contplancode,
                            nvl(c.calfactorvalue, 0) amnt,
                            (select nvl(calfactorvalue, 180)
                               from lccontplandutyparam
                              where grpcontno = c.grpcontno
                                and contplancode = c.contplancode
                                and riskcode = c.riskcode
                                and calfactor = 'PayDay') payday,
                            (select count(1)
                               from lcinsured
                              where grpcontno = c.grpcontno
                                and contplancode = c.contplancode) contplaninsured
                       from lccontplandutyparam c
                      where c.grpcontno = P_GrpContNo
                        and c.riskcode = P_RiskCode
                        and c.calfactor = 'Amnt') t)
           when exists (select 1
                   from ldcode
                  where codetype = 'ishelarisk'
                    and code = P_RiskCode
                    and othersign = '2') then
            (select nvl(sum(amnt), 0)
               from lcgrppol
              where grpcontno = P_GrpContNo
	      and riskcode = P_RiskCode)
           else
            (select nvl(sum(amnt), 0)
               from lcpol
              where riskcode = P_RiskCode
                and grpcontno = P_GrpContNo)
         end
    into Result
    from dual;
  return(Result);
end getHelaAmnt;


/

