create FUNCTION convert_PayEndYear(PayEndYear integer)
  return integer as
  Result integer;
begin
  -- if (PayEndYear = 1000) then
     --select 0 into Result from LDSysvar where sysvar = 'onerow';
   --else
    --select PayEndYear into Result from LDSysvar where sysvar = 'onerow';
   --end if;
  return(PayEndYear);
end convert_PayEndYear;


/

