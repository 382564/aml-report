create FUNCTION getValueBySex(Sex in varchar2)
return number is v_tR number;
begin

	v_tR :=0;
	  if Sex='1' then
		v_tR := 1;
	  end if;
	return(v_tR);
end;


/

