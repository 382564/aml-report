create function calRearBonus(vAgentGroup in varchar2,
                                        vIndexCalNo in varchar2,
                                        vbranchtype in varchar2)
  RETURN number authid current_user IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  Result    number := 0;
  tupbranch varchar2(20);
  BranchFYC number := 0;

begin
  --团队卓越贡献奖=（营业部当月FYC-直辖组当月FYC）*团队卓越贡献奖系数
  select upbranch
    into tupbranch
    from labranchgroup
   where AgentGroup = vAgentGroup;
  select nvl(sum(FirstPension), 0)
    into BranchFYC
    from LAIndexInfo a
   where exists (select '1'
            from labranchgroup
           where AgentGroup = a.AgentGroup
             and upbranch = tupbranch
             and AgentGroup <> vAgentGroup
             and branchtype = vbranchtype)
     and indextype = '00'
     and IndexCalNo = vIndexCalNo;
  if BranchFYC >= 120000 then
    Result := round(nvl(BranchFYC, 0) * 0.2, 2);
  else
    Result := 0;
  end if;

  return(Result);
exception
  when others then
    return 0;
end calRearBonus;

/

