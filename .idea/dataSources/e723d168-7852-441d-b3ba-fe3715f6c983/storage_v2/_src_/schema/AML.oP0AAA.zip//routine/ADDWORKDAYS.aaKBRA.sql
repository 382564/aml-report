create function addWorkDays(StartDate   in Date,
                                       RunningDays in number) return date is
  Result Date;
  temp number := 0;
begin
  loop
    if CountWorkDays(StartDate, StartDate + temp) =  RunningDays then
      exit;
    end if;
    temp := temp+1;
  end loop;
  Result := StartDate + temp;
  return(Result);
end addWorkDays;


/

