create function getScanDate(tPrtNo in lccont.prtno%type) return date is
  Result date;

  tempPrtNo varchar2(14);

begin
  tempPrtNo:=trim(tPrtNo);
  select min(makedate) into Result from es_doc_main where doccode=tempPrtNo;
  if(Result is null or Result='') then
  select makedate into Result from lccont where prtno=tPrtNo;
  end if;

  return(Result);
end getScanDate;


/

