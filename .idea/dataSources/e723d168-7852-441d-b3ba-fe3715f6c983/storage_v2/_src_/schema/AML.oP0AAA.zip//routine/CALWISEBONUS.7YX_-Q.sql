create FUNCTION CALWISEBONUS(tAgentCode in varchar2,tAgentGrade in varchar2,tWageCode in varchar2, tAreaType in varchar2,TempEnd in date) return number is
  tCount3  integer := 0;
  tCount6  integer := 0;
  tRewardMoney1  number:=0;
  tRewardMoney2  number:=0;

  Result   number:=0;
--?????

begin

  SELECT nvl(count(*),0) into tCount3 from laagenttreeview
  WHERE AgentState<'03'
    and indueformdate is not null
    and DateInterval(employdate,indueformdate-1)<=3
    and to_char(TempEnd,'yyyymm') = to_char(Indueformdate,'yyyymm')
    and startdate = indueformdate
    and employdate <> indueformdate
    and trim(introagency) = trim(tAgentCode)
    ;

  SELECT nvl(count(*),0) into tCount6 from laagenttreeview
  WHERE AgentState<'03'
    and indueformdate is not null
    and DateInterval(employdate,indueformdate-1)<=6
    and DateInterval(employdate,indueformdate-1)>3
    and to_char(TempEnd,'yyyymm') = to_char(Indueformdate,'yyyymm')
    and startdate = indueformdate
    and employdate <> indueformdate
    and trim(introagency) = trim(tAgentCode)
    ;

  --??????
  select rewardmoney into tRewardMoney1 from LAWageRadix
  where DrawStart = 0
    and DrawEnd = 3 and trim(AreaType) = trim(tAreaType)
    and trim(AgentGrade) = trim(tAgentGrade)
    and trim(WageCode) = trim(tWageCode)
    ;

  select rewardmoney into tRewardMoney2 from LAWageRadix
  where DrawStart = 4
    and DrawEnd = 6 and trim(AreaType) = trim(tAreaType)
    and trim(AgentGrade) = trim(tAgentGrade)
    and trim(WageCode) = trim(tWageCode)
    ;

  Result := tRewardMoney1*tCount3 + tRewardMoney2*tCount6;

  return(Result);
end CALWISEBONUS;


/

