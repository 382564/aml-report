create FUNCTION fnc_292_03(c_polno char,c_dutyFeeCode char,c_caseNo char,c_cureType char,n_daysInHos number,d_startDate date,d_accidentDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
  d_feeStartDate Date;
  d_feeEndDate Date;
  d_intvDate number;
  d_feeCount llcasereceipt.daycount%TYPE;
  d_sumCount llcasereceipt.daycount%TYPE;
  d_Date Date;
  t_flag2 number;

   CURSOR t_llcasereceiptSet IS
  select distinct(a.startdate),a.enddate,a.daycount
  from llcasereceipt a,llclaimuwmain b
  where a.caseno in (select caseno from llcaserela where caserelano=(select caserelano from llcaserela where caseno=c_caseNo and rownum=1))
  and a.feeitemtype='B'
  and a.feeitemcode like 'CR%'
  and a.startdate<=d_startDate
  and a.enddate<=d_endDate
  and a.startdate>=d_lcgetStartDate
  and a.dealflag='1'
  and ((a.caseno=b.caseno and a.caseno<>c_caseNo and b.examconclusion='0') or (a.caseno=c_caseNo))
  order by a.startdate DESC;

begin
d_sumCount :=0;
Result:=0;                               --?Result??
d_Date:=d_startDate;

select standbyflag1 into t_flag2 from lcduty where polno=c_polno and dutycode='292901';

                                         --??????????,????????????  (?????????,?????????????????)
select d_lcgetEndDate+30 into d_limitDate from dual;

-------------------------------------------------------------------------------------------------------------


if c_cureType<>'A' and d_accidentDate<=d_startDate then     --?????,???????????????


 FOR t_feeNo IN t_llcasereceiptSet LOOP

 d_feeStartDate:=trim(t_feeNo.startdate);
 d_feeEndDate:=trim(t_feeNo.enddate);
 d_feeCount:=trim(t_feeNo.daycount);

 d_intvDate:=d_Date-d_feeEndDate;
 if d_intvDate<=90 then

-------------------------------------------------------------------------------------------------------------
--??????????????,???????????????,????????? --
   if  d_lcgetStartDate<=d_feeStartDate then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)
        	d_sumCount :=d_sumCount+d_feeCount;
    else                                 --??????????????
        	d_sumCount :=d_sumCount+(d_limitDate-d_startDate);
    end if;

   end if ;
----------------------------------------------------------------------------------------------------------------
  else
   exit;
  end if;

  d_Date:=d_feeStartDate;
  END LOOP;


 if d_sumCount<=90 then
   -------------------------------------------------------------------------------------------------------------
  --??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate and d_startDate<d_limitDate and c_dutyFeeCode='CR002' then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)
        	select t_flag2*least(n_daysInHos,(90-d_sumCount+n_daysInHos)) into Result from Dual;
    else                                 --??????????????
        	select t_flag2*least((d_limitDate-d_startDate),(90-d_sumCount+(d_limitDate-d_startDate))) into Result from Dual;
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
 else
-------------------------------------------------------------------------------------------------------------
  --??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate and d_startDate<d_limitDate and c_dutyFeeCode='CR002' then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)
        	select t_flag2*greatest(0,(90-d_sumCount+n_daysInHos)) into Result from Dual;
    else                                 --??????????????
        	select t_flag2*greatest(0,(90-d_sumCount+(d_limitDate-d_startDate))) into Result from Dual;
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------

 end if;

end if;
  return(Result);

end fnc_292_03;


/

