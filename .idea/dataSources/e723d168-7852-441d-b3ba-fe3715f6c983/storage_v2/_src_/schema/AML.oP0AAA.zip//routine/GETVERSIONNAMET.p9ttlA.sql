create function         getVersionNameT(p_grppolno in varchar2) 			 
	return varchar2 is  
	v_RiskPeriod varchar2(1);
	v_SignDate Date;
	v_CValiDate Date;
	v_VersionName varchar2(120);
	v_RiskCode varchar2(20);
	v_GrpContNo varchar2(20);
	ResultStr varchar2(20);
	Result varchar2(120);
begin
   /*判断险种是长短险*/
  select riskcode,grpcontno into v_Riskcode,v_GrpContNo from lcgrppol where grppolno = p_grppolno;
  select RiskPeriod
    into v_RiskPeriod
    from lmriskapp
   where riskcode = v_Riskcode;
   
   /*判断是否是长期限*/
	if v_RiskPeriod = 'L' then
		select SignDate into v_SignDate from lcgrpcont where grpcontno = v_GrpContNo;
		select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_SignDate and v_SignDate <= (case when enddate is null then date'9999-01-01' else enddate end);
		Result := v_VersionName;
	else
		select count(*) into ResultStr from lpgrpedoritem where grpcontno = v_GrpContNo and edorstate ='0' and edortype='LR';
		/*判断是否做过保单补发保全项目*/
		if ResultStr >0 then
			select cvalidate into v_CValiDate from lcgrppol where grppolno = p_grppolno;
			select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_CValiDate and v_CValiDate <= (case when enddate is null then date'9999-01-01' else enddate end);
			Result := v_VersionName;
		else
			select SignDate into v_SignDate from lcgrpcont where grpcontno = v_GrpContNo;
			select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_SignDate and v_SignDate <= (case when enddate is null then date'9999-01-01' else enddate end);
			Result := v_VersionName;
		end if;
	end if;
  return(Result);
end getVersionNameT;


/

