create function CrossSellFYCPeriod(tagentcode  in varchar2,
                                              tagentgrade in varchar2)
  return number is

  pragma autonomous_transaction;
  BZFYC     number(20, 6) := 0;
  mAreaType ldcoderela.code2%Type;
begin
  BZFYC := 0;
  Select othersign
    Into mAreaType
    From Ldcoderela
   Where Relatype = 'comtoareatype'
     And Code3 = '1'
     And TRIM(Code1) In (Select Substr(Managecom, 1, 4)
                           From Latree
                          Where Agentcode = tagentcode);

  if tagentgrade = 'A103' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A103'
       and destagentgrade = 'A102'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A104' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A104'
       and destagentgrade = 'A103'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A105' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A105'
       and destagentgrade = 'A104'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A106' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A106'
       and destagentgrade = 'A105'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A201' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A201'
       and destagentgrade = 'A106'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A202' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A202'
       and destagentgrade = 'A201'
       and areatype = mAreaType;
  end if;
  if tagentgrade = 'A203' then
    select nvl(indfycsum, 0)
      into BZFYC
      from LAAgentPromRadix
     where assesscode = '01'
       and agentgrade = 'A203'
       and destagentgrade = 'A202'
       and areatype = mAreaType;
  end if;
  BZFYC:=BZFYC*0.3;
  return(BZFYC);
end CrossSellFYCPeriod;


/

