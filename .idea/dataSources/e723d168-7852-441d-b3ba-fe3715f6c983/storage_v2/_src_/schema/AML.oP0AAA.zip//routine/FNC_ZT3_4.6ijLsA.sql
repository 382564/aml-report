create FUNCTION fnc_zt3_4(payendyear in number) return varchar2
is
tR varchar2(20);
begin

  tR := 1;

		if payendyear >= 5 then
			tR := 0.8;
		end if;
    if payendyear>=3 and payendyear < 5 then
			tR := 0.85;
		end if;
	return(tR);
end;


/

