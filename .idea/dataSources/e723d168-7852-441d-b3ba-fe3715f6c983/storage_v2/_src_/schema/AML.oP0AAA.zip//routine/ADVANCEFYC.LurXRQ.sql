create function AdvanceFYC(ACODE  in VARCHAR2,
                                      tagentgroup in VARCHAR2,
                                      tempbegin   in date,
                                      tempend     in date,
                                      tgens       in INTEGER) return number is
  -------------------???????????fyc---------------------------
  ACODELOOP VARCHAR2(10);
  GENSCOUNT    INTEGER;
  SUMSTANDPREM NUMBER;
  BRANCHCODE VARCHAR2(12);
  AGENTSERIES VARCHAR2(2);
  tCAUTIONERBIRTHDAY date;
  tLimitDate date;
begin
  ACODELOOP := ACODE;
  SUMSTANDPREM := 0;

  --?????
  select B.CAUTIONERBIRTHDAY,A.branchcode,trim(A.AGENTSERIES)
  into tCAUTIONERBIRTHDAY,BRANCHCODE,AGENTSERIES
  from latree A,LAAGENT B where A.AGENTCODE=B.AGENTCODE AND A.agentcode=ACODELOOP;

  if (tCAUTIONERBIRTHDAY is not null and tCAUTIONERBIRTHDAY<=tempend) then
      select enddate into tLimitDate from lastatsegment
      where stattype='5' and yearmonth=to_char(add_months(tCAUTIONERBIRTHDAY,-1),'yyyymm');
  else
      tLimitDate := tempend;
  end if;

  --?????????????
  if BRANCHCODE=tagentgroup AND AGENTSERIES='0' then
  SELECT nvl(sum(directwage),0)
    INTO SUMSTANDPREM
    FROM lacommision
   WHERE (commdire = '1' or
         (commdire = '2' and transtype not in ('CT', 'PT')))
     and p6 = 0
     and payyear<1
     and agentcode = ACODELOOP
     and signdate >= tempbegin
     and signdate <= tLimitDate;
  else
  SUMSTANDPREM := 0;
  end if;
  --??????????????? ?????
  DECLARE
    ADDCODE VARCHAR2(10);
    CURSOR C_ADDAGENTFYC IS
      SELECT AGENTCODE
        FROM LATREE
       WHERE AGENTGROUP = tagentgroup
         AND INTROAGENCY = ACODELOOP
         AND STATE = '0';

  BEGIN
    GENSCOUNT := tgens + 1;
    OPEN C_ADDAGENTFYC;
    LOOP
      FETCH C_ADDAGENTFYC
        INTO ADDCODE;
      EXIT WHEN C_ADDAGENTFYC%NOTFOUND;
      if GENSCOUNT < 1000 then
        SUMSTANDPREM := SUMSTANDPREM + AdvanceFYC(addcode,
                                                  tagentgroup,
                                                  tempbegin,
                                                  tempend,
                                                  genscount);
      end if;
    END LOOP;
    CLOSE C_ADDAGENTFYC;
  END;

  return SUMSTANDPREM;
end AdvanceFYC;


/

