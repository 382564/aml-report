create FUNCTION chgByPayIntv610(PayIntv in number,InsuYear in number) return number
is v_tR number;
begin
	v_tR:=1;
	if PayIntv = 0 then
		v_tR := 1;
	end if;
	if PayIntv = 1 then
		v_tR := InsuYear;
	end if;

	return(v_tR);
end;


/

