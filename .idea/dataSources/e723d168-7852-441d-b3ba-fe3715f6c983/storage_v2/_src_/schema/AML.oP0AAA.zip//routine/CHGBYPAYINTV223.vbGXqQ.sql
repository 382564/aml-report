create FUNCTION chgbypayintv223(payintv in varchar2) return varchar2
is
tR varchar2(2);
begin
	if payintv = '0' then
		tR := '1';
	end if;
	if payintv = '12' then
		tR := '6';
	end if;

	return(tR);
end;


/

