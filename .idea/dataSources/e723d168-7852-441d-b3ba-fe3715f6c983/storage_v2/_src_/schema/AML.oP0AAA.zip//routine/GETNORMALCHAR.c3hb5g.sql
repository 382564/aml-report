create function GETNORMALCHAR(tName in char) return char is

  startPosition integer := 1;
  endPosition   integer := 1;
  tempName      char(4);

begin
  if tName is not null then
    loop
      tempName := substr(tName, startPosition, endPosition);
      if tempName is not null then
        if tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?' or
           tempName = '?' or tempName = '?' or tempName = '?'

         then
          return('');
        end if;
      else
        exit;
      end if;
      startPosition := startPosition + 1;
    end loop;
  end if;
  return(tName);
end GETNORMALCHAR;


/

