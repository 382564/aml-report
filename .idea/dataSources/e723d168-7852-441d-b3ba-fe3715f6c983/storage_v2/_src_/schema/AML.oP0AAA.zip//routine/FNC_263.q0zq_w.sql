create function fnc_263(c_CaseNo char ,n_daysInHos number,n_fee number,d_injuryDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
  d_minDate Date;
begin

Result:=0;                               --?Result??

                                         --??????????
select min(startdate) into d_minDate from LLCaseReceipt where CaseNo=c_CaseNo and feeitemcode like 'CR%' and startdate>=d_injuryDate;

select d_minDate+30 into d_limitDate from dual ;	--????????????
-------------------------------------------------------------------------------------------------------------
if d_lcgetStartDate<=d_startDate and d_startDate<d_limitDate and d_injuryDate<=d_startDate  then   --????,????????????????
  if d_endDate<=d_limitDate then       --?????????????
      	select n_fee into Result from Dual;
  else                                 --?????????????
      	select n_fee*(d_limitDate-d_startDate)/n_daysInHos into Result from Dual;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_263;


/

