create Function Getappntphone(Tcontno Lcappnt.Contno%Type, Tphonetype In Char) Return Varchar2 Is
	Result Varchar2(25);

	--????????????
	--????????:???????????????????
	--???????:?????????
	Tmngcom       Varchar2(2);
	Tmobile       Varchar2(15);
	Tmobile2      Varchar2(15);
	Thomephone    Varchar2(18);
	Tphone        Varchar2(18);
	Tcompanyphone Varchar2(18);
	Thomefax      Varchar2(20);
	Tcompanyfax   Varchar2(20);
	--Tphonetype  ?? Mobile, Mobile2, Homephone, Phone, Companyphone, Homefax, Companyfax
Begin

	Select Trim(Mngcom)
	Into Tmngcom
	From Lcpol a, Lmriskapp b
	Where a.Polno = a.Mainpolno And a.Riskcode = b.Riskcode And a.Contno = Tcontno;

	Select q.Mobile, q.Mobile2, q.Homephone, q.Phone, q.Companyphone, q.Homefax, q.Companyfax
	Into Tmobile, Tmobile2, Thomephone, Tphone, Tcompanyphone, Thomefax, Tcompanyfax
	From Lcaddress q, Lcappnt c
	Where c.Appntno = q.Customerno And c.Addressno = q.Addressno And c.Contno = Tcontno;

	If Tphonetype Is Not Null Then
		If Tphonetype = 'Mobile' And Tmobile Is Not Null Then
			Result := Trim(Tmobile) || '(M)';
		Elsif Tphonetype = 'Mobile2' And Tmobile2 Is Not Null Then
			Result := Trim(Tmobile2) || '(M)';
		Elsif Tphonetype = 'Homephone' And Thomephone Is Not Null Then
			Result := Trim(Thomephone) || '(H)';
		Elsif Tphonetype = 'Phone' And TPhone Is Not Null Then
			Result := Trim(Tphone) || '(C)';
		Elsif Tphonetype = 'Companyphone'And TCompanyphone Is Not Null Then
			Result := Trim(Tcompanyphone) || '(O)';
		Elsif Tphonetype = 'Homefax' And THomefax Is Not Null Then
			Result := Trim(Thomefax) || '(F)';
		Elsif Tphonetype = 'Companyfax' And TCompanyfax Is Not Null Then
			Result := Trim(Tcompanyfax) || '(F)';
		End If;
	End If;
	If Tphonetype Is Null Then
		Case Tmngcom
			When 'B' Then
				--??
				If Tmobile Is Not Null Then
					Result := Trim(Tmobile) || '(M)';
				Elsif Tmobile2 Is Not Null Then
					Result := Trim(Tmobile2) || '(M)';
				Elsif Thomephone Is Not Null Then
					Result := Trim(Thomephone) || '(H)';
				Elsif Tphone Is Not Null Then
					Result := Trim(Tphone) || '(C)';
				Elsif Tcompanyphone Is Not Null Then
					Result := Trim(Tcompanyphone) || '(O)';
				Elsif Thomefax Is Not Null Then
					Result := Trim(Thomefax) || '(F)';
				Elsif Tcompanyfax Is Not Null Then
					Result := Trim(Tcompanyfax) || '(F)';
				End If;
			When 'I' Then
				--??
				If Tmobile Is Not Null Then
					Result := Trim(Tmobile) || '(M)';
				Elsif Tmobile2 Is Not Null Then
					Result := Trim(Tmobile2) || '(M)';
				Elsif Thomephone Is Not Null Then
					Result := Trim(Thomephone) || '(H)';
				Elsif Tphone Is Not Null Then
					Result := Trim(Tphone) || '(C)';
				Elsif Tcompanyphone Is Not Null Then
					Result := Trim(Tcompanyphone) || '(O)';
				Elsif Thomefax Is Not Null Then
					Result := Trim(Thomefax) || '(F)';
				Elsif Tcompanyfax Is Not Null Then
					Result := Trim(Tcompanyfax) || '(F)';
				End If;
			Else
				If Tmobile Is Not Null Then
					Result := Trim(Tmobile) || '(M)';
				Elsif Tmobile2 Is Not Null Then
					Result := Trim(Tmobile2) || '(M)';
				Elsif Thomephone Is Not Null Then
					Result := Trim(Thomephone) || '(H)';
				Elsif Tphone Is Not Null Then
					Result := Trim(Tphone) || '(C)';
				Elsif Tcompanyphone Is Not Null Then
					Result := Trim(Tcompanyphone) || '(O)';
				Elsif Thomefax Is Not Null Then
					Result := Trim(Thomefax) || '(F)';
				Elsif Tcompanyfax Is Not Null Then
					Result := Trim(Tcompanyfax) || '(F)';
				End If;
		End Case; End If;
	Return(Result);
End Getappntphone;


/

