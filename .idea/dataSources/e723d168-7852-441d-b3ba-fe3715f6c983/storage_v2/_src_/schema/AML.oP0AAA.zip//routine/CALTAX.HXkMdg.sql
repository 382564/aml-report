create function CALTAX(tAgentCode in varchar2,ReturnType in varchar2,TempBegin in date,tAgentGroup in varchar2) return number is
  tIndexCalNo    char(10);
 -- tStr           varchar2(10);
 -- tManageCom     char(20);
 --modify renhl 2009-03-17 latax managecom ????,?????????????,???????????????????????
  tManageCom   latax.managecom%type;
  tverifycom     char(20);
  tSaleRate      number(10,4) := 0;  --????????
  tExpenseRate   number(10,4) := 0;  --??????
  tValue1        number(10,4) := 0;  --??????
  tIncomeRate    number(10,4) := 0;  --???????
  tReleaseRate   number(10,4) := 0;  --??????
  tQuickCal      number(10,2) := 0;  --?????
  tReleaseMoney  number(10,2) := 0;  --??????

  tWage          number(10,2) := 0;
  tSale          number(10,2) := 0;
  tExpense       number(10,2) := 0;
  tIncomeTax     number(10,2) := 0;
  tBase          number(10,2) := 0;
  tLeftMoney     number(10,2) := 0;

  Result         number := 0;

  tEmployeeType varchar2(4);
  tAgentGroupType varchar2(1);
  --tongmeng 2006-07-18 add
  --???,??????????
  tCount int ;
  tTempRate number(10,5);
  tAddSale number(10,2) := 0;

begin
   --weikai add ??????????? ??0,?????
  tAgentGroupType :=JUDGSPECILEAGENTGROUP(tAgentCode);
  if (tAgentGroupType!='0') then
    Result:=0;
  else

 -- tStr := to_char(TempBegin,'yyyy-mm-dd');
 -- tIndexCalNo := substr(tStr,1,4);
 -- tIndexCalNo := concat(tIndexCalNo,substr(tStr,6,2));
 tIndexCalNo:=trim(to_char(TempBegin,'yyyyMM'));

  --select F01+F02+F03+F04+F05+F06+F07+F08+F09+F10+F11+F12+F13+F14+F15+F16+F17+F18+F19+F20+F21+F22+F23+F24+F25+F26+F27+F28+F29+F30+lastmoney-K03+K11+K12

  --2003.11.30 modified begin--
  --2004.02.17 modified by caigang begin
  select T30
  --------modified end---------
  into tWage from laindexinfo
  where indexcalno = trim(tIndexCalNo)
        and indextype='01' and AgentCode = tAgentCode;

  --2003.11.30 modified begin--
  --2004.02.17 modified by caigang end
  if tWage <= 0 then
    return 0;
  end if;
  --------modified end---------
  /*select trim(code2) into tManageCom From LDCoderela
  Where trim(code1) = (select substr(trim(managecom),1,4) from labranchgroup
  where agentgroup = tAgentGroup) and relatype = 'taxareatype';*/
  --???????????????3000,?latax??????862102???
  select B.y into tManageCom from (select A.x, A.y, A.z from
  (select code1 x, code2 y, code3 z from ldcoderela where relatype = 'taxareatype'
   and trim(code1) = (select substr(trim(managecom),1,4) from labranchgroup where agentgroup = tAgentGroup)
      union
   select code1 x, code2 y, code3 z from ldcoderela where relatype = 'taxareatype'
   and trim(code1) = (select substr(trim(managecom),1,6) from labranchgroup where agentgroup = tAgentGroup)) A
    order by A.z desc) B where rownum = 1;

  --tManageCom := substr(tManageCom,1,4);
  ------?? 2004-03-12??,??Judgeemployeetype??,??????
  -----??????,?????,??????
  tEmployeeType := Judgeemployeetype(tAgentCode,tIndexCalNo);

   if (tEmployeeType = 'YT3')-----?? 2004-03-12??,???YT3??,?????,?????????

     then tSaleRate :=0;-----?? 2004-03-15??,????????,????????????
     else

  --??????
    select TaxRate into tSaleRate from latax
    where (basemax is null or (basemax > tWage and basemin <= tWage))
    and ManageCom = tManageCom
    and TaxType = '01' ;
   end if;
    tSale := tWage * tSaleRate;

  --tongmeng 2006-07-18 add
      tCount := 0;
    --tongmeng 2006-07-11  add
    --???????????????????????????
    select count(*) into tCount from latax where
    (basemax is null or (basemax > tWage and basemin <= tWage))
    and ManageCom = tManageCom
    and TaxType = '99';
    if(tCount<>0) then
    select TaxRate into tTempRate from latax
    where ManageCom = tManageCom
    and TaxType = '99' ;

    tAddSale :=  tTempRate * tWage;
    end if;


  if ReturnType = 'S' then
    --?????,?? ???????,???? tAddSale
    if(tCount<>0) then
       return(tAddSale);
    end if;

    return(tSale);

  end if;

   if (tEmployeeType = 'YT3')-----?? 2004-03-12??,???YT3??,?????,?????????

     then tValue1 :=0;-----?? 2004-03-15??,????????,????????????
     else
                 --????
      select TaxRate,calvalue1 into tExpenseRate,tValue1 from latax
      where ManageCom = tManageCom
            and TaxType = '02';
    end if;
  if tValue1 is null or tValue1 = 0 then
    tExpense := (tWage - tSale)*tExpenseRate;
  else
    tExpense := tValue1;
  end if;

  if ReturnType = 'E' then
    return(tExpense);
  end if;


  --?????
  --tongmeng 2006-07-18 modify
  --????,?? ???????
  tBase := tWage - tExpense - tSale - tAddSale;
  if tBase <= 0 then
    return(0);
  end if;

  if tEmployeeType<>'YT3'
  then
  select calrate1,calvalue1,calvalue2,taxrate into
         tReleaseRate,tReleaseMoney,tQuickCal,tIncomeRate
  from latax
  where basemax >=  tBase
        and basemin < tBase
        and ManageCom = tManageCom
        and taxtype = '03'
        ;
   else
   select calrate1,calvalue1,calvalue2,taxrate into
         tReleaseRate,tReleaseMoney,tQuickCal,tIncomeRate
  from latax
  where (basemax+calvalue1) >=  tBase
        and (basemin+calvalue1) < tBase
        and ManageCom = tManageCom
        and taxtype = '11'
        ;
  end if;

  if nvl(tReleaseRate,0) = 0 then
    tLeftMoney := tBase - nvl(tReleaseMoney,0);
  else
    tLeftMoney := tBase - tBase * nvl(tReleaseRate,0);
  end if;

  if tLeftMoney <= 0 then
    return(0);
  else
    tIncomeTax := tLeftMoney * tIncomeRate - nvl(tQuickCal,0);
  end if;

  select substr(trim(managecom),1,6) into tverifycom from labranchgroup where agentgroup = tAgentGroup;
  if tverifycom = '865107' then
    Result := tIncomeTax * 0.2;
  else
  Result := tIncomeTax;
  end if;

  end if;
  return(Result);
end CALTAX;


/

