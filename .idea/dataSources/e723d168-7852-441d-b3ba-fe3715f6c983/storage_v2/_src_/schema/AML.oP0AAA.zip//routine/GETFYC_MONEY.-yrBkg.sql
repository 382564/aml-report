create FUNCTION GETFYC_MONEY(VGRPPOLNO LACOMMISION.GRPPOLNO%TYPE,
                                        VRADIXJS  LACommision.TRANSMONEY%TYPE)

 RETURN NUMBER IS
  RESULT      NUMBER(12,6) := 0;

BEGIN

 SELECT NVL((SELECT sum(C.FEEvalue)
              from lcgrpfee C
            WHERE C.GRPPOLNO = VGRPPOLNO
                  and feecalmode='01'
                  and RISKCODE = '2062070'),
           VRADIXJS)
  INTO RESULT
  FROM DUAL;

 RETURN RESULT;

END GETFYC_MONEY;

/

