create FUNCTION GETFYC_GRP(VGRPPOLNO LACOMMISION.GRPPOLNO%TYPE,
                                      VAGENTCOM LACOMMISION.AGENTCOM%TYPE,
                                      VRISKCODE LACOMMISION.RISKCODE%TYPE)
  RETURN NUMBER IS
  RESULT      NUMBER(12,6) := 0;
  TFLAG       VARCHAR(2);--销售类型：D直销，A中介
  TMANAGERATE NUMBER(12,6) := 0;--管理费比例
BEGIN
  IF VAGENTCOM IS NULL THEN
    TFLAG := 'D';
  ELSE
    TFLAG := 'A';
  END IF;
  --如果是管理费类产品，lcgrpfee.FEEvalue字段存储有两种情况情况：
  --存储管理费比例时，返回的值为 管理费比例*险种的提奖比例
  --存储管理费时，返回险种的提奖比例
  IF VRISKCODE = '2062070' THEN
 SELECT NVL((SELECT MAX(C.FEEvalue)
              from lcgrpfee C
            WHERE C.GRPPOLNO = VGRPPOLNO
                  and feecalmode='02'),
           1)
  INTO TMANAGERATE
  FROM DUAL;

    SELECT A.RATE*TMANAGERATE
      INTO RESULT
      FROM LARATECOMMISION A
     WHERE A.BRANCHTYPE = '2'
       AND RISKCODE = VRISKCODE
       AND A.F02 = TFLAG;
  ELSE
    --如果在录单的时候就录入的比例，则取录单的比例，如没有录默认为0.0000，则取系统定义的比例
    SELECT C.COMMRATE
      INTO RESULT
      FROM LCGRPPOL C
     WHERE c.grppolno = VGRPPOLNO;
    IF RESULT = 0.0000 THEN
      SELECT A.RATE
        INTO RESULT
        FROM LARATECOMMISION A
       WHERE A.BRANCHTYPE = '2'
         AND RISKCODE = VRISKCODE
         AND A.F02 = TFLAG;
  END IF;
END IF;
if RESULT IS NULL then
   RESULT:=0;
end if;

 RETURN RESULT;

 EXCEPTION
  WHEN OTHERS THEN
    --数据库中PayYear没有配置的部分均返回0
    RETURN 0;
END GETFYC_GRP;

/

