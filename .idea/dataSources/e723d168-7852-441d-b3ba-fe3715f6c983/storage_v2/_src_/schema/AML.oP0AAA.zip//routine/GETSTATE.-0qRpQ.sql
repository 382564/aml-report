create function getState(strCN in lccont.contno%type) return char is
  v_strState char(9);
/*  v_debug_flag char(10);*/

begin
   DECLARE
  strState char(9);
  strContNo char(30);
  Rs integer;
  CurrentDate date;
  strMiddle_3 char(1):='0';
  strMiddle_7 char(1):='0';
  Flag integer:=0;
  strPayToDate date;
  strPolNo char(20);
/*  vStateType char(10);
  vStateReason char(10);
  vState char(10);
  vEnddate date;*/

 cursor s_cur_lcpol(vContNo char)
 is select polno from lcpol where ContNo=vContNo;

 cursor s_cur_lcontstate(vPolNo varchar)
 is select * from lccontstate
 where polno=vPolNo
 order by startdate
 desc;

begin

  --execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';
  select Sysdate into CurrentDate from dual;
  strContNo:=strCN;

  --v_debug_flag := '00';

  if strContNo is null then
   strState:='000000000';
   return  strState;
  end if;

  --v_debug_flag := '01';

   --???
   select count(1) into Rs from LJAGetDraw where ConfDate is  null and contno=strContNo;
   if Rs=0 then
    strState:='0';
    else
    strState:='1';
   end if;

 -- v_debug_flag := '02';


  --???

   select count(1) into Rs from LJAGetClaim where ConfDate is  null and contno=strContNo;
   if Rs=0 then
    strState:=trim(strState)||'0';
    else
    strState:=trim(strState)||'1';
   end if;

  --v_debug_flag := '03';

  --???

   select count(1) into Rs from LJAGetClaim where ConfDate is  null and contno=strContNo;
 if Rs<>0 then
  for s_record_lcpol in s_cur_lcpol(strContNo) loop
   select count(1) into Rs
   from LCPrem where FreeFlag = 1 and  FreeStartDate < CurrentDate
   and PolNo = s_record_lcpol.polno;
   if Rs=1 then
    strMiddle_3:='1';
   end if;
   exit;
  end loop;
end if;
   strState:=trim(strState)||strMiddle_3;

  --v_debug_flag := '04';


   --???

    strState:=trim(strState)||'0';

    --???
    select count(1) into Rs from LCContState where contno=strContNo and  StateType='PayPrem' and State='1' and EndDate is null;
   if Rs=0 then
    strState:=trim(strState)||'0';
    else
    strState:=trim(strState)||'1';
   end if;

  --v_debug_flag := '05';

    --???

     select count(1) into Rs from LCContState where contno=strContNo and  StateType='Loan' and State='1' and EndDate is null;
   if Rs=0 then
    strState:=trim(strState)||'0';
    else
    strState:=trim(strState)||'1';
   end if;

   --v_debug_flag := '06';

   --???

    select count(1) into Rs from LJAGetClaim where ConfDate is  null and contno=strContNo;
 if Rs<>0 then
  for s_record_lcpol in s_cur_lcpol(strContNo) loop
   select count(1) into Rs
   from LCPrem where FreeFlag = 1 and ( FreeEndDate is null or FreeEndDate > CurrentDate)
   and  FreeStartDate < CurrentDate
   and PolNo = s_record_lcpol.polno;
   if Rs=1 then
    strMiddle_7:='1';
   end if;
   exit;
  end loop;
end if;
   strState:=trim(strState)||strMiddle_7;
  --v_debug_flag := '07';

 --???
 select count(1) into Rs from LLSubReport
 where CustomerNo in (select insuredno from lcinsured where contno=strContNo);
  if Rs!=0 then
   select count(1) into Rs from LLCase where  CustomerNo in (select insuredno from lcinsured where contno=strContNo);
    if Rs<>0 then
     strState:=trim(strState)||'4';
    else
     strState:=trim(strState)||'2';
    end if;
  else
    strState:=trim(strState)||'0';
 end if;
  --v_debug_flag := '08';

 --???-?10???

  --?????polno

 select polno into strPolNo from lcpol where contno=strContNo and polno=mainpolno;


 --c
  select count(2) into Rs from lccont where contno = strContNo and UWFlag='1';
 if Rs<>0 then
  strState:=trim(strState)||'c';
  return strState;
 end if;


 for v_cur_lccontstate in s_cur_lcontstate(strPolNo) loop
  if v_cur_lccontstate.StateType='Available' and v_cur_lccontstate.State='0' and v_cur_lccontstate.Enddate is null then
      strState:=trim(strState)||'1';
      return strState;

  else if v_cur_lccontstate.StateType='Terminate' then
  if v_cur_lccontstate.StateReason='01' and v_cur_lccontstate.State='1' and v_cur_lccontstate.Enddate is null then
     strState:=trim(strState)||'b';
     return strState;
  end if;

  if v_cur_lccontstate.StateReason='05' and v_cur_lccontstate.State='1' and v_cur_lccontstate.Enddate is null then
     strState:=trim(strState)||'9';
     return strState;
  end if;

  if  v_cur_lccontstate.StateReason='04' and v_cur_lccontstate.State='1' and v_cur_lccontstate.Enddate is null then
     strState:=trim(strState)||'6';
     return strState;
  end if;

  if  v_cur_lccontstate.StateReason='02' and v_cur_lccontstate.State='1' and v_cur_lccontstate.Enddate is null then
     strState:=trim(strState)||'4';
     return strState;
  end if;

  if  v_cur_lccontstate.StateReason='06' and v_cur_lccontstate.State='1' and v_cur_lccontstate.Enddate is null then
     strState:=trim(strState)||'3';
     return strState;
  end if;
 end if;
 end if;

 end loop;


   --v_debug_flag := '09_c';
  --b,????
 /* if Flag=1 then
  return strState;
 end if;

 select count(1) into Rs from LCContState
 where  polno=strPolNo and StateType='Terminate' and StateReason='01' and State='1' and Enddate is null;
  if Rs<>0 then
  strState:=trim(strState)||'b';
  Flag:=1;
 end if;

  --v_debug_flag := '09_b';*/
 --a
 if Flag=1 then
  return strState;
 end if;

 --
 select count(1) into Rs from LLContState
 where polno=strPolNo and StateType='Terminate'  and State='1'  and (StateReason='0' or StateReason='04');

 if Rs<>0 then
  strState:=trim(strState)||'a';
  Flag:=1;
 end if;

/*    --v_debug_flag := '09_a';
 --9 ????
 if Flag=1 then
  return strState;
 end if;

 select count(1) into Rs from LCContState where   polno=strPolNo and  StateType='Terminate'  and State='1' and StateReason='05' and Enddate is null;

  if Rs<>0 then
  strState:=trim(strState)||'9';
  Flag:=1;
 end if;
*/
    --v_debug_flag := '09_9';
 --8 ?????
 if Flag=1 then
  return strState;
 end if;

  select paytodate into strPayToDate from lcpol where polno=strPolNo;
  if CurrentDate-strPayToDate>0 then
    if CurrentDate-(strPayToDate+60)<0 then
      strState:=trim(strState)||'8';
      return strState;
    end if;
  end if;


 /*   --v_debug_flag := '09_8';
 --6
 if Flag=1 then
  return strState;
 end if;

 select count(1) into Rs from LCContState where  polno=strPolNo  and  StateType='Terminate'  and StateReason='04'  and State='1'   and Enddate is null;
 if Rs<>0 then
  strState:=trim(strState)||'6';
  Flag:=1;
 end if;

    --v_debug_flag := '09_6';
 --4
 if Flag=1 then
  return strState;
 end if;
 select count(1) into Rs from LCContState where  polno=strPolNo and  StateType='Terminate' and StateReason='02' and State='1'  and Enddate is null;
 if Rs<>0 then
  strState:=trim(strState)||'4';
  Flag:=1;
 end if;

     --v_debug_flag := '09_4';
 --3
 if Flag=1 then
  return strState;
 end if;
  select count(1) into Rs from LCContState where  polno=strPolNo and  StateType='Terminate' and StateReason='06' and State='1'  and Enddate is null;
 if Rs<>0 then
  strState:=trim(strState)||'3';
  Flag:=1;
 end if;*/

    --v_debug_flag := '09_3';
 --2 ??


  select paytodate into strPayToDate from lcpol where  polno=strPolNo;
    if CurrentDate-(strPayToDate+60)>0 then
      strState:=trim(strState)||'2';
      return strState;
    end if;


    --v_debug_flag := '09_2';
  strState:=trim(strState)||'1';
  v_strState:=strState;
end;

  --v_debug_flag := 'END';

  return(v_strState);
exception
   when others then
   --?????????
   --dbms_output.put_line('????:getState??????' || ' ???????: ' || sqlerrm);
   return( 'E???????: ' || sqlerrm);
   --return(v_debug_flag || 'E???????: ' || sqlerrm);

end getState;


/

