create Function Agentstatebydate(Tagentcode In Varchar2, Twageno In Varchar2) Return Varchar2 Is
	Result Varchar2(4);

	--???? : tAgentcode  ????
	--            tWageno     ????(?:200509)

	Tenddate     Date;
	Tcautiondate Date;
	Toutdate     Date;

Begin

	Select Enddate Into Tenddate From Lastatsegment Where Stattype = '5' And Yearmonth = Twageno;

	Select Cautionerbirthday,Outworkdate Into Tcautiondate,Toutdate From Laagent Where Agentcode = Tagentcode;

--	Select Outworkdate Into Toutdate From Laagent Where Agentcode = Tagentcode;

	If (Tenddate < Tcautiondate Or Tcautiondate Is Null) Then
		Result := '??';
	End If;

	If Tenddate >= Tcautiondate And (Tenddate < Toutdate Or Toutdate Is Null) Then
		Result := '??';
	End If;

	If Tenddate >= Toutdate Then
		Result := '??';
	End If;

	Return(Result);
End Agentstatebydate;


/

