create function calFnq(vManageCom in varchar2) return integer is
  Result integer;
  pragma autonomous_transaction;
begin

 declare

 cursor v_cursor_newsys is
 select * from newsystemp2
 where managecom like vManageCom||'%'
 ;

 v_row_newsystemp2 newsystemp2%rowtype;

 begin

 open v_cursor_newsys;

 loop
  fetch v_cursor_newsys into v_row_newsystemp2;
  exit when v_cursor_newsys%notfound;

   v_row_newsystemp2.prema := v_row_newsystemp2.prem+v_row_newsystemp2.addb+v_row_newsystemp2.addf-v_row_newsystemp2.mf;
   v_row_newsystemp2.bprem := v_row_newsystemp2.prema +v_row_newsystemp2.dx;

   update newsystemp2 set prema = v_row_newsystemp2.prema,bprem = v_row_newsystemp2.bprem
   where managecom = v_row_newsystemp2.managecom
   and salechnl = v_row_newsystemp2.salechnl
   and riskcode = v_row_newsystemp2.riskcode
   and payyears = v_row_newsystemp2.payyears
   ;

 commit;

 end loop;

 close v_cursor_newsys;


 end;
  return(Result);
end calFnq;


/

