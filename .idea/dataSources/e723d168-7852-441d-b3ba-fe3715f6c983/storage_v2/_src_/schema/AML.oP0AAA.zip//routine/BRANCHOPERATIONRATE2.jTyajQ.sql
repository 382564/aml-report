create FUNCTION BranchOperationRate2(
       TempBegin date, --????
       TempEnd date,   --????
       tBranchattr LACommision.Branchattr%TYPE, --?????
       tIndexCalNo integer   --????
       ) return number as   --???????
v_Rate number;--???????
v_StandPrem number; -- ????
v_Planvalue number; --????
v_month number; --????


begin

select months_between(TempEnd,LAST_DAY(TempBegin))+1 into v_Month from dual;

select NVL(sum(StandPrem),0) into v_StandPrem from LACommision
where BranchAttr like substr(tBranchattr,0,8)||'%'
and tmakedate >= TempBegin And  tmakedate <= TempEnd;


select v_Month*decode(nvl(sum(planvalue),0),0,1000000000000,sum(planvalue))/6 into v_Planvalue
from laplan where branchtype = '3' and plantype = '2'
and planobject like substr(tBranchattr,0,8)||'%'
and PlanPeriod <= tIndexCalNo and PlanPeriod > to_char(tIndexCalNo-6);

select nvl(v_StandPrem/v_Planvalue,0) into v_Rate from ldsysvar where sysvar = 'onerow';


return v_Rate;
End BranchOperationRate2;


/

