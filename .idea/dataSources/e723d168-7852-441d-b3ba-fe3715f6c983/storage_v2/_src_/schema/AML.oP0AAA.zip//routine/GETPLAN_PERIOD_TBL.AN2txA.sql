create function GETPLAN_PERIOD_TBL(cRiskPeriod in CHAR,
                                              cRiskCode   in CHAR)
  return CHAR is
  mplan_period_tbl CHAR;
  temp1            VARCHAR(5);
  temp2            VARCHAR(5);
begin


    -- ??
  if TRIM(cRiskPeriod) = 'M' or TRIM(cRiskPeriod) = 'S' then
    mplan_period_tbl := '1';
  end if;

   -- ?????
  if TRIM(cRiskPeriod) = 'L' THEN
   BEGIN
    select riskdutytype
      into temp1
      from lfrisk
     where riskcode = cRiskCode;
     EXCEPTION
     WHEN NO_DATA_FOUND THEN
         mplan_period_tbl := '2';
     END;

    IF TRIM(temp1) = '1' THEN
      mplan_period_tbl := '9'; --??
     ELSE
      mplan_period_tbl := '2'; --?????
    end if;

 end if;

  return(mplan_period_tbl);
end GETPLAN_PERIOD_TBL;


/

