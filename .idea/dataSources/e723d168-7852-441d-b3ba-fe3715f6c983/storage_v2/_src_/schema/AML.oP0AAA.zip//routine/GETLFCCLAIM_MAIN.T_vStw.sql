create function getLFCClaim_Main(startdate in date,enddate in date,tManageCom in varchar) return char is
  vResI char;
  pragma autonomous_transaction;
 begin


 declare



 v_rgtantname varchar2(20);

 v_rptdate  date;
 v_rgtdate date;
 v_endcasedate date ;
 v_DeclineAmnt  char(20);
 v_clmno char(20);
 v_contno char(20);
 v_standpay number(16,2);
 v_realpay  number(16,2);
 v_appntname varchar2(60);




 v_row_lfcclaimmain  lfcclaim_main%rowtype;

 cursor v_cursor_llclaimpolicy is
 --???????????????
 select distinct clmno,contno,max(appntname),sum(standpay),sum(realpay)
 from llclaimpolicy a
 where 1=1
     and exists (select 1 from ljagetclaim
         where otherno = a.clmno
         and confdate >= startdate
         and confdate <= enddate
         and managecom like  tManageCom||'%')
  group by clmno,contno

  union
  --???????????????
 select distinct clmno,contno,max(appntname),sum(standpay),sum(realpay)
 from llclaimpolicy a
 where 1=1
  and exists(select 1 from llreport
            where rptno = a.clmno
            and rptdate >=startdate
            and rptdate <=enddate
            and mngcom like  tManageCom||'%')

  group by clmno,contno

  union
  --????????????,???????????????
 select distinct clmno,contno,max(appntname),sum(standpay),sum(realpay)
 from llclaimpolicy a
 where 1=1
     and exists(select 1 from llreport
            where rptno = a.clmno
            and rptdate <=startdate
            and mngcom like  tManageCom||'%')
     and exists(select 1 from ljagetclaim
                where otherno = a.clmno
                and confdate >= enddate
                and managecom
                like  tManageCom||'%')
  group by clmno,contno
     ;

 begin

 execute immediate  'truncate table lfcclaim_main';
 open v_cursor_llclaimpolicy;

 loop
 fetch v_cursor_llclaimpolicy into v_clmno,v_contno,v_appntname,v_standpay,v_realpay;
 exit when v_cursor_llclaimpolicy%notfound;

 -- ???
  v_row_lfcclaimmain.CaseNo := v_clmno;

 --????
  v_row_lfcclaimmain.GP_Type := 'P';

 --???
  v_row_lfcclaimmain.POLNO :=v_contno;

 --?????


  v_row_lfcclaimmain.App_name := v_appntname;

 --?????

 begin
  select rgtantname into v_rgtantname from llregister where rgtno = v_clmno;
  exception when no_data_found
  then
  null;
  end;
  v_row_lfcclaimmain.Requ_Name := v_rgtantname;

 --????
 begin
 select rptdate into v_rptdate from llreport where rptno = v_clmno;
 exception when no_data_found then
 null;
 end;
  v_row_lfcclaimmain.Docu_date :=v_rptdate;


 --????

 begin
 select rgtdate,endcasedate into v_rgtdate,v_endcasedate from llregister where rgtno = v_clmno;
 exception when no_data_found then
 null;
 end;

  v_row_lfcclaimmain.Case_date := v_rgtdate;
 --????
  v_row_lfcclaimmain.End_date := v_endcasedate;

 --????
  v_row_lfcclaimmain.Reckon_Loss := nvl(v_standpay,0);

 --?????
  v_row_lfcclaimmain.Exam_Amt := nvl(v_realpay,0);


 --????
  v_row_lfcclaimmain.Check_Fee := 0;


  --????
  begin
  select DeclineAmnt into v_DeclineAmnt from llclaimdetail where clmno = v_clmno and rownum =1;
  exception when no_data_found then
  null;
  end;
  v_row_lfcclaimmain.reje_amt := nvl(v_DeclineAmnt,0);

  --	??????
  v_row_lfcclaimmain.accommodate_cause := '';


 insert into lfcclaim_main values v_row_lfcclaimmain;
 commit;

end loop;
close v_cursor_llclaimpolicy;

return vResI;
 end;
end getLFCClaim_Main;


/

