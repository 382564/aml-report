create FUNCTION GETSTANDPREM_GRP(VAGENTCOM LACOMMISION.AGENTCOM%TYPE,
                                            VRISKCODE LACOMMISION.RISKCODE%TYPE)
  RETURN NUMBER IS
  RESULT NUMBER(12, 2) := 0;
  /*
  团渠折标算法
  险种类别                     折标比例
                            直销业务              中介业务
  短期意外险（含一年期定寿）  1            直销折标比例的50%
  短期健康险                 0.3           直销折标比例的50%
  年金保险                    0.6           直销折标比例的50%
  管理式业务                 0.3           直销折标比例的50%

  */

  TKINDCODE   VARCHAR2(2);
  TRISKPROP   VARCHAR2(2);
  TRISKPERIOD VARCHAR2(2);

BEGIN

  SELECT KINDCODE, RISKPROP, RISKPERIOD
    INTO TKINDCODE, TRISKPROP, TRISKPERIOD
    FROM LMRISKAPP
   WHERE RISKCODE = VRISKCODE;
  --直销业务
  IF TKINDCODE = 'H' AND TRISKPERIOD = 'L' THEN
    RESULT := 0.3;
  ELSIF TKINDCODE = 'R' AND TRISKPROP = 'G' THEN
    RESULT := 0.6;
  ELSIF TRISKPERIOD = 'M' THEN
    RESULT := 1;
  ELSE
    RESULT := 0;
  END IF;

  IF VAGENTCOM IS NOT NULL THEN
    --中介业务
    RESULT := RESULT * 0.5;
  END IF;

  RETURN RESULT;
END GETSTANDPREM_GRP;

/

