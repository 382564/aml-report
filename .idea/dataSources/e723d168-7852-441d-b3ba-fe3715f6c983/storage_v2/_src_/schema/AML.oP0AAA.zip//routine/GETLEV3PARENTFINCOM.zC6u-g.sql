create function getLev3ParentFinCom(FinComCode in varchar2) return varchar2 is
  Result varchar2(10);
begin
  select parentcomcodeisc
    into Result
    from lfcomisc
   where comcodeisc = FinComCode;
  return(Result);
end getLev3ParentFinCom;
CREATE OR REPLACE PUBLIC SYNONYM getLev3ParentFinCom for liscode.getLev3ParentFinCom;
GRANT EXECUTE ON liscode.getLev3ParentFinCom to lis;


/

