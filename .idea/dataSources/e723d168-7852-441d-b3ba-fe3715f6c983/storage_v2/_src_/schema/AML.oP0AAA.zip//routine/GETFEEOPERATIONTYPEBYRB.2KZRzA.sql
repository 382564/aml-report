create function GetFeeOperationTypebyRB(TEdorNO in varchar2)
  return varchar2 is
  Result        varchar2(20);
  TEdorAcceptNO varchar2(20);
  ContNO        varchar2(20);
begin
  --TEdorNO保全号码=保全申请号
  if TEdorNO is null then
    return 'ErrorEdorNO';
  end if;
  begin
    --fecth the source BQ-buss Accecpt NO and contract no.
    select t.standbyflag1, t.contno, t.standbyflag3
      into TEdorAcceptNO, ContNO, Result
      from LPEDORITEM t
     where t.edorno = TEdorNO;
  exception
    when no_data_found then
      return 'ErrorBQ-RB';
  end;
  if Result is not null then
      return Result;
  end if;
  begin
    --fetch the source BQ-buss type.
    select t.edortype
      into Result
      from lpedoritem t
     where t.edoracceptno = TEdorAcceptNO
       and t.contno = ContNO;
  exception
    when no_data_found then
      return 'ErrorBQ-SourceBuss';
  end;
  return(Result);
end GetFeeOperationTypebyRB;


/

