create function getEdorState(P_EdorAcceptNo varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select case
           when exists (select 1
                   from lpgrpedoritem
                  where edoracceptno = P_EdorAcceptNo
                    and edorstate = '1') and exists
            (select 1
                   from lwmission
                  where missionprop1 = P_EdorAcceptNo
                    and activityid = '0000008002') then
            '待申请确认'
           else
            nvl((select codename
                  from ldcode
                 where codetype = 'gbqactivityname'
                   and code in
                       (select activityid
                          from lwmission
                         where missionprop1 = P_EdorAcceptNo)),
                (select codename
                   from ldcode
                  where codetype = 'edorstate'
                    and code = (select edorstate
                                  from lpedorapp
                                 where edoracceptno = P_EdorAcceptNo)))
         end
    into Result
    from dual;
  return(Result);
end getEdorState;

/

