create FUNCTION agefactor(appage in number) return number
is
tR number;
begin
 if appage > 0 and appage < 5 then
  tR := 2;
 end if;
 if appage > 4 and appage < 16 then
  tR := 0.6;
 end if;
 if appage > 15 and appage < 31 then
  tR := 0.55;
 end if;
 if appage > 30 and appage < 41 then
  tR := 0.7;
 end if;
 if appage > 40 and appage < 51 then
  tR := 1;
 end if;
 if appage > 50 and appage < 61 then
  tR := 1.5;
 end if;
 if appage > 60 and appage < 65 then
  tR := 2;
 end if;

 return(tR);
end;


/

