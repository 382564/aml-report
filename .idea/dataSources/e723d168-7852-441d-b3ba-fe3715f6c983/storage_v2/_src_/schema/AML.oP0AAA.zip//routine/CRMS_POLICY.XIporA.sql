create PROCEDURE CRMS_POLICY(TSTRATDATE  IN VARCHAR2,
                                        TENDDATE    IN VARCHAR2,
                                        TCUSTOMERNO       IN VARCHAR2,
                                        ERRORMSG    OUT VARCHAR2) AS
  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有保单号时，只通过保单号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Policy A
       WHERE A.Contno IN (SELECT A.CONTNO FROM LCCONT A WHERE A.APPNTNO = TCUSTOMERNO and a.appflag <> '0');
      --开始提数
      INSERT INTO MID_CR_Policy
        SELECT DISTINCT A.CONTNO ContNo,
                        '01' ContType,
                        SUBSTR(A.Managecom,0,6) LOCID,
                        (SELECT sum(lc.prem) FROM lcpol lc  WHERE lc.contno = A.Contno) PREM,
                        (SELECT sum(lc.amnt) FROM lcpol lc  WHERE lc.contno = A.Contno) AMNT,
                        A.PAYINTV PAYMETHOD,
                        A.APPFLAG ContStatus,
                        A.CVALIDATE EFFECTIVEDATE,
                        (SELECT MAX(D.ENDDATE)
                           FROM LCPOL D
                          WHERE D.CONTNO = A.CONTNO and D.polno = D.mainpolno) EXPIREDATE,
                        '' ACCOUNTNO,
                        (SELECT sum(lc.sumprem) FROM lcpol lc  WHERE lc.contno = A.Contno) SumPrem,
                        '' MAINYEARPREM,
                       (SELECT decode(lc.payintv,'1',lc.prem*12,'12',lc.prem,'3',lc.prem*4,'6',lc.prem*2, '')  FROM lcpol lc WHERE A.Contno = LC.CONTNO AND ROWNUM =1) YEARPREM,
                        A.AGENTCODE AGENTCODE,
                        '' GRPFLAG,
                        '个险核心' Channel,
                        '人身' InsSubject,
                        (SELECT lm.Risktype3 FROM lmriskapp lm WHERE lm.riskcode = (
                                SELECT riskcode FROM lcpol lc WHERE lc.contno = A.contno
                                   and lc.mainpolno = lc.polno and rownum =1)) INVESTFLAG,
                        '' REMAINACCOUNT,
                        (SELECT DECODE(D.PAYENDYEARFLAG,
                                       'A',
                                       D.PAYENDYEAR,
                                       'Y',
                                       D.PAYENDYEAR,
                                       'M',
                                       D.PAYENDYEAR / 12,
                                       'D',
                                       D.PAYENDYEAR / 365)
                           FROM LCPOL D
                          WHERE D.CONTNO = A.CONTNO
                            AND D.POLNO = D.MAINPOLNO
                            AND ROWNUM = 1) PayPeriod,
                            A.Salechnl,
                        (SELECT lc.InsuredPeoples FROM lcpol lc WHERE lc.contno = A.Contno and rownum =1) InsuredPeoples,
                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LCAPPNT B
          LEFT JOIN LCADDRESS C ON B.APPNTNO = C.CUSTOMERNO
                               AND B.ADDRESSNO = C.ADDRESSNO,
         LCCONT A
         WHERE A.CONTTYPE = '1'
           AND A.CONTNO = B.CONTNO
           AND A.APPFLAG <> '0'
           AND A.APPNTNO = TCUSTOMERNO; --有保单号时，只通过保单号查询
      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Policy C
         WHERE C.CONTNO  IN (SELECT A.CONTNO
                                FROM LCCONT A
                               WHERE A.APPFLAG <> '0'
                                AND A.CONTTYPE = '1'
                                 AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                     TCDATE AND TMDATE); --没有客户号时，通过时间查询
        --开始提数
       INSERT INTO MID_CR_Policy
         SELECT DISTINCT A.CONTNO ContNo,
                        '01' ContType,
                        A.Managecom LOCID,
                        (SELECT sum(lc.prem) FROM lcpol lc  WHERE lc.contno = A.Contno) PREM,
                        (SELECT sum(lc.amnt) FROM lcpol lc  WHERE lc.contno = A.Contno) AMNT,
                        A.PAYINTV PAYMETHOD,
                        A.APPFLAG ContStatus,
                        A.CVALIDATE EFFECTIVEDATE,
                        (SELECT MAX(D.ENDDATE)
                           FROM LCPOL D
                          WHERE D.CONTNO = A.CONTNO and D.polno = D.mainpolno) EXPIREDATE,
                        '' ACCOUNTNO,
                        (SELECT sum(lc.sumprem) FROM lcpol lc  WHERE lc.contno = A.Contno) SumPrem,
                        '' MAINYEARPREM,
                       (SELECT decode(lc.payintv,'1',lc.prem*12,'12',lc.prem,'3',lc.prem*4,'6',lc.prem*2, '')  FROM lcpol lc WHERE A.Contno = LC.CONTNO AND ROWNUM =1) YEARPREM,
                        A.AGENTCODE AGENTCODE,
                        '' GRPFLAG,
                        '个险核心' Channel,
                        '人身' InsSubject,
                        (SELECT lm.Risktype3 FROM lmriskapp lm WHERE lm.riskcode = (
                                SELECT riskcode FROM lcpol lc WHERE lc.contno = A.contno
                                   and lc.mainpolno = lc.polno and rownum =1)) INVESTFLAG,
                        '' REMAINACCOUNT,
                        (SELECT DECODE(D.PAYENDYEARFLAG,
                                       'A',
                                       D.PAYENDYEAR,
                                       'Y',
                                       D.PAYENDYEAR,
                                       'M',
                                       D.PAYENDYEAR / 12,
                                       'D',
                                       D.PAYENDYEAR / 365)
                           FROM LCPOL D
                          WHERE D.CONTNO = A.CONTNO
                            AND D.POLNO = D.MAINPOLNO
                            AND ROWNUM = 1) PayPeriod,
                            A.Salechnl,
                        (SELECT lc.InsuredPeoples FROM lcpol lc WHERE lc.contno = A.Contno and rownum =1) InsuredPeoples,
                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCAPPNT B
            LEFT JOIN LCADDRESS C ON B.APPNTNO = C.CUSTOMERNO
                                 AND B.ADDRESSNO = C.ADDRESSNO,
           LCCONT A
           WHERE A.CONTTYPE = '1'
             AND A.CONTNO = B.CONTNO
             AND A.APPFLAG <> '0'
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE; --没有客户号时，通过时间查询
        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_POLICY;


/

