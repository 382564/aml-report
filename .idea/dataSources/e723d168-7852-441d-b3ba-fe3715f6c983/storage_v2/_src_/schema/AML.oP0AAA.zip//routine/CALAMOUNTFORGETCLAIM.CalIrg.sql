create function calAmountForGetClaim(p_actugetno in varchar2,
                                           p_managecom in varchar2,
                                           p_key       in varchar2,
                                           p_getmoney  in number)
  return number is
  Result        number(12, 2);
  v_sumPay      number(12, 2);
  v_cursorMoney number(12, 2);
  v_cursorKey   varchar2(200);
  cursor myCursor is
    select money, key
      from (select abs(a.pay) as money,
                   a.ActuGetNo || ',' || a.FeeFinaType || ',' || a.SubFeeOperationType || ',' ||
                   a.FeeOperationType || ',' || a.DutyCode || ',' || a.GetDutyKind || ',' ||
                   a.GetDutyCode || ',' || a.PolNo as key
              from ljagetclaim a
             where a.actugetno = p_actugetno
               and a.managecom = p_managecom
               and a.feefinatype in ('SWPK', 'TF', 'YLPK','SCPK','DQPK','TB')
             order by abs(a.pay) desc,
                       a.ActuGetNo || ',' || a.FeeFinaType || ',' || a.SubFeeOperationType || ',' ||
                       a.FeeOperationType || ',' || a.DutyCode || ',' || a.GetDutyKind || ',' ||
                       a.GetDutyCode || ',' || a.PolNo);
  reMyCurson myCursor%ROWTYPE;
  /*
  函数用途：
         用于实付凭证，对于收付同时发生的业务，计算一笔应付数据的付费金额被收费金额冲抵之后的差额。

  函数需解决的问题：
         1、在一次交易业务的明细数据中，只有一笔收、一笔付；
         2、在一次交易业务的明细数据中，有多笔收、一笔付；
         3、在一次交易业务的明细数据中，有一笔收、多笔付；
         4、在一次交易业务的明细数据中，有多笔收、多笔付；
     注：
         1、以上四种情况，付费金额之和总是大于收费金额之和；
         2、单笔收费金额可能会大于任何一笔付费金额；

  算法：
         1、金额最大的付费数据先抵；
         2、如果金额最大的付费数据不够抵，次大的抵；
         3、以此类推，直至收费金额之和抵为0为止；
  */
begin
  --取得收费金额之和
  select sum(abs(a.pay))
    into v_sumPay
    from ljagetclaim a
   where a.actugetno = p_actugetno
     and a.managecom = p_managecom
     and a.feefinatype in ('YCLX','HK','HKLX');

  open myCursor;
  loop
    --取得游标金额
    fetch myCursor
      into reMyCurson;
    exit when myCursor%notfound;
    v_cursorMoney := reMyCurson.Money;
    v_cursorKey   := reMyCurson.Key;

    if v_cursorMoney > p_getmoney then
      --游标金额大于被计算的付费金额，属于先被抵减的付费数据
      if v_cursorMoney >= v_sumPay then
        --先被抵减的付费数据大于收费金额之和，说明收费金额已被抵减为0，被计算付费数据就不用被抵减了
        Result := p_getmoney;
        exit;
      else
        --先被抵减的付费数据小于收费金额之后，说明不能将收费金额抵减到0，则计算出收费数据被抵减之后的余额
        v_sumPay := v_sumPay - v_cursorMoney;
      end if;
    elsif v_cursorMoney = p_getmoney then
      --游标金额等于被计算金额，按如下逻辑处理：
      if v_cursorKey <> p_key then
        --游标主键不等于被计算付费数据的主键，说明游标数据不是被计算付费数据（也是属于先抵减的付费数据）
        if v_cursorMoney >= v_sumPay then
          --先被抵减的付费数据大于收费金额之和，说明收费金额已被抵减为0，被计算付费数据就不用被抵减了
          Result := p_getmoney;
          exit;
        else
          --先被抵减的付费数据小于收费金额之后，说明不能将收费金额抵减到0，则计算出收费数据被抵减之后的余额
          v_sumPay := v_sumPay - v_cursorMoney;
        end if;
      else
        --游标主键等于被计算付费数据的主键
        if p_getmoney >= v_sumPay then
          --被计算的数据大于收费数据余额，说明被计算付费数据足够抵减，直接返回抵减后的差额
          Result := p_getmoney - v_sumPay;
          exit;
        else
          --被计算的数据小于收费数据余额，说明被计算付费数据不够抵减，直接返回0
          Result := 0;
          exit;
        end if;
      end if;
    end if;
  end loop;
  close myCursor;
  return(Result);
end calAmountForGetClaim;


/

