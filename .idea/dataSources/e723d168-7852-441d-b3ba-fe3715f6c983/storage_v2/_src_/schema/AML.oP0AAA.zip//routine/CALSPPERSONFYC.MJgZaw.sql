create FUNCTION calSPpersonFYC(vAgentCode  IN VARCHAR2,
                                          vIndexCalNo IN VARCHAR2) RETURN NUMBER IS
  RESULT NUMBER := 0;
BEGIN

  SELECT nvl(SUM(a.value), 0)
    INTO RESULT
    FROM lacommisionindex a
   WHERE a.agentcode = vAgentCode
     AND a.yearmonth = vIndexCalNo
     AND a.caltype IN ('00', '04');

  RETURN round(RESULT, 2);

END calSPpersonFYC;


/

