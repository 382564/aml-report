create FUNCTION GetAverageMoney(aYear in char, aMonth in char, aInteCode in char

,aUnitCode in char) return number is
 /*
 hq_money number(12,2);--????
 dq_money number(12,2);--????
 de_money number(12,2);--??????
 gz_money number(12,2);--??
 jr_money number(12,2);--????
 qy_money number(12,2);--????
 zq_money number(12,2);--??????
 mr_money number(12,2);--????
 */
 --money number (12,2);
 --???
 mResultMoney number(12,2);

begin
  if((aMonth=1)and(aInteCode='2443')) then
   --   if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount) into mResultMoney from msh_subjassvalue where

year=aYear and month = '01' and subjcode='43010401' and unitcode = aUnitCode
          group by unitcode;
      end if;
/*
      if((aMonth=1)and(aInteCode='2444')) then
          --???????-????-????
          select sum(totalcreditamount) into mResultMoney from  msh_subjassvalue where

year=aYear and month = '01' and subjcode='43010402' and unitcode = aUnitCode
          group by unitcode;
      end if ;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount) into mResultMoney from msh_subjassvalue where year=aYear and

month = '01' and subjcode in ('100212080101','100212090101','100212040101') and unitcode =

aUnitCode
          group by unitcode;
      end if ;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount) into mResultMoney from msh_subjassvalue where year=aYear and

month = '01' and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401') and unitcode = aUnitCode
          group by unitcode;
       end if ;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount) into mResultMoney from msh_subjassvalue where year=aYear and

month = '01' and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403') and unitcode = aUnitCode
           group by unitcode;
       end if ;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount) into mResultMoney from msh_subjassvalue where year=aYear and

month = '01' and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402') and unitcode = aUnitCode
           group by unitcode;
       end if ;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount) into mResultMoney  from msh_subjassvalue where year=aYear and

month = '01' and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405') and unitcode = aUnitCode
           group by unitcode;
        end if ;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount) into mResultMoney from msh_subjassvalue where year=aYear and

month = '01' and subjcode ='1151' and unitcode = aUnitCode
          group by unitcode ;
        end if ;


 else if(aMonth=2) then
     if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/2 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/2 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/2 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02') and subjcode in ('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/2 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/2 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/2 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/2 into mResultMoney  from msh_subjassvalue where year=aYear

and month in ('01','02') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/2 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02') and subjcode ='1151'
          group by unitcode ;
        end if;

 else if(aMonth=3) then
      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/3 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/3 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/3 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03') and subjcode in ('100212080101','100212090101','100212040101')
          group by unitcode;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/3 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/3 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/3 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/3 into mResultMoney  from msh_subjassvalue where year=aYear

and month in ('01','02','03') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/3 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03') and subjcode ='1151'
          group by unitcode ;
        end if;
 else if(aMonth=4) then
      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/4 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/4 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/4 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04') and subjcode in ('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/4 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/4 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/4 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/4 into mResultMoney  from msh_subjassvalue where year=aYear

and month in ('01','02','03','04') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/4 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04') and subjcode ='1151'
          group by unitcode ;
        end if;





 else if(aMonth=5) then
     if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/5 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/5 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/5 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/5 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/5 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/5 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/5 into mResultMoney  from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/5 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05') and subjcode ='1151'
          group by unitcode ;
         end if;


 else if(aMonth=6) then
     if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/6 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/6 into mResultMoney from  msh_subjassvalue where

year=aYear and month in  ('01','02','03','04','05','06') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/6 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/6 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/6 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/6 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/6 into mResultMoney  from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/6 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05','06') and subjcode ='1151'
          group by unitcode ;
        end if;
 else if(aMonth=7) then
     if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/7 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/7 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/7 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/7 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/7 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/7 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/7 into mResultMoney  from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/7 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05','06','07') and subjcode ='1151'
          group by unitcode ;
        end if;
 else if(aMonth=8) then
      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/8 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/8 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/8 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07','08') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/8 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07','08') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/8 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/8 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/8 into mResultMoney  from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/8 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05','06','07','08') and subjcode ='1151'
          group by unitcode ;
        end if;


 else if(aMonth=9) then
      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/9 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09') and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/9 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09') and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/9 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07','08','09') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/9 into mResultMoney from msh_subjassvalue where year=aYear and

month in  ('01','02','03','04','05','06','07','08','09') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/9 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/9 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/9 into mResultMoney  from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/9 into mResultMoney from msh_subjassvalue where year=aYear and

month in ('01','02','03','04','05','06','07','08','09') and subjcode ='1151'
          group by unitcode ;
        end if;

 else if(aMonth=10) then
       if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/10 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09','10') and

subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/10 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09','10') and

subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/10 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09','10') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/10 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09','10') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/10 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/10 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/10 into mResultMoney  from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09','10') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/10 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09') and subjcode ='1151'
          group by unitcode ;
        end if;

 else if(aMonth=11) then
      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/11 into mResultMoney from msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09','10','11') and

subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/11 into mResultMoney from  msh_subjassvalue where

year=aYear and month in ('01','02','03','04','05','06','07','08','09','10','11') and

subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09','10','11') and subjcode in

('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and month in  ('01','02','03','04','05','06','07','08','09','10','11') and subjcode in

('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10','11') and subjcode in

('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10','11') and subjcode in

('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/11 into mResultMoney  from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10','11') and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and month in ('01','02','03','04','05','06','07','08','09','10','11') and subjcode ='1151'
          group by unitcode ;
        end if;
else

      if(aInteCode='2443') then
          --???????-????-????
          select sum(totalcreditamount)/12 into mResultMoney from msh_subjassvalue where

year=aYear  and subjcode='43010401'
          group by unitcode;
      end if;
      if(aInteCode='2444') then
          --???????-????-????
          select sum(totalcreditamount)/11 into mResultMoney from  msh_subjassvalue where

year=aYear  and subjcode='43010402'
          group by unitcode;
      end if;
      if(aInteCode='2445') then
          --???????-????-????-??:??????
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and subjcode in ('100212080101','100212090101','100212040101')
          group by unitcode;
      end if;
      if(aInteCode='2447') then
          --???????-????-??
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and subjcode in ('11011101','11011201','14020101','14020201','14020301','14020401')
          group by unitcode;
       end if;
       if(aInteCode-'2448') then
           --???????-????-????
           select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and subjcode in ('11011103','11011203','14020103','14020203','14020303','14020403')
           group by unitcode;
       end if;
       if(aInteCode='2449') then
           --???????-????-????
           select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and subjcode in ('11011102','11011202','14020102','14020202','14020302','14020402')
           group by unitcode;
       end if;
       if(aInteCode='2451') then
           --???????-????-??????
           select sum(endamount)/11 into mResultMoney  from msh_subjassvalue where year=aYear

and subjcode in

('1101110601','1101120601','1101110602','1101120602','14020104','14020204','14020304','1402040

4','14020105','14020205','14020305','14020405')
           group by unitcode;
        end if;
        if(aInteCode='2452') then
          --???????-????-??????
          select sum(endamount)/11 into mResultMoney from msh_subjassvalue where year=aYear

and subjcode ='1151'
          group by unitcode ;
        end if;
  end if  ;
  */
  return(mResultMoney);
end ;


/

