create FUNCTION DEALBONUS(tagentgrade varchar2,tagentcode varchar2, twageno varchar2) return NUMBER  is
  ---??????
  ctransmoney number(10,2):=0;
  trate number(10,2):=0;
  sumdealbonus number(10,2):=0;
   tdrawrate number(10,2):=0;
  Result number(10,2):=0;

begin

if tagentgrade>='A01' and tagentgrade<='A07' then
---??????
  select T71 into ctransmoney from laindexinfo
  where trim(agentcode)=trim(tagentcode);
---??????
  select rate into trate from laratecommision
  where riskcode=(select riskcode from lacommision
                  where trim(agentcode)=trim(tagentcode)
                  and trim(wageno)=trim(twageno));
   result:=ctransmoney*trate;

else if tagentgrade>='E01' and tagentgrade<='E03' then
  select nvl(sum(T2),0) into sumdealbonus from laindexinfo
  where agentcode=(select agentcode from laagent
                         where agentgroup=(select agentgroup from labranchgroup
                                                 where branchmanager=tagentcode)
                               and agentstate<>'03'
                               and branchtype='2');
---???????????????
  select drawrate into tdrawrate from lawageradix2
  where trim(agentgrade)=trim(tagentgrade)
  and wagecode='WP0002';
  result:=sumdealbonus*tdrawrate;

 end if;
 end if;

  return(Result);
end DEALBONUS;


/

