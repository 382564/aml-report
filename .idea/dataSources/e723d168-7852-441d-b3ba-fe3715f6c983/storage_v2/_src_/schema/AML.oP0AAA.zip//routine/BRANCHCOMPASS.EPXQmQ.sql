create FUNCTION BRANCHCOMPASS (
       tWageNo in varchar2,
       tAgentGroup in varchar2)   --?????
       return number is
  tBranchAttr LABranchGroup.BranchAttr%TYPE;
  tDep number;
  Result number:=0;

  CURSOR cFGroup is
    select AgentGroup from LABranchGroup
    where BranchType='3' and BranchLevel='3' and BranchAttr like trim(tBranchAttr)||'%';

begin
  select BranchAttr into tBranchAttr
   from LABranchGroup
   where trim(AgentGroup) = trim(tAgentGroup);
  for vFGroup in cFGroup loop
    select nvl(sum(TransMoney),0) into tDep
     from LACommision
     where CommDire = '1' and trim(WageNo) = trim(tWageNo) and AgentGroup = vFGroup.AgentGroup;
     Result := Result + tDep;
  end loop;
  return(Result);
end BranchCompass;


/

