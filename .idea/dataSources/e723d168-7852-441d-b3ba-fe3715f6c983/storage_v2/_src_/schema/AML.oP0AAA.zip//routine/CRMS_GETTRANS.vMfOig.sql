create PROCEDURE CRMS_GETTRANS(TSTRATDATE  IN VARCHAR2,
                                            TENDDATE    IN VARCHAR2,
                                            TCUSTOMERNO IN VARCHAR2,
                                            ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Trans D
       WHERE D.TRANSNO IN (SELECT C.ACTUGETNO
                             FROM LCCONT A, LJAGET C
                            WHERE A.CONTTYPE = '1'
                              AND A.APPFLAG <> '0'
                              AND A.contno = C.OTHERNO
                              AND C.APPNTNO = TCUSTOMERNO
                           union
                           SELECT C.ACTUGETNO
                             FROM LCCONT A, LJAGET C, ljagetclaim lj
                            WHERE A.CONTTYPE = '1'
                              AND A.APPFLAG <> '0'
                              AND lj.actugetno = c.actugetno
                              and lj.contno = a.contno
                              AND C.APPNTNO = TCUSTOMERNO

                           UNION
                           SELECT A.EDORACCEPTNO
                             FROM LPEDORITEM A, LCCONT B
                            WHERE A.CONTNO = B.CONTNO
                              AND A.EDORTYPE = 'PC'
                              AND A.GRPCONTNO = '00000000000000000000'
                              AND B.APPNTNO = TCUSTOMERNO
                           union
                           SELECT C.ACTUGETNO
                             FROM LCCONT A, LJAGET C, ljtempfee lj
                            WHERE A.CONTTYPE = '1'
                              AND A.APPFLAG <> '0'
                              AND lj.TEMPFEENO = c.otherno
                              and lj.otherno = a.contno
                              AND C.APPNTNO = TCUSTOMERNO
                           UNION
                           SELECT C.ACTUGETNO
                             FROM LJAGET C, LPEDORITEM LP, LCCONT A
                            WHERE LP.EDORACCEPTNO = C.OTHERNO
                              AND LP.CONTNO = A.CONTNO
                              AND LP.GRPCONTNO = '00000000000000000000'
                              AND C.APPNTNO = TCUSTOMERNO);
      --开始提数
      INSERT INTO MID_CR_Trans
        SELECT C.ACTUGETNO TRANSNO,
               A.CONTNO ContNo,
               '01' ContType,
               '1' TransMethod,
               case c.othernotype
                 when '2' then
                  'BQ'
                 when '4' then
                  'BQ'
                 when '5' then
                  'BQ'
                 when '6' then
                  'BQ'
                 when '7' then
                  'BQ'
                 when '9' then
                  'BQ'
                 else
                  c.othernotype
               END transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               C.PAYMODE PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCCONT A, LJAGET C
         WHERE A.CONTTYPE = '1'
           AND A.APPFLAG <> '0'
           AND A.CONTNO = C.OTHERNO
           and not exists (SELECT 1
                  FROM ljagetclaim lj
                 WHERE c.actugetno = lj.actugetno)
           and not exists
         (select 1 from LJTEMPFEE lj WHERE c.otherno = lj.tempfeeno)
           AND A.APPNTNO = TCUSTOMERNO --有客户号时，只通过客户号查询
        union
        SELECT C.ACTUGETNO TRANSNO,
               A.CONTNO ContNo,
               '01' ContType,
               '1' TransMethod,
               case c.othernotype
                 when '2' then
                  'BQ'
                 when '4' then
                  'BQ'
                 when '5' then
                  'BQ'
                 when '6' then
                  'BQ'
                 when '7' then
                  'BQ'
                 when '9' then
                  'BQ'
                 else
                  c.othernotype
               END transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               C.PAYMODE PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCCONT A, LJAGET C, LJTEMPFEE lj
         WHERE A.CONTTYPE = '1'
           AND A.APPFLAG <> '0'
           AND lj.TEMPFEENO = c.otherno
           and lj.otherno = a.contno
           AND A.APPNTNO = TCUSTOMERNO
           and not exists (SELECT 1
                  FROM ljagetclaim lj
                 WHERE c.actugetno = lj.actugetno)
        UNION

        SELECT C.ACTUGETNO TRANSNO,
               A.CONTNO ContNo,
               '01' ContType,
               (SELECT apptype
                  FROM lpedorapp
                 WHERE edoracceptno = a.edoracceptno) transmethod,
               case a.edortype
                 when 'LN' THEN
                  '07'
                 when 'CT' THEN
                  '05'
                 when 'PD' THEN
                  '08'
                 when 'PT' THEN
                  '09'
                 when 'XT' THEN
                  '13'
                 when 'WT' THEN
                  '11'
                 when 'PC' THEN
                  '14'
                 ELSE
                  'BQ'

               end transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               C.PAYMODE PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          from lpedoritem a, LJAGET c
         where a.edoracceptno = c.otherno
           and a.grpcontno = '00000000000000000000'
           AND C.APPNTNO = TCUSTOMERNO --有客户号时，只通过客户号查询
        UNION

        SELECT a.edoracceptno TRANSNO,
               A.CONTNO ContNo,
               '01' ContType,
               (SELECT apptype
                  FROM lpedorapp
                 WHERE edoracceptno = a.edoracceptno) transmethod,
               '14' transtype,
               a.EDORVALIDATE TRANSDATE,
               'RMB' CURETYPE,
               to_number('0') PAYAMT,
               '' PAYWAY,
               (SELECT PAYFORM
                  FROM lpedorapp
                 WHERE edoracceptno = a.edoracceptno) PayMode,
               B.BANKCODE AccBank,
               B.BANKACCNO AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               B.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          from lpedoritem a, lccont b
         where a.contno = b.contno
           and a.edortype = 'PC'
           AND B.APPNTNO = TCUSTOMERNO
           and b.grpcontno = '00000000000000000000'
        union
        SELECT C.ACTUGETNO TRANSNO,
               A.CONTNO ContNo,
               '01' ContType,
               '1' TransMethod,
               case c.othernotype
                 when '2' then
                  'BQ'
                 when '4' then
                  'BQ'
                 when '5' then
                  'BQ'
                 when '6' then
                  'BQ'
                 when '7' then
                  'BQ'
                 when '9' then
                  'BQ'
                 else
                  c.othernotype
               END transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               C.PAYMODE PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCCONT A, LJAGET C, ljagetclaim lj
         WHERE A.CONTTYPE = '1'
           AND A.APPFLAG <> '0'
           AND lj.actugetno = c.actugetno
           and lj.contno = a.contno
           and not exists
         (select 1 from LJTEMPFEE lj WHERE c.otherno = lj.tempfeeno)
           AND A.APPNTNO = TCUSTOMERNO; --有客户号时，只通过客户号查询

      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Trans D
         WHERE D.TRANSNO IN (SELECT C.ACTUGETNO
                               FROM LCCONT A, LJAGET C
                              WHERE A.CONTTYPE = '1'
                                AND A.APPFLAG <> '0'
                                AND A.contno = C.OTHERNO
                                AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                    TCDATE AND TMDATE
                             union
                             SELECT C.ACTUGETNO
                               FROM LCCONT A, LJAGET C, ljagetclaim lj
                              WHERE A.CONTTYPE = '1'
                                AND A.APPFLAG <> '0'
                                AND lj.actugetno = c.actugetno
                                and lj.contno = a.contno
                                AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                    TCDATE AND TMDATE
                             union
                             SELECT C.ACTUGETNO
                               FROM LCCONT A, LJAGET C, ljtempfee lj
                              WHERE A.CONTTYPE = '1'
                                AND A.APPFLAG <> '0'
                                AND lj.TEMPFEENO = c.otherno
                                and lj.otherno = a.contno
                                AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                    TCDATE AND TMDATE
                             UNION
                             SELECT A.EDORACCEPTNO
                               FROM LPEDORITEM A, LCCONT B
                              WHERE A.CONTNO = B.CONTNO
                                AND A.EDORTYPE = 'PC'
                                AND A.GRPCONTNO = '00000000000000000000'
                                AND A.edorvalidate BETWEEN
                                    TCDATE AND TMDATE
                             UNION
                             SELECT C.ACTUGETNO
                               FROM LJAGET C, LPEDORITEM LP, LCCONT A
                              WHERE LP.EDORACCEPTNO = C.OTHERNO
                                AND LP.CONTNO = A.CONTNO
                                AND LP.GRPCONTNO = '00000000000000000000'
                                AND LP.edorvalidate BETWEEN
                                    TCDATE AND TMDATE); --没有客户号时，通过时间查询
        --开始提数
        INSERT INTO MID_CR_Trans
          SELECT C.ACTUGETNO TRANSNO,
                 A.CONTNO ContNo,
                 '01' ContType,
                 '1' TransMethod,
                 case c.othernotype
                   when '2' then
                    'BQ'
                   when '4' then
                    'BQ'
                   when '5' then
                    'BQ'
                   when '6' then
                    'BQ'
                   when '7' then
                    'BQ'
                   when '9' then
                    'BQ'
                   ELSE
                    c.othernotype
                 END transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 C.PAYMODE PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCCONT A, LJAGET C
           WHERE A.CONTTYPE = '1'
             AND A.APPFLAG <> '0'
             AND A.CONTNO = C.OTHERNO
             and not exists (SELECT 1
                    FROM ljagetclaim lj
                   WHERE c.actugetno = lj.actugetno)
             and not exists
           (select 1 from LJTEMPFEE lj WHERE c.otherno = lj.tempfeeno)
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE

          union
          SELECT C.ACTUGETNO TRANSNO,
                 A.CONTNO ContNo,
                 '01' ContType,
                 '1' TransMethod,
                 case c.othernotype
                   when '2' then
                    'BQ'
                   when '4' then
                    'BQ'
                   when '5' then
                    'BQ'
                   when '6' then
                    'BQ'
                   when '7' then
                    'BQ'
                   when '9' then
                    'BQ'
                   ELSE
                    c.othernotype
                 END transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 C.PAYMODE PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCCONT A, LJAGET C, ljagetclaim lj
           WHERE A.CONTTYPE = '1'
             AND A.APPFLAG <> '0'
             AND lj.actugetno = c.actugetno
             and lj.contno = a.contno
             AND A.CONTNO <> C.OTHERNO
             and not exists
           (select 1 from LJTEMPFEE lj WHERE c.otherno = lj.tempfeeno)
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE
          UNION
          SELECT C.ACTUGETNO TRANSNO,
                 A.CONTNO ContNo,
                 '01' ContType,
                 '1' TransMethod,
                 case c.othernotype
                   when '1' then
                    '1'
                   when '2' then
                    'BQ'
                   when '4' then
                    'BQ'
                   when '5' then
                    'BQ'
                   when '6' then
                    'BQ'
                   when '7' then
                    'BQ'
                   when '9' then
                    'BQ'
                   ELSE
                    c.othernotype
                 END transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 C.PAYMODE PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCCONT A, LJAGET C, LJTEMPFEE lj
           WHERE A.CONTTYPE = '1'
             AND A.APPFLAG <> '0'
             AND lj.TEMPFEENO = c.otherno
             and lj.otherno = a.contno
             AND C.OTHERNO <> A.CONTNO
             and not exists (SELECT 1
                    FROM ljagetclaim lj
                   WHERE c.actugetno = lj.actugetno)
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                 TCDATE AND TMDATE

          UNION
          SELECT C.ACTUGETNO TRANSNO,
                 A.CONTNO ContNo,
                 '01' ContType,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = a.edoracceptno) transmethod,
                 case a.edortype
                   when 'LN' THEN
                    '07'
                   when 'CT' THEN
                    '05'
                   when 'PD' THEN
                    '08'
                   when 'PT' THEN
                    '09'
                   when 'XT' THEN
                    '13'
                   when 'WT' THEN
                    '11'
                   when 'PC' THEN
                    '14'
                   ELSE
                    'BQ'

                 end transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 C.PAYMODE PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            from lpedoritem a, LJAGET c, lccont b
           where a.edoracceptno = c.otherno
             and a.contno = b.contno
             and b.grpcontno = '00000000000000000000'
             AND a.edorvalidate BETWEEN TCDATE AND
                 TMDATE --没有客户号时，通过时间查询
          UNION

          SELECT a.edoracceptno TRANSNO,
                 A.CONTNO ContNo,
                 '01' ContType,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = a.edoracceptno) transmethod,
                 '14' transtype,
                 a.EDORVALIDATE TRANSDATE,
                 'RMB' CURETYPE,
                 to_number('0.0') PAYAMT,
                 '' PAYWAY,
                 (SELECT PAYFORM
                    FROM lpedorapp
                   WHERE edoracceptno = a.edoracceptno) PayMode,
                 B.BANKCODE AccBank,
                 B.BANKACCNO AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 B.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            from lpedoritem a, lccont b
           where a.contno = b.contno
             and a.edortype = 'PC'
             and b.grpcontno = '00000000000000000000'
             AND a.edorvalidate BETWEEN TCDATE AND
                 TMDATE; --没有客户号时，通过时间查询
        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_GETTRANS;


/

