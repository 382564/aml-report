create function CalPresenceSubtract(tAgentCode in varchar2,tAgentGrade in varchar2, tWageCode in varchar2 ,TempBegin  in date,TempEnd in date,tAreaType in varchar2 ) return number is
  tCount1     integer := 0;
  tCount2     integer := 0;
  tCount3     integer := 0;
  tCount4     integer := 0;
  tSubMoney1  number(12,2) := 0;
  tSubMoney2  number(12,2) := 0;
  tSubMoney3  number(12,2) := 0;
  tSubMoney4  number(12,2) := 0;

  tMoney      number(12,2) := 0;
  tTimes      integer := 0;
  tLimit      number(12,2) :=0;

  tFlag       char(2);  --?????????

  Result      number := 0;
----??????-----
begin
  --????: 2006-09-18 LL
  --????:?????????????????????
  select trim(code2) into tFlag from ldcoderela where trim(relatype) = 'agentedition'
    and substr(tAgentCode,1,4)=trim(code1);

--??????
if tFlag = '02' then
  --'01':????'02':????'03':????'04':????
  select nvl(sum(Times),0) into tCount1 from lapresence
  where AClass = '01'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount2 from lapresence
  where AClass = '02'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount3 from lapresence
  where AClass = '03'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount4 from lapresence
  where AClass = '04'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;


  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '01';
  tSubMoney1 := tCount1 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '02';
  tSubMoney2 := tCount2 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '03';
  tSubMoney3 := tCount3 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '04';
  tSubMoney4 := tCount4 * tMoney / tTimes;
else if tFlag = '01' then  --??????
  --'01':????'02':????'03':????'04':????
  select nvl(sum(Times),0) into tCount1 from lapresence
  where AClass = '01'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount2 from lapresence
  where AClass = '02'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount3 from lapresence
  where AClass = '03'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;

  select nvl(sum(Times),0) into tCount4 from lapresence
  where AClass = '04'
        and donedate >= TempBegin
        and donedate <= TempEnd
        and AgentCode = tAgentCode
        ;


  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '05';
  tSubMoney1 := tCount1 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '06';
  tSubMoney2 := tCount2 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '07';
  tSubMoney3 := tCount3 * tMoney / tTimes;

  select param,param1 into tMoney,tTimes from ldparam
  where trim(ParamType) = '08';
  tSubMoney4 := tCount4 * tMoney / tTimes;
end if;
end if;

  Result := nvl(tSubMoney1,0) + nvl(tSubMoney2,0) + nvl(tSubMoney3,0) + nvl(tSubMoney4,0);


  select nvl(fycmax,'99999999') into tLimit from lawageradix where wagecode=tWageCode and trim(areatype)=tAreaType
  and agentgrade=tAgentGrade;
  if (Result>tLimit)then
  result:=tLimit;
  end if;
  return(Result);
end CalPresenceSubtract;


/

