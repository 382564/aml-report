create FUNCTION FNC_299(C_TYPE        CHAR,
                                   C_POLNO       CHAR,
                                   C_GETDUTYCODE CHAR,
                                   N_FEE         NUMBER,
                                   C_CASENO      CHAR) RETURN NUMBER IS
  RESULT NUMBER;
  --  d_limitDate Date;
  -- d_minDate Date;
  --c_planCode CHAR;
  -- c_kind CHAR(1);
  --select FNC_289('FILTER','?PolNo?','?GetDutyCode?',Je_gf,'?CaseNo?') from dual
  N_GETRATE NUMBER;
  N_THIRD   NUMBER;
  N_LEAST   NUMBER;
  N_SUMFEE NUMBER;

  /*c_minGet CHAR;
  c_maxGet CHAR;*/
  C_FEEFLAG CHAR(1);
BEGIN
  RESULT    := 0; --?Result??
  C_FEEFLAG := 'A';

  IF C_GETDUTYCODE = '299120' THEN
    C_FEEFLAG := 'B';
  END IF;

  --????
  SELECT NVL(STANDBYFLAG3,0)
    INTO N_LEAST
    FROM LCDUTY
   WHERE DUTYCODE IN (SELECT DUTYCODE
                        FROM LMDUTYGETRELA
                       WHERE GETDUTYCODE = C_GETDUTYCODE)
     AND POLNO = C_POLNO;

  IF C_TYPE = 'FILTER' THEN
      SELECT NVL(SUM(ADJSUM), 0) INTO N_SUMFEE
          FROM LLCASERECEIPT
         WHERE FEEITEMTYPE = C_FEEFLAG
           AND CLMNO = C_CASENO ;
    IF (N_SUMFEE >= N_LEAST) THEN
      RESULT := 1;
     END IF;

    ELSE

      IF C_FEEFLAG = 'A' THEN
        --- ?? ?????
        SELECT NVL(SUM(ADJSUM), 0)
          INTO N_THIRD
          FROM LLOTHERFACTOR
         WHERE FACTORCODE IN ('B001A', 'B002A')
           AND CLMNO = C_CASENO;
      ELSE
        --- ?? ?????
        SELECT NVL(SUM(ADJSUM), 0)
          INTO N_THIRD
          FROM LLOTHERFACTOR
         WHERE FACTORCODE IN ('B001B', 'B002B')
           AND CLMNO = C_CASENO;
      END IF;
      ---????
      SELECT GETRATE
        INTO N_GETRATE
        FROM LCGET
       WHERE GETDUTYCODE = C_GETDUTYCODE
         AND POLNO = C_POLNO;

      IF N_GETRATE = 0 THEN
        N_GETRATE := 100; --??????
      END IF;

      IF C_GETDUTYCODE = '299122' THEN
        ---?????(????)?????=(?????????-?????????)?????
        ---?????????????
        --????
        SELECT STANDBYFLAG3
          INTO N_LEAST
          FROM LCDUTY
         WHERE DUTYCODE = '299102'
           AND POLNO = C_POLNO;

        SELECT SUM(A)
          INTO RESULT
          FROM (SELECT GREATEST((SUM(ADJSUM) - N_LEAST) * N_GETRATE/100, 0) A
                  FROM LLCASERECEIPT CR
                 WHERE CR.FEEITEMTYPE = 'A'
                   AND CR.CLMNO = C_CASENO
                 GROUP BY MAINFEENO);
      ELSE
        SELECT N_GETRATE * (N_FEE - N_THIRD) / 100 INTO RESULT FROM DUAL;
      END IF;

      IF RESULT < 0 THEN
        RESULT := 0;
      END IF;

    END IF;

    RETURN(RESULT);
  END FNC_299;


/

