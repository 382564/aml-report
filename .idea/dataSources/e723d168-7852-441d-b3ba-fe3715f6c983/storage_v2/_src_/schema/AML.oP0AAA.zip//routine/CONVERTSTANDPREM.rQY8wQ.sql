create function convertStandPrem(cPrem in ljtempfee.PAYMONEY%TYPE ,
         cRiskCode in varchar2,
        cPayIntv in integer,
        cPayYears in integer)
return number is
  rStandPrem    number(12,2);

  tRiskPeriod char(1);

begin
 select riskperiod into tRiskPeriod from lmriskapp where riskcode = cRiskCode;

 if tRiskPeriod = 'L' then
  if cPayYears >= 20 then
   rStandPrem := cPrem * 1;
   return rStandPrem;
  end if;

  if cPayYears = 10 then
   rStandPrem := cPrem * 0.5;
   return rStandPrem;
  end if;

  if cPayYears < 20 and cPayYears != 10 and cPayYears != 1 then
   rStandPrem := cPrem * cPayYears * 0.05;
   return rStandPrem;
  end if;

    if cPayIntv = 0 then
   rStandPrem := cPrem * 0.05;
   return rStandPrem;
  end if;
 end if;

 if cRiskCode = '111601' or cRiskCode = '131602' or cRiskCode = '111302' or cRiskCode = '141802' then
  rStandPrem := cPrem * 0.5 ;
 end if;

 if cRiskCode = '121703' or cRiskCode = '121701' or cRiskCode = '121702' or cRiskCode = '121801' or
    cRiskCode = '111602' or cRiskCode = '111603' or cRiskCode = '141601' or cRiskCode = '141803' or
    cRiskCode = '141804' or cRiskCode = '141805' or cRiskCode = '141806' then
  rStandPrem := cPrem * 0.25;
  return rStandPrem;
 end if;

 return(rStandPrem);
end convertStandPrem;


/

