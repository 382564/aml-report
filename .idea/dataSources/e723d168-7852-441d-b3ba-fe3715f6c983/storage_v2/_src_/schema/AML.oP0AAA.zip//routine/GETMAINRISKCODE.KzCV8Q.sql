create Function getMainRiskCode(v_contno in varchar2) Return varchar2 is
  Result varchar2(30);

  v_flag Number;

begin
  select case when plancode is not null then 1 else 0 end into v_flag from lccont where contno=v_contno;
  if v_flag=0 then
     select count(1)  into v_flag from lccont a where a.salechnl = '05' and contno = v_contno and exists(select contno from lcpol where contno = a.contno and polno=mainpolno  group by contno having count(1) > 1);
         if v_flag = 1 then
           select contplancode into Result from lcinsured where contno = v_contno;
           else
             select riskcode into Result from lcpol where contno = v_contno and polno=mainpolno;
          end if;
  else
    select plancode into Result from lccont where contno=v_contno;
  END IF;
return(Result);
End getMainRiskCode;

/

