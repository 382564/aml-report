create function getFFContNo(p_actugetno   varchar2,
                                       p_otherno     varchar2,
                                       p_othernotype varchar2)
  return varchar2 is
  tempContNo INTEGER;
  Result     varchar2(20);
begin
  select count(1)
    into tempContNo
    from ljagetendorse a
   where a.actugetno = p_actugetno
     and a.otherno = p_otherno
     and a.othernotype = p_othernotype;
  -- 参数从ljaget表中获取
  if tempContNo = 0 then
    -- 暂收费退费
    if p_othernotype = '4' then
      select nvl(lcco.contno, '')
        into Result
        from ljtempfee ljt, lccont lcco
       where ljt.tempfeeno = p_otherno
         and lcco.prtno = ljt.otherno
         and rownum = 1;
      -- 理赔付费
    elsif p_othernotype = '5' then
      select lpc.contno
        into Result
        from ljagetclaim lpc
       where lpc.actugetno = p_actugetno
         and rownum = 1;
      -- 溢缴退费/团险定期结算
    elsif p_othernotype in ('6', 'B') then
      select p_otherno into Result from dual;
      -- 保全付费
      -- 为了满期金/生存金需求改造
    elsif p_othernotype in ('3', '10') then
      select case
               when exists (select lcc.grpcontno
                       from ljagetendorse lja, lcgrpcont lcc
                      where lja.actugetno = p_actugetno
                        and lja.grpcontno = lcc.grpcontno
                        and rownum = 1) then
                (select lcc.grpcontno
                   from ljagetendorse lja, lcgrpcont lcc
                  where lja.actugetno = p_actugetno
                    and lja.grpcontno = lcc.grpcontno
                    and rownum = 1)
               when exists (select lcc.contno
                       from ljagetendorse lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.contno = lcc.contno
                        and rownum = 1) then
                (select lcc.contno
                   from ljagetendorse lja, lccont lcc
                  where lja.actugetno = p_actugetno
                    and lja.contno = lcc.contno
                    and rownum = 1)
               when exists (select lcc.contno
                       from ljagetdraw lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.contno = lcc.contno
                        and rownum = 1) then
                (select lcc.contno
                   from ljagetdraw lja, lccont lcc
                  where lja.actugetno = p_actugetno
                    and lja.contno = lcc.contno
                    and rownum = 1)
               else
                p_otherno
             end
        into Result
        from dual;
      -- 网销手续费支付
    elsif p_othernotype = '12' then
      select p_otherno into Result from dual;
    else
      select p_otherno into Result from dual;
    end if;
  else
    -- 参数直接从ljagetendorse表中获取
    select lcc.contno
      into Result
      from ljagetendorse lja, lccont lcc
     where lja.actugetno = p_actugetno
       and lja.contno = lcc.contno
       and rownum = 1;
  end if;
  return(Result);
end getFFContNo;

/

