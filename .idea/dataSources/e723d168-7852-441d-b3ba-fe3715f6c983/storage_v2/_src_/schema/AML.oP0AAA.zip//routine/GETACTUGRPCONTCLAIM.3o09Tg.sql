create function getActuGrpContClaim(dEvlDateStr in DATE,dEvlDateEnd in DATE,vManComCode in VARCHAR2) return integer is
  Result integer;
  pragma autonomous_transaction;
begin
  DECLARE

  v_row_LLClaimPolicy LLClaimPolicy%rowtype;
  v_row_ActuGrpContClaim ActuGrpContClaim%rowtype;


 tmpCustomerNo char(24);
 tmpCustomerName varchar2(120);
 tmpIDNo char(20);
 tmpAccidentDate date;
 tmpRptDate date;
 tmpClmState char(6);
 tmpAccResult1 char(10);
 tmpAccResult2 char(10);
 v_int_tmp integer;
 v_int_temp2 integer;
 v_count integer :=0;
 v_GetDutyKind varchar2(50);
 v_YearBonus number(16,2);
 v_EndBonus number(16,2);
 v_pay number(16,2);
 v_Amnt number(12,2);--??????
 tmp_count integer:=1;
 fen char(10):='8632'; --fgs

  cursor v_cur_LLClaimPolicy is
  select * from LLClaimPolicy a
  where 1=1
/*    and ((trim(dEvlDateEnd) is null) or (makedate<=dEvlDateEnd))
    and ((trim(dEvlDateStr) is null) or (makedate>=dEvlDateStr))   */
    and (MngCom like vManComCode || '%')
    --
    and exists(select RiskProp from LMRiskApp where riskcode = a.riskcode)
    --and contno='HB410421411000530'
/*    and clmno='90000015534'*/
    and exists (select 1 FROM ActuGrpContData,LLReport
    --zhangxi updated 2006-03-20
    where ActuGrpContData.contno=a.contno and a.clmno=LLReport.rptno
    and LLReport.RptDate>ActuGrpContData.signdate)
    --and contno ='NJ000123141012994'
    ;

  begin

  execute immediate 'TRUNCATE TABLE ActuGrpContClaim';
  --execute immediate 'TRUNCATE TABLE ActuGrpContClaim_log';
  --execute immediate 'delete from  ActuGrpContClaim where fgs = '''||substr(vManComCode,3,2)||''''  ;
  commit;
  execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';
  open v_cur_LLClaimPolicy;
  loop
   fetch v_cur_LLClaimPolicy into v_row_LLClaimPolicy;
   exit when v_cur_LLClaimPolicy%notfound;
   --????,xsl,20060321,00001
   begin
   select salechnl into v_row_ActuGrpContClaim.salechnl from lcpol where polno =v_row_LLClaimPolicy.polno;
   exception when NO_DATA_FOUND THEN NULL;
   END ;
   --???
   begin
   select managecom into fen from lccont where contno =v_row_LLClaimPolicy.contno;
   exception when NO_DATA_FOUND THEN NULL;
   END ;

   if fen is not null and length(trim(fen))>4 then
   v_row_ActuGrpContClaim.fgs := substr(fen, 3, 2);--fgs
   end if;
   --???
   v_count:=v_count+1;
   v_row_ActuGrpContClaim.WatNum:= v_count;

   --???
   v_row_ActuGrpContClaim.ContNo:= v_row_LLClaimPolicy.ContNo;

   --????
    if v_row_LLClaimPolicy.riskcode is not null then
    v_row_ActuGrpContClaim.riskcode:=substr(v_row_LLClaimPolicy.riskcode,3,3);
   end if;

    --???
   if v_row_LLClaimPolicy.ClmNo is not null then
    v_row_ActuGrpContClaim.ClmNo:=v_row_LLClaimPolicy.ClmNo;
   end if;

    --????
       if v_row_LLClaimPolicy.polno<>'000000' then
        select count(1) into v_int_tmp from lcpol where polno=v_row_LLClaimPolicy.polno and polno=mainpolno;
        if v_int_tmp<>0 then
         v_row_ActuGrpContClaim.mainflag:= 1;
         else
         v_row_ActuGrpContClaim.mainflag:= 2;
        end if;
       end if;



  select count(1) into v_int_tmp from llcase where caseno=v_row_LLClaimPolicy.ClmNo  and rownum=1;

     --?????-??????
   if v_int_tmp<>0 then
   if v_row_LLClaimPolicy.ClmNo is not null then
    select nvl(CustomerNo,'000000000') into tmpCustomerNo from llcase where caseno=v_row_LLClaimPolicy.ClmNo  and rownum=1;
    v_row_ActuGrpContClaim.CustomerNo:=tmpCustomerNo;

    --?????
    v_row_ActuGrpContClaim.CustomerName:=trim(tmpCustomerNo);

    --???????
    begin
    select nvl(IDNo,'0000000000') into tmpIDNo from lcinsured where insuredno=tmpCustomerNo and rownum=1;
    v_row_ActuGrpContClaim.IDNo:=tmpIDNo;
     EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
     END;

  --????1,2

    select AccResult1,AccResult2 into tmpAccResult1,tmpAccResult2 from llcase where caseno=v_row_LLClaimPolicy.ClmNo and rownum=1;
    v_row_ActuGrpContClaim.AccResult1:=tmpAccResult1;
    v_row_ActuGrpContClaim.AccResult2:=tmpAccResult2;
   end if;
 end if;
    --?????
   select count(1) into v_int_tmp from LLReport where rptno=v_row_LLClaimPolicy.ClmNo;
   if v_int_tmp<>0 then
    if v_row_LLClaimPolicy.ClmNo is not null then
     select AccidentDate into tmpAccidentDate from LLReport where rptno=v_row_LLClaimPolicy.ClmNo;
     v_row_ActuGrpContClaim.AccidentDate:=tmpAccidentDate;
   end if;

    --???
   if v_row_LLClaimPolicy.ClmNo is not null then
    select RptDate into tmpRptDate from LLReport where rptno=v_row_LLClaimPolicy.ClmNo;
    v_row_ActuGrpContClaim.RptDate:=tmpRptDate;
   end if;
  end if;

   --???
    v_row_ActuGrpContClaim.EndCaseDate:=v_row_LLClaimPolicy.EndCaseDate;

    --????
   if v_row_LLClaimPolicy.ClmNo is not null then
    --select ClmState into tmpClmState from LLClaim where clmno=v_row_LLClaimPolicy.ClmNo;
    if v_row_LLClaimPolicy.EndCaseDate is null then
     v_row_ActuGrpContClaim.ClmState:= '0';
    else
     v_row_ActuGrpContClaim.ClmState:= '1';
   end if;
   end if;



  --??????
  v_YearBonus :=0;
  select nvl(sum(YearBonus),0) into v_YearBonus from  llclaimdetail where clmno=v_row_LLClaimPolicy.ClmNo
  and contno=v_row_LLClaimPolicy.contno
  and riskcode=v_row_LLClaimPolicy.RiskCode
  and getdutykind=v_row_LLClaimPolicy.getdutykind;
   v_row_ActuGrpContClaim.YearBonus :=v_YearBonus;

     --????
    v_pay:=0;
   select nvl(sum(PAY),0) into  v_pay from llbalance where CLMNO=v_row_LLClaimPolicy.ClmNo
   and contno=v_row_LLClaimPolicy.contno
   and riskcode=v_row_LLClaimPolicy.RiskCode
   and getdutykind=v_row_LLClaimPolicy.getdutykind;
    v_row_ActuGrpContClaim.RealPay:=v_pay-v_YearBonus;


  --??????
  v_EndBonus:=0;
  select nvl(sum(EndBonus),0) into v_EndBonus from  llclaimdetail where clmno=v_row_LLClaimPolicy.ClmNo
  and contno=v_row_LLClaimPolicy.contno
  and riskcode=v_row_LLClaimPolicy.RiskCode
  and getdutykind=v_row_LLClaimPolicy.getdutykind  ;
   v_row_ActuGrpContClaim.EndBonus :=v_EndBonus;

   --????

   v_row_ActuGrpContClaim.StandPay :=0;
   --???????
   v_Amnt :=0;
   select nvl(sum(Amnt),0)  into v_Amnt from lcpol where contno=v_row_LLClaimPolicy.ContNo
   and riskcode=v_row_LLClaimPolicy.RiskCode and rownum=1;
   v_row_ActuGrpContClaim.RiakToAmnt :=v_Amnt;

   --?????? 2006-0403 liuzhao
   if v_row_LLClaimPolicy.GetDutyKind is not null then
 /*   select getdutyname into v_GetDutyKind from lmdutygetclm
    where getdutykind = v_row_LLClaimPolicy.GetDutyKind and rownum=1 ;
*/    v_row_ActuGrpContClaim.GetDutyKind:=v_row_LLClaimPolicy.GetDutyKind;
   end if;


    --???
   if v_row_LLClaimPolicy.CaseNo is not null then
    v_row_ActuGrpContClaim.CaseNo:=v_row_LLClaimPolicy.CaseNo;
   end if;

     --?????
   if v_row_LLClaimPolicy.CaseRelaNo is not null then
    v_row_ActuGrpContClaim.CaseRelaNo:=v_row_LLClaimPolicy.CaseRelaNo;
   end if;

     insert into ActuGrpContClaim values v_row_ActuGrpContClaim;

     commit;
   end loop;
  close  v_cur_LLClaimPolicy;

  end;
 return(result);


exception
   when others then
   dbms_output.put_line('????:getActuGrpContClaim' || ' ???????: ' || sqlerrm);
   return('E???????: ' || sqlerrm);
end getActuGrpContClaim;


/

