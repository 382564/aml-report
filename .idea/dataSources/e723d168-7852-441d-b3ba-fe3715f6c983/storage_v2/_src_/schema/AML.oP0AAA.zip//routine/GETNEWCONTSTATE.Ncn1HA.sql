create function getNewContState(V_ContNo in varchar2)
  return varchar2 is

  R_errors varchar2(1000);
  r_1 varchar2(200);
  str varchar2(500);
  cursor c_cal is
    select calcode,calsql,remark
    from MIS_LMCalMode where riskcode = 'Status' order by calcode;
  c_row c_cal%rowtype;
begin
  --循环执行算法并拼接结果
  for c_row in c_cal loop
     r_1:='a';
     str:=c_row.calsql;
     execute immediate str into r_1 using V_ContNo;

     if r_1<>0 then
             R_errors := R_errors||c_row.remark||'/';
     end if;
  end loop;
  --去除最后一个分隔符
  if length(R_errors)>0 then
     R_errors := substr(R_errors, 1, length(R_errors)-1);
  end if;

  return R_errors;
end getNewContState;


/

