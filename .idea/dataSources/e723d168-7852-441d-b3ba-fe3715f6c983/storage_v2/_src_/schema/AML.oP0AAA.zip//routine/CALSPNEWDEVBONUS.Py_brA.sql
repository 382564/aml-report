create FUNCTION calSPNewDevBonus(vAgentCode  IN VARCHAR2,
                                            vAgentGrade IN VARCHAR2,
                                            vIndexCalNo IN VARCHAR2,
                                            vMonths     IN NUMBER,
                                            vPreceptNo  IN VARCHAR2,
                                            vItemCode   IN VARCHAR2) RETURN NUMBER IS
  RESULT NUMBER := 0;
  tSql   VARCHAR2(5000) := '';
BEGIN
  tSql := 'select ''select nvl(max(LABONUSRADIX.RewardMoney),0) as RM from LABONUSRADIX,LABONUSINDEXINFO where LABONUSINDEXINFO.agentcode = ''''' ||
          vAgentCode || ''''' and LABONUSINDEXINFO.indexcalno = ''''' || vIndexCalNo ||
          ''''' and LABONUSRADIX.preceptno = ''''' || vPreceptNo || ''''' and LABONUSRADIX.agentgrade = ''''' ||
          vAgentGrade || ''''' and LABONUSRADIX.itemcode =''''' || vItemCode || ''''' and LABONUSRADIX.StartMonth <= ' ||
          vMonths || ' and LABONUSRADIX.EndMonth >= ' || vMonths ||
          ' '' ||max(SYS_CONNECT_BY_PATH(t.sql1, '' and '')) from (select rownum as rowno,
          ''LABONUSINDEXINFO.'' || b.rcolname || '' >=  LABONUSRADIX.'' || b.icolname as sql1
          from LAIndexToItem a, LABonusIndex b where a.indexcode = b.indexcode ' || ' and a.preceptno = ''' ||
          vPreceptNo || ''' and a.agentgrade = ''' || vAgentGrade || ''' and a.itemcode = ''' || vItemCode ||
          ''') t connect by prior t.rowno = t.rowno - 1  start with t.rowno = 1';
  EXECUTE IMMEDIATE tSql
    INTO tSql;
  EXECUTE IMMEDIATE tSql
    INTO RESULT;
  RESULT := round(RESULT, 2);
  RETURN(RESULT);
END calSPNewDevBonus;


/

