create function getAppAgreedAnnuityAge(P_CONTNO varchar2)
  return varchar2 is
  Result varchar2(20);
  FLAG   CHAR(2);
  SEX    CHAR(2);
begin
  SELECT (SELECT AgreedAnnuityAge
            FROM LCGRPCONT
           WHERE GRPCONTNO =
                 (SELECT GRPCONTNO FROM LCCONT WHERE CONTNO = P_CONTNO))
    INTO FLAG
    FROM DUAL;
  SELECT (SELECT V.INSUREDSEX FROM LCCONT V WHERE CONTNO = P_CONTNO)
    INTO SEX
    FROM DUAL;

  if FLAG = '1' then
    if SEX = '0' then
      SELECT (SELECT MaleRetirementAge
                FROM LCGRPCONT
               WHERE GRPCONTNO =
                     (SELECT GRPCONTNO FROM LCCONT WHERE CONTNO = P_CONTNO))
        into Result
        FROM dual;
    elsif SEX = '1' then
      SELECT (SELECT FemaleRetirementAge
                FROM LCGRPCONT
               WHERE GRPCONTNO =
                     (SELECT GRPCONTNO FROM LCCONT WHERE CONTNO = P_CONTNO))
        into Result
        FROM dual;
    end if;
  elsif FLAG = '2' then
    SELECT (SELECT standbyflag3
              FROM LCDUTY
             where contno = P_CONTNO
               and rownum = 1)
      into Result
      FROM dual;

  end if;
  return(Result);
end getAppAgreedAnnuityAge;


/

