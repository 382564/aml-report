create function GETACCDATE(tEndorNo in VARCHAR, tPolNo in VARCHAR, tContNo in VARCHAR,tType in VARCHAR) return char is
  rAccDate date;
begin
     if tType='1' then
       select max(EnterAccDate) into rAccDate from ljagetendorse where  EndorsementNo =tEndorNo and PolNo =tPolNo  and ContNo=tContNO;
     else
       select max(EnterAccDate) into rAccDate from ljagetendorse where EndorsementNo =tEndorNo and GrpPolNo =tPolNo  and GrpContNo=tContNO;
     end if;
  if rAccDate is null then
    return(' ');
  end if;
  return(rAccDate);
end GETACCDATE;


/

