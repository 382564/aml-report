create function checkDoubleMngGroup(tManageCom in VARCHAR2,tBranchType in VARCHAR2) return integer IS
-------------------??????????????????????????---------------------------
  ADDCOUNT   INTEGER;
begin
  select nvl(sum(count(*)),0) into ADDCOUNT from labranchgroup
  where (endflag is null or endflag<>'Y')   and branchtype=tBranchType and (state is null or state<>'1')
  and managecom like concat(tManageCom,'%')
  and branchmanager is not null
  group by branchmanager,branchlevel having count(*)>1;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkDoubleMngGroup;


/

