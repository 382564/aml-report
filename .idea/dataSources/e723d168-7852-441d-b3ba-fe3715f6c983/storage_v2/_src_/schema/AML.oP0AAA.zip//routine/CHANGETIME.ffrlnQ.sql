create FUNCTION changeTime(
       tDate varchar2 ,
       tTime varchar2       ) return integer as   --???
tResult integer;--?

begin
tResult:=0;

tResult := getStringBySymbol(tTime,':',1)*60+getStringBySymbol(tTime,':',2);
return tResult;
End changeTime;


/

