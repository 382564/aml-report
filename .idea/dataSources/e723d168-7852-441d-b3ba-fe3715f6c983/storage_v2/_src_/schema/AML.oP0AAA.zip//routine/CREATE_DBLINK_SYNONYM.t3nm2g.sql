create procedure create_dblink_synonym(dbLinkName in varchar2) authid current_user  is
 cTbName varchar2(50);
 synonym_ctable varchar2(50);
 v_sql varchar2(1000);
 cursor ctable is select CoreTableCode from pd_tablemap;
 begin
   OPEN ctable;
   loop
   fetch ctable into cTbName;
   EXIT WHEN ctable%NOTFOUND;
        synonym_ctable:= cTbName||'@'||dbLinkName;
        v_sql:= 'create or replace public synonym '||cTbName||' for '||synonym_ctable;
         execute immediate v_sql;
  END LOOP;
 end create_dblink_synonym;


/

