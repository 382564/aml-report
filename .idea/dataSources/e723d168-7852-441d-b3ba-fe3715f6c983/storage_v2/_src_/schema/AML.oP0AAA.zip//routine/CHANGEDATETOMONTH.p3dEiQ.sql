create Function Changedatetomonth(v_Payyears In Integer, v_Payyearsflag In Char) Return Integer Is
	Rs_Payyears Integer;
Begin
	If v_Payyears Is Not Null Then
		If v_Payyearsflag = 'Y' Then
			If v_Payyears = 1000 Then
				Rs_Payyears := 9999;
			Else
				Rs_Payyears := v_Payyears * 12;
			End If;
		End If;
		--??????,????
		If v_Payyearsflag = 'M' Then
			Rs_Payyears := v_Payyears;
		End If;
		--??????,????
		If v_Payyearsflag = 'D' Then
			Rs_Payyears := Round(v_Payyears / 30);
		End If;
		--??????,?????????
		If v_Payyearsflag = 'A' Then
			Rs_Payyears := v_Payyears;
		End If;
	End If;

  Return Rs_Payyears;

Exception
	When others Then
  Dbms_Output.Put_Line('????:ChangeDateToMonth?????');
End Changedatetomonth;


/

