create FUNCTION calSPAttendRate(vAgentCode  IN VARCHAR2,
                                           vAgentGrade IN VARCHAR2,
                                           vIndexCalNo IN VARCHAR2) RETURN NUMBER IS
  RESULT NUMBER;
BEGIN
  SELECT PresenceRate
    INTO RESULT
    FROM LAPresenceRate
   WHERE AgentCode = vAgentCode
     AND IndexCalNo = vIndexCalNo;
  RETURN RESULT;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN 0;
END calSPAttendRate;


/

