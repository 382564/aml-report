create FUNCTION APE(TPREM IN NUMBER, TPAYINTV IN INTEGER)
  RETURN NUMBER IS
  --年缴化保费

  --实际保费       tPrem in number
  --缴费时间间隔   tPayIntv  in integer

  --  -1  不定期缴,  0  趸交, 1  月缴, 3  季缴,6 半年缴一次,12 一年缴一次

  RESULT NUMBER;
BEGIN

  /*  
    if tPayIntv = 0 then
        result:=tPrem;
    elsif tPayIntv = 1 then
        result:=tPrem*0.08;--每年的1/12
    elsif tPayIntv = 3 then
        result:=tPrem*0.25;--每年的3/12
    elsif tPayIntv = 6 then
        result:=tPrem*0.5;--每年的6/12
    elsif tPayIntv = 12 then
        result:=tPrem*1 ;--每年的12/12
    elsif tPayIntv = 36 then
        result:=tPrem*3 ;--每年的12/12
    end if;
  */
  IF TPAYINTV = 0 THEN
    RESULT := TPREM;
  ELSIF TPAYINTV = -1 THEN
    RESULT := TPREM;
  ELSE
    RESULT := TPREM * (TPAYINTV / 12); --每年的X/12
  END IF;
  RETURN(RESULT);
END APE;


/

