create function CalDelMoney(tAgentCode in varchar2, tAgentGrade in varchar2, tReturnType in varchar2, tTempBegin in date, tTempEnd in date,

tAgentGroup in varchar2, tAreaType in varchar2) return number is
  tIndexCalNo    varchar2(10);
  tShouldMoney   number(10,4) := 0;   --K0G09$WJ
  tSumMoney1      number(10,4) := 0;   --K0:s9$WJ
  tK21           number(10,4) := 0;   --2nGZ?[?nJ5?[=p6n
  tK03           number(10,4) := 0;   --2nGZ?[?nS&?[=p6n
  tF25           number(10,4) := 0;   --1>TBS`6n
  tTax           number(10,4) := 0;   --K0
  tTemp          number(10,4) := 0;   --AYJ11dA?
  tSumMoney      number(10,4) := 0;
  tT22           number(10,4) := 0;   --???6
  tT20           number(10,4) := 0;  --???6??
  tShuiHouKou       number(10,4) := 0; --????
  Result         number := 0;
begin
   tIndexCalNo := trim(to_char(tTempBegin,'yyyyMM'));
   select nvl(T14,0)+nvl(T15,0) into tShouldMoney from laindexinfo
     where agentcode = tAgentCode and indexcalno = tIndexCalNo and indexType='01' ;

     --add by jiaqiangli 2008-01-11 ????
     --create index on agentcode donedate
     --modify renhl 2009-03-19 tAgentCode ??rpad
     select nvl(sum(Money),0) into tShuiHouKou from laRewardPunish where agentcode =tAgentCode
     and DoneDate >= tTempBegin and DoneDate <= tTempEnd
     and DoneFlag = '7';

   if tShouldMoney<=0 then
      tF25 := tShouldMoney - tShuiHouKou;
      tSumMoney := 0;
      select nvl(sum(Money),0) into tT22 from laRewardPunish where agentcode = tAgentCode
      and DoneDate >= tTempBegin and DoneDate <= tTempEnd
      and DoneFlag = '6';
      tF25 := tF25-tT22;
   else
      tF25 := 0;
      select nvl(CalPresenceSubtract(tAgentCode,tAgentGrade,'W00038',tTempBegin,tTempEnd,tAreaType),0) into tK03 from ldsysvar where sysvar = 'onerow';
      select nvl(caltax(tAgentCode,'S',tTempBegin,tAgentGroup),0) into tTemp from ldsysvar where sysvar = 'onerow';
      tTax := tTax + tTemp;
      select nvl(caltax(tAgentCode,'I',tTempBegin,tAgentGroup),0) into tTemp from ldsysvar where sysvar = 'onerow';
      tTax := tTax + tTemp;
      tTemp := tShouldMoney - tTax;
      --comment by jiaqiangli tShouldMoney > tTax ????
      if tTemp >= tShuiHouKou then
         tF25 := 0;
         tTemp := tTemp - tShuiHouKou;
      else
         tF25 := tTemp - tShuiHouKou;
         tTemp := tTemp - tShuiHouKou;
      end if;

      select nvl(sum(Money),0) into tT22 from laRewardPunish where agentcode = tAgentCode
      and DoneDate >= tTempBegin and DoneDate <= tTempEnd
      and DoneFlag = '6';

      if tTemp <= 0 then
         tT20 := 0;
         tF25 := tTemp-tT22;
         tTemp := tTemp - tT22;
      else
         if tTemp > tT22 then
           tTemp := tTemp - tT22;
           tT20 := tT22;
         else
           tT20 := tTemp;
           tF25 := tTemp-tT22;
           tTemp := tTemp - tT22;
         end if;
      end if;

      if tTemp>=tK03 then
         tSumMoney := tTemp - tK03;
         tK21 := tK03;
      else
         tSumMoney := 0;
         tK21 := tTemp;
         -- add by jiaqiangli 2008-01-10 tTemp := tTemp - tShuiHouKou;?tTemp??
         if tK21 < 0 then
           tK21 := 0;
         end if;
      end if;
    end if;



  if UPPER(tReturnType)='C' then  --1>TBS`6n
     Result := tF25;
  end if;
  if UPPER(tReturnType)='F' then  --K0:s9$WJ
     Result := tSumMoney;
  end if;
  if UPPER(tReturnType)='D' then  --2nGZ?[?nJ5?[=p6n
     Result := tK21;
  end if;
  if UPPER(tReturnType)='H' then
     Result := tT20;
  end if;

  return(Result);
end CalDelMoney;


/

