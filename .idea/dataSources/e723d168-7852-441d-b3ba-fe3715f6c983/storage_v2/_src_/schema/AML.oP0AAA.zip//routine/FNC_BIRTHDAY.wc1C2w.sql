create FUNCTION fnc_birthday(tContNo in char) return number is
  t_flag          number; --???????????????
  t_count         number; --?????????????????????????
  t_count1        number;
  t_birthday      date;
  t_birthday1     number;
  t_birthday2     number;
  t_birthday3     number;
  t_birthday4     number;
  t_enteraccdate  date;
  t_enteraccdate1 number;
  t_enteraccdate2 number;
  t_sysdate       number;
  t_sysdate1      number;

  CURSOR t_birthdayset is
    select birthday from lcinsured where contno = tContNo;

begin
 t_flag := 0;
 t_count := 0;
 t_count1 := 0;

  --t_flag ???????????????,1?????,0????
   select case
           when exists (select 'X'
                   from lcissuepol
                  where contno = tContNo
                    and BackObjType = '2') then
            0
           else
            1
         end
    into t_flag
    from dual;

  --?????????,???????,????0
  if t_flag = 0 then
    return(0);
  end if;

   For t_birthday in t_birthdayset LOOP

    --??????
    select min(enteraccdate)
      into t_enteraccdate
      from ljtempfee
     where otherno = tContNo;

    --???????????
    select to_char(sysdate, 'MM') into t_sysdate from dual;
    select to_char(t_birthday.birthday - 1, 'MM')
      into t_birthday1
      from dual;
    select to_char(t_birthday.birthday, 'MM') into t_birthday2 from dual;
    select to_char(t_enteraccdate, 'MM') into t_enteraccdate1 from dual;
    --??????????
    select to_char(sysdate, 'DD') into t_sysdate1 from dual;
    select to_char(t_birthday.birthday - 1, 'DD')
      into t_birthday3
      from dual;
    select to_char(t_birthday.birthday, 'DD') into t_birthday4 from dual;
    select to_char(t_enteraccdate, 'DD') into t_enteraccdate2 from dual;

    --t_count ?????????????????????????,1??,0???,????????
    if t_sysdate > t_birthday1 and t_enteraccdate1 < t_birthday2 then
      t_count := 1;
    elsif t_sysdate = t_birthday1 and t_enteraccdate1 < t_birthday2 then
      if t_sysdate1 >= t_birthday3 then
        t_count := 1;
      else
        t_count := 0;
      end if;
    elsif t_sysdate = t_birthday1 and t_enteraccdate1 = t_birthday2 and
          t_enteraccdate2 < t_birthday4 then
      if t_sysdate1 >= t_birthday3 then
        t_count := 1;
      else
        t_count := 0;
      end if;
    elsif t_sysdate > t_birthday1 and t_enteraccdate1 = t_birthday2 then
      if t_enteraccdate2 < t_birthday4 then
        t_count := 1;
      else
        t_count := 0;
      end if;
    elsif t_sysdate = t_birthday1 and t_sysdate1 >= t_birthday3 and
          t_enteraccdate1 = t_birthday2 then
      if t_enteraccdate2 < t_birthday4 then
        t_count := 1;
      else
        t_count := 0;
      end if;
    elsif t_sysdate < t_birthday1 or t_enteraccdate1 > t_birthday2 then
      t_count := 0;
    end if;

    --?????????????
        t_count1 := t_count1 + nvl(t_count,0);
    END LOOP;

  if t_count1 > 0 then
    return(1);
  else
    return(0);
  end if;
end fnc_birthday;


/

