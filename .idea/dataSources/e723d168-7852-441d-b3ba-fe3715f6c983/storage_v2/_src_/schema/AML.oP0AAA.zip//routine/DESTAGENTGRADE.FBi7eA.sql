create function DestAgentGrade(tagentgrade in varchar2) return varchar2 is
----------------????????????-------------------------
  Result varchar2(4);
begin

  if tagentgrade='G131' then
     Result:='G123';
  elsif tagentgrade='G132' then
     Result:='G131';
  elsif tagentgrade='G133' then
     Result:='G132';
  elsif tagentgrade='G141' then
     Result:='G133';
  elsif tagentgrade='G142' then
     Result:='G141';
  elsif tagentgrade='G143' then
     Result:='G142';
  end if;


  return(Result);
end DestAgentGrade;


/

