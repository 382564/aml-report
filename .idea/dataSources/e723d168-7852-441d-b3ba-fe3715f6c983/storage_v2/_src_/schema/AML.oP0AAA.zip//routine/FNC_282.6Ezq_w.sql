create function fnc_282(n_fee number) return number is
  Result number;

begin

  if n_fee>0 and n_fee<=1000 then Result:=n_fee*0.55;
  end if;
  if n_fee>1000 and n_fee<=5000 then Result:=(n_fee-1000)*0.65+1000*0.55;
  end if;
  if n_fee>5000 and n_fee<=10000 then Result:=(n_fee-5000)*0.75+4000*0.65+1000*0.55;
  end if;
  if n_fee>10000 and n_fee<=20000 then Result:=(n_fee-10000)*0.85+5000*0.75+4000*0.65+1000*0.55;
  end if;
  if n_fee>20000 and n_fee<=30000 then Result:=(n_fee-20000)*0.90+10000*0.85+5000*0.75+4000*0.65+1000*0.55;
  end if;
  if n_fee>30000 then Result:=(n_fee-30000)*0.95+10000*0.90+10000*0.85+5000*0.75+4000*0.65+1000*0.55;
  end if;

  return(Result);

end fnc_282;


/

