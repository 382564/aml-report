create function Fnc_275_02(n_fee number) return number is
  Result number;

begin
  Result:=0;
  if     0<n_fee and n_fee<=1000  then select 0 into Result from dual;
  end if;
  if 1000< n_fee and n_fee<=5000  then select (n_fee-1000)*0.6 into Result from dual;
  end if;
  if 5000< n_fee and n_fee<=20000 then select (n_fee-5000)*0.7+4000*0.6 into Result from dual;
  end if;
  if 20000<n_fee and n_fee<=40000 then select (n_fee-20000)*0.8+4000*0.6+15000*0.7 into Result from dual;
  end if;
  if 40000<n_fee then select (n_fee-40000)*0.9+4000*0.6+15000*0.7+20000*0.8 into Result from dual;
  end if;

  return(Result);
end Fnc_275_02;


/

