create FUNCTION FORMATBUFFEREX(a_ManageCom in varchar2) return integer is
  Result integer;
begin
     DECLARE
     v_row_liab liactuarybuffer%rowtype;

     cursor v_cur_liab
     is select * from liactuarybuffer;

     begin
       open v_cur_liab;
       loop
            fetch v_cur_liab into v_row_liab;
            exit when v_cur_liab%NOTFOUND;

            if( length(v_row_liab.contno) <> 12 ) then
                dbms_output.put_line(v_row_liab.peopleno);
            end if;

            v_row_liab.payendyearflag := 'M';

            update liactuarybuffer
            set row = v_row_liab
            where contno = v_row_liab.contno
            and riskcode = v_row_liab.riskcode;

       end loop;
       close v_cur_liab;
       commit;
     end;


  return(Result);
end FORMATBUFFEREX;


/

