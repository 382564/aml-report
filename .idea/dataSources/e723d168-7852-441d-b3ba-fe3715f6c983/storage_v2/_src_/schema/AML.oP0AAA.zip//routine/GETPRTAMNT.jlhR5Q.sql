create function getPrtAmnt(tPrtNo in character,
                                      --  tRiskCode  in varchar2,
                                        tRiskType  in varchar2
                                       -- , tCalType in varchar2
                                        )
  return NUMBER is
  tRiskAmnt    NUMBER;
-- tRiskType = 1 ??????
-- tRiskType = 2 ???????
-- tRiskType = 3 ???????
-- tRiskType = 4 ???????
-- tRiskType = 12 ??????
-- tRiskType = 13 ??????
-- tRiskType = 14 ??????
-- tRiskType = 15 ??????

-- tCalType = 1 ????????
-- tCalType = 2 ????????

  t_sql        LMCalMode.calsql%TYPE;
  --t_cursor      NUMBER;
  t_cursor_sql  NUMBER;
  t_count       NUMBER;
  t_ReceiveFlag LCPol.Riskcode%TYPE;
  t_Amnt        LCPol.Amnt%TYPE;
  t_InsuredNo   LCPol.Insuredno%TYPE;
  t_Riskcode    LCPol.Riskcode%TYPE;
  t_Mult        LCPol.Mult%TYPE;
  t_InsuYear    LCPol.Insuyear%TYPE;
  t_Interval    integer;
  t_temp        NUMBER;
  --???????
  --t_DeadInterval NUMBER;
  --??????????
 -- t_DeadInteMoth  NUMBER;
  t_command       varchar2(200);
  t_DutyCode      NUMBER;
  t_AppAge        NUMBER;
  t_Sex           LCPol.InsuredSex%TYPE;
  t_PayEndYear    LCPol.PayYears%TYPE;
  t_PayIntv       LCPol.PayIntv%TYPE;
 -- t_DeathDate     LDPerson.Deathdate%TYPE;
  t_temp_SumAmnt  NUMBER;
  t_Interval_temp LCPol.Cvalidate%TYPE;
  t_Exflag        number; --??Lmrisksort?
  t_Exlcsflag     number; --??lccontstate?
  t_Exlcflag      number; --??lccont?
  --  t_cvalidate     lcpol.cvalidate%type;
--tongmeng 2009-04-20 modify
--?????????????????.
  CURSOR t_polNoSet IS
  /*  select LCPol.Amnt,
           LCPol.InsuredNo,
           LCPol.Riskcode,
           LCPol.Mult,
           LCPol.Cvalidate,
           LCPol.PayEndYear,
           LCPol.insuyear,
           LCPol.PayIntv,
           LCPol.polno,
           lcpol.appflag,
           LCPol.contno
      from LCPol, lcinsuredrelated
     where LCPol.Polno = lcinsuredrelated.polno
       and lcinsuredrelated.customerno = tInsuredNo
       and LCPol.Appflag in ('0', '1', '2','9')
       and (LCPol.Uwflag <> '1' and LCPol.Uwflag <> '2' and
           LCPol.Uwflag <> 'a')
    union
    select Amnt,
           InsuredNo,
           Riskcode,
           Mult,
           Cvalidate,
           PayEndYear,
           insuyear,
           PayIntv,
           polno,
           appflag,
           contno
      from LCPol
     where InsuredNo = tInsuredNo
       and LCPol.Appflag in ('0', '1', '2','9')
       and (LCPol.Uwflag <> '1' and LCPol.Uwflag <> '2' and
           LCPol.Uwflag <> 'a') and riskcode<>'121301'
    union
    select Amnt,
           InsuredNo,
           Riskcode,
           Mult,
           Cvalidate,
           PayEndYear,
           insuyear,
           PayIntv,
           polno,
           appflag,
           contno
      from LCPol
     where appntno = tInsuredNo
       and riskcode in ('121301')
       and LCPol.Appflag in ('0', '1', '2','9')
       and (LCPol.Uwflag <> '1' and LCPol.Uwflag <> '2' and
           LCPol.Uwflag <> 'a');*/
     select  LCPol.Amnt,
             LCPol.InsuredNo,
             LCPol.Riskcode,
             LCPol.Mult,
             LCPol.Cvalidate,
             LCPol.PayEndYear,
             LCPol.insuyear,
             LCPol.PayIntv,
             LCPol.polno,
             lcpol.appflag,
             LCPol.contno
     from  lcpol
     where prtno=tPrtNo and Uwflag not in ('a','1','2');
  /*
    CURSOR t_CalSQLSet IS
      select calsql, riskcode
        from lmcalmode
       where calcode like 'FX%'
         and riskcode = t_Riskcode;
  */
begin
  --DBMS_OUTPUT.put_line('HEHE');
  tRiskAmnt       := 0;
  --t_count         := 0;
  t_temp_SumAmnt  := 0;
  t_sql           := '';
  t_ReceiveFlag   := 0;
  t_Amnt          := 0;
  --t_InsuredNo     := 0;
  t_Riskcode      := 0;
  t_Mult          := 0;
  t_Interval      := 0;
  t_Interval_temp := '';
  t_DutyCode      := 0;
  t_AppAge        := 0;
  t_Sex           := '0';
  t_PayEndYear    := '0';
  t_PayIntv       := '0';
  t_InsuYear      := 0;
 -- t_DeadInterval  := 0;
  --t_DeadInteMoth  := 0;


  --????????????????,???????????????????????????????
  --t_cursor := DBMS_SQL.OPEN_CURSOR;
  FOR t_polNo IN t_polNoSet LOOP
    t_count         := 0;
    t_temp_SumAmnt  := 0;
    t_ReceiveFlag   := 0;
    t_Amnt          := 0;
    t_InsuredNo     := '';
    --t_Riskcode      := 0;
    t_Mult          := 0;
    t_Interval      := 0;
    t_Interval_temp := '';
    t_command       := '';
    t_InsuYear      := 0;
    t_Exflag        := 0;
    t_Exlcsflag     := 0;
    t_Exlcflag      := 0;
    ---??????
    t_Riskcode := trim(t_polNo.Riskcode);
    --??lmrisksort?
    select count(1)
      into t_Exflag
      from lmrisksort
     where riskcode = t_Riskcode
       and risksorttype = '3'
       and RiskSortValue = tRiskType;

    if t_Exflag = 1 then
      --?????,??
      select floor(Months_between(t_polNo.cvalidate, Birthday) / 12), Sex
        into t_AppAge, t_Sex
        from ldperson
      -- where CustomerNo = tInsuredNo;
      where CustomerNo =t_polNo.insuredno;
      --????
      t_PayEndYear := trim(t_polNo.PayEndYear);
      t_InsuYear   := trim(t_polNo.insuyear);
      t_PayIntv    := trim(t_polNo.PayIntv);
      t_command    := trim(t_polNo.Polno);
      --????
      select dutycode
        into t_DutyCode
        from lcduty
       where polno = t_polNo.polNo
         and rownum = 1;
      --??????
      select case count(1)
               when 1 then
                'Y'
               when 0 then
                'N'
             end
        into t_ReceiveFlag
        from lcget
       where getstartdate <= sysdate
         and livegettype = '0'
         and polNo = t_polNo.polNo;
      ---????
      t_Amnt := trim(t_polNo.Amnt);
      ---?????
     -- t_InsuredNo := trim(t_polNo.InsuredNo);
      ---????
      t_Mult := trim(t_polNo.Mult);
      ---??????
      t_Interval_temp := trim(t_polNo.Cvalidate);
      t_Interval      := trunc(to_number(sysdate - t_Interval_temp) / 365,
                               0);
      t_cursor_sql    := DBMS_SQL.OPEN_CURSOR;

   --  if tCalType = '1' then
      select calsql
        into t_sql
        from lmcalmode
       where calcode like 'FX%'
         and riskcode = t_Riskcode
         and type= tRiskType;
  --   end if;


      t_sql := REPLACE(trim(t_sql), '?DutyCode?', trim(t_DutyCode));
      t_sql := REPLACE(trim(t_sql), '?polno?', trim(t_command));
      t_sql := REPLACE(trim(t_sql), '?PolNo?', trim(t_command));
      t_sql := REPLACE(trim(t_sql), '?InsuYear?', trim(t_InsuYear));
      t_sql := REPLACE(trim(t_sql), '?AppAge?', trim(t_AppAge));
      t_sql := REPLACE(trim(t_sql), '?Sex?', trim(t_Sex));
      t_sql := REPLACE(trim(t_sql), '?PayEndYear?', trim(t_PayEndYear));
      t_sql := REPLACE(trim(t_sql), '?Payintv?', trim(t_PayIntv));

      t_sql := REPLACE(trim(t_sql), '?ReceiveFlag?', trim(t_ReceiveFlag));
      --?SQL??"?Amnt?"?????????
      t_sql := REPLACE(trim(t_sql), '?Amnt?', trim(t_Amnt));
      t_sql := REPLACE(trim(t_sql), '?Get?', trim(t_Amnt));
      --?SQL??"?insuredno?"?????????
   --   t_sql := REPLACE(trim(t_sql), '?InsuredNo?', trim(tInsuredNo));
    t_sql := REPLACE(trim(t_sql), '?InsuredNo?', trim(t_polNo.insuredno));
      --?SQL??"?Riskcode?"?????????
      t_sql := REPLACE(trim(t_sql), '?Riskcode?', trim(t_Riskcode));
      --?SQL??"?Mult?"?????????
      t_sql := REPLACE(trim(t_sql), '?Mult?', trim(t_Mult));
      --?SQL??"?Interval?"?????????
      t_sql := REPLACE(trim(t_sql), '?Interval?', trim(t_Interval));

      DBMS_SQL.PARSE(t_cursor_sql, t_sql, DBMS_SQL.native);
      --???????????t_temp_SumAmnt?
      DBMS_SQL.DEFINE_COLUMN(t_cursor_sql, 1, t_temp_SumAmnt);
      --????SQL??
      t_temp := DBMS_SQL.EXECUTE(t_cursor_sql);

      LOOP
        --?????????? t_temp_SumAmnt,?????
        IF DBMS_SQL.FETCH_ROWS(t_cursor_sql) > 0 THEN
          DBMS_SQL.COLUMN_VALUE(t_cursor_sql, 1, t_temp_SumAmnt);
          --tongmeng 2009-05-12 modify
          --???????
        --  IF t_temp_SumAmnt is not null and t_temp_SumAmnt > 0 THEN
         IF t_temp_SumAmnt is not null THEN
            tRiskAmnt := tRiskAmnt + t_temp_SumAmnt;
          END IF;
        ELSE
          EXIT;
        END IF;
      END LOOP;
      DBMS_SQL.CLOSE_CURSOR(t_cursor_sql);
    end if;
  END LOOP;
  --DBMS_SQL.CLOSE_CURSOR(t_cursor);
  if tRiskAmnt is not null then
    return(tRiskAmnt);
  else
    return(0);
  end if;

end getPrtAmnt;


/

