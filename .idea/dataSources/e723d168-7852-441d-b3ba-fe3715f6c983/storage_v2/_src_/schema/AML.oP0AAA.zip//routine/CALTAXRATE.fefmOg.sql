create function CALTaxRate(tAgentCode  Laagent.Agentcode%TYPE,
                                        tManageCom  Laagent.Managecom%type,
                                        tIndexCalNo in varchar2,
                                        tWage  lawage.shouldmoney%type,
                                        flag in varchar2  --'0' ????????,'1'????
                                        ) return number is
----????????
  tEmployeeType varchar2(4);         ----?????
  tSaleRate      number(10,4) := 0;  --????????
  tValue1        number(10,4) := 0;  --??????
  tExpenseRate   number(10,4) := 0;  --??????
  tReleaseRate   number(10,4) := 0;  --??????
  tReleaseMoney  number(10,2) := 0;  --??????
  tIncomeRate    number(10,4) := 0;  --???????

  tSale          number(10,2) := 0;
  tExpense       number(10,2) := 0;
  tBase          number(10,2) := 0;
  tLeftMoney     number(10,2) := 0;

begin

 tEmployeeType := Judgeemployeetype(tAgentCode,tIndexCalNo);----?????

 --??????
 if (tEmployeeType = 'YT3') then ----?? 2004-03-12??,???YT3??,?????,?????????
     tSaleRate :=0;-----?? 2004-03-15??,????????,????????????
 else
    select TaxRate into tSaleRate from latax
    where (basemax is null or (basemax > tWage and basemin <= tWage))
    and trim(ManageCom) = tManageCom and TaxType = '01' ;
 end if;

    tSale := tWage * tSaleRate;

 --????
 if (tEmployeeType = 'YT3') then -----?? 2004-03-12??,???YT3??,?????,?????????
     tValue1 :=0;-----?? 2004-03-15??,????????,????????????
 else
      select TaxRate,calvalue1 into tExpenseRate,tValue1 from latax
      where trim(ManageCom) = tManageCom and TaxType = '02';
 end if;

  if tValue1 is null or tValue1 = 0 then
    tExpense := (tWage - tSale)*tExpenseRate;
  else
    tExpense := tValue1;
  end if;

tBase := tWage - tExpense - tSale;

 if tEmployeeType<>'YT3' then
   select calrate1,calvalue1,taxrate into tReleaseRate,tReleaseMoney,tIncomeRate
    from latax where basemax>=tBase and basemin<tBase
     and trim(ManageCom) = tManageCom and taxtype = '03' ;
 else
   select calrate1,calvalue1,taxrate into tReleaseRate,tReleaseMoney,tIncomeRate
    from latax where (basemax+calvalue1)>=tBase
     and (basemin+calvalue1)<tBase and trim(ManageCom) = tManageCom and taxtype = '11' ;
 end if;

if nvl(tReleaseRate,0) = 0 then
    tLeftMoney := tBase - nvl(tReleaseMoney,0);
  else
    tLeftMoney := tBase - tBase * nvl(tReleaseRate,0);
  end if;

if flag='0' then
  return(tLeftMoney);
elsif flag='1' then
  return(tIncomeRate);
end if;

end CALTaxRate;


/

