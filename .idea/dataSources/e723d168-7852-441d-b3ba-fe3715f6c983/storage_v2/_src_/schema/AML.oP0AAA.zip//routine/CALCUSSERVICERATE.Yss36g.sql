create function CalCusServiceRate(tAgentOld varchar2,
  tAgentNew varchar2,tTempBegin Date,tTempEnd Date)
   return number  is  Result number(10,2);

   --????????????
   --tTempBegin ????
   --tTempEnd   ????
   --???=????/????
  tShouldMoney number(10,2):=0.00;--????
  tShouldMoney1 number(10,2):=0.00;--??????
  tRealMoney number(10,2):=0.00;--????
  tRealMoney1 number(10,2):=0.00;--????????
  tMainPolNo varchar(30); --?????
  tPolNo varchar(30);--????
  tTBEdorno varchar(20);--??edorno
  tPayToDate Date;--????
  tAscriptionDate Date;--??????
  count4 integer; --???????????
  count1 integer;--??????????
  count3 integer;--???????????????????
  tFXFlag integer;--??????????
  tTBFlag integer;--??????????
  countflag integer;--?????????????
  PayFlag varchar2(6);

  tKuanMoDate Date;--???? tPayToDate + 60
  tAscriptionPlusDate Date;--tAscriptionDate+30
  tShiShouDate Date;--??????lacommision.tmakedate

  --select tTempEnd - 60 into tTJEnd from dual;
  --select tTempBegin - 60 into tTJBegin from dual;
  --????????????????????
  CURSOR tPolNo_Cur IS select a.MainPolNo,a.PolNo,b.PayToDate,a.AscriptionDate,'UnPay'
        from lcpol b,LAAgentAscription a
        where b.contno=a.contno and a.riskcode=b.riskcode
        and a.AgentOld=tAgentOld and a.AgentNew=tAgentNew
        and b.PayIntv= 12 and a.AscriptState in ('00','01')
        and a.mainpolno=a.polno
        and b.paytodate <> b.PayEndDate --???????
        --????????????
        and b.PaytoDate <= (select tTempEnd - 60 from dual)
        and b.PaytoDate >= (select tTempBegin - 60 from dual)
        union
        select distinct a.MainPolNo,a.PolNo,b.lastpaytodate,a.AscriptionDate,'HasPay'
        from lacommision b,LAAgentAscription a
        where b.contno=a.contno and a.riskcode=b.riskcode
        and a.AgentOld=tAgentOld and a.AgentNew=tAgentNew
        and a.mainpolno=a.polno
        and b.agentcode=tAgentNew and b.riskmark='1'
        and b.PayIntv= 12 and a.AscriptState in ('00','01','02')
        --????????????
        and b.LastPayToDate <= (select tTempEnd - 60 from dual)
        and b.LastPayToDate >= (select tTempBegin - 60 from dual);

  begin
  --????????????
   open tPolNo_Cur ;

      fetch tPoLNo_Cur into tMainPolNo ,tPolNo,tPayToDate,tAscriptionDate,PayFlag;
             while tPolNo_Cur%found loop

       -- add by jiaqiangli 2007-09-19
       select (tPayToDate + 60) into tKuanMoDate from dual;
       select (tAscriptionDate + 30) into tAscriptionPlusDate from dual;

       if (tAscriptionDate < tKuanMoDate) then
          if (tAscriptionPlusDate <= tKuanMoDate) then
   if(PayFlag='HasPay') then

    -- haspay tmakedate >= tAscriptionDate (hspay:agentnew && riskmark)

       --???????????
       select nvl(count(*),0) into count4 from lacommision where MainPolNo=tMainPolNo and mainpolno=polno
       and PayIntv=12 and P5='1' and agentcode=tAgentNew and LastPayToDate=tPayToDate;

       --?????????
       --?????????????????????????????????,?????????????
       select decode(count(*),0,0,1) into count1 from lacommision a ,lpedoritem b,ljapay c
       where a.receiptno=c.payno and b.edorno=c.incomeno and c.IncomeType='3' and LastPayToDate=tPayToDate
       and b.edortype='RE' and a.commdire='1' and a.MainPolNo=tMainPolNo ;

        if(count4 = 1) or (count1 = 1) then
           if (count4 = 1) then
              --????????[??????]
              select count(polno) into countflag from lacommision where MainPolNo=tMainPolNo and mainpolno=polno
              and PayIntv=12 and P5='1' and commdire='2' and curpaytodate=tPayToDate;
               if (countflag = 0) then
                  select nvl(sum(prem),0) into tShouldMoney1
                  from lcpol a where MainPolNo=tMainPolNo
                  and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                  union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5');
                  tShouldMoney := tShouldMoney + tShouldMoney1;
               end if;
           elsif (count1 = 1) then
              --??????????,????????,????,?????
              --???
              select nvl(sum(prem),0) into tShouldMoney1
              from lcpol a where MainPolNo=tMainPolNo
              and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
              union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5');

              tShouldMoney := tShouldMoney + tShouldMoney1;
           end if;
       else
         --??????????(?????????)
        select nvl(sum(TransMoney),0) into tShouldMoney1 from lacommision
        where MainPolNo=tMainPolNo
        and LastPayToDate = tPayToDate;
          tShouldMoney:=tShouldMoney+tShouldMoney1;
           --???

       select nvl(sum(TransMoney),0) into tRealMoney1 from lacommision
       where MainPolNo=tMainPolNo
       and tmakedate <= (select tPayToDate + 60 from dual)
       and LastPayToDate = tPayToDate;
       tRealMoney:=tRealMoney+tRealMoney1;
      end if;

   else
      --????????[??????],???????????
      select count(polno) into countflag from lacommision where MainPolNo=tMainPolNo and mainpolno=polno
      and PayIntv=12 and P5='1' and commdire='2' and curpaytodate=tPayToDate;
      if (countflag = 0) then
        --????????????????,??,?????????
        select decode(count(*),0,0,1) into count3 from llclaimpolicy where clmstate='60' and polno=tMainPolNo;
         if(count3 = 1) then
          tShouldMoney := tShouldMoney + 0;
          tRealMoney := tRealMoney + 0;
         else
              select decode(count(*),0,0,1) into tTBFlag From lpedoritem a ,lcpol b where b.polno=tMainPolNo and a.contno=b.contno and edortype in ('CT','XT')
           and edorstate='0';

           -- ???? ???0
           if (tTBFlag = 1) then
           select a.contno into tTBEdorno From lpedoritem a ,lcpol b where b.polno=tMainPolNo and a.contno=b.contno and edortype in ('CT','XT')
               and edorstate='0';
               select nvl(sum(prem),0) into tShouldMoney1
               from lcpol a where contno = tTBEdorno;

               tShouldMoney := tShouldMoney+tShouldMoney1;
           else
           --??????,??????????
           select decode(count(*),0,0,1) into tFXFlag from llclaimpolicy where clmstate='60'
           and polno in (select polno from lcpol where mainpolno=tMainPolNo);

         if tFXFlag = 1 then
           ---?????????????????????????????????????
          select nvl(sum(prem),0) into tShouldMoney1 from lcprem where length(trim(DutyCode))<=6
	                and PolNo in (select a.polno from lcpol a
		              where mainpolno = tMainPolNo and PayToDate = tPayToDate
		              and RnewFlag='-2' and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                  union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5')
		             --????????
		              union
		              select a.polno from lcpol a
		              where mainpolno = tMainPolNo and PayToDate = tPayToDate
		              and appflag in('9') and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                  union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5')
		             --?????????
		              union
		              select a.polno from lcpol a
		              where mainpolno = tMainPolNo and PayToDate = tPayToDate
		              and appflag in( '1','4') and mainpolno<>polno
		              and not exists(select '1' from lcpol where mainpolno=a.mainpolno and appflag in('9'))
		              and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                  union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5'));
          tShouldMoney:=tShouldMoney+tShouldMoney1;
          tRealMoney := tRealMoney + 0;

          else
           --?????,?????
          select nvl(sum(prem),0) into tShouldMoney1 from lcpol  where PolNo in (select a.polno from lcpol a
		               where mainpolno = tMainPolNo and PayToDate = tPayToDate
		               and RnewFlag='-2' and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                   union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5')
		              --????????
		               union
		               select a.polno from lcpol a
		               where mainpolno = tMainPolNo and PayToDate = tPayToDate
			             and appflag in('9') and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                   union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5')
		              --?????????
		               union
		               select a.polno from lcpol a
		               where mainpolno = tMainPolNo and PayToDate = tPayToDate
		               and appflag in ( '1','4') and mainpolno<>polno
		               and not exists(select '1' from lcpol where mainpolno=a.mainpolno and appflag in('9'))
		               and not exists(select 1 from lcrnewstatelog where proposalno=a.polno and state='6'
                   union select 1 from lcrnewstatehistory where a.contno=contno and a.riskcode=riskcode and state='5'));
          tShouldMoney:=tShouldMoney+tShouldMoney1;
          end if;
        end if;
      end if;
      end if;
      end if;
    else

     if (PayFlag='HasPay' ) then
      --??????????????????????30?
      --?????????????
      select nvl(tmakedate,'3099-12-31') into tShiShouDate from lacommision
      where MainPolNo=tMainPolNo and mainpolno=polno and LastPayToDate = tPayToDate and rownum=1;
      --tShiShouDate <= tKuanMoDate ????????????????
      if (tShiShouDate <= tKuanMoDate) then
          --???
          select nvl(sum(TransMoney),0) into tShouldMoney1 from lacommision
          where MainPolNo=tMainPolNo
          and LastPayToDate = tPayToDate;
          tShouldMoney := tShouldMoney+tShouldMoney1;

           --???
          select nvl(sum(TransMoney),0) into tRealMoney1 from lacommision
          where MainPolNo=tMainPolNo
          and LastPayToDate = tPayToDate;
          tRealMoney := tRealMoney+tRealMoney1;
      end if;
     end if;
    end if;
  end if;
  --??????????? ????????

      fetch tPoLNo_Cur into tMainPolNo ,tPolNo,tPayToDate,tAscriptionDate,PayFlag;
     end loop;
    close tPolNo_Cur;

    --?????
    if(tShouldMoney=0.00) then
    Result:= -1;
    else
    Result:=tRealMoney/tShouldMoney;
    end if;
    return(Result);
  end CalCusServiceRate;


/

