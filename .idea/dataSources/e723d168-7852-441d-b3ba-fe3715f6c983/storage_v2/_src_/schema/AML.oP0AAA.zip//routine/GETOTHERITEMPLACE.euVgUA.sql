create FUNCTION getOtherItemPlace(vOtherItemCode IN VARCHAR2) RETURN VARCHAR2 IS
  RESULT VARCHAR2(200);
  tSql   VARCHAR2(1000);
BEGIN
  tSql := 'select  ''0''|| max(SYS_CONNECT_BY_PATH(sql1, ''+'')) from (select rownum as rowno, ITableName ||''.'' || IColName as sql1 from LABonusItem where itemcode in (''' ||
          REPLACE(vOtherItemCode, ';', ''',''') ||
          '''))t connect by prior t.rowno = t.rowno - 1 start with t.rowno = 1';
  EXECUTE IMMEDIATE tSql
    INTO RESULT;
  RETURN(RESULT);
END getOtherItemPlace;


/

