create function Agentstate1(Tagentcode In Varchar2, Twageno In Varchar2) return varchar2 is
  Result varchar2(4);
  	--???? : tAgentcode  ????
	--            tWageno     ????(?:200509)

	Tenddate     Date;
	Tcautiondate Date;
	Toutdate     Date;
  Tenddate1    Date;
  Toutdate1     Date;
begin
  	Select Enddate,startdate Into Tenddate,Tenddate1 From Lastatsegment Where Stattype = '5' And Yearmonth = Twageno;

	Select Cautionerbirthday,Outworkdate,EmployDate Into Tcautiondate,Toutdate,Toutdate1 From Laagent Where Agentcode = Tagentcode;

--	Select Outworkdate Into Toutdate From Laagent Where Agentcode = Tagentcode;


	If (Tenddate < Tcautiondate Or Tcautiondate Is Null) Then
		Result := '';
	End If;

	If Tenddate >= Tcautiondate And (Tenddate < Toutdate Or Toutdate Is Null) Then
		Result := '*';
	End If;

	If Tenddate >= Toutdate Then
		Result := '$';
	End If;
  If (Toutdate1>=Tenddate1+15) And Toutdate1<=Tenddate Then
  Result := '#';
  End If;
  return(Result);
end Agentstate1;


/

