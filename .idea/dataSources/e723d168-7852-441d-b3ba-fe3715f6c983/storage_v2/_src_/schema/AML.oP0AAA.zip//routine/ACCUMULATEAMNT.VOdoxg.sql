create function AccumulateAmnt(pInsuredNo in varchar2,
                                          pDutyCode  in varchar2,
                                          pContNo    in varchar2)
  return number is
  accAmnt number(20, 2) := 0;
begin
  select case
           when trim(pDutyCode) in
                (select distinct associatedcode from RIAccumulateRDCode) then
            (select nvl(sum(b.amnt), 0) A
               from LCPol a, LCDuty b
              where trim(a.polno) = trim(b.polno)
                and trim(b.dutycode) in
                    (select trim(c.AssociatedCode)
                       from RIAccumulateRDCode c
                      where trim(c.AccumulateDefNO) in
                            (select trim(d.AccumulateDefNO)
                               from RIAccumulateRDCode d
                              where d.AssociatedCode = trim(pDutyCode)))
                and a.InsuredNo = pInsuredNo
                and (trim(a.AppFlag) = '1' or
                     (trim(a.AppFlag) <> '1' and a.ContNo = pContNo)))
           else
            0
         end
    into accAmnt
    from ldsysvar
   where sysvar = 'onerow';
  return(accAmnt);
end AccumulateAmnt;


/

