create FUNCTION fnc_275_01(c_cureType char , c_caseNo char,c_contNo char,c_polno char,c_insuredNo char,n_fee number,n_daysInHos number,d_accidentDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
  c_havaPre number;
  c_havaNext number;
  d_minStartDate Date;
begin

Result:=0;                               --?Result??

c_havaPre:=0;

c_havaNext:=0;

                                         --???????
select nvl(min(StartDate),'1900-01-01') into d_minStartDate from LLCaseReceipt where CaseNo=c_caseNo;

                                         --???????????
select nvl(Count(*),0) into c_havaPre from lcpol where riskcode='00275000' and contno=c_contNo and appflag in ('1','4') and insuredno=c_insuredNo and enddate=(select getstartdate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --???????????
select nvl(Count(*),0) into c_havaNext from lcpol where riskcode='00275000' and contno=c_contNo and appflag in ('1','4') and insuredno=c_insuredNo and getstartdate=(select enddate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --??????????,????????????  (?????????,?????????????????)
select d_lcgetEndDate+30 into d_limitDate from dual;

-------------------------------------------------------------------------------------------------------------


if c_cureType<>'A' and d_accidentDate<=d_startDate then     --??????,???????????????

-------------------------------------------------------------------------------------------------------------
--??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate and c_havaNext=0 and d_startDate<d_limitDate then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)
        	select n_fee into Result from Dual;
    else                                 --??????????????
        	select n_fee*(d_limitDate-d_startDate)/n_daysInHos into Result from Dual;
    end if;

  end if ;
-------------------------------------------------------------------------------------------------------------
--??????????????,??????????? --
  if d_lcgetStartDate<=d_startDate and  d_startDate <d_lcgetEndDate and  c_havaNext<>0 then

   if d_endDate<=d_lcgetEndDate then   --???????

        	select n_fee into Result from Dual;

   else                                  --???? ,????????

        	select n_fee*(d_lcgetEndDate-d_startDate)/n_daysInHos into Result from Dual;--?????,?lcgetenddate?????

   end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
  --??????????????,?????????,???????????? ????????--
  if  d_startDate<d_lcgetStartDate and  d_lcgetStartDate<d_endDate and  d_endDate <=d_lcgetEndDate and c_havaPre<>0 then

      	select n_fee*(d_endDate-d_lcgetStartDate)/n_daysInHos into Result from Dual;

  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  return(Result);

end fnc_275_01;


/

