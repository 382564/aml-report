create function chgpaymode248(payintv in varchar2) return varchar2
is
tR varchar2(20);
begin
	if payintv = '0' then
		tR := '1';
	end if;
	if payintv = '1' then
		tR := '0.09';
	end if;
	if payintv = '3' then
		tR := '0.27';
	end if;
	if payintv = '6' then
		tR := '0.52';
	end if;
	if payintv = '12' then
		tR := '1';
	end if;
	return(tR);
end;


/

