create function getStringBySymbol(
tString varchar2,tSymbol varchar2 ,tPos integer)
return  varchar2 is
Result varchar2(1000);


tTempPos integer;
begin
  if(tPos = 1)then
    if(instr(tString,tSymbol)<>0) then
      Result := nvl(substr(tString,0,instr(tString,tSymbol)-1),' ');
    else
      Result := nvl(tString,' ');
    end if;
  else
    if(tPos>1)then
    tTempPos := tPos -1 ;
    end if;

    if(instr(tString,tSymbol)<>0) then
       Result := nvl(getStringBySymbol(nvl(substr(tString,instr(tString,tSymbol)+1),' '),tSymbol,tTempPos),' ');
    else
       Result := ' ';
    end if;
  end if;

return(Result);
end getStringBySymbol;


/

