create FUNCTION DRREARDEPMONLABOR (ACODE in VARCHAR2,AGROUP in VARCHAR2,YEARMONTH in VARCHAR2, FYCSTANDARD in NUMBER,SDATE in DATE,EDATE in DATE) return integer is
-------------------??????????????-------------------------
  ACOUNT         INTEGER;
  ASUM           INTEGER;
  TEMPBEGINDATE  DATE;
  TEMPENDDATE    DATE;
begin
  ACOUNT := 0;
  ASUM   := 0;
  --????????,?????
  TEMPBEGINDATE := SDATE;
  IF TRUNC(SDATE,'MM') = SDATE THEN
    TEMPENDDATE := ADD_MONTHS(SDATE,1)-1;
  ELSE
    TEMPENDDATE := ADD_MONTHS(TRUNC(SDATE,'MM'),1)-1;
  END IF;
  LOOP
    SELECT COUNT(A.AGENTCODE) INTO ACOUNT FROM
    (SELECT AGENTCODE,NVL(SUM(FYC),0) DWSUM FROM LACOMMISION
     WHERE PAYYEAR < 1 and TRIM(BRANCHCODE) IN (SELECT trim(AGENTGROUP) FROM LABRANCHGROUP
                                WHERE TRIM(UPBRANCH) = AGROUP AND ENDFLAG = 'N')
       AND CALDATE >= TEMPBEGINDATE AND CALDATE <= TEMPENDDATE
       GROUP BY AGENTCODE) A
    WHERE A.DWSUM >= FYCSTANDARD;
    ASUM := ASUM + ACOUNT;
    EXIT WHEN TEMPENDDATE=EDATE;
    TEMPBEGINDATE := TEMPENDDATE+1;
    TEMPENDDATE := ADD_MONTHS(TEMPBEGINDATE,1)-1;
  END LOOP;
  --??
  DECLARE
    CAGENT  VARCHAR2(10);
    CGROUP  VARCHAR2(12);
  CURSOR C_REARGROUPFYC IS
    select distinct AgentCode,TRIM(AgentGroup) from Latreeaccessory
     where AgentGrade in ('A06', 'A07') And
        AgentCode not in
           (select AgentCode from LATree where AgentGrade >= 'A08' and AgentCode not in
              (select AgentCode from Latreeb where TRIM(indexcalno) = YEARMONTH and AgentGrade = 'A07')) and
        AgentCode not in (select AgentCode from laagent where agentState in ('03', '04', '05'))
        and TRIM(rearAgentCode) = ACODE ;
  BEGIN
    OPEN C_REARGROUPFYC;
    LOOP
      FETCH C_REARGROUPFYC INTO CAGENT,CGROUP;
      EXIT WHEN C_REARGROUPFYC%NOTFOUND;
      ASUM := ASUM + DRREARDEPMONLABOR(CAGENT,CGROUP,YEARMONTH,FYCSTANDARD,SDATE,EDATE);
    END LOOP;
    CLOSE C_REARGROUPFYC;
  END;
  RETURN ASUM;
end DRREARDEPMONLABOR;


/

