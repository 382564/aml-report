create function         FEENOTOContno(FEENO varchar2)
  return varchar2 is
  rAppntno varchar2(40) default '000000';
begin
  ---LCGet
  select nvl(max(appntno), '000000')
    into rAppntno
    from (
          --一般领取

          --当othernotype=1,otherno直接为客户号appntno.
        --  select l.appntno appntno
          --  from ljaget l
         --  where l.othernotype = '1'
          --   and l.actugetno = FEENO
         -- union all

          --当othernotype=2,otherno为生存领取对应的合同号
          select c.contno appntno
            from ljaget l, lccont c
           where l.othernotype = '2'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all
          select c.grpcontno appntno
            from ljaget l, lcgrpcont c
           where l.othernotype = '2'
             and c.grpcontno = l.otherno
             and c.grpcontno <> '00000000000000000000'
             and l.actugetno = FEENO
          union all
          --当othernotype=4,otherno为暂收退费的印刷号
          select c.contno appntno
            from ljtempfee t, ljaget g, lccont c
           where t.tempfeeno = g.otherno
             and t.othernotype = '4'
             and c.prtno = t.otherno
             and c.grpcontno = '00000000000000000000'
             and g.actugetno = FEENO
          union all
          select c.grpcontno appntno
            from ljtempfee t, ljaget g, lcgrpcont c
           where t.tempfeeno = g.otherno
             and t.othernotype = '4'
             and c.prtno = t.otherno
             and c.grpcontno <> '00000000000000000000'
             and g.actugetno = FEENO
          union all
          ---当othernotype=5,由ljagetclaim和appntno
          select c.contno appntno
            from ljagetclaim l, ljaget a, lccont c
           where a.actugetno = l.actugetno
             and c.contno = l.contno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all
          select distinct  c.grpcontno appntno
            from ljagetclaim l, ljaget a, lccont c
           where a.actugetno = l.actugetno
             and c.contno = l.contno
             and c.grpcontno <> '00000000000000000000'
             and l.actugetno = FEENO
          union all
          ---当othernotype=6,otherno为溢交退费对应的合同号
          select c.contno appntno
            from ljaget l, lccont c
           where l.othernotype = '6'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all
          select c.grpcontno appntno
            from ljaget l, lccont c
           where l.othernotype = '6'
             and c.contno = l.otherno
             and c.grpcontno <> '00000000000000000000'
             and l.actugetno = FEENO
          union all
          ---当othernotype=7,otherno红利给付对应的合同号
          select c.contno appntno
            from ljaget l, lccont c
           where l.othernotype = '7'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all
  select c.grpcontno appntno
            from ljaget l, lccont c
           where l.othernotype = '7'
             and c.contno = l.otherno
             and c.grpcontno <> '00000000000000000000'
             and l.actugetno = FEENO
          union all

          ---当othernotype=9,otherno续期回退对应的合同号
          select c.contno appntno
            from ljaget l, lccont c
           where l.othernotype = '9'
             and c.contno = l.otherno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all

          --当oternotype=10,otherno为保全对应的保全受理号
          select c.contno appntno
            from ljaget l, lpedormain m, lccont c
           where l.othernotype = '10'
             and l.otherno = m.edoracceptno
             and m.contno = c.contno
             and c.grpcontno = '00000000000000000000'
             and l.actugetno = FEENO
          union all
          --实收 1  集体合同号 2  个人合同号 5  理赔赔案号
          select distinct incomeno appntno from ljapay  a where a.payno=FEENO and incometype='1'
  union all
          --实收 1  集体合同号 2  个人合同号 5  理赔赔案号
          select distinct incomeno appntno from ljapay  a where a.payno=FEENO and incometype='2'
  union all
          --实收 1  集体合同号 2  个人合同号 5  理赔赔案号
           select b.contno appntno from ljapay  a,ljagetclaim b  where a.payno=b.actugetno and  incometype='5' and grpcontno ='00000000000000000000' and a.payno=FEENO
             union all
            select b.grpcontno appntno from ljapay  a,ljagetclaim b  where a.payno=b.actugetno and  incometype='5' and grpcontno ='00000000000000000000' and a.payno=FEENO

            union all
          --实收 1  集体合同号 2  个人合同号 5  理赔赔案号 10 保全受理号码
           select b.contno appntno from ljapay  a, lpedoritem b where  incometype='10' and a.otherno=b.edoracceptno and grpcontno='00000000000000000000' and a.payno=FEENO
  union all
          --实收 1  集体合同号 2  个人合同号 5  理赔赔案号 10 保全受理号码
          select b.grpcontno appntno from ljapay  a, lpedoritem b where  incometype='10' and a.otherno=b.edoracceptno and grpcontno<>'00000000000000000000' and a.payno=FEENO
);



  return rAppntno;
end FEENOTOContno;


/

