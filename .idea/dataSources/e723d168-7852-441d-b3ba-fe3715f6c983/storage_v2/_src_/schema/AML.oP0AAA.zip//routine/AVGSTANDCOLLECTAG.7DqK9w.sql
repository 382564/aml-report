create function
AvgStandCollectAg(tAgentGroup in varchar2,
                 tStaticBegin in date,
                 tStaticEnd in date,
                 tStandFYC in number
                 ) return int is

  tRelaAgentCode      varchar2(10);       --?????????????
  tAgentCode      varchar2(10);       --????????
  tStartDate      date;              --????

  tPerReAg       int := 0;   --????????????
  tSumAg         int := 0;   --????????

  tAllSumAg         int := 0;   --???????????

  tBeginMonth VARCHAR2(6);
  tIndexCalNo VARCHAR2(6);
  tIntv Integer;
  tBeginDate Date;
  --?????
  tMonthStaticBegin date;
  tMonthStaticEnd date;
  sCount Integer := 0; -- ?????
  tempIndexCalNo varchar2(8); -- ????????

  --??:???????????????[???+?????] by jiaqiangli 2007-02-26

  --????:
  --??:???????????????????
  CURSOR C_DEALRECALPER IS
   select agentcode,startDate from LARelation where RelaType = '02'
   and RelaLevel = '02' and RelaGens = 1 and RelaAgentCode = tRelaAgentCode
   -- by jiaqiangli 2007-05-18 ???????????
   and startdate >= '2007-01-01'
   -- ???????:6??100% by jiaqiangli 2007-02-08
   and RearFlag = '1' and ReCalFlag = '1';

begin
  select yearmonth into tBeginMonth
    from lastatsegment
    where stattype = '5'
    and startdate <= tStaticBegin and tStaticBegin <= enddate;
    select yearmonth into tIndexCalNo
    from lastatsegment
    where stattype = '5'
    and startdate <= tStaticEnd and tStaticEnd <= enddate;
    -- ?????1?
    tBeginDate := to_Date(substr(tBeginMonth, 0, 4) || '-' ||substr(tBeginMonth, 5, 2) ||'-01','YYYY-MM-DD');
    -- months_between
    select months_between(add_months(to_date((substr(tIndexCalNo, 0, 4) || '-' ||
                                             substr(tIndexCalNo, 5, 2) ||
                                             '-01'),
                                             'YYYY-MM-DD'),1),tBeginDate)
      into tIntv
      from dual;

  --???????[?????????]
  select nvl(branchmanager,'NoData') into tRelaAgentCode from labranchgroup
  where agentgroup = tAgentGroup;
  tempIndexCalNo := tIndexCalNo;
  --??????
  loop
  select startdate,enddate into tMonthStaticBegin,tMonthStaticEnd
  from lastatsegment where stattype = '5' and yearmonth=tempIndexCalNo;
  --??????03-24?
  if (sCount=0)then
     if (tMonthStaticEnd>tStaticEnd) then
          tMonthStaticEnd :=tStaticEnd;
     end if;
  end if;
  --??????01-02?
  if (sCount=tIntv-1)then
     if (tMonthStaticBegin<tStaticBegin) then
          tMonthStaticBegin :=tStaticBegin;
     end if;
  end if;
  --??????????
  select NVL(count(*),0) into tSumAg from ( select a.agentcode from lacommision a where a.branchtype='1' and a.payyear=0
  and a.paycount<=1 and a.tmakedate >= tMonthStaticBegin and a.tmakedate <= tMonthStaticEnd and a.agentgroup2=tAgentGroup
  --????????
  and exists(select 'x' from laagent c,labranchgroup d where c.agentcode=a.agentcode and c.branchcode=d.agentgroup and (d.state <> '1' or d.state is null))
  group by a.agentcode having sum(a.fyc) >= tStandFYC );

  --??StandDepartListAgRe????????????
  --????: ?????????
  OPEN C_DEALRECALPER;
   LOOP
      FETCH C_DEALRECALPER INTO tAgentCode,tStartDate;
      EXIT WHEN C_DEALRECALPER%NOTFOUND;
      --??????????FYC
      tPerReAg := StandDepartListAgRe(tRelaAgentCode,tAgentCode,tStartDate,tMonthStaticBegin,tMonthStaticEnd,tStandFYC);
      --????FYC
      tSumAg := tSumAg + tPerReAg;
   END LOOP;
  CLOSE C_DEALRECALPER;

  tAllSumAg := tAllSumAg+tSumAg;

  sCount := sCount+1;
   -- ????????
  select to_char(add_months(to_date(tIndexCalNo,'YYYYMM'),-1*sCount),'YYYYMM')
  into tempIndexCalNo from dual;

  exit when sCount = tIntv;
  end loop;

  return(tAllSumAg);
end AvgStandCollectAg;


/

