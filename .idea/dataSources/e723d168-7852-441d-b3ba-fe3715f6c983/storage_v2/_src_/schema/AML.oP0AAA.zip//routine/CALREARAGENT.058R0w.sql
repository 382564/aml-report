create function calRearAgent(vAgentCode  in varchar2,
                                        vIndexCalNo in varchar2,
                                        vbranchtype in varchar2)

 return number is
  Result        number := 0;
  FirstPensions number := 0;
  --attend        number := 0;
begin
  --增员奖金=一代增员人当月FYC*增员奖金系数 (一代增员人入司一年内其增员人可领取，即最多发12个月，且只发增员第一代人)

  select nvl(sum(case
                   when FirstPension >= 500 and FirstPension < 1500 then
                    FirstPension * 0.08
                   when FirstPension >= 1500 then
                    FirstPension * 0.12
                   else
                    0
                 end),
             0)
    into FirstPensions
    from LAIndexInfo a
   where branchtype = vbranchtype
     and IndexCalNo = vIndexCalNo
     and indextype = '00'
     and exists
   (select 'Y'
            from LARearRelation r, laagent b
           where b.agentcode = r.AgentCode
             and r.RearLevel = '00'
             and r.RearAgentCode = vAgentCode
             and r.RearFlag = '0'
             and r.rearedgens = '1'
             and r.AgentCode = a.agentcode
             and MONTHS_BETWEEN(to_date(vIndexCalNo, 'yyyymm'),
                                trunc(b.EmployDate, 'mm')) >= 0
             and MONTHS_BETWEEN(to_date(vIndexCalNo, 'yyyymm'),
                                trunc(b.EmployDate, 'mm')) <= 11);

  /*  select case
             when FirstPensions >= 500 and FirstPensions < 1500 then
              0.8
             when FirstPensions >= 1500 then
              0.12
             else
              0
           end
      into attend
      from dual;
  */
  Result := round(FirstPensions, 2);

  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
end;

/

