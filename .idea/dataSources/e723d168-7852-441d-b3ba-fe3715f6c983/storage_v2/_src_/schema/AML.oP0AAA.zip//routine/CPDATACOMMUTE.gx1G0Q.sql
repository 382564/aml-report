create FUNCTION CPDATACOMMUTE(vEdorNo_Par in VARCHAR2,vEdorType_Par in VARCHAR2) return varchar2 is
  pragma autonomous_transaction;
  --??:?C??P??????
  --??:Nicholas
  --?????????
  TN_Body VARCHAR2(2000);
  v_num number;
  T_MK_Name VARCHAR2(2000);
  T_MK_Condition VARCHAR2(2000);
  T_AC_Name VARCHAR2(2000);
  T_AC_String VARCHAR2(2000);
  --tab_num number;
  tab_do_name_c VARCHAR2(10000);
  tab_do_name_d VARCHAR2(10000);
  vEdorNo VARCHAR2(2000);
  vEdorType VARCHAR2(2000);
--gunn varchar2(2000);
  --??C??P???????????
  CURSOR CP_BODY IS
  SELECT distinct a.table_name_body
  FROM (select substr(table_name,3,length(table_name)-2) as table_name_body from user_tables where table_name like 'LC%') a,
       (select substr(table_name,3,length(table_name)-2) as table_name_body from user_tables where table_name like 'LP%' and table_name not in
       ('LPINDUWERROR','LPINDUWMASTER','LPINDUWSUB','LPPENOTICE','LPPENOTICEITEM','LPREMARK','LPRREPORT','LPRREPORTITEM','LPRREPORTRESULT','LPCUWMASTER','LPCUWSUB','LPGCUWMASTER','LPGCUWSUB','LPGUWMASTER','LPGUWSUB','LPUWMASTER','LPUWSUB')
       ) b
  WHERE a.table_name_body=b.table_name_body;

  --??D??P???????????,?????????,????????????????
  CURSOR DP_BODY IS
  SELECT distinct a.table_name_body
  FROM (select substr(table_name,3,length(table_name)-2) as table_name_body from user_tables where table_name like 'LD%') a,
       (select substr(table_name,3,length(table_name)-2) as table_name_body from user_tables where table_name like 'LP%' and table_name not in
       ('LPCOM','LPRREPORT')
       ) b
  WHERE a.table_name_body=b.table_name_body;

  --????????,??????????
  CURSOR T_MAINKEY (t_name VARCHAR2) IS
  SELECT distinct COLUMN_NAME
  FROM user_cons_columns
  WHERE table_name = t_name and CONSTRAINT_NAME like 'PK_%';

  --????????????
  CURSOR T_AC_BQ (t_n VARCHAR2) IS
  SELECT column_name
  FROM user_tab_columns
  WHERE table_name=t_n;

begin
  --/********************************************??CP??******************************************************\
  --tab_num := 0;
  tab_do_name_c := null;
  vEdorNo := trim(vEdorNo_Par);
  vEdorType := trim(vEdorType_Par);
  OPEN CP_BODY;
  LOOP
    FETCH CP_BODY INTO TN_Body;
    EXIT WHEN CP_BODY%NOTFOUND;
    --???
      --??P?????????
      --execute immediate 'select count(*) from LP' || TN_Body || ' where trim(EdorNo)=:1 and trim(EdorType)=:2' into v_num using vEdorNo,vEdorType;
      execute immediate 'select count(*) from LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''' into v_num;
--gunn := 'A';
      if v_num>0 then
        --????????????
        SELECT count(*) into v_num FROM user_tables WHERE table_name='T_TEMP_BQ';
        if v_num>0 then
          execute immediate 'DELETE FROM T_TEMP_BQ';
          execute immediate 'DROP table T_TEMP_BQ';
          --execute immediate 'select 1 from dual';
        end if;
        --?????,??????
--gunn := 'B';
        execute immediate 'CREATE GLOBAL TEMPORARY TABLE T_TEMP_BQ as select * from LP' || TN_Body || ' where rownum=1';
        execute immediate 'INSERT INTO T_TEMP_BQ select * from LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
--gunn := 'C';
        --??P???
        execute immediate 'DELETE FROM LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
        --?????????????
        T_MK_Condition := null;
        OPEN T_MAINKEY('LC' || TN_Body);
        LOOP
          FETCH T_MAINKEY INTO T_MK_Name;
          EXIT WHEN T_MAINKEY%NOTFOUND;
            T_MK_Condition := T_MK_Condition || ' and C.' || T_MK_Name || '=X.' || T_MK_Name;
        END LOOP;
        CLOSE T_MAINKEY;
        --?C???????P?
--gunn := 'D';
        execute immediate 'INSERT INTO LP' || TN_Body ||
                          ' SELECT ''' || vEdorNo || ''',''' || vEdorType || ''',C.*' ||
                          ' FROM LC' || TN_Body || ' C,T_TEMP_BQ X' ||
                          ' WHERE 1=1' || T_MK_Condition;
--gunn := 'E';
        --??C?????
        execute immediate 'DELETE FROM LC' || TN_Body || ' C' ||
                          ' WHERE exists(select ''Z'' from T_TEMP_BQ X where 1=1' || T_MK_Condition || ')';
        --??C?????
        T_AC_String := null;
        OPEN T_AC_BQ('LC' || TN_Body);
        LOOP
          FETCH T_AC_BQ INTO T_AC_Name;
          EXIT WHEN T_AC_BQ%NOTFOUND;
            if T_AC_String is null then
              T_AC_String := T_AC_Name;
            else
              T_AC_String := T_AC_String || ',' || T_AC_Name;
            end if;
        END LOOP;
        CLOSE T_AC_BQ;
--gunn := 'F';
        --????????C?
        execute immediate 'INSERT INTO LC' || TN_Body || '(' || T_AC_String || ') SELECT '
                          || T_AC_String || ' FROM T_TEMP_BQ';
        --????,???????????
        commit;
        --???????
        --tab_num := tab_num + 1;
        --???????,???????????,?????????,??????????
        if tab_do_name_c is null then
          tab_do_name_c := TN_Body;
        else
          tab_do_name_c := tab_do_name_c || ',' || TN_Body;
        end if;
        --?????
        execute immediate 'DROP table T_TEMP_BQ';
      end if;
  END LOOP;
  CLOSE CP_BODY;
  --\************************************************************************************************************/
  --/********************************************??DP??******************************************************\
  --tab_num := 0;
  tab_do_name_d := null;
  OPEN DP_BODY;
  LOOP
    FETCH DP_BODY INTO TN_Body;
    EXIT WHEN DP_BODY%NOTFOUND;
    --???
      --??P?????????
--gunn := 'G';
      --execute immediate 'select count(*) from LP' || TN_Body || ' where trim(EdorNo)=:1 and trim(EdorType)=:2' into v_num using vEdorNo,vEdorType;
      execute immediate 'select count(*) from LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''' into v_num;
      if v_num>0 then
        --????????????
        SELECT count(*) into v_num FROM user_tables WHERE table_name='T_TEMP_BQ';
        if v_num>0 then
          execute immediate 'DELETE FROM T_TEMP_BQ';
          execute immediate 'DROP table T_TEMP_BQ';
        end if;
--gunn := 'H';
        --?????,??????
        --execute immediate 'CREATE GLOBAL TEMPORARY TABLE T_TEMP_BQ as select * from LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || ''' ON COMMIT delete ROWS';
        execute immediate 'CREATE GLOBAL TEMPORARY TABLE T_TEMP_BQ as select * from LP' || TN_Body || ' where rownum=1';
        execute immediate 'INSERT INTO T_TEMP_BQ select * from LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
        --??P???
--gunn := 'I';
        execute immediate 'DELETE FROM LP' || TN_Body || ' where trim(EdorNo)=''' || vEdorNo || ''' and trim(EdorType)=''' || vEdorType || '''';
        --?????????????
        T_MK_Condition := null;
        OPEN T_MAINKEY('LD' || TN_Body);
        LOOP
          FETCH T_MAINKEY INTO T_MK_Name;
          EXIT WHEN T_MAINKEY%NOTFOUND;
            T_MK_Condition := T_MK_Condition || ' and D.' || T_MK_Name || '=X.' || T_MK_Name;
        END LOOP;
        CLOSE T_MAINKEY;
        --?D???????P?
--gunn := 'J';
        execute immediate 'INSERT INTO LP' || TN_Body ||
                          ' SELECT ' || vEdorNo || ',' || vEdorType || ',D.*' ||
                          ' FROM LD' || TN_Body || ' D,T_TEMP_BQ X' ||
                          ' WHERE 1=1' || T_MK_Condition;
        --??D?????
--gunn := 'K';
        execute immediate 'DELETE FROM LD' || TN_Body || ' D' ||
                          ' WHERE exists(select ''Z'' from T_TEMP_BQ X where 1=1' || T_MK_Condition || ')';
        --??D?????
        T_AC_String := null;
        OPEN T_AC_BQ('LD' || TN_Body);
        LOOP
          FETCH T_AC_BQ INTO T_AC_Name;
          EXIT WHEN T_AC_BQ%NOTFOUND;
            if T_AC_String is null then
              T_AC_String := T_AC_Name;
            else
              T_AC_String := T_AC_String || ',' || T_AC_Name;
            end if;
        END LOOP;
        CLOSE T_AC_BQ;
        --????????D?
--gunn := 'L';
        execute immediate 'INSERT INTO LD' || TN_Body || '(' || T_AC_String || ') SELECT '
                          || T_AC_String || ' FROM T_TEMP_BQ';
        --????,???????????
        commit;
        --???????
--gunn := 'M';
        --tab_num := tab_num + 1;
        --???????,???????????,?????????,??????????
        if tab_do_name_d is null then
          tab_do_name_d := TN_Body;
        else
          tab_do_name_d := tab_do_name_d || ',' || TN_Body;
        end if;
        --?????
        execute immediate 'DROP table T_TEMP_BQ';
      end if;
  END LOOP;
  CLOSE DP_BODY;
  --\************************************************************************************************************/
  --????!????:S+?????????
  return('S' || tab_do_name_c || '|' || tab_do_name_d);
exception
  when others then
  --????????
  rollback;
  --????
  --??????
  if T_MAINKEY%isopen=true then
     close T_MAINKEY;
  end if;
  if T_AC_BQ%isopen=true then
     close T_AC_BQ;
  end if;
  if CP_BODY%isopen=true then
     close CP_BODY;
  end if;
  if DP_BODY%isopen=true then
     close DP_BODY;
  end if;
  --?????????
  SELECT count(*) into v_num FROM user_tables WHERE table_name='T_TEMP_BQ';
  if v_num>0 then
    execute immediate 'DELETE FROM T_TEMP_BQ';
    execute immediate 'DROP table T_TEMP_BQ';
  end if;
  --?????????
  dbms_output.put_line('????:CPDATACOMMUTE??????' || ' ???????: ' || sqlerrm);
  --????!????:E+????
  return('E' || tab_do_name_c || '|' || tab_do_name_d);
  --return(gunn || ' aaaa ' || sqlerrm);
  --return(gunn);
end CPDATACOMMUTE;


/

