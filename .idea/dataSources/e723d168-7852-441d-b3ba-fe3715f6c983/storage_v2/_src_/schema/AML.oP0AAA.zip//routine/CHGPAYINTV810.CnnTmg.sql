create function chgpayintv810(payintv in varchar2) return varchar2
is
tR varchar2(20);
begin
 if payintv = '0' then
  tR := '0';
 end if;
 if payintv = '12' then
  tR := '12';
 end if;
 if payintv = '1' then
  tR := '12';
 end if;

 return(tR);
end;


/

