create function getHelaPrem(P_GrpContNo varchar2,
                                       P_RiskCode  varchar2,
                                       P_UWFlag    varchar2)
  return varchar2 is
  Result varchar2(20);
begin
  select case
           when exists (select 1
                   from ldcode
                  where codetype = 'ishelarisk'
                    and code = P_RiskCode
                    and othersign = '2') then
            (select to_char(nvl(sum(prem), 0), 'fm9999999999990.90')
               from lcgrppol
              where grpcontno = P_GrpContNo
                and riskcode = P_RiskCode)
           else
            case
           when P_UWFlag = '1' then
            (select to_char(nvl(sum(prem), 0), 'fm9999999999990.90')
               from lcpol
              where riskcode = P_RiskCode
                and grpcontno = P_GrpContNo
                and appflag <> '2'
                and uwflag <> '1')
           when P_UWFlag = '2' then
            (select to_char(nvl(sum(prem), 0), 'fm9999999999990.90')
               from lcpol
              where riskcode = P_RiskCode
                and grpcontno = P_GrpContNo
                and appflag <> '2'
                and (uwflag = '9' or uwflag = 'z'))
           else
            (select to_char(nvl(sum(prem), 0), 'fm9999999999990.90')
               from lcpol
              where riskcode = P_RiskCode
                and appflag <> '2'
                and grpcontno = P_GrpContNo)
         end end
    into Result
    from dual;
  return(Result);
end getHelaPrem;


/

