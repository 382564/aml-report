create function checkBranchAttr(tManageCom in VARCHAR2,tBranchType in VARCHAR2,tIndexCalNo in VARCHAR2)
return integer is
Result   INTEGER;

tAgentCode laagent.agentcode%type;
tAgentGroup laagent.agentgroup%type;
tBranchCode laagent.branchcode%type;
tBranchAttr labranchgroup.branchattr%type;
tBranchAttr1 labranchgroup.branchattr%type;
tCount integer;
--????????A04?????,?????????,???????
CURSOR tBranchManager_Cur IS
select branchmanager,agentgroup,branchattr from labranchgroup a where branchtype='1'
and branchlevel='01' and upbranchattr='1' and endflag<>'Y' and (state is null or state='0')
and branchmanager is not null and managecom like tManageCom||'%'
and exists (select '1' from latree where agentcode =a.branchmanager and agentgrade >='A06' )
;
begin

  Result := 1;
  open tBranchManager_Cur;
      --????
      fetch tBranchManager_Cur into tAgentCode,tBranchCode,tBranchAttr;
      while tBranchManager_Cur%found loop

      --?????????????????
      select agentgroup into tAgentGroup from laagent where agentcode=tAgentCode;
      select count(*) into tCount from labranchgroup where agentgroup=tAgentGroup;
      if(tCount<=0 or tCount>1 ) then
        return 0;
      end if;

      select branchattr into tBranchAttr1 from labranchgroup where agentgroup=tAgentGroup;

      if(substr(tBranchAttr,0,length(tBranchAttr1))<>tBranchAttr1) then
        --dbms_output.put_line('tAgentCode:'||tAgentCode||'##tBranchAttr:'||tBranchAttr||'##tBranchAttr1:'||tBranchAttr1);
        return 0;
      end if;

      fetch tBranchManager_Cur into tAgentCode,tBranchCode,tBranchAttr;
      end loop;
  close tBranchManager_Cur;

  return(Result);
end checkBranchAttr;


/

