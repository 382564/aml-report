create function fnc_zt627(payendyear in number,interval in number) return varchar2
is
tR number;
begin

  tR := 1;

		if payendyear <= 9 and interval=0 then
			tR := 0.55;
		end if;
		if payendyear = 3 and interval<>0 then
			tR := 0.85;
		end if;
		if payendyear >= 10 and interval=0 then
			tR := 0.35;
		end if;
		if payendyear <> 3 and interval<>0 then
			tR := 0.8;
		end if;
	return(tR);
end;


/

