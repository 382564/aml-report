create procedure cal_chk(startdate   in varchar2,
                                    enddate     in varchar2,
                                    busstype    in varchar2,
                                    calcode_chk in varchar2,
                                    massage     out varchar2) is
  v_sql   varchar2(12000);
  v_code  ldcode1.code%type;
  v_code1 ldcode1.code1%type;

  type t_code1_calsql is record(
    code   ldcode1.code%type,
    code1  ldcode1.code1%type,
    calsql varchar2(12000));
  v_code1_calsql t_code1_calsql;

  type t_lmcalmode_chk is record(
    calcode lmcalmode_chk.calcode%type,
    calsql1 varchar2(12000));

  v_lmcalmode_chk t_lmcalmode_chk;

  type t_sql_cur is ref cursor;
  v_sql_cur t_sql_cur;

begin
  DBMS_OUTPUT.ENABLE(buffer_size => null);
v_sql := 'truncate table temp_LCPOLTRANSACTION';
execute immediate v_sql;

v_sql := 'truncate table temp_LCCONT';
execute immediate v_sql;

v_sql := 'truncate table temp_LCPRODINSURELA';
execute immediate v_sql;

v_sql := 'truncate table temp_LCPRODUCT';
execute immediate v_sql;

v_sql := 'truncate table temp_LCLiability';
execute immediate v_sql;

v_sql := 'truncate table temp_LCBNF';
execute immediate v_sql;

v_sql := 'truncate table temp_LCGrpCont';
execute immediate v_sql;

v_sql := 'truncate table temp_LCGrpProduct';
execute immediate v_sql;

v_sql := 'truncate table temp_LCGrpAppnt';
execute immediate v_sql;

v_sql := 'truncate table temp_LCInsured';
execute immediate v_sql;

v_sql := 'truncate table temp_LCInsureAcc';
execute immediate v_sql;

v_sql := 'truncate table temp_LLClaimPolicy';
execute immediate v_sql;

v_sql := 'truncate table temp_LLBnf';
execute immediate v_sql;

v_sql := 'truncate table temp_LLClaimDetail';
execute immediate v_sql;

v_sql := 'truncate table temp_LLClaimInfo';
execute immediate v_sql;

v_sql := 'truncate table temp_LLClaimantInfo';
execute immediate v_sql;

v_sql := 'truncate table temp_LLReceipt';
execute immediate v_sql;

v_sql := 'truncate table temp_LLCostItem';
execute immediate v_sql;

v_sql := 'truncate table temp_LLMedicalFeeDetail';
execute immediate v_sql;

v_sql := 'truncate table temp_LLDisease';
execute immediate v_sql;

v_sql := 'truncate table temp_LLOperation';
execute immediate v_sql;

v_sql := 'truncate table temp_LASales';
execute immediate v_sql;

v_sql := 'truncate table temp_LAAgent';
execute immediate v_sql;

v_sql := 'truncate table temp_LJTempFee';
execute immediate v_sql;

v_sql := 'truncate table temp_LJDivDistrib';
execute immediate v_sql;

v_sql := 'truncate table temp_LJAGetLivBene';
execute immediate v_sql;

v_sql := 'truncate table temp_LJAPayGrp';
execute immediate v_sql;

v_sql := 'truncate table temp_LJAPay';
execute immediate v_sql;

v_sql := 'truncate table temp_LMProduct';
execute immediate v_sql;

v_sql := 'truncate table temp_LJAGet';
execute immediate v_sql;

v_sql := 'truncate table temp_lallunderwriting';
execute immediate v_sql;

v_sql := 'truncate table temp_LCBlacklist';
execute immediate v_sql;

v_sql := 'truncate table temp_lmliability';
execute immediate v_sql;

 v_sql := 'truncate table temp_lcinsureacctrace';
execute immediate v_sql;

  --存量交易算法获取
  if busstype = 'HIS' then
    open v_sql_cur for

      select calcode, (concat(concat(calsql1, calsql2), calsql3))
        from lmcalmode_pripsx
       where calcode = 'PRIP01'
       order by calcode;

    --增量交易算法获取
  else
    if calcode_chk is not null and  calcode_chk <> 'Y' then
      open v_sql_cur for
        select calcode, (concat(concat(calsql1, calsql2), calsql3))
          from lmcalmode_pripsx
         where calcode <> 'PRIP01'
           and type = 'HH'
           and calcode = calcode_chk
         order by calcode;
    else
      if calcode_chk ='Y' then
        open v_sql_cur for
          select calcode, (concat(concat(calsql1, calsql2), calsql3))
            from lmcalmode_pripsx
           where calcode not in ('PRIP01', 'PRIP02')
             and type = 'HH'
           order by calcode;
      else
        open v_sql_cur for
          select calcode, (concat(concat(calsql1, calsql2), calsql3))
            from lmcalmode_pripsx
           where calcode <> 'PRIP01'
             and type = 'HH'
           order by calcode;
      end if;
    end if;
  end if;

  loop
    fetch v_sql_cur
      into v_lmcalmode_chk;
    exit when v_sql_cur%notfound;

    v_sql := v_lmcalmode_chk.calsql1;
    v_sql := REPLACE(trim(v_sql), '?STARTDATE?', trim(startdate));
    v_sql := REPLACE(trim(v_sql), '?ENDDATE?', trim(enddate));

    DBMS_OUTPUT.put_line('Message: ' || v_lmcalmode_chk.calcode);
    --DBMS_OUTPUT.put_line ('Message: ' || v_sql);

    execute immediate v_sql;

    commit;
  end loop;

  if busstype = 'HIS' then
    open v_sql_cur for
      select b.code, b.code1, (concat(concat(calsql1, calsql2), calsql3))
        from lmcalmode_pripsx a, LDCODEBDDJ b
       where codetype = 'busstype_relation'
         and b.code = '01'
         and b.codename = a.calcode
       order by b.codename;
  else
    if calcode_chk is not null and  calcode_chk <> 'Y'  then
      DBMS_OUTPUT.put_line('Message: ' || substr(calcode_chk, 5));
      open v_sql_cur for
        select b.code, b.code1, (concat(concat(calsql1, calsql2), calsql3))
          from lmcalmode_pripsx a, LDCODEBDDJ b
         where codetype = 'busstype_relation'
           and code = substr(calcode_chk, 5)
           and b.code <> '01'
           and b.codename = a.calcode
           and exists
         (select 1 from temp_lcpoltransaction where busstype = b.code)
         order by b.codename;
    else
      open v_sql_cur for
        select b.code, b.code1, (concat(concat(calsql1, calsql2), calsql3))
          from lmcalmode_pripsx a, LDCODEBDDJ b
         where codetype = 'busstype_relation'
           and b.code <> '01'
           and b.codename = a.calcode
           and exists
         (select 1 from temp_lcpoltransaction where busstype = b.code)
         order by b.codename;
    end if;
  end if;

  loop
    fetch v_sql_cur
      into v_code1_calsql;
    exit when v_sql_cur%notfound;
    v_code  := v_code1_calsql.code;
    v_code1 := v_code1_calsql.code1;
    v_sql   := v_code1_calsql.calsql;
    v_sql   := REPLACE(trim(v_sql), '?busstype?', trim(v_code));
    v_sql   := REPLACE(trim(v_sql), '?STARTDATE?', trim(startdate));
    v_sql   := REPLACE(trim(v_sql), '?ENDDATE?', trim(enddate));
    DBMS_OUTPUT.put_line('Message: ' || v_code1_calsql.code1);
    execute immediate v_sql;
    commit;
  end loop;

  if (v_sql_cur%isopen) then
    close v_sql_cur;
  end if;
exception
  when others then
    massage := SUBSTR(SQLERRM, 1, 200);
    DBMS_OUTPUT.put_line('Message: ' || SQLERRM);
    rollback;
    if (v_sql_cur%isopen) then
      close v_sql_cur;
    end if;
end cal_chk;

/

