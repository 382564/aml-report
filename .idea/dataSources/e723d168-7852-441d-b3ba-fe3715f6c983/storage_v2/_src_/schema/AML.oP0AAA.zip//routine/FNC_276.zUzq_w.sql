create FUNCTION fnc_276(c_caseNo char,c_cureType char ,c_contNo char,c_polno char,c_insuredNo char,n_fee number,n_daysInHos number,d_accidentDate date,d_feeStartDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
  d_minStartDate Date;
  c_havaPre number;
  c_havaNext number;
  c_In3Day number;
  n_fixdaysInHos number;
  d_startDate Date;
begin                                    --???????????

Result:=0;                               --?Result??

c_havaPre:=0;

c_havaNext:=0;

c_In3Day:=0;

n_fixdaysInHos:=n_daysInHos;

d_startDate:=d_feeStartDate;
                                         --????????????
select min(startdate) into d_minStartDate from llcasereceipt where clmno=c_caseNo and feeitemcode like 'CR%';

     --????????????????????????????3?(?),?????
if  d_feeStartDate <= (d_minStartDate+2) and d_endDate<=(d_minStartDate+2) and d_accidentDate<=d_feeStartDate then
   c_In3Day:=1;
end if;

     --???????????????????????3?(?),?????3??,???????????4?
if  d_feeStartDate <= (d_minStartDate+2) and d_endDate>(d_minStartDate+2) and d_accidentDate<=d_feeStartDate then

   d_startDate:=d_minStartDate+3;
   n_fixdaysInHos:=n_fixdaysInHos-(d_minStartDate+3-d_feeStartDate);

end if;

                                         --???????????
select nvl(Count(*),0) into c_havaPre from lcpol where contno=c_contNo and appflag in ('1','4') and insuredno=c_insuredNo and enddate=(select getstartdate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --???????????
select nvl(Count(*),0) into c_havaNext from lcpol where contno=c_contNo and appflag in ('1','4') and insuredno=c_insuredNo and getstartdate=(select enddate from lcpol where polno=c_polno) and amnt=(select amnt from lcpol where polno=c_polno);

                                         --??????????,????????????  (?????????,?????????????????)
select d_lcgetEndDate+30 into d_limitDate from dual;

-------------------------------------------------------------------------------------------------------------


if d_accidentDate<=d_feeStartDate  then     --?????????????

-------------------------------------------------------------------------------------------------------------
--??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate and c_havaNext=0 and d_startDate<d_limitDate then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)

          select n_fixdaysInHos*50 into Result from Dual;
    else                                 --??????????????
        	select (d_limitDate-d_startDate)*50 into Result from Dual;
    end if;

  end if ;
-------------------------------------------------------------------------------------------------------------
--?????????????????????????? --
  if d_lcgetStartDate<=d_startDate and  d_StartDate <d_lcgetEndDate and  c_havaNext<>0   then

    if d_endDate<=d_lcgetEndDate then   --???????

        	select n_fixdaysInHos*50 into Result from Dual;
    else                                --???? ,????????
        	select (d_lcgetEndDate-d_startDate)*50 into Result from Dual;--?????,?lcgetenddate?????
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
  --??????????????,?????????,???????????? ,????????--
  if  d_startDate<d_lcgetStartDate and  d_lcgetStartDate<d_endDate and  d_endDate <=d_lcgetEndDate and c_havaPre<>0  then
      	select (d_endDate-d_lcgetStartDate)*50 into Result from Dual;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------

  if c_In3Day=1 then
     select 0 into Result from Dual;
  end if;

  return(Result);

end fnc_276;


/

