create function getIs_mann(tRiskCode in VARCHAR2) return char is
 vCount integer := 0;
 vFlag  char(1);
begin

  vCount := 0;
  select count(1) into vCount from lfrisk where trim(riskcode) = trim(tRiskCode) and RiskDutyType='4';
  if vCount = 1 then
    vFlag := 'Y';
  ELSE
    vFlag := 'N';
  end if;


  return(vFlag);
end getIs_mann;


/

