create function calSortRate1(begin_Date   varchar2,
                                        insuyear     number,
                                        insuyearflag varchar2)
  return number is
  Result      number;
  count_month number;
begin
  Result := 0;
  if insuyear=1 and insuyearflag = 'Y' then
    Result := 1;
  end if;
  if insuyearflag = 'M' then
    if insuyear = 12 then
      Result := 1;
    elsif insuyear = 11 then
      Result := 0.95;
    elsif insuyear = 10 then
      Result := 0.9;
    elsif insuyear = 9 then
      Result := 0.85;
    elsif insuyear = 8 then
      Result := 0.8;
    elsif insuyear = 7 then
      Result := 0.75;
    elsif insuyear = 6 then
      Result := 0.65;
    elsif insuyear = 5 then
      Result := 0.55;
    elsif insuyear = 4 then
      Result := 0.45;
    elsif insuyear = 3 then
      Result := 0.35;
    elsif insuyear = 2 then
      Result := 0.25;
    elsif insuyear = 1 then
      Result := 0.15;
    end if;
  end if;
  if insuyearflag = 'D' then
    select months_between((to_date(begin_Date, 'YYYY-MM-DD') + insuyear),
                          to_date(begin_Date, 'YYYY-MM-DD'))
      into count_month
      from dual;
    if insuyear = 1 then
      Result := 0.05;
    elsif insuyear >= 2 and insuyear <= 4 then
      Result := 0.06;
    elsif insuyear >= 5 and insuyear <= 7 then
      Result := 0.07;
    elsif insuyear >= 8 and insuyear <= 10 then
      Result := 0.08;
    elsif insuyear >= 11 and insuyear <= 13 then
      Result := 0.09;
    elsif insuyear >= 14 and insuyear <= 16 then
      Result := 0.1;
    elsif insuyear >= 17 and insuyear <= 19 then
      Result := 0.11;
    elsif insuyear >= 20 and insuyear <= 22 then
      Result := 0.12;
    elsif insuyear >= 23 and insuyear <= 25 then
      Result := 0.13;
    elsif insuyear >= 26 and insuyear <= 28 then
      Result := 0.14;
    elsif insuyear >= 29 and insuyear <= 31 then
      Result := 0.15;
    end if;
    if count_month>12 then
      Result := 0;
    elsif count_month > 11 then
      Result := 1;
    elsif count_month > 10 then
      Result := 0.95;
    elsif count_month > 9 then
      Result := 0.9;
    elsif count_month > 8 then
      Result := 0.85;
    elsif count_month > 7 then
      Result := 0.8;
    elsif count_month > 6 then
      Result := 0.75;
    elsif count_month > 5 then
      Result := 0.65;
    elsif count_month > 4 then
      Result := 0.55;
    elsif count_month > 3 then
      Result := 0.45;
    elsif count_month > 2 then
      Result := 0.35;
    elsif count_month > 1 then
      Result := 0.25;
    elsif count_month = 1 then
      Result := 0.15;
    end if;
  end if;

  return(Result);
end calSortRate1;


/

