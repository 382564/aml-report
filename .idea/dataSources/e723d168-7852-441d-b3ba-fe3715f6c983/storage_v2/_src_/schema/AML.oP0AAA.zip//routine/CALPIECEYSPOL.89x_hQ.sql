create FUNCTION CALPIECEYSPol(
       tStartDate date, --????
       tEndDate date,   --????
       tAgentcode Ljtempfee.Agentcode%TYPE
       ) return number is
LongRisk number;
ShortRiskSm number;
tpaymoney number;
v_Piece number;

--?????????
CURSOR cMainPolNo is

select distinct MainPolNo  from LMRiskApp,lcpol
where lcpol.Riskcode=LMRiskApp.Riskcode and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod<>'L'
AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PolNo AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PrtNo AND EnterAccDate IS NOT NULL )
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.ProposalNo AND EnterAccDate IS NOT NULL))
and Lcpol.makedate>=tStartDate and Lcpol.makedate<=tEndDate and Lcpol.Agentcode=tAgentcode
union
select distinct MainPolNo from LMRiskApp,lbpol
where lbpol.Riskcode=LMRiskApp.Riskcode and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod<>'L'
AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = lbpol.polno AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.PrtNo AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.ProposalNo AND EnterAccDate IS NOT NULL))
and Lbpol.makedate>=tStartDate and Lbpol.makedate<=tEndDate and Lbpol.Agentcode=tAgentcode
;

begin
--??????
select nvl(sum(a),0) into LongRisk from
(select nvl(count(distinct(lcpol.polno)),0) a  from LMRiskApp,lcpol
where lcpol.Riskcode=LMRiskApp.Riskcode
and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod='L'
AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PolNo AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.PrtNo AND EnterAccDate IS NOT NULL )
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LCPol.ProposalNo AND EnterAccDate IS NOT NULL))
and Lcpol.makedate>=tStartDate and Lcpol.makedate<=tEndDate
and Lcpol.Agentcode=tAgentcode
union
select nvl(count(distinct(lbpol.polno)),0) a from LMRiskApp,lbpol
where lbpol.Riskcode=LMRiskApp.Riskcode and LMRiskApp.subriskflag='M' and LMRiskApp.Riskperiod='L'
AND (EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = lbpol.polno AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.PrtNo AND EnterAccDate IS NOT NULL)
OR EXISTS (SELECT 1 FROM LJTempFee WHERE OtherNo = LBPol.ProposalNo AND EnterAccDate IS NOT NULL))
and Lbpol.makedate>=tStartDate and Lbpol.makedate<=tEndDate and Lbpol.Agentcode=tAgentcode
) ;

--????(??500?or??500)???
 ShortRiskSm:=0;

 for vMainPolNo in cMainPolNo loop

  select nvl(sum(a),0) into tpaymoney from
  (
  select sum(prem) a from lcpol where mainpolno=vMainPolNo.mainpolno
  union select sum(prem) a from lbpol where mainpolno=vMainPolNo.mainpolno
  );

  if tpaymoney>=500 then
    ShortRiskSm:=ShortRiskSm+1;
   else
    ShortRiskSm:=ShortRiskSm+tpaymoney/500;
   end if;
end loop;




 v_Piece:=LongRisk+ShortRiskSm;

return v_Piece;
end CALPIECEYSPol;


/

