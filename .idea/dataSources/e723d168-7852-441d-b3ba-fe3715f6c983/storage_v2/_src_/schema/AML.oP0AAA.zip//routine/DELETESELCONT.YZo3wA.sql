create function deleteSelCont(moren in varchar2) return int is
  Result int;
    pragma autonomous_transaction;
begin

  declare
  conts integer;
  v_contno char(20);


  cursor v_cursor_selcont is
  select contno from selcont
  ;

  begin


  open v_cursor_selcont;
  loop
  fetch v_cursor_selcont into v_contno;
  exit when v_cursor_selcont%notfound;

  delete from Nclactucontdata1 where contno = v_contno;
  commit;

  end loop;
  close v_cursor_selcont;


  end;


  return(Result);
end deleteSelCont;


/

