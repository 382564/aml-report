create function func_1803_01(s_StandbyFlag2 in varchar2) return varchar2 is
  Result varchar2(100);
  newdt varchar2(100);
  finat varchar2(100);
  finatdd varchar2(100);
  finatddt varchar2(100);
  newd varchar2(100);
  fina varchar2(100);
  aa number ;
begin
     select INSTR(s_StandbyFlag2,',',1,1) into aa from dual ;
     if(aa = 0)
     then
     select columnmark into finatdd from FITableColumnDef where columnid =s_StandbyFlag2 and tableid='FIAboriginalData';
     else
     select substr(s_StandbyFlag2,1,aa-1) into fina from dual ;
     select substr(s_StandbyFlag2,aa+1) into newd from dual;
     select columnmark into finatdd from FITableColumnDef where columnid =fina and tableid='FIAboriginalData';
     while(INSTR(newd,',',1,1)>0) loop
     begin
      select INSTR(newd,',',1,1) into aa from dual ;
      select substr(newd,1,aa-1) into finat from dual ;
      select columnmark into finatddt from FITableColumnDef where columnid =finat and tableid='FIAboriginalData';
      select finatdd ||','||finatddt into finatdd from dual;
      select substr(newd,aa+1) into newd from dual;
     end;
     end loop;
     select columnmark into finatddt from FITableColumnDef where columnid =newd and tableid='FIAboriginalData';
     select finatdd ||','||finatddt into finatdd from dual;
     end if;
  Result:=finatdd;
  return(Result);
end func_1803_01;


/

