create function GETENDORMONEY(tEndorNo in VARCHAR, tPolNo in VARCHAR, tContNo in VARCHAR, tType in VARCHAR) return DECIMAL is
  rGetMoney DECIMAL;
  --tCount INTEGER;
begin
     if tType='1' then
       select sum(GetMoney) into rGetMoney from ljagetendorse where EndorsementNo =tEndorNo and PolNo =tPolNo  and ContNo=tContNO;
     else
        --  set rGetMoney=0;
       select sum(GetMoney) into rGetMoney from ljagetendorse where EndorsementNo =tEndorNo and GrpPolNo =tPolNo  and GrpContNo=tContNO;
     end if;
     if rGetMoney is null then
         rGetMoney :=0.0;
     end if;
  return(rGetMoney);
end GETENDORMONEY;


/

