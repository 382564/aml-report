create PROCEDURE CRMS_CLIENT(TSTRATDATE  IN VARCHAR2,
                                          TENDDATE    IN VARCHAR2,
                                          TCUSTOMERNO IN VARCHAR2,
                                          ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块
BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询s
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数

      DELETE FROM MID_CR_Client A
       WHERE A.CLIENTNO = TCUSTOMERNO
         AND A.CONTTYPE = '01';
      --开始提数
      INSERT INTO MID_CR_Client
        SELECT distinct A.CUSTOMERNO CLIENTNO,
                        A.NAME NAME,
                        A.BIRTHDAY BIRTHDAY,
                        get_Age(A.BIRTHDAY, SYSDATE) AGE,
                        A.SEX SEX,
                        A.IDTYPE CARDTYPE,
                        A.IDNO CARDID,
                        to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                        '01' CLIENTTYPE,
                        C.COMPANYPHONE WorkPhone,
                        C.HOMEPHONE FamilyPhone,
                        C.MOBILE Telephone,
                        A.OCCUPATIONCODE OCCUPATION,
                        '' BusinessType,
                        A.YEARINCOME INCOME,
                        C.GRPNAME GrpName,
                        C.POSTALADDRESS Address,
                        C.ZIPCODE ZipCode,

                        A.NATIVEPLACE NATIONALITY,
                        LC.MANAGECOM ComCode,
                        '01' ContType,
                        '' BusinessLicenseNo, --营业执照号码
                        '' OrgComCode,
                        '' TaxRegistCertNo,
                        '' LegalPerson,
                        '' LegalPersonCardType,
                        '' LegalPersonCardID,
                        '' LinkMan,
                        '' ComRegistArea,
                        '' ComRegistType,
                        '' ComBusinessArea,
                        '' ComBusinessScope,
                        '1' AppntNum,
                        '' ComStaffSize,
                        '' GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        '' HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,

                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDPERSON A, LCADDRESS C, LCCONT LC
         WHERE EXISTS (SELECT 1
                  FROM LCCONT LC
                 WHERE LC.CONTTYPE = '1'
                   AND LC.APPNTNO = A.CUSTOMERNO
                   AND LC.APPFLAG <> '0')
           AND A.CUSTOMERNO = TCUSTOMERNO
           AND A.CUSTOMERNO = C.CUSTOMERNO
           AND A.CUSTOMERNO = LC.APPNTNO
           AND LC.POLAPPLYDATE =
               (SELECT MAX(POLAPPLYDATE)
                  FROM LCCONT
                 WHERE A.CUSTOMERNO = APPNTNO)
           and c.addressno =
               (select max(addressno)
                  from lcaddress
                 where A.CUSTOMERNO = CUSTOMERNO)

        union
        SELECT distinct A.CUSTOMERNO CLIENTNO,
                        A.NAME NAME,
                        A.BIRTHDAY BIRTHDAY,
                        get_Age(A.BIRTHDAY, SYSDATE) AGE,
                        A.SEX SEX,
                        A.IDTYPE CARDTYPE,
                        A.IDNO CARDID,
                        to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                        '01' CLIENTTYPE,
                        C.COMPANYPHONE WorkPhone,
                        C.HOMEPHONE FamilyPhone,
                        C.MOBILE Telephone,
                        A.OCCUPATIONCODE OCCUPATION,
                        '' BusinessType,
                        A.YEARINCOME INCOME,
                        C.GRPNAME GrpName,
                        C.POSTALADDRESS Address,
                        C.ZIPCODE ZipCode,

                        A.NATIVEPLACE NATIONALITY,
                        LC.MANAGECOM ComCode,
                        '01' ContType,
                        '' BusinessLicenseNo, --营业执照号码
                        '' OrgComCode,
                        '' TaxRegistCertNo,
                        '' LegalPerson,
                        '' LegalPersonCardType,
                        '' LegalPersonCardID,
                        '' LinkMan,
                        '' ComRegistArea,
                        '' ComRegistType,
                        '' ComBusinessArea,
                        '' ComBusinessScope,
                        '1' AppntNum,
                        '' ComStaffSize,
                        '' GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        '' HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,

                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDPERSON       A,
               LCADDRESS      C,
               LCCONT         LC,
               lxihtrademain  d,
               lxreportdetail lx
         WHERE EXISTS (SELECT 1
                  FROM LCCONT LC
                 WHERE LC.CONTTYPE = '1'
                   AND LC.APPNTNO = A.CUSTOMERNO
                   AND LC.APPFLAG <> '0')
           AND A.CUSTOMERNO = TCUSTOMERNO
           and d.dealno = lx.dealno
           and d.csnm = A.customerno
           AND A.CUSTOMERNO = C.CUSTOMERNO
           AND A.CUSTOMERNO = LC.APPNTNO
           and c.addressno =
               (select max(addressno)
                  from lcaddress
                 where A.CUSTOMERNO = CUSTOMERNO)

        union
        SELECT distinct A.CUSTOMERNO CLIENTNO,
                        A.NAME NAME,
                        A.BIRTHDAY BIRTHDAY,
                        get_Age(A.BIRTHDAY, SYSDATE) AGE,
                        A.SEX SEX,
                        A.IDTYPE CARDTYPE,
                        A.IDNO CARDID,
                        to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                        '01' CLIENTTYPE,
                        C.COMPANYPHONE WorkPhone,
                        C.HOMEPHONE FamilyPhone,
                        C.MOBILE Telephone,
                        A.OCCUPATIONCODE OCCUPATION,
                        '' BusinessType,
                        A.YEARINCOME INCOME,
                        C.GRPNAME GrpName,
                        C.POSTALADDRESS Address,
                        C.ZIPCODE ZipCode,

                        A.NATIVEPLACE NATIONALITY,
                        LC.MANAGECOM ComCode,
                        '01' ContType,
                        '' BusinessLicenseNo, --营业执照号码
                        '' OrgComCode,
                        '' TaxRegistCertNo,
                        '' LegalPerson,
                        '' LegalPersonCardType,
                        '' LegalPersonCardID,
                        '' LinkMan,
                        '' ComRegistArea,
                        '' ComRegistType,
                        '' ComBusinessArea,
                        '' ComBusinessScope,
                        '1' AppntNum,
                        '' ComStaffSize,
                        '' GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        '' HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,

                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDPERSON       A,
               LCADDRESS      C,
               LCCONT         LC,
               lxistrademain  d,
               lxreportdetail lx
         WHERE EXISTS (SELECT 1
                  FROM LCCONT LC
                 WHERE LC.CONTTYPE = '1'
                   AND LC.APPNTNO = A.CUSTOMERNO
                   AND LC.APPFLAG <> '0')
           AND A.CUSTOMERNO = TCUSTOMERNO
           and d.dealno = lx.dealno
           and d.csnm = A.customerno
           AND A.CUSTOMERNO = C.CUSTOMERNO
           AND A.CUSTOMERNO = LC.APPNTNO
           and c.addressno =
               (select max(addressno)
                  from lcaddress
                 where A.CUSTOMERNO = CUSTOMERNO)

        union

        SELECT distinct A.CUSTOMERNO CLIENTNO,
                        A.NAME NAME,
                        A.BIRTHDAY BIRTHDAY,
                        get_Age(A.BIRTHDAY, SYSDATE) AGE,
                        A.SEX SEX,
                        A.IDTYPE CARDTYPE,
                        A.IDNO CARDID,
                        to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                        '01' CLIENTTYPE,
                        C.COMPANYPHONE WorkPhone,
                        C.HOMEPHONE FamilyPhone,
                        C.MOBILE Telephone,
                        A.OCCUPATIONCODE OCCUPATION,
                        '' BusinessType,
                        A.YEARINCOME INCOME,
                        C.GRPNAME GrpName,
                        C.POSTALADDRESS Address,
                        C.ZIPCODE ZipCode,

                        A.NATIVEPLACE NATIONALITY,
                        LC.MANAGECOM ComCode,
                        '01' ContType,
                        '' BusinessLicenseNo, --营业执照号码
                        '' OrgComCode,
                        '' TaxRegistCertNo,
                        '' LegalPerson,
                        '' LegalPersonCardType,
                        '' LegalPersonCardID,
                        '' LinkMan,
                        '' ComRegistArea,
                        '' ComRegistType,
                        '' ComBusinessArea,
                        '' ComBusinessScope,
                        '1' AppntNum,
                        '' ComStaffSize,
                        '' GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        '' HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,

                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDPERSON A, LCADDRESS C, LCCONT LC, lpedoritem lp
         WHERE EXISTS (SELECT 1
                  FROM LCCONT LC
                 WHERE LC.CONTTYPE = '1'
                   AND LC.APPNTNO = A.CUSTOMERNO
                   AND LC.APPFLAG <> '0')
           AND A.CUSTOMERNO = TCUSTOMERNO
           and lp.contno = lc.contno
           AND A.CUSTOMERNO = C.CUSTOMERNO
           AND A.CUSTOMERNO = LC.APPNTNO
           and c.addressno =
               (select max(addressno)
                  from lcaddress
                 where A.CUSTOMERNO = CUSTOMERNO);

      --有客户号时，只通过客户号查询
      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Client D
         WHERE D.CLIENTNO IN
               (SELECT C.APPNTNO
                  FROM LCAPPNT C
                 WHERE EXISTS (SELECT 1
                          FROM LCCONT A
                         WHERE A.CONTTYPE = '1'
                           AND A.APPNTNO = C.APPNTNO
                           AND A.APPFLAG <> '0'
                           AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                               TCDATE AND TMDATE)
                union
                SELECT b.appntno
                  FROM lpedoritem a, lccont b
                 where a.contno = b.contno
                   and b.CONTTYPE = '1'
                   AND b.APPFLAG <> '0'
                   and a.edorvalidate BETWEEN TCDATE AND TMDATE

                union
                select LC.APPNTNO
                  FROM LDPERSON       A,
                       LCCONT         LC,
                       lxreportdetail lp,
                       lxistrademain  lx
                 WHERE lp.dealno = lx.dealno
                   and lx.csnm = a.customerno
                   AND A.CUSTOMERNO = LC.APPNTNO
                   AND EXISTS
                 (SELECT 1
                          FROM LCCONT C
                         WHERE C.CONTTYPE = '1'
                           AND C.APPNTNO = A.CUSTOMERNO
                           AND C.APPFLAG <> '0'
                           AND lx.dealdate BETWEEN TCDATE AND TMDATE)

                );
        --开始提数
        INSERT INTO MID_CR_Client
          SELECT distinct A.CUSTOMERNO CLIENTNO,
                          A.NAME NAME,
                          A.BIRTHDAY BIRTHDAY,
                          get_Age(A.BIRTHDAY, SYSDATE) AGE, --TODO 投保人生日计算？？
                          A.SEX SEX,
                          A.IDTYPE CARDTYPE,
                          A.IDNO CARDID,
                          --A.IDEXPDATE CardExpireDate,
                          --A.IDEXPDATE CardExpireDate,
                          to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                          '01' CLIENTTYPE,
                          C.COMPANYPHONE WorkPhone,
                          C.HOMEPHONE FamilyPhone,
                          C.MOBILE Telephone,
                          A.OCCUPATIONCODE OCCUPATION,
                          '' BusinessType,
                          A.YEARINCOME INCOME,
                          C.GRPNAME GrpName,
                          C.POSTALADDRESS Address,
                          C.ZIPCODE ZipCode,

                          A.NATIVEPLACE NATIONALITY,
                          LC.MANAGECOM ComCode,
                          '01' ContType,
                          '' BusinessLicenseNo, --营业执照号码
                          '' OrgComCode,
                          '' TaxRegistCertNo,
                          '' LegalPerson,
                          '' LegalPersonCardType,
                          '' LegalPersonCardID,
                          '' LinkMan,
                          '' ComRegistArea,
                          '' ComRegistType,
                          '' ComBusinessArea,
                          '' ComBusinessScope,
                          '1' AppntNum,
                          '' ComStaffSize,
                          '' GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          '' HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,

                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LDPERSON A, LCADDRESS C, LCCONT LC
           WHERE EXISTS (SELECT 1
                    FROM LCCONT C
                   WHERE C.CONTTYPE = '1'
                     AND C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND GREATEST(C.CVALIDATE, C.SIGNDATE) BETWEEN
                         TCDATE AND TMDATE) --没有客户号时，通过时间查询
             AND A.CUSTOMERNO = C.CUSTOMERNO
             AND A.CUSTOMERNO = LC.APPNTNO
             AND LC.POLAPPLYDATE =
                 (SELECT MAX(POLAPPLYDATE)
                    FROM LCCONT
                   WHERE A.CUSTOMERNO = APPNTNO)
             and c.addressno =
                 (select max(addressno)
                    from lcaddress
                   where A.CUSTOMERNO = CUSTOMERNO)

          union
          SELECT distinct A.CUSTOMERNO CLIENTNO,
                          A.NAME NAME,
                          A.BIRTHDAY BIRTHDAY,
                          get_Age(A.BIRTHDAY, SYSDATE) AGE, --TODO 投保人生日计算？？
                          A.SEX SEX,
                          A.IDTYPE CARDTYPE,
                          A.IDNO CARDID,
                          --A.IDEXPDATE CardExpireDate,
                          --A.IDEXPDATE CardExpireDate,
                          to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                          '01' CLIENTTYPE,
                          C.COMPANYPHONE WorkPhone,
                          C.HOMEPHONE FamilyPhone,
                          C.MOBILE Telephone,
                          A.OCCUPATIONCODE OCCUPATION,
                          '' BusinessType,
                          A.YEARINCOME INCOME,
                          C.GRPNAME GrpName,
                          C.POSTALADDRESS Address,
                          C.ZIPCODE ZipCode,

                          A.NATIVEPLACE NATIONALITY,
                          LC.MANAGECOM ComCode,
                          '01' ContType,
                          '' BusinessLicenseNo, --营业执照号码
                          '' OrgComCode,
                          '' TaxRegistCertNo,
                          '' LegalPerson,
                          '' LegalPersonCardType,
                          '' LegalPersonCardID,
                          '' LinkMan,
                          '' ComRegistArea,
                          '' ComRegistType,
                          '' ComBusinessArea,
                          '' ComBusinessScope,
                          '1' AppntNum,
                          '' ComStaffSize,
                          '' GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          '' HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,

                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LDPERSON       A,
                 LCADDRESS      C,
                 LCCONT         LC,
                 lxreportdetail lp,
                 lxistrademain  lx
           WHERE EXISTS (SELECT 1
                    FROM LCCONT C
                   WHERE C.CONTTYPE = '1'
                     AND C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND lx.dealdate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
             AND A.CUSTOMERNO = C.CUSTOMERNO
             and lp.dealno = lx.dealno
             and lx.csnm = a.customerno
             AND A.CUSTOMERNO = LC.APPNTNO
             and c.addressno =
                 (select max(addressno)
                    from lcaddress
                   where A.CUSTOMERNO = CUSTOMERNO)

          union
          SELECT distinct A.CUSTOMERNO CLIENTNO,
                          A.NAME NAME,
                          A.BIRTHDAY BIRTHDAY,
                          get_Age(A.BIRTHDAY, SYSDATE) AGE, --TODO 投保人生日计算？？
                          A.SEX SEX,
                          A.IDTYPE CARDTYPE,
                          A.IDNO CARDID,
                          --A.IDEXPDATE CardExpireDate,
                          --A.IDEXPDATE CardExpireDate,
                          to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                          '01' CLIENTTYPE,
                          C.COMPANYPHONE WorkPhone,
                          C.HOMEPHONE FamilyPhone,
                          C.MOBILE Telephone,
                          A.OCCUPATIONCODE OCCUPATION,
                          '' BusinessType,
                          A.YEARINCOME INCOME,
                          C.GRPNAME GrpName,
                          C.POSTALADDRESS Address,
                          C.ZIPCODE ZipCode,

                          A.NATIVEPLACE NATIONALITY,
                          LC.MANAGECOM ComCode,
                          '01' ContType,
                          '' BusinessLicenseNo, --营业执照号码
                          '' OrgComCode,
                          '' TaxRegistCertNo,
                          '' LegalPerson,
                          '' LegalPersonCardType,
                          '' LegalPersonCardID,
                          '' LinkMan,
                          '' ComRegistArea,
                          '' ComRegistType,
                          '' ComBusinessArea,
                          '' ComBusinessScope,
                          '1' AppntNum,
                          '' ComStaffSize,
                          '' GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          '' HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,

                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LDPERSON       A,
                 LCADDRESS      C,
                 LCCONT         LC,
                 lxreportdetail lp,
                 lxihtrademain  lx
           WHERE EXISTS (SELECT 1
                    FROM LCCONT C
                   WHERE C.CONTTYPE = '1'
                     AND C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND lx.dealdate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
             AND A.CUSTOMERNO = C.CUSTOMERNO
             and lp.dealno = lx.dealno
             and lx.csnm = a.customerno
             AND A.CUSTOMERNO = LC.APPNTNO
             and c.addressno =
                 (select max(addressno)
                    from lcaddress
                   where A.CUSTOMERNO = CUSTOMERNO)

          union

          SELECT distinct A.CUSTOMERNO CLIENTNO,
                          A.NAME NAME,
                          A.BIRTHDAY BIRTHDAY,
                          get_Age(A.BIRTHDAY, SYSDATE) AGE, --TODO 投保人生日计算？？
                          A.SEX SEX,
                          A.IDTYPE CARDTYPE,
                          A.IDNO CARDID,
                          --A.IDEXPDATE CardExpireDate,
                          --A.IDEXPDATE CardExpireDate,
                          to_date(A.IDEXPDATE, 'yyyy-mm-dd') CardExpireDate,
                          '01' CLIENTTYPE,
                          C.COMPANYPHONE WorkPhone,
                          C.HOMEPHONE FamilyPhone,
                          C.MOBILE Telephone,
                          A.OCCUPATIONCODE OCCUPATION,
                          '' BusinessType,
                          A.YEARINCOME INCOME,
                          C.GRPNAME GrpName,
                          C.POSTALADDRESS Address,
                          C.ZIPCODE ZipCode,

                          A.NATIVEPLACE NATIONALITY,
                          LC.MANAGECOM ComCode,
                          '01' ContType,
                          '' BusinessLicenseNo, --营业执照号码
                          '' OrgComCode,
                          '' TaxRegistCertNo,
                          '' LegalPerson,
                          '' LegalPersonCardType,
                          '' LegalPersonCardID,
                          '' LinkMan,
                          '' ComRegistArea,
                          '' ComRegistType,
                          '' ComBusinessArea,
                          '' ComBusinessScope,
                          '1' AppntNum,
                          '' ComStaffSize,
                          '' GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          '' HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,

                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LDPERSON A, LCADDRESS C, LCCONT LC, lpedoritem lp
           WHERE EXISTS (SELECT 1
                    FROM LCCONT C
                   WHERE C.CONTTYPE = '1'
                     AND C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND lp.edorvalidate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
             AND A.CUSTOMERNO = C.CUSTOMERNO
             and lc.contno = lp.contno
             AND A.CUSTOMERNO = LC.APPNTNO
             and c.addressno =
                 (select max(addressno)
                    from lcaddress
                   where A.CUSTOMERNO = CUSTOMERNO);

        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
    END;

END CRMS_CLIENT;


/

