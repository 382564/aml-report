create function ActuGrpSelContNo(GrpOrPerson in varchar2, fFlag in VARCHAR2, vFlag in VARCHAR2 ,dStartDate in DATE,dEvlDateEnd in DATE,vManComCode in VARCHAR2/*,vNewManComCode in VARCHAR2*/) return integer is
  Result integer;
  pragma autonomous_transaction;
  v_total integer:=0;
  v_debug_flag char(10);
begin
declare
  vContNo  CHAR(20);
  v_row_SelGrpCont SelGrpCont%rowtype;
  v_row_ActuGrpContData ActuGrpContData%rowtype;
  --v_row_liactuarybuffer_log liactuarybuffer_log%rowtype;
  v_count  integer;
  vPolNo  VARCHAR2(20);
  vCvaliDate date;

  InterYear date;
  CurrPolYear date;
  intel integer;
  total integer;
  vPolYears integer;
  CurrentDate date;
  tLeng integer:=0;
  pLength integer :=0;
  i integer:= 0;
  tManageCom varchar2(10);
 --
 cursor v_cursor_SelGrpCont is
 select distinct contno from SelGrpCont;


 cursor v_cursor_actu is
 select * from ActuGrpContData where polstate in('1')/* and contno='HB020327011000580'*/
 and managecom like vManComCode || '%';

  --???
 cursor v_cur_lcpol is
   --?? payendyear<>1 and payendyearflag<>'Y'???,
   --??????????????,????
   --???????????????,payendyear????1

 select contno from lcpol
 where
 appflag not in ('0')
 and payendyear<>1
 and SignDate>=dStartDate
 and SignDate<=dEvlDateEnd
 and ManageCom like vManComCode || '%'
 --and contno = vContNo

 --??? payendyear=1 and payendyearflag='Y'???
 union
 select contno from lcpol
 where
 appflag not in ('0')
 and polno=mainpolno and payendyear=1
 and SignDate>=dStartDate
 and SignDate<=dEvlDateEnd
 and ManageCom like vManComCode || '%'
 --and contno = vContNo

 UNION
 select contno from lcpol
 where
 appflag not in ('0')
 and payendyear=1 and payendyearflag='A'
 and SignDate>=dStartDate
 and SignDate<=dEvlDateEnd
 and ManageCom like vManComCode || '%'
 --and contno = vContNo

 -- ?????????????
 union
 select contno from
 (
  select contno
  from lcpol
  where polno<>mainpolno and payendyear=1 and payendyearflag='Y'
  and appflag<>9
  and SignDate>=dStartDate
  and SignDate<=dEvlDateEnd
  and ManageCom like vManComCode || '%'
  --and contno = vContNo
  order by cvalidate desc--???
  );



  --??
  cursor v_cursor_lpedorapp IS
  select otherno
  from lpedorapp
  where 1=1
  and edorstate in ('0', '6', 'b')
  and managecom like vManComCode||'%'
  and confdate between dStartDate and dEvlDateEnd;

  --??
  cursor v_cursor_ljtempfee is
  select otherno
  from ljtempfee
  where 1=1
  and tempfeeno in('2','3')
  and managecom like vManComCode||'%'
  and enteraccdate between dStartDate and dEvlDateEnd;

  --?????
  cursor v_cursor_ljtempfee_xcz is
  select otherno from ljtempfee
  where 1=1
  and tempfeetype='C'
  and othernotype = '7'
  and managecom like vManComCode||'%'
  and makedate between dStartDate and dEvlDateEnd;

  --????
  cursor v_cursor_ljaget_xqht is
  select otherno from ljaget
  where 1=1
  and othernotype = '9'
  and managecom like vManComCode||'%'
  and makedate between dStartDate and dEvlDateEnd;

  --????,????????????????????,?????,????
  cursor v_cursor_ljtempfee_xqcz is
  select otherno from ljtempfee
  where 1=1
  and tempfeetype='C'
  and othernotype = '2'
  and managecom like vManComCode||'%'
  and makedate between dStartDate and dEvlDateEnd;

  --?? ????????,?????
  cursor v_cursor_LJAGetClaim is
  select contno from ljagetclaim
  where 1=1
  and managecom like vManComCode||'%'
  and grpcontno <> '00000000000000000000'
  and OPConfirmDate between dStartDate and dEvlDateEnd;



  begin
  execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';
  --execute immediate 'TRUNCATE TABLE SelGrpCont';
  execute immediate 'delete from  SelGrpCont where  default3 like '''||vManComCode || '%''';
  commit;
--???????
if vFlag = '1'  and fFlag in('1','4') then
  --??????
  select to_date(Sysdate,'YYYY-MM-DD') into CurrentDate from dual;

 open v_cursor_actu;
   loop
      fetch v_cursor_actu into v_row_ActuGrpContData;
      exit when v_cursor_actu%NOTFOUND;

       /*????*/
      if v_row_ActuGrpContData.CValiDate is not null then

      if v_row_ActuGrpContData.MainFlag='1' then
       select  to_date(dEvlDateEnd,'YYYY-MM-DD')+1 into InterYear from dual;
       select Trunc(Months_between(to_date(InterYear,'YYYY-MM-DD'),v_row_ActuGrpContData.Cvalidate)/12) into vPolYears from dual;

       update ActuGrpContData set PolYearCount = vPolYears where contno=v_row_ActuGrpContData.contno
       and riskcode=v_row_ActuGrpContData.riskcode and peopleno=v_row_ActuGrpContData.peopleno;
       commit;
      end if;
  /*????*/
       select Trunc(Months_between(to_date(dEvlDateEnd+1,'YYYY-MM-DD'),v_row_ActuGrpContData.Cvalidate)/12) into intel from dual;
       select Add_months(v_row_ActuGrpContData.Cvalidate,intel*12) into CurrPolYear from dual;
       select Trunc(Months_between(TO_DATE(dEvlDateEnd+1,'YYYY-MM-DD'),TO_DATE(CurrPolYear,'YYYY-MM-DD'))) into total from dual;
       v_row_ActuGrpContData.PolMonthCount:=total;

       update ActuGrpContData set PolMonthCount = total where contno=v_row_ActuGrpContData.contno
       and riskcode=v_row_ActuGrpContData.riskcode and peopleno=v_row_ActuGrpContData.peopleno;
       commit;

  /*????*/
     select TO_DATE(dEvlDateEnd+1,'YYYY-MM-DD')-CurrPolYear into total from dual;
       v_row_ActuGrpContData.PolDayCount:=total;

       update ActuGrpContData set PolDayCount = total where contno=v_row_ActuGrpContData.contno
       and riskcode=v_row_ActuGrpContData.riskcode and peopleno=v_row_ActuGrpContData.peopleno;
       commit;
    end if;

/*      --?????????????
    if v_row_ActuGrpContData.makedate <> CurrentDate then
      --v_row_ActuGrpContData.MakeDate:=CurrentDate;
    update ActuGrpContData set MakeDate = CurrentDate where contno=v_row_ActuGrpContData.contno
    and riskcode=v_row_ActuGrpContData.riskcode and peopleno=v_row_ActuGrpContData.peopleno;
    commit;

    end if;*/

   end loop;
 close  v_cursor_actu;


    --??????
   /* ????????????,????*/
   update ActuGrpContData set makedate = CurrentDate where managecom like vManComCode || '%';
   commit;
   --??????
   /* ????????????,????*/
   update ActuGrpContData set CalDate = to_date(dEvlDateEnd,'YYYY-MM-DD') where managecom like vManComCode || '%';
   commit;
  end if;



   --???1,??????
 if vFlag = '1' then

  --???????????
  open v_cursor_lpedorapp;
  loop
     fetch v_cursor_lpedorapp into vContNo;
     exit when v_cursor_lpedorapp%NOTFOUND;

     v_row_SelGrpCont.ContNo := vContNo;
     v_row_SelGrpCont.default2 := 'BQ';
     v_row_SelGrpCont.default3 := vManComCode;
     insert into SelGrpCont  values v_row_SelGrpCont;
     commit;
  end loop;
  close v_cursor_lpedorapp;

  --???????????
  open v_cursor_ljtempfee;
  loop
     fetch v_cursor_ljtempfee into vContNo;
     exit when v_cursor_ljtempfee%NOTFOUND;

     v_row_SelGrpCont.ContNo := vContNo;
     v_row_SelGrpCont.default2 := 'XQ';
     v_row_SelGrpCont.default3 := vManComCode;
     insert into SelGrpCont  values v_row_SelGrpCont;
     commit;
  end loop;
  close v_cursor_ljtempfee;

/*  --???????
  open v_cursor_ljaget_xqht;
  loop
     fetch v_cursor_ljaget_xqht into vContNo;
     exit when v_cursor_ljaget_xqht%NOTFOUND;

     v_row_SelGrpCont.ContNo := vContNo;
     v_row_SelGrpCont.default2 := 'XQHT';
     v_row_SelGrpCont.default3 := vManComCode;
     insert into SelGrpCont  values v_row_SelGrpCont;
     commit;
  end loop;
  close v_cursor_ljaget_xqht;*/

/*--??????????
  open v_cursor_ljtempfee_xcz;
  loop
      fetch v_cursor_ljtempfee_xcz into vContNo;
      exit when v_cursor_ljtempfee_xcz%NOTFOUND;

      v_row_SelGrpCont.ContNo := vContNo;
      v_row_SelGrpCont.default2 := 'QYCZ';
      v_row_SelGrpCont.default3 := vManComCode;
      insert into SelGrpCont  values v_row_SelGrpCont;
      commit;
  end loop;
  close v_cursor_ljtempfee_xcz;*/


--???????

  open v_cursor_LJAGetClaim;
  loop
      fetch v_cursor_LJAGetClaim into vContNo;
      exit when v_cursor_LJAGetClaim%NOTFOUND;

      v_row_SelGrpCont.ContNo := vContNo;
      v_row_SelGrpCont.default2 := 'LP';
      v_row_SelGrpCont.default3 := vManComCode;
      insert into SelGrpCont  values v_row_SelGrpCont;
      commit;
  end loop;
  close v_cursor_LJAGetClaim;



  /*-----------------------??????????--------------------------------*/

 --?????????,
   IF fFlag in('1','4') then
  --????????????,??????????????,?????????
  --???????????? 2  ???0???????,?2????????
   select getactugrpcontdata('2',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;

    --?????????
   delete from ActuGrpContData where contno in(select  contno from SelGrpCont where  default3 like vManComCode || '%');
   commit;
   --????????
   select getactugrpcontdata('1',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   commit;

   --????,????
   delete from ActuGrpContData
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
   commit;
  end if;

  /*-----------------------????????????------------------------*/
  IF fFlag in('2','4') then

    --???
  open v_cur_lcpol;
  loop
      fetch v_cur_lcpol into vContNo;
      exit when v_cur_lcpol%NOTFOUND;

      v_row_SelGrpCont.ContNo := vContNo;
      v_row_SelGrpCont.default2 := 'QY';
      insert into SelGrpCont  values v_row_SelGrpCont;
      commit;
  end loop;
  close v_cur_lcpol;

  delete from actucontstate where contno in(select  contno from SelGrpCont where default3 like vManComCode || '%');
  commit;
 --?????????,
   select getactugrpcontstate('1',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;

   --????,????
   delete from actucontstate
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
   commit;
   end if;
  /*-----------------------????????,?????????------------------------*/

   IF fFlag in('3','4') then
   select getactugrpcontclaim(dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   end if;
  end if;



  --???????
 if vFlag = '0' then
--IF GrpOrPerson = '1' THEN
  IF fFlag in('1','4') then
   select getActuGrpContData('0',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   --????,????
   delete from ActuGrpContData
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
   commit;
  end if;
  IF fFlag in('2','4') then
   select getActuGrpContState('0',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   --????,????
   delete from actucontstate
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
   commit;
  end if;
  IF fFlag in('3','4') then
   select getActuGrpContClaim(dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
  end if;
 --End if;

 --???

/*  IF fFlag in('1','4') then
   select getActuGrpContData('0',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   --????,????
\*   delete from ActuGrpContData
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
*\   commit;
  end if;
  IF fFlag in('2','4') then
   select getActuGrpContState('0',dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
   --????,????
   delete from actucontstate
   where contno in(select contno from lbcont a where managecom like vManComCode || '%' and state='1009' and exists(select 1 from ljapayperson where contno=a.contno));
   commit;
  end if;
  IF fFlag in('3','4') then
   select getActuGrpContClaim(dStartDate,dEvlDateEnd,vManComCode) into  v_count from dual;
  end if;*/

 end if;

  end;
  COMMIT;
 return(v_total);

exception
   when others then
   dbms_output.put_line('????:ActuSelGrpContNo??????' || ' ???????: ' || sqlerrm);
   return('E???????: ' || sqlerrm);
end ActuGrpSelContNo;


/

