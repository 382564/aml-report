create function getParentCom(cComCode in varchar2)
return  varchar2 as
tParentComCodeISC varchar2(10);
tComCodeISC varchar2(10);
begin
select trim(max(ComCodeISC)) into tComCodeISC from LFComToISCCom where trim(ComCode)=trim(cComCode);
select trim(max(ParentComCodeISC)) into tParentComCodeISC from LFComISC where trim(ComCodeISC)= trim(tComCodeISC);
return(tParentComCodeISC);
end;


/

