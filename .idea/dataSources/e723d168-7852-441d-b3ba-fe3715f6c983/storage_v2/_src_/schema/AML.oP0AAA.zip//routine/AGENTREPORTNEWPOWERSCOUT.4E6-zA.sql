create function AgentReportNewPowerScout(sFlag in varchar2,
 sGrade in varchar2,sMonth in number,sIndexCalNo in varchar2,
 sBranchatt in varchar2 )
 return int is Result int;
 /*  ?????????????????
   *  @param sFlag:?????   sGrade:????????
   *         sMonth:????????    sIndexCalNo:?????????
   *         sBranchatt:??
   *  @return Result:??
  */

  sdate VARCHAR2(6) ;



begin
  --?????????????sdate?
  select to_char(add_months(to_date(sIndexCalNo,'YYYYMM'),1-sMonth),'YYYYMM')
  into sdate from dual;

 --??????,1???????,2???????,3??????
  if(sFlag = '1' ) then
     --????????????? ????
       if(sgrade = 'A05') then
       select nvl(count(a.agentcode),0) into Result from laagent a,latree b
       where a.branchtype='1' and a.managecom like sBranchatt||'%'
       and a.EmployDate>=(select startdate from lastatsegment
            where stattype='5'and yearmonth=sdate)
       and a.EmployDate<=(select enddate from lastatsegment
            where stattype='5'and yearmonth=sdate)
       and exists (select 'X' from labranchgroup where branchtype='1'
       and a.branchcode=agentgroup and (state is null or state<>'1'))
       and a.agentcode=b.agentcode
       and  b.agentgrade like 'A%' and b.employgrade>=sGrade  ;

       else
       select nvl(count(a.agentcode),0) into Result from laagent a,latree b
       where a.branchtype='1' and a.managecom like sBranchatt||'%'
       and a.EmployDate>=(select startdate from lastatsegment
            where stattype='5'and yearmonth=sdate)
       and a.EmployDate<=(select enddate from lastatsegment
            where stattype='5'and yearmonth=sdate)
       and exists (select 'X' from labranchgroup where branchtype='1'
       and a.branchcode=agentgroup and (state is null or state<>'1'))
       and a.agentcode=b.agentcode
       and  b.agentgrade like 'A%' and b.employgrade=sGrade  ;
       end if;
  end if;

 --???????2,??????
  if (sFlag = '2' ) then
    if(sgrade = 'A05') then
    select nvl(count( a.agentcode),0) into Result from laagent a,latree b
    where EmployDate>=(select startdate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and EmployDate<=(select enddate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and outworkdate>=(select startdate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and outworkdate<=(select enddate from lastatsegment
              where stattype='5'and yearmonth=sIndexCalNo)
    and  a.agentState>='03' and a.BranchType='1'and a.managecom like sBranchatt||'%'
    and exists (select 'X' from labranchgroup where branchtype='1'
               and a.branchcode=agentgroup)
    and a.agentcode=b.agentcode
    and  b.agentgrade like 'A%' and b.employgrade>=sGrade  ;
    else
    select nvl(count( a.agentcode),0) into Result from laagent a,latree b
    where EmployDate>=(select startdate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and EmployDate<=(select enddate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and outworkdate>=(select startdate from lastatsegment
              where stattype='5'and yearmonth=sdate)
    and outworkdate<=(select enddate from lastatsegment
              where stattype='5'and yearmonth=sIndexCalNo)
    and  a.agentState>='03' and a.BranchType='1'and a.managecom like sBranchatt||'%'
    and exists (select 'X' from labranchgroup where branchtype='1'
               and a.branchcode=agentgroup)
    and a.agentcode=b.agentcode
    and  b.agentgrade like 'A%' and b.employgrade=sGrade  ;
  end if;
  end if;

  --??????
  if(sFlag = '3' ) then
  select nvl(count(a.agentcode),0) into Result from laagent a,latree b
    where a.branchtype='1' and a.managecom like sBranchatt||'%'
    and a.EmployDate>=(select startdate from lastatsegment
                  where stattype='5'and yearmonth=sdate)
    and a.EmployDate<=(select enddate from lastatsegment
                  where stattype='5'and yearmonth=sdate)
    and a.InDueFormDate<=(select startdate from lastatsegment
                  where stattype='1'and yearmonth=to_char(add_months(to_date(sIndexCalNo,'YYYYMM'),1),'YYYYMM'))
    and a.InDueFormDate>=(select startdate from lastatsegment
                  where stattype='1'and yearmonth=to_char(add_months(to_date(sIndexCalNo,'YYYYMM'),2-sMonth),'YYYYMM'))
    and exists (select 'X' from labranchgroup where branchtype='1'
                and (state is null or state<>'1')and a.branchcode=agentgroup)
    and a.agentcode=b.agentcode
    and b.employgrade='A01'
    --and a.agentcode in (select agentcode from latree where agentgrade='A02' and agentcode=a.agentcode
    --       union select agentcode from latreeb where agentgrade='A02' and agentcode=a.agentcode)
    and a.employdate<>a.indueformdate;

  end if;
  return(Result);
end AgentReportNewPowerScout;


/

