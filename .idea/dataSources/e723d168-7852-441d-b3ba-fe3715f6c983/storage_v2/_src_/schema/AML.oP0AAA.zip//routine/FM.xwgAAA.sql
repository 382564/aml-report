create FUNCTION FM(
       PolYears number, --???????
       PayEndYear number, --????
       Payintv number ,    --????
       param   number   --??
       ) return number as   --???????
r_value number;--r?
temp    number;--???????
temp1   number;--???????
begin
select Least(20,PayEndYear) into temp from dual;

if param=0.8 then
  if PayIntv=0 then
    select 1 into r_value from dual;
  else
    if (PolYears+1)>temp then
      select 1 into r_value from dual;
    else
      select (0.8+0.2*(PolYears+1)/temp) into r_value from dual;
    end if;
  end if;
end if ;

if param=0.9 then
  if PayIntv=0 then
    select 1 into r_value from dual;
  else
    if (PolYears+1)>temp then
      select 1 into r_value from dual;
    else
      select (0.9+0.1*(PolYears+1)/temp) into r_value from dual;
    end if;
  end if;
end if ;

if param=0.95 and (PolYears+1)>=1 then
  if PayIntv=0 then
    select 1 into r_value from dual;
  else
    if (PolYears+1)>6 then
      select 6 into temp1 from dual;
    else
      select PolYears+1 into temp1 from dual;
    end if;
    select 0.95+0.01*(temp1-1) into r_value from dual;
  end if;
end if ;

return r_value;
End FM;


/

