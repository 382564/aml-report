create function chggetmode230(getmode in varchar2) return varchar2
is
tR varchar2(20);
begin
 if getmode = '1' then
  tR := '0.009';
 end if;
 if getmode = '12' then
  tR := '0.1';
 end if;

 return(tR);
end;


/

