create function GETRATE(cRiskCode in CHAR, tYears in INTEGER, tInsuFlag in CHAR) return laratecommision.rate%type is
  rRate number(5, 2) ;
  temp integer;
  tRC integer;
begin
  rRate :=0.00;

  if ChangDateToYear(tYears,tInsuFlag) >30 then
    temp :=0;
  else
    temp :=ChangDateToYear(tYears,tInsuFlag);
  end if;
  --temp:=0;
  /*select 1 into tRC from laratecommision where exists(select 1 from laratecommision where  riskcode =cRiskCode );
  if tRC =0 then
    return(0.00);
  end if;*/
  SELECT rate into rRate FROM laratecommision  where RiskCode=cRiskCode  and  year= 0 and rownum=1;

  if rRate >0 then
    return(rRate);
  --else
    --return(0);
  end if;
  rRate :=0.00;
  return(rRate);
end GETRATE;


/

