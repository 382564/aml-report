create FUNCTION decrypt(tCode in char) --??
       return varchar2 is
  middle char(16);
  Result number(15,2);
  ResultValue varchar2(16);
begin
  middle:=replace(tCode,'GNWD','SSSS');
  middle:=replace(middle,'LYJ','   ');
  middle:=replace(middle,'B',' ');
  middle:=replace(middle,'M','0');
  middle:=replace(middle,'P','1');
  middle:=replace(middle,'C','2');
  middle:=replace(middle,'F','3');
  middle:=replace(middle,'Z','4');
  middle:=replace(middle,'Q','5');
  middle:=replace(middle,'H','6');
  middle:=replace(middle,'R','7');
  middle:=replace(middle,'A','8');
  middle:=replace(middle,'S','9');
  middle:=replace(middle,'V','.');
  Result:=to_number(middle);
  Result:=(10000000000000-Result)/1743-8351;
  ResultValue:=to_char(Result);
  return(ResultValue);
end decrypt;


/

