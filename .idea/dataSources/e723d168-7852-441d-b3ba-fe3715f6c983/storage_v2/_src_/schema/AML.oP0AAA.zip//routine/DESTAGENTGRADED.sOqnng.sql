create FUNCTION DestAgentGradeD(
       TempBegin date, --????
       TempEnd date,--????
       tAgentCode Laindexinfo.Agentcode%TYPE, --?????
       tAgentGrade LARATETOMARK.Agentgrade%TYPE -- ?????
       ) return varchar2 as   --???????
v_Grade varchar2(10);--??????
v_Month  number;--??????
v_Standprem number;--????
v_Temp number;
v_MGrade varchar2(10);--????
v_Grade1 varchar2(10);--????
v_Grade2 varchar2(10);--????


begin
  --??????
  select months_between(TempEnd,LAST_DAY(TempBegin))+1 into v_Month from dual;
  --????????
  select nvl(sum(Standprem),0) into v_Standprem from LACommision where
  caldate>=TempBegin And caldate<=TempEnd and AgentCode=tAgentCode;
  --??????,???D01-D10??
  v_Temp:=v_Standprem/v_Month;
  select trim(planobject) into v_MGrade from laplan where PlanPeriod='6' and branchtype='2'
  and (v_Temp)>=(planvalue/6)
  and planperiodunit='1' and rownum=1 order by planvalue;

  --??????

  select substr(tAgentGrade,2)+2,substr(tAgentGrade,2)-2 into v_Grade1,v_Grade2 From dual;

  if((to_number(substr(v_MGrade,2),99)<=to_number(v_Grade1)) and (to_number(substr(v_MGrade,2),99)>=to_number(v_Grade2))) then
     v_Grade:=v_MGrade;
   elsif(to_number(substr(v_MGrade,2),99)>to_number(v_Grade1)) then
     v_Grade:=concat('D',v_Grade1);
   elsif(to_number(substr(v_MGrade,2),99)<to_number(v_Grade2)) then
     v_Grade:=concat('D',v_Grade2);

   end if;

   if(length(trim(v_Grade))=2) then
   v_Grade:=concat('D0',substr(v_Grade,2));
   end if;

   if(trim(v_Grade)='D00') then
   v_Grade:='00';
   end if;

 return v_Grade;
End DestAgentGradeD;


/

