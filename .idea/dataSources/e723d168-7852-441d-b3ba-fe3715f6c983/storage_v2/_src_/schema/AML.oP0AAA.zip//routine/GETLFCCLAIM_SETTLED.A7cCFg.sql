create function getLFCClaim_Settled(startdate in date,enddate in date,tManageCom in varchar) return char is
  vResI char;
  pragma autonomous_transaction;
 begin


 declare



 v_endcasedate date ;

 v_salechnl char(2);
 v_years integer;
 v_insuyearflag char(1);
 v_PayYears integer;
 v_payendyearflag char(1);
 v_mult           number(20,5);
 v_PayIntv    integer;
 v_cvalidate  date;
 v_count      integer;
 v_insuredname  varchar2(120);
 v_RiskPeriod  char(1);

 v_confdate date;
 v_drawer  varchar2(120);
 v_opconfdate Date;
 d_count Integer:=0;





 v_row_lfcclaim_settle  lfcclaim_settled%rowtype;
 v_row_llclaimpolicy llclaimpolicy%rowtype;

 cursor v_cursor_llclaimpolicy is
 --???????????????
 select *
 from llclaimpolicy a
 where 1=1
/*      And contno = 'XJ100522651000736'*/
     and exists (select 1 from ljagetclaim
         where otherno = a.clmno
         and confdate >= startdate
         and confdate <=enddate
         and managecom like  tManageCom||'%'
         )
         --And clmno = '90000091960'

  union
    --???????????????
 select *
 from llclaimpolicy a
 where 1=1
/*  And contno = 'XJ100522651000736' */
  and exists(select 1 from llreport
            where rptno = a.clmno
            and rptdate >=startdate
            and rptdate <=enddate
            and mngcom like tManageCom||'%')
         --And clmno = '90000091960'


  union
    --????????????,???????????????
 select *
 from llclaimpolicy a
 where 1=1
/*     And contno = 'XJ100522651000736' */
     and exists(select 1 from ljagetclaim
                where otherno = a.clmno
                and confdate >= enddate
                and managecom like  tManageCom||'%')
     and exists(select 1 from llreport
            where rptno = a.clmno
            and rptdate <=startdate
            and mngcom like  tManageCom||'%')
         --And clmno = '90000091960'

     ;

 begin

 execute immediate  'truncate table lfcclaim_settled';
 open v_cursor_llclaimpolicy;

 loop
 fetch v_cursor_llclaimpolicy into v_row_llclaimpolicy;
 exit when v_cursor_llclaimpolicy%notfound;


  select salechnl,years,insuyearflag,PayYears,payendyearflag,mult,PayIntv,insuredname,cvalidate
  into v_salechnl,v_years,v_insuyearflag,v_PayYears,v_payendyearflag,v_mult,v_PayIntv,v_insuredname,v_cvalidate
  from lcpol
  where polno = v_row_llclaimpolicy.polno
  ;


  -- ????
  v_row_lfcclaim_settle.Dept_Name := getCode('com',v_row_llclaimpolicy.mngcom);
 -- ???
  v_row_lfcclaim_settle.CaseNo := v_row_llclaimpolicy.clmno;

 --????
  v_row_lfcclaim_settle.GP_Type := 'P';

 --???
  v_row_lfcclaim_settle.POLNO := v_row_llclaimpolicy.contno;

 --???

  v_row_lfcclaim_settle.CertNo := v_row_llclaimpolicy.contno;

 --???

  v_row_lfcclaim_settle.ListNo := '1';

 --????

  v_row_lfcclaim_settle.BrNo := getriskseq(v_row_llclaimpolicy.riskcode, v_row_llclaimpolicy.contno);

 --????

  v_row_lfcclaim_settle.Plan_Code := v_row_llclaimpolicy.riskcode;

 --??????
  v_row_lfcclaim_settle.Busi_Src_Type := trim(getCode('salechnl', v_salechnl));

 --????(?)
  v_row_lfcclaim_settle.Period := changeDateToMonth(v_years, v_insuyearflag);

 --????(?)
  If v_payintv <> 0 Then
   v_row_lfcclaim_settle.Prem_Term := changeDateToMonth(v_payyears, v_payendyearflag);
  Else
   v_row_lfcclaim_settle.Prem_Term := 0;
  End If;


 --??
  v_row_lfcclaim_settle.Units := v_mult;


  --????
    If v_row_lfcclaim_settle.brno = '2' then
    Begin
        Select cvalidate Into v_cvalidate From lcpol Where polno = mainpolno And contno = v_row_llclaimpolicy.contno;
    exception when no_data_found then
     Null;
    end;
    End If;

  Begin
   Select a.opconfirmdate Into v_opconfdate from ljagetclaim a where otherno = v_row_llclaimpolicy.clmno and rownum = 1;
    v_row_lfcclaim_settle.Pol_Yr := GETCURYEAR(v_opconfdate,v_cvalidate);
  exception when no_data_found then
   v_row_lfcclaim_settle.Pol_Yr := '';
  end;


  --??
  v_row_lfcclaim_settle.Prem_Type := trim(getCode('payintv', to_char(v_payintv)));

  --	????

  select count(1) into v_count from llclaimpolicy where caseno = v_row_llclaimpolicy.caseno;

  v_row_lfcclaim_settle.PaySeq := v_count;

  --?????
  v_row_lfcclaim_settle.InsName := GETNORMALCHAR(v_insuredname);

  --?????


  begin
   select confdate,drawer into v_confdate,v_drawer from ljaget where otherno = v_row_llclaimpolicy.caseno and rownum = 1;
  exception when no_data_found then
  null;
  end;
  v_row_lfcclaim_settle.Paid_Name := v_drawer;

  --????
  begin
   select RiskPeriod into v_RiskPeriod from lmriskapp where riskcode = v_row_llclaimpolicy.riskcode and rownum =1;
  exception when no_data_found then
  null;
  end;
  -- v_row_lfcclaim_settle.Amt_Type := getAmt_type_tbl(substr(v_row_llclaimpolicy.getdutykind, 2, 2),'0',v_RiskPeriod);
  If v_RiskPeriod = 'L' Then
    v_row_lfcclaim_settle.Amt_Type := '08';
   Else
    v_row_lfcclaim_settle.Amt_Type := '09';
  End If;

  --?????????
  v_row_lfcclaim_settle.Paid_Amt_cnvt := v_row_llclaimpolicy.realpay;

  --????
  v_row_lfcclaim_settle.Check_Fee := 0;

  --??
  v_row_lfcclaim_settle.CurNo := '01';

  --????

  begin
     select endcasedate into v_endcasedate from llregister where rgtno = v_row_llclaimpolicy.clmno;
  exception when no_data_found then
  null;
  end;

  v_row_lfcclaim_settle.End_date := v_endcasedate;

  --????(????)

  v_row_lfcclaim_settle.Gained_date := v_confdate;

  --?????
  v_row_lfcclaim_settle.Is_PrePay := 'N';

  --????????

  v_row_lfcclaim_settle.N_Share_Sum := 0;
  --?????????

  v_row_lfcclaim_settle.N_Share_Sum_n := 0;
  d_count := d_count +1 ;

 insert into lfcclaim_settled values v_row_lfcclaim_settle;
 commit;

end loop;
close v_cursor_llclaimpolicy;

return vResI;
 end;
end getLFCClaim_Settled;


/

