create function getLFCprem_2(sDate in date,eDate in date,tManageCom in varchar) return char is
  Result_Endo varchar2(10);
  pragma autonomous_transaction;
 begin


 Declare
 v_cvalidate date;
 v_insuyearflag char(1);
 v_years   integer;
 v_PayIntv integer;
 v_PayEndYear integer;
 v_payendyearflag char(1);
 v_SaleChnl char(2);
 v_AgentCom char(20);
 v_agentcode char(10);
 v_mult  number(20,5);
 v_amnt  number(12,2);
 v_riskperiod char(1);

 c_actugetno         Char(20);
 c_Endorsementno     Char(20);
 c_feeoperationtype  Char(10);
 v_riskcode          varchar2(10);
 c_polno             Char(20);
 d_PayMoney          Number(12,2);
 c_managecom         Char(10);
 c_enteraccdate      Date;
 c_contno            Char(20);
 v_Edorvalidate      Date;
 c_PayNo             Char(20);
 c_edorno           Char(20);

 v_cursor_lfcendo lfcendo_fee%rowtype;



 cursor v_cursor_ljapayperson is

 --????????????????????????????
Select a.payno,a.paytype,a.riskcode,a.polno,a.managecom ,a.enteraccdate,Sum(sumactupaymoney)
 from ljapayperson a
 where 1=1
     --and contno = 'WH210326011003773'
     and enteraccdate >= sDate
     and enteraccdate <= eDate
     and managecom like tManageCom||'%'
     and paytype In('RE','NS','AA')
     --And contno = 'XJB10526111000046'
     and exists(select 1
                   from ljapay s
                   where exists(select 1 from lpedoritem  t
                                where 1=1
                                and t.edoracceptno = s.otherno
                                And t.edortype <> 'RB'
                                And t.edorstate = '0'
                                and t.managecom Like tManageCom||'%'
                                and t.edorvalidate <= sDate
                                )
                    and a.payno = s.payno
                   )
      Group By a.payno,a.paytype,a.riskcode,a.polno,a.managecom ,a.enteraccdate

   Union

    Select a.payno,a.paytype,a.riskcode,a.polno,a.managecom ,a.enteraccdate,Sum(sumactupaymoney)
     from ljapayperson a
     where 1=1
     --And contno = 'XJB10526111000046'
         and managecom like tManageCom||'%'
         and paytype In('RE','NS','AA')
         and exists(select 1
                       from ljapay s
                       where exists(select 1 from lpedoritem t
                                    where 1=1
                                    and t.edoracceptno = s.otherno
                                And t.edortype <> 'RB'
                                And t.edorstate = '0'
                                    and t.managecom Like tManageCom||'%'
                                    and t.edorvalidate >= sDate
                                    and t.edorvalidate <= eDate
                                    )
                                    and a.payno = s.payno
                       )
          Group By a.payno,a.paytype,a.riskcode,a.polno,a.managecom ,a.enteraccdate
     ;

 Begin

 --execute immediate  'truncate table lfcendo_fee';
open v_cursor_ljapayperson;

 loop
 fetch v_cursor_ljapayperson Into c_PayNo,c_feeoperationtype,v_riskcode,c_polno,c_managecom,c_enteraccdate,d_PayMoney;
 exit when v_cursor_ljapayperson%notfound;

 Begin
   Select contno,cvalidate,years,insuyearflag,PayIntv,PayEndYear,payendyearflag,SaleChnl,AgentCom,agentcode
          ,mult,amnt
   Into c_contno,v_cvalidate,v_years,v_insuyearflag,v_PayIntv,v_PayEndYear,v_payendyearflag,v_SaleChnl,v_AgentCom,v_agentcode
          ,v_mult,v_amnt
   from lcpol
   where polno = c_polno;


 --dep_name????

    v_cursor_lfcendo.dept_name :=  trim(getCode('com',c_managecom));

   --???

		Select Edorvalidate,EdorNo
		Into v_Edorvalidate,c_edorno
		From Lpedoritem
		Where Edoracceptno In (Select Otherno From ljapay Where payno = c_PayNo) And Rownum = 1;


    v_cursor_lfcendo.entno := c_edorno;


    --????
     v_cursor_lfcendo.gp_type := 'P';


     -- ???
     v_cursor_lfcendo.polno := c_contno;


     --???
     v_cursor_lfcendo.certno := c_contno;


     --????
     v_cursor_lfcendo.brno := getriskseq(c_polno, c_contno);


     --????
     v_cursor_lfcendo.plan_code := v_riskcode;

     --????
     v_cursor_lfcendo.pol_yr := Getcuryear(v_Edorvalidate,v_cvalidate);


     --????(?)
     v_cursor_lfcendo.period := ChangeDateToMonth(v_years, v_insuyearflag);


     --??
     v_cursor_lfcendo.prem_type := trim(getCode('payintv', to_char(v_PayIntv)));


     --????(?)
        If v_payintv <> 0 Then
				v_cursor_lfcendo.Prem_Term := Changedatetomonth(v_Payendyear, v_Payendyearflag);
        Else
				v_cursor_lfcendo.Prem_Term := 0;
        End If;

   --??????
     v_cursor_lfcendo.Busi_Src_Type := trim(getCode('salechnl', v_SaleChnl));


   --??????
     v_cursor_lfcendo.Agt_Code := v_AgentCom;

     --?????

     v_cursor_lfcendo.AgentNo := ChangeAgentcode(v_agentcode);


   --????
     v_cursor_lfcendo.POS_Type := trim(getCode('edortype', c_feeoperationtype));

  -- ????
     v_cursor_lfcendo.Amt_Type := getAmtype_Endo_Fee(c_endorsementno,c_feeoperationtype,'',v_RiskCode);

     --??
     v_cursor_lfcendo.CurNo := '01';



     --??????????
     v_cursor_lfcendo.Amt_Incured_cnvt := d_PayMoney;



     --?????
     v_cursor_lfcendo.Units := v_mult;


     --?????
     v_cursor_lfcendo.Sum_Ins := v_amnt;


		 --????(????)
     v_cursor_lfcendo.Proc_date := v_Edorvalidate;


     --???(????)
     v_cursor_lfcendo.Gained_date := c_enteraccdate;


   insert into lfcendo_fee values v_cursor_lfcendo;
   commit;
Exception
 When no_data_found Then
  Null;
 End;
end loop;

close v_cursor_ljapayperson;
return Result_Endo;
 end;
end getLFCprem_2;


/

