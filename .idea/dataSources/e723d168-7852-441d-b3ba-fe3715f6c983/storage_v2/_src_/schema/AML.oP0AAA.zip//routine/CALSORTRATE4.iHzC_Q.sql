create function         calSortRate4(begin_Date   varchar2,
                                        insuyear     number,
                                        insuyearflag varchar2)
  return number is
  Result      number;
  count_month number;
begin
  Result := 0;
  if insuyear=1 and insuyearflag = 'Y' then
    Result := 1;
  end if;
  if insuyearflag = 'M' then
    if insuyear = 12 then
      Result := 1;
    elsif insuyear = 11 then
      Result := 1;
    elsif insuyear = 10 then
      Result := 1;
    elsif insuyear = 9 then
      Result := 1;
    elsif insuyear = 8 then
      Result := 1;
    elsif insuyear = 7 then
      Result := 1;
    elsif insuyear = 6 then
      Result := 0.75;
    elsif insuyear = 5 then
      Result := 0.75;
    elsif insuyear = 4 then
      Result := 0.75;
    elsif insuyear = 3 then
      Result := 0.75;
    elsif insuyear = 2 then
      Result := 0.75;
    elsif insuyear = 1 then
      Result := 0.5;
    end if;
  end if;
  if insuyearflag = 'D' then
    select months_between((to_date(begin_Date, 'YYYY-MM-DD') + insuyear),
                          to_date(begin_Date, 'YYYY-MM-DD'))
      into count_month
      from dual;
    if insuyear = 1 then
      Result := 0.2;
    elsif insuyear >= 2 and insuyear <= 3 then
      Result := 0.25;
    elsif insuyear >= 4 and insuyear <= 7 then
      Result := 0.5;
    elsif insuyear >= 8 and insuyear <= 14 then
      Result := 0.5;
    elsif insuyear >= 15 and insuyear <= 21 then
      Result := 0.5;
    elsif insuyear >= 22 and insuyear <= 30 then
      Result := 0.5;
    end if;
    if count_month>12 then
      Result := 0;
    elsif count_month > 11 then
      Result := 1;
    elsif count_month > 10 then
      Result := 1;
    elsif count_month > 9 then
      Result := 1;
    elsif count_month > 8 then
      Result := 1;
    elsif count_month > 7 then
      Result := 1;
    elsif count_month > 6 then
      Result := 1;
    elsif count_month > 5 then
      Result := 0.75;
    elsif count_month > 4 then
      Result := 0.75;
    elsif count_month > 3 then
      Result := 0.75;
    elsif count_month > 2 then
      Result := 0.75;
    elsif count_month > 1 then
      Result := 0.75;
    elsif count_month = 1 then
      Result := 0.5;
    end if;
  end if;

  return(Result);
end calSortRate4;


/

