create FUNCTION GetGrpRiskSort(tRiskode lmrisksort.riskcode%type)
return varchar2 is
  Result varchar2(30);
  cName1 Char(40);
  cName2 Char(40);
  cName3 Char(40);
  tName1Count int;
  tName2Count int;
  tName3Count int;
begin
  --
  select count(1) into tName1Count from lmrisksort where risksorttype ='23' and trim(riskcode)=trim(tRiskode);
  if tName1Count>0 then
    select decode(risksortvalue,'1','??','2','???','3','???',' ') into cName1
    from lmrisksort where risksorttype ='23' and trim(riskcode)=trim(tRiskode);
    Result:=trim(cName1);
  end if;
  --
  select count(1) into tName2Count from lmrisksort where risksorttype ='24' and trim(riskcode)=trim(tRiskode);
  if tName2Count>0 then
    select decode(risksortvalue,'1','??','2','???',' ') into cName2
    from lmrisksort where risksorttype ='24' and trim(riskcode)=trim(tRiskode);
    Result:=Concat(trim(Result), trim(cName2));
  end if;
  --
  select count(1) into tName3Count from lmrisksort where risksorttype ='25' and trim(riskcode)=trim(tRiskode);
  if tName3Count>0 then
    select decode(risksortvalue,'1','??','2','????','3','????',' ') into cName3
    from lmrisksort where risksorttype ='25' and trim(riskcode)=trim(tRiskode);
    Result:=Concat(trim(Result), trim(cName3));
  end if;

  Return(Result);
end GetGrpRiskSort;


/

