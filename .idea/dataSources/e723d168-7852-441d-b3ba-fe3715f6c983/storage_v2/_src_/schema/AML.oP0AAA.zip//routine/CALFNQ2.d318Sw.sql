create function calFnq2(vManageCom in varchar2) return integer is
  Result integer;
  pragma autonomous_transaction;
begin

 declare

 cursor v_cursor_newsys is
 select * from newsystemp4
 where managecom like vManageCom||'%'
 ;

 v_row_newsystemp4 newsystemp4%rowtype;

 begin

 open v_cursor_newsys;

 loop
  fetch v_cursor_newsys into v_row_newsystemp4;
  exit when v_cursor_newsys%notfound;
   --?????????????? 2007-01-31 liuzhao v_row_newsystemp4.xaddf
   v_row_newsystemp4.prema := v_row_newsystemp4.prem+v_row_newsystemp4.xaddf+v_row_newsystemp4.addb+v_row_newsystemp4.addf-v_row_newsystemp4.mf;
   v_row_newsystemp4.bprem := v_row_newsystemp4.prema +v_row_newsystemp4.dx;

   update newsystemp4 set prema = v_row_newsystemp4.prema,bprem = v_row_newsystemp4.bprem
   where managecom = v_row_newsystemp4.managecom
   and salechnl = v_row_newsystemp4.salechnl
   and riskcode = v_row_newsystemp4.riskcode
   and payyears = v_row_newsystemp4.payyears
   ;

 commit;

 end loop;

 close v_cursor_newsys;


 end;
  return(Result);
end calFnq2;


/

