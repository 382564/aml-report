create FUNCTION BranchOperationRate(
       TempBegin date, --????
       TempEnd date,   --????
       tAgentGroup LACommision.AgentGroup%TYPE, --?????
       tIndexCalNo integer   --????
       ) return number as   --???????
v_Rate number;--???????
v_StandPrem number; -- ????
v_Planvalue number; --????
v_branchattr varchar2(70);

begin
select branchattr into v_branchattr from labranchgroup where agentgroup=tAgentGroup ;

select NVL(sum(StandPrem),0) into v_StandPrem from LACommision
where BranchAttr like substr(v_branchattr,0,8)||'%'
and tmakedate >= TempBegin And  tmakedate <= TempEnd;


select decode(nvl(sum(planvalue),0),0,1000000000000,sum(planvalue)) into v_Planvalue
from laplan where branchtype = '3' and plantype = '2'
and planobject like substr(v_branchattr,0,8)||'%'
and PlanPeriod <= tIndexCalNo and PlanPeriod > to_char(tIndexCalNo-6);

select nvl(v_StandPrem/v_Planvalue,0) into v_Rate from ldsysvar where sysvar = 'onerow';

return v_Rate;
End BranchOperationRate;


/

