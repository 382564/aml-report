create function calWorkDaysRate(EmployDate in Date)
  return number is
  Result number;
  v_first_day date;
  v_last_day date;
  v_days number;
  v_days2 number;
begin
  select trunc(EmployDate, 'month')
    into v_first_day
    from dual;

  select last_day(trunc(EmployDate, 'month') + 1)
    into v_last_day
    from dual;

  select count(*)
    into v_days
    from ldworkcalendar
   where caldate between EmployDate and v_last_day
     and datetype = 'Y';

  select count(*)
    into v_days2
    from ldworkcalendar
   where caldate between v_first_day and v_last_day
     and datetype = 'Y';

  if v_days2 = 0 then
    Result := 1;
  else
    Result := v_days/v_days2;
  end if;

  return(Result);
end calWorkDaysRate;


/

