create FUNCTION GETSTANDPREMRATE(ARISKCODE IN VARCHAR2,
                                            APAYINTV  IN INTEGER,
                                            AYEARS    IN INTEGER,
                                            APAYYEARS IN INTEGER)
  RETURN NUMBER IS
  RESULT     NUMBER := 0;
  V_YEARS    INTEGER := 0;
  V_PAYYEARS INTEGER := 0;

  ---------------------提数的标准保费-----------------------
BEGIN
  --支持险种123010，只有费率，其他字段在LARATESTANDPREM中都配置为-9
  --配置为-9时，表示查询费率时不考虑改字段
  --类似的险种也应如此配置
  V_YEARS    := NVL(AYEARS, 0);
  V_PAYYEARS := NVL(APAYYEARS, 0);

  --银保渠道标准

  IF APAYINTV = 0 THEN
    SELECT NVL((SELECT RATE
                 FROM LARATESTANDPREM
                WHERE RISKCODE = ARISKCODE
                  AND DECODE(PAYINTV, '-9', APAYINTV, PAYINTV) = APAYINTV
                  AND DECODE(YEAR, '-9', V_YEARS, YEAR) = V_YEARS),
               0)
      INTO RESULT
      FROM DUAL;
  ELSE
    SELECT NVL((SELECT RATE
                 FROM LARATESTANDPREM
                WHERE RISKCODE = ARISKCODE
                  AND DECODE(PAYINTV, '-9', APAYINTV, PAYINTV) = APAYINTV
                  AND DECODE(YEAR, '-9', V_YEARS, YEAR) = V_YEARS
                  AND DECODE(F01, '-9', V_PAYYEARS, F01) = V_PAYYEARS),
               0)
      INTO RESULT
      FROM DUAL;
  END IF;

  RETURN(RESULT);
END GETSTANDPREMRATE;


/

