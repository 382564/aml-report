create function fnc_345(c_GetDutyKind  char,c_InsuredNo char,c_ContNo char,c_PolNo  char,Je_gf number,c_amnt number) return number is
 Result number;
--dutykind char;
amnt  number;
realpay number;
rela  lcinsured.relationtomaininsured%TYPE;
sumIsd number;
t_amnt number;
t_Oamnt number;
t_birthday lcinsured.birthday%TYPE;
t_je_gf number;
t_cvalidate lcpol.cvalidate%TYPE;
t_managecom lcpol.signcom%TYPE;
appage number;
CURSOR t_CalSQLSet IS
    select  * from lcinsured where contno =c_contno;
begin
Result:=0;
amnt:=0;
realpay:=0;
rela :='';
sumIsd :=0;
t_je_gf:=0;
  --select c_GetDutyKind into dutykind from dual ;
  select count('X') into sumIsd from lcinsured where contno =c_ContNo and relationtomaininsured <>'00';
  select relationtomaininsured into rela from lcinsured where contno =c_ContNo and insuredno =c_InsuredNo;
  select cvalidate into t_cvalidate from lcpol where polno =c_PolNo;
  select nvl(signcom,'') into t_managecom from lcpol where polno =c_PolNo;
  --????????
  select basevalue into t_amnt from LLParaPupilAmnt where trim(comcode) =substr(t_managecom ,1,4) and startdate <=t_cvalidate and ((enddate is NULL) or enddate ='' or enddate>t_cvalidate) ;
  if (c_GetDutyKind ='101' or c_getdutykind ='102')  then   --?????????????
    if  rela ='00' then
     --???????????
     select nvl(sum(realpay),0) into realpay from llclaimdetail where customerno =c_InsuredNo  and polno =c_polno and givetype ='0'  and getdutykind in ('101','102') and exists (select 'X' from llclaim where clmno=llclaimdetail.clmno and clmstate in ('50','60'));
     --??????
      if sumIsd > 0 THEN
        FOR t_CalSQL IN t_CalSQLSet LOOP
          --????SQL??
          appage:=0;
          t_birthday := t_CalSQL.birthday;
          select floor(months_between (t_cvalidate ,t_birthday)/12) into appage from dual ;
          if appage >=18 then
             amnt :=amnt+0;
          else

             if c_amnt/(2*sumIsd)>t_amnt then
                amnt :=amnt +c_amnt/(2*sumIsd)-t_amnt ;
             else
                 amnt :=amnt+0;
             end if;
          end if;
        END LOOP;
      else
          amnt:=0;
      end if;
     --??????
     t_Oamnt:= amnt +c_amnt/2;
     amnt := amnt +c_amnt/2-realpay;
     --????????
     if (c_getdutykind ='102') then
        t_je_gf :=je_gf*amnt/c_amnt;
     else
         t_je_gf :=je_gf*t_Oamnt/c_amnt;
     end if;
     --????,?????????

  else   --????????????
      --???????????
      select nvl(sum(realpay),0) into realpay from llclaimdetail where customerno =c_InsuredNo  and polno =c_polno and givetype ='0'  and getdutykind in ('101','102') and exists (select 'X' from llclaim where clmno=llclaimdetail.clmno and clmstate in ('50','60'));
      amnt:=c_amnt/(2*sumIsd);
      select birthday into t_birthday from lcinsured where insuredno =c_InsuredNo and contno =c_ContNo;
      select floor(months_between (t_cvalidate ,t_birthday)/12) into appage from dual ;
      if appage <18 then
         if amnt >=t_amnt then
            amnt :=t_amnt;
         end if;
      end if;
      t_Oamnt:= amnt;
      amnt:=amnt-realpay;
      if (c_getdutykind ='102') then
        t_je_gf :=je_gf*amnt/c_amnt;
     else
         t_je_gf :=je_gf*t_Oamnt/c_amnt;
     end if;
  end if;
  end if;
  --???????????
  if (c_GetDutyKind ='100' )  then
      --???????????
      select nvl(sum(realpay),0) into realpay from llclaimdetail where customerno =c_InsuredNo  and polno =c_polno and givetype ='0'  and getdutykind in ('100') and exists (select 'X' from llclaim where clmno=llclaimdetail.clmno and clmstate in ('50','60'));
      amnt:=c_amnt/(sumIsd+1);
      amnt:=amnt-realpay;
      t_je_gf :=je_gf;
  end if;
  --????
  if amnt >=t_je_gf then
      result :=t_je_gf;
  else
      result :=amnt;
  end if;
  if result <0 then
     result :=0;
  end if;
  return(Result);
end fnc_345;


/

