create function fnc_222(c_caseNo char ,n_daysInHos number,n_fee number,d_injuryDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_maxDate date;
  d_limitDate Date;
begin

Result:=0;                               --?Result??

select max(endDate) into d_maxDate from LLCaseReceipt where CaseNo=c_CaseNo;	--???????

if d_lcgetStartDate<=d_startDate and d_injuryDate<=d_startDate and d_injuryDate<=d_lcgetEndDate  then
  if  d_maxDate<d_lcgetEndDate then    --??????????????????
    select n_fee into Result from Dual;
  else
    select d_injuryDate+30 into d_limitDate from dual ;	--????????????
    if  d_startDate<d_limitDate then   --????,????????????????
      if d_endDate<d_limitDate then       --?????????????
      	select n_fee into Result from Dual;
      else                                 --?????????????
      	select n_fee*(d_limitDate-d_startDate)/(n_daysInHos+1) into Result from Dual;
      end if;
    end if;
  end if;
end if;
  return(Result);

end fnc_222;


/

