create FUNCTION convert_dutycode(DutyCode char) return integer is
  Result integer;
begin
case
when (substr(DutyCode,6,1) = 0) then
    select 1 into Result from LDSysvar where sysvar = 'onerow';
when (substr(DutyCode,6,1) = 1) then
    select 2 into Result from LDSysvar where sysvar = 'onerow';
when (substr(DutyCode,6,1) = 2) then
    select 3 into Result from LDSysvar where sysvar = 'onerow';
when (substr(DutyCode,6,1) = 3) then
    select 4 into Result from LDSysvar where sysvar = 'onerow';
end case;
  return(Result);
end convert_dutycode;


/

