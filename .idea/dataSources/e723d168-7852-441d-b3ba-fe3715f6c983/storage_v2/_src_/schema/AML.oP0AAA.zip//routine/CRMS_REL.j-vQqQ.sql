create PROCEDURE CRMS_Rel(TSTRATDATE  IN VARCHAR2,
                                      TENDDATE    IN VARCHAR2,
                                      TCUSTOMERNO IN VARCHAR2,
                                      ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Rel C
      WHERE C.CLIENTNO = TCUSTOMERNO;

      --开始提数
      INSERT INTO MID_CR_Rel
        SELECT  DISTINCT A.Contno ContNo,
               A.Appntno ClientNo,
               'O' CusType,
               '1' RelaAppnt,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCCONT A,LCAPPNT C
         WHERE A.CONTTYPE = '1'
            AND A.APPFLAG <> '0'
            AND A.APPNTNO = C.APPNTNO
           AND A.APPNTNO = TCUSTOMERNO; --有客户号时，只通过客户号查询
      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Rel D
         WHERE D.CLIENTNO IN (SELECT C.APPNTNO
                              FROM LCCONT A, LCAPPNT C
                                WHERE A.CONTTYPE = '1'
                                 AND A.APPFLAG <> '0'
                                AND A.APPNTNO = C.APPNTNO
                                 AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                     TCDATE AND TMDATE); --没有客户号时，通过时间查询
        --开始提数
       INSERT INTO MID_CR_Rel
        SELECT  DISTINCT A.Contno ContNo,
               A.Appntno ClientNo,
               'O' CusType,
               '1' RelaAppnt,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCCONT A,LCAPPNT C
           WHERE A.CONTTYPE = '1'
             AND A.APPFLAG <> '0'
             AND A.APPNTNO = C.APPNTNO
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE; --没有客户号时，通过时间查询
        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_Rel;


/

