create function checkSplitAch(tManageCom in VARCHAR2,tBranchType in VARCHAR2,tIndexCalNo in VARCHAR2) return integer IS
-------------------?????????????????---------------------------
  ADDCOUNT   INTEGER;
begin
  select sum(count(distinct branchattr)) into ADDCOUNT from lacommision
  where wageno=tIndexCalNo
  and  branchtype=tBranchType
  and commdire<>'2'
  and managecom like concat(tManageCom,'%')
  group by agentcode having count(distinct branchattr)>1;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkSplitAch;


/

