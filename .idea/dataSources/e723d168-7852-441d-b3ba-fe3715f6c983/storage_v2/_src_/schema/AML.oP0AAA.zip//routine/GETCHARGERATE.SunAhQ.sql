create FUNCTION GETCHARGERATE(CRISKCODE IN VARCHAR2,
                                         CPAYINTV  IN NUMBER,
                                         CPAYYEAR  IN NUMBER,
                                         CPAYCOUNT IN NUMBER) RETURN NUMBER IS
  RESULT NUMBER;
BEGIN
  RESULT := 0;
  RETURN(RESULT);
END GETCHARGERATE;


/

