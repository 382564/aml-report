create FUNCTION getCvalidAmnt(strRiskcode in varchar
               ,strType in varchar
               ,iPayCount in integer
               ,strPayIntv in integer
               ,dAmnt in number
               ,dPrem in number
               ,dMult in number
               ,iInsuredAge in integer
               ,iGetAge in integer
               ,iInsureYears in integer
               ,iPayYears in integer
               ,iPassMonth in integer
               ,iPassYear in integer
               ,vGetStartDate date
               ,vPolNo in varchar2
               ) return number is

  CvalidAmnt number(15,2) :=0;

begin
declare

dParam number(3,2);
vPassMonths integer;
vCurrentDate date;
dInsuaccbala number(12,2);
begin
  --110?110B?118,143,144,708,293,294
  if strRiskcode in ('1101','110B','1181','1431','1441','7081','2931','2941') then
     CvalidAmnt := dAmnt;
     return CvalidAmnt;
  end if;

   --141
  if strRiskcode in ('1411') then
     CvalidAmnt:= (1+0.05*iPassYear)*dAmnt;
     return  CvalidAmnt;
  end if;
    --128?126?138
  if strRiskcode in ('1281','1261','1381') then
  select to_date(Sysdate,'YYYY-MM-DD') into vCurrentDate from dual;
      if(strPayIntv=1) then
       if vCurrentDate<vGetStartDate then
        CvalidAmnt := dPrem*1.5;
        return CvalidAmnt;
       else
        return CvalidAmnt;
       end if;
      end if;
      if(strPayIntv<>1) then
       if vCurrentDate<vGetStartDate then
        CvalidAmnt := dPrem*1.5*iPayCount;
        return CvalidAmnt;
       else
        return CvalidAmnt;
       end if;
      end if;
  end if;
    --146
  if(strRiskcode='1461') then

       CvalidAmnt := dMult*10000;
       return CvalidAmnt;

  end if;
   --108
   if(strRiskcode='1081') then
     if(strType='2') then
      CvalidAmnt:=dMult*40000;
      return CvalidAmnt;
      end if;
     if(strType<>'2') then
      CvalidAmnt:=dMult*20000;
      return CvalidAmnt;
      end if;
  end if;
      --145
    if(strRiskcode='1451') then
      if(strPayIntv=1) then
       CvalidAmnt:=dPrem*(1+0.03*iPassYear);
       return  CvalidAmnt;
      end if;
      if(strPayIntv<>1) then
        if(iPassYear<iPayYears) then
         CvalidAmnt:=dPrem*(iPassYear+1+0.03*iPassYear*(iPassYear+1)/2);
         return CvalidAmnt;
        end if;
        if(iPassYear>iPayYears) then
         CvalidAmnt:=dPrem*(iPayYears+0.03*iPayYears*(2*iPassYear-iPayYears+1)/2);
         return CvalidAmnt;
        end if;
   end if;
  end if;
      --104
  if(strRiskcode='1041') then
     CvalidAmnt:=dMult*10000;
     return CvalidAmnt;
  end if;
     --115
  if(strRiskcode='1151') then
   if((dMult*1000)<100000) then
     CvalidAmnt:=dMult*1000;
     return CvalidAmnt;
   end if;
   if((dMult*1000)>100000) then
     CvalidAmnt:=100000;
     return CvalidAmnt;
   end if;
  end if;
    --107
  if(strRiskcode='1071') then
     if(strPayIntv=1)then
      if (iInsuredAge+iPassYear)>=60 then
        CvalidAmnt := dPrem+dAmnt;
        return CvalidAmnt;
      end if;
      if (iInsuredAge+iPassYear)<60 then
        CvalidAmnt := dAmnt*4+dPrem;
        return CvalidAmnt;
      end if;
     end if;

     if(strPayIntv<>1) then
      if (iInsuredAge+iPassYear)>60 then
        CvalidAmnt := dAmnt+dPrem*iPayCount;
        return CvalidAmnt;
      end if;
      if (iInsuredAge+iPassYear)<60 then
        CvalidAmnt := dAmnt*4+dPrem*iPayCount;
        return CvalidAmnt;
      end if;
    end if;
   end if;

  --230?231?233?234?235?268
  if strRiskcode in ('2301','2311','2331','2341','2351','2681') then
   if(iPassYear<1) then
    CvalidAmnt:=dAmnt*0.1+dPrem;
    return CvalidAmnt;
   end if;
   if(iPassYear>=1) then
    CvalidAmnt:=dAmnt;
    return CvalidAmnt;
   end if;
  end if;


   --279 ,279??????,?????????????

   if strRiskcode in ('2791') then

    CvalidAmnt:=dAmnt;
    return CvalidAmnt;
   end if;

   --266,267 ?????

    if strRiskcode in ('2661','2671') then

    CvalidAmnt:=dAmnt;
    return CvalidAmnt;

    end if;

   --129?101?127?130?139?205?209?225?237?264?238?604?605?606?622 ?0

    if strRiskcode in ('1291','1011','1271','1301','1391',
                       '2051','2091','2251','2371','2641',
                       '2381','6041','6051','6061','6221') then
     return CvalidAmnt;
    end if;

   --265
   if strRiskcode in('2651') then
   if iPassYear<1 then
    CvalidAmnt:=dAmnt*01+dPrem;
    else
    CvalidAmnt:=dAmnt*(1+0.02*iPassYear);
    return  CvalidAmnt;
   end if;
   end if;

   --614,615
   if strRiskcode in('6141','6151') then
     if(strPayIntv=1) then
      CvalidAmnt:=dAmnt;
      return CvalidAmnt;
     end if;
     if(strPayIntv=2) then
      CvalidAmnt:=dAmnt*(iPassYear+1)/iInsureYears;
      return CvalidAmnt;
     end if;
     if(strPayIntv=5) then
      vPassMonths:=iPassYear*12+iPassMonth;
      CvalidAmnt:=dAmnt*(vPassMonths+1/(iInsureYears*12));
      return CvalidAmnt;
     end if;
   end if;

 --153
  if strRiskcode in ('1531') then
    CvalidAmnt:=dAmnt*3;
    return CvalidAmnt;
  end if;

 --603
   if strRiskcode in ('6031') then
/*    CvalidAmnt:=iPassMonth/(iInsureYears/12);*/

      vPassMonths:=iPassYear*12+iPassMonth;
      CvalidAmnt:=dAmnt*(vPassMonths+1/(iInsureYears*12));
    return CvalidAmnt;
  end if;

 --607
   if strRiskcode in ('6071') then
   if (iPassYear+iInsuredAge)<18 then
    return CvalidAmnt;
    else
    CvalidAmnt:=dAmnt*6;
   end if;
  end if;


 --608
   if strRiskcode in ('6081') then
   --CvalidAmnt:=iPassYear/iInsureYears;
   CvalidAmnt:=dAmnt*(iPassYear+1)/iInsureYears;
    return CvalidAmnt;
  end if;

 --902
   if strRiskcode in ('9021') then
     CvalidAmnt:=2200*dMult;
    return CvalidAmnt;
   end if;

   --618
   if strRiskcode in ('6181') then
    if iGetAge<=(iPassYear+iInsuredAge) then
    select decode(iPassYear,0,1.00,1,1.15,2,1.30,3,1.45,4,1.60,5,1.75
                           ,6,1.90,7,2.05,8,2.20,9,2.35,10,2.50,11,2.65
                           ,12,2.80,13,2.95,14,3.10,15,3.25,16,3.40,17,3.55
                           ,18,3.70,19,3.85,20,4.00,21,4.15,22,4.30,23,4.45
                           ,24,4.60,25,4.75,26,4.90,27,5.05,28,5.20,29,5.35,30,5.50)
     into dParam from dual;
     CvalidAmnt:=dAmnt*dParam;
     return CvalidAmnt;
    end if;
    if iGetAge>(iPassYear+iInsuredAge) then
      return CvalidAmnt;
    end if;
   end if;

   --619
   if strRiskcode in ('6191') then
    if iGetAge<=(iPassYear+iInsuredAge) then
    select decode(iPassYear,0,1.00,1,1.15,2,1.30,3,1.45,4,1.60,5,1.75
                           ,6,1.90,7,2.05,8,2.20,9,2.35,10,2.50,11,2.65
                           ,12,2.80,13,2.95,14,3.10,15,3.25,16,3.40,17,3.55
                           ,18,3.70,19,3.85,20,4.00,21,4.15,22,4.30,23,4.45
                           ,24,4.60,25,4.75,26,4.90,27,5.05,28,5.20,29,5.35,30,5.50)
     into dParam from dual;
     CvalidAmnt:=dAmnt*dParam;
     return CvalidAmnt;
    end if;
    if iGetAge>(iPassYear+iInsuredAge) then
      return CvalidAmnt;
    end if;
   end if;

 --258,??,???????

 /*   if strRiskcode in ('00258000') then
     return CvalidAmnt;
   end if;
 */

 --105?109?110A?131?132?133?134?135?136?137?142?147?148?150?155?156?201?210?215?216?221?227?232?236?240?241?242?257?278?301?325?601?602?609?701?611?613?616?617?623
 --??109??,?????????
   if strRiskcode in (
     '1051','110A','1311','1321','1331'
     ,'1341','1351','1361','1371','1421','1471'
     ,'1481','1501','1551','1561','2011','2101'
     ,'2151','2161','2211','2271','2321','2361'
     ,'2401','2411','2421','2571','2781','3011'
     ,'3251','6011','6021','6091','7011','6111'
     ,'6131','6161','6171','6231'
     ) then
     CvalidAmnt:=dAmnt;
     return CvalidAmnt;
   end if;

   --610
      if strRiskcode in ('6101') then
      if(iPassYear+iInsuredAge<66) then
       CvalidAmnt:=dAmnt*2;
       return CvalidAmnt;
      else
         CvalidAmnt:=dAmnt;
         return CvalidAmnt;
      end if;
      end if;


    --277
   if strRiskcode in ('2771') then
         CvalidAmnt:=dAmnt;
         return CvalidAmnt;
   end if;

   --286
   if strRiskcode in ('2861') then
   if iPassYear<1 then
    CvalidAmnt:=dPrem;
    else
    CvalidAmnt:=dAmnt;
    return  CvalidAmnt;
   end if;
   end if;

  --109
     if strRiskcode in ('1091') then
   if iPassYear<1 then
    CvalidAmnt:=dPrem;
    else
    CvalidAmnt:=(1 + 0.05 * iPassYear)*dAmnt;
    return  CvalidAmnt;
   end if;
   end if;

  --628
    if strRiskcode in ('6281') then
    	CvalidAmnt:=dAmnt*3;
    	return CvalidAmnt;
    end if;
  --6301
    if strRiskcode in ('6301') then
    	CvalidAmnt:=dAmnt*2;
    	return CvalidAmnt;
    end if;
  --332
    if strRiskcode in ('3321') then
    	CvalidAmnt:=dAmnt*5;
    	return CvalidAmnt;
    end if;
  --634\635
    if strRiskcode in ('6341','6351') then
      if(iPassYear+iInsuredAge<66) then
         CvalidAmnt:=dAmnt*3;
         return CvalidAmnt;
      else
         CvalidAmnt:=dAmnt*1.5;
         return CvalidAmnt;
    	end if;
    end if;
 --280
    if strRiskcode in ('2801') then
	    if iPassYear<1 then
	    	CvalidAmnt:=dAmnt;
	    	return CvalidAmnt;
	    end if;
	    if iPassYear>=1 then
	    	CvalidAmnt := ( 1 + (iPassYear-1)*0.02 ) * dAmnt;
	    	return CvalidAmnt;
	    end if;
    end if;
   --9041 9031
    if strRiskcode in ('9031') then
      select insuaccbala into dInsuaccbala from lcinsureacc
      where polno = vPolNo and insuaccno = '903000';
       if dInsuaccbala > dPrem then
        return 3*dInsuaccbala;
       else
        return 3*dPrem;
       end if;
    end if;

   --9041 9031
    if strRiskcode in ('9041') then
      select insuaccbala into dInsuaccbala from lcinsureacc
      where polno = vPolNo and insuaccno = '904000';
       if dInsuaccbala > dPrem then
        return 3*dInsuaccbala;
       else
        return 3*dPrem;
       end if;
    end if;

   end;
  return(CvalidAmnt);
end getCvalidAmnt;


/

