create function CalDePFYCCount(tPolno in varchar2,tFlag in varchar2,tTransMoney in number)
return number is Result number(10,2);

--?????????????
--????:
--tPolno  ???
--tFlag   ???????
--tTransMoney ????

Mpolno_check varchar2(2); -- ???? 1,??;2,???.
LongShort_flag varchar2(2);  --????? 1,??;0,??.
check_flag varchar2(2);  --?????????


begin
  --???????????
    select count(*)  into  Mpolno_check from lacommision a,lmriskapp b where a.riskcode=b.riskcode
    and b.subriskflag='M' and a.polno=tPolno;

    if(Mpolno_check=0)then  --????????0
       Result := 0;
    else  --??
       --???????
       select count(*) into LongShort_flag from lacommision a, lmriskapp e
	     where a.riskcode = e.riskcode and a.payyears > 1 and e.subriskflag = 'M'
	     and a.polno = tPolno;
       if(LongShort_flag>=1) then  --??
    		  if( tflag='1' and tTransMoney<0) then --???????,?????
    		    Result := -1;
          else
            Result := 1;
		      end if;
		   else  --??
		     select count(*) into check_flag from lacommision a, lmriskapp e
			   where a.riskcode = e.riskcode and a.payyears = 1 and e.subriskflag = 'M'
			   and a.polno = tPolno;
         if(check_flag>=1) then
			      select round(nvl(tTransMoney, 0) / 600, 2) into Result from dual;
		     else
			      Result := 0;
		     end if;
       end if;
    end if;
  return(Result);
end CalDePFYCCount;


/

