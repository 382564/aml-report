create function         GetAccountDateByACCTRACE(tmakedate in date,
                                                       tpolno    in varchar2,
                                                       tconttype in varchar2)
 return date is
  Result      date;
  tcvalidate date;
  newdate date;
begin

  if tmakedate  is null then 
     return(Result);
     end if ;
  if tconttype = 'G' then 
   
   
    --?个单号
    select cvalidate
      into tcvalidate
      from (select cvalidate, polno,signdate
              from lcpol
            union
            select cvalidate, polno,signdate from lbpol)
     where polno = tpolno;
  else
    --团单险种号
    select cvalidate
      into tcvalidate
      from (select cvalidate, grppolno,(select signdate from lcgrpcont where lcgrpcont.grpcontno=lcgrppol.grpcontno) signdate
              from lcgrppol
            union
            select cvalidate, grppolno,(select signdate from lbgrpcont where lbgrpcont.grpcontno=lbgrppol.grpcontno) signdate from lbgrppol)
     where grppolno = tpolno;
  end if;

  --生效日与签单日 取大者
  if tcvalidate > tmakedate then
    newdate := tcvalidate;  
  else
    newdate := tmakedate;
  end if;
 Result:=newdate;
  return(Result);
end GetAccountDateByACCTRACE;


/

