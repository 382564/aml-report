create function calAgentSalesTax(v_Commission in number, v_ManageCom in varchar2)
  return number is
  Tax number;
  v_BaseMin NUMBER(12,2);
  v_TaxRate NUMBER(12,6);
begin
  if length(v_ManageCom) >= 4 then
    SELECT basemin, taxrate
      INTO v_BaseMin, v_TaxRate
      FROM (SELECT basemin, taxrate
              FROM latax
             WHERE taxtype = '01'
               AND taxcode = 1
               AND substr(v_ManageCom, 1, 6) like managecom||'%'
             ORDER BY managecom)
     WHERE rownum = 1;
  else
    v_BaseMin := 30000;
    v_TaxRate := 0.056000;
  end if;

  if v_Commission < v_BaseMin then
    Tax := 0;
  else
    Tax := v_Commission * v_TaxRate;
  end if;
  return round(Tax,2);
exception
  when NO_DATA_FOUND then
    v_BaseMin := 30000;
    v_TaxRate := 0.056000;
    if v_Commission < v_BaseMin then
      Tax := 0;
    else
      Tax := v_Commission * v_TaxRate;
    end if;
    return round(Tax,2);
end calAgentSalesTax;


/

