create function getLFCprem_4(startdate in date,enddate in date,tManageCom in varchar) return char is
  Result_Endo varchar2(10);
  pragma autonomous_transaction;
 begin


 Declare
 v_cvalidate date;
 v_insuyearflag char(1);
 v_years   integer;
 v_PayIntv integer;
 v_PayEndYear integer;
 v_payendyearflag char(1);
 v_SaleChnl char(2);
 v_AgentCom char(20);
 v_agentcode char(10);
 v_mult  number(20,5);
 v_amnt  number(12,2);
 v_riskperiod char(1);

 c_actugetno         Char(20);
 c_Endorsementno     Char(20);
 c_feeoperationtype  Char(6);
 v_riskcode          varchar2(10);
 c_polno             Char(20);
 d_getmoney          Number(12,2);
 c_managecom         Char(10);
 c_enteraccdate      Date;
 c_contno            Char(20);
 v_Edorvalidate      Date;
 c_edorno            Char(20);
 c_edortype         Char(2);
 v_startdate        Date;
 v_enddate          Date;

 v_cursor_lfcendo lfcendo_fee%rowtype;

 cursor v_cursor_lpedoritem is

 --????????????????????????????
  Select a.edorno,a.edortype,b.riskcode,b.polno,a.managecom ,Edorvalidate,a.contno,Sum(getmoney)
   From lpedoritem a ,lppol b
   where 1=1
       and a.managecom like tManageCom||'%'
       and A.EDORVALIDATE >= v_startdate
       and A.EDORVALIDATE <= v_enddate
       --And a.edorno = '6020070330003839'
       And a.edorno = b.edorno
       And getmoney = 0
   Group By a.edorno,a.edortype,b.riskcode,b.polno,a.managecom,Edorvalidate ,a.contno
   Having Sum(getmoney) = 0

    Union

 Select a.edorno,a.edortype,b.riskcode,b.polno,a.managecom ,Edorvalidate,a.contno ,Sum(getmoney)
   From lpedoritem a,lcpol b
   where 1=1
       and a.managecom like tManageCom||'%'
       --And a.edorno = '6020070330003839'
       and A.EDORVALIDATE >= v_startdate
       and A.EDORVALIDATE <= v_enddate
       And b.polno = b.mainpolno
       And a.contno = b.contno
       And a.getmoney = 0
       And Not Exists(Select 1 From lppol c Where c.edorno = a.edorno)
       Group By a.edorno,a.edortype,b.riskcode,b.polno,a.managecom,Edorvalidate ,a.contno
       Having Sum(getmoney) = 0
       ;

 begin

 --execute immediate  'truncate table lfcendo_fee';

 v_startdate :=startdate;
 v_enddate  := enddate;

open v_cursor_lpedoritem;

 loop
 fetch v_cursor_lpedoritem Into c_edorno,c_edortype,v_riskcode,c_polno,c_managecom,v_Edorvalidate,c_contno,d_getmoney;
 exit when v_cursor_lpedoritem%notfound;

 Begin

   Select cvalidate,years,insuyearflag,PayIntv,PayEndYear,payendyearflag,SaleChnl,AgentCom,agentcode
          ,mult,amnt
   Into v_cvalidate,v_years,v_insuyearflag,v_PayIntv,v_PayEndYear,v_payendyearflag,v_SaleChnl,v_AgentCom,v_agentcode
          ,v_mult,v_amnt
   from lcpol
   where polno = c_polno;


 --dep_name????

    v_cursor_lfcendo.dept_name :=  trim(getCode('com',c_managecom));

   --???
    v_cursor_lfcendo.entno := c_edorno;


    --????
     v_cursor_lfcendo.gp_type := 'P';


     -- ???
     v_cursor_lfcendo.polno := c_contno;


     --???
     v_cursor_lfcendo.certno := c_contno;


     --????
     v_cursor_lfcendo.brno := getriskseq(c_polno, c_contno);


     --????
     v_cursor_lfcendo.plan_code := v_riskcode;

     --????
     v_cursor_lfcendo.pol_yr := Getcuryear(v_Edorvalidate,v_cvalidate);


     --????(?)
     v_cursor_lfcendo.period := ChangeDateToMonth(v_years, v_insuyearflag);


     --??
     v_cursor_lfcendo.prem_type := trim(getCode('payintv', to_char(v_PayIntv)));


     --????(?)
        If v_payintv <> 0 Then
				v_cursor_lfcendo.Prem_Term := Changedatetomonth(v_Payendyear, v_Payendyearflag);
        Else
				v_cursor_lfcendo.Prem_Term := 0;
        End If;


   --??????
     v_cursor_lfcendo.Busi_Src_Type := trim(getCode('salechnl', v_SaleChnl));


   --??????
     v_cursor_lfcendo.Agt_Code := v_AgentCom;

     --?????

     v_cursor_lfcendo.AgentNo := ChangeAgentcode(v_agentcode);


   --????
     v_cursor_lfcendo.POS_Type := trim(getCode('edortype', c_edortype));

  -- ????
     v_cursor_lfcendo.Amt_Type := getAmtype_Endo_Fee('',c_edortype,'',v_RiskCode);

     --??
     v_cursor_lfcendo.CurNo := '01';



     --??????????
     v_cursor_lfcendo.Amt_Incured_cnvt := d_getmoney;


     --?????
     v_cursor_lfcendo.Units := v_mult;


     --?????
     v_cursor_lfcendo.Sum_Ins := v_amnt;


		 --????(????)
     v_cursor_lfcendo.Proc_date := v_Edorvalidate;


     --???(????)
     v_cursor_lfcendo.Gained_date := v_Edorvalidate;


   insert into lfcendo_fee values v_cursor_lfcendo;
   commit;
Exception
 When no_data_found Then
  Null;
 End;
end loop;

close v_cursor_lpedoritem;
return Result_Endo;
 end;
end getLFCprem_4;


/

