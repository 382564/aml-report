create FUNCTION calAddagent(vAgentCode  in varchar2,
                                       vbranchtype in varchar2,
                                       vIndexCalNo in varchar2)
  RETURN NUMBER IS
  Result  number := 0;
  attend  number := 0;
  AppntNo number := 0;
  money   number := 0;
BEGIN
  select count(distinct a.AppntNo)
    into AppntNo
    from lacommision a
   where a.wageno = vIndexCalNo
     and a.agentcode = vAgentCode
     and a.branchtype = '1'
     and a.transtype = 'ZC'
        -- and a.years>1
     and not exists (select 'Y'
            from lpedoritem
           where edortype = 'WT'
             and contno = a.contno)
     and not exists
   (select 'Y'
            from lacommision c
           where c.branchtype = '1'
             and c.AppntNo = a.AppntNo
             and c.contno <> a.contno
             and not exists
           (select 'Y'
                    from lpedoritem
                   where edortype = 'WT'
                     and contno = c.contno)
             and c.wageno is not null
             and ((c.wageno < a.wageno) or
                 (c.wageno = a.wageno and c.signdate < a.signdate)));
  SELECT CASE
           WHEN AppntNo < 3 THEN
            0
           WHEN 3 <= AppntNo AND AppntNo < 5 THEN
            0.1
           WHEN 5 <= AppntNo THEN
            0.2
           ELSE
            0
         END
    INTO attend
    FROM dual;
  select round(nvl(sum(FirstPension) * attend, 0), 2)
    into money
    from LAIndexInfo a
   where a.agentcode = vAgentCode
     and indextype = '00'
     and branchtype = vbranchtype
     and IndexCalNo = vIndexCalNo;
  if money > 20000 then
    Result := 20000;
  else
    Result := money;
  end if;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
END;

/

