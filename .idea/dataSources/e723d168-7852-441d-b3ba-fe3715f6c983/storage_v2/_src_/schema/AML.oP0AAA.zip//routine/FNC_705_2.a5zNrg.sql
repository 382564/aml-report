create function fnc_705_2(c_cureType char ,n_daysInHos number,n_fee number,d_injuryDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date) return number is
  Result number;
  d_limitDate Date;
begin

Result:=0;                               --?Result??

select least((d_injuryDate+179),(d_lcgetEndDate+29)) into d_limitDate from dual ;	--????????????
-------------------------------------------------------------------------------------------------------------
if d_lcgetStartDate<=d_startDate and d_startDate<=d_limitDate and d_injuryDate<=d_startDate then   --????,????????????????
  if d_endDate<=(d_limitDate+1) then       --?????????????--??????????????????,?????????????
      	select n_fee into Result from Dual;
  else                                 --?????????????
      	select n_fee*(d_limitDate-d_startDate+1)/n_daysInHos into Result from Dual;
  end if;

end if;
----------------------------------------------------------------------------------------------------------------
  return(Result);
end fnc_705_2;


/

