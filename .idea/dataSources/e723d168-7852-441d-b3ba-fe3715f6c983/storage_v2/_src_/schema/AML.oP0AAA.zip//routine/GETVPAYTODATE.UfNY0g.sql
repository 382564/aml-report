create function getvPayToDate(vPayCount in varchar2,vPayIntv in varchar2,vPayDate in date,vPayToDate in date) return date is
  Result date;
  tDate      date;
begin
  declare
  tPayCount  integer;
  tPayIntv   integer;

  begin
  tPayCount := vPayCount;
  tPayIntv  := vPayIntv;
  if tPayCount = 1 then

     tDate := vPayDate;

  end if;

  if tPayCount <> 1 and tPayIntv <> 0 then
  tDate := vPayToDate;

  end if;


  end ;

  return(tDate);
end getvPayToDate;


/

