create function getavoirdupois_bank(ContNo1 char, CustomerNo1 char) return integer is
  Result integer;
begin
  select distinct ImpartParam into result from LCCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 And Impartver='03' and Impartcode='001' and ImpartParamNo='2';
  return(Result);
end getavoirdupois_bank;


/

