create FUNCTION CALPIECECBPol(
       tStartDate date, --????
       tEndDate date,   --????
       tAgentcode Ljtempfee.Agentcode%TYPE
       ) return number is
LongRisk number;
ShortRisk number;
ShortRiskSm number;
v_Piece number;

begin
--??????
select nvl(count(distinct(a.polno)),0) into LongRisk from LMRiskApp b,ljapayperson a
where a.makedate>=tStartDate and a.makedate<=tEndDate
and b.subriskflag='M' and b.Riskperiod='L'
and a.Riskcode=b.Riskcode
and a.Agentcode=tAgentcode
;

--??????500???

select nvl(count(distinct(a.polno)),0) into ShortRisk from LMRiskApp b,ljapayperson a
where a.makedate>=tStartDate and a.makedate<=tEndDate
and b.subriskflag='M' and b.Riskperiod<>'L' and a.SumActuPayMoney>='500'
and a.Riskcode=b.Riskcode
and a.Agentcode=tAgentcode;

--??????500????
select nvl(sum(a.SumActuPayMoney),0)/500 into ShortRiskSm from LMRiskApp b,ljapayperson a
where a.makedate>=tStartDate and a.makedate<=tEndDate
and b.subriskflag='M' and b.Riskperiod<>'L' and a.SumActuPayMoney<'500'
and a.Riskcode=b.Riskcode
and a.Agentcode=tAgentcode;

 v_Piece:=LongRisk+ShortRisk+ShortRiskSm;

return v_Piece;
end CALPIECECBPol;


/

