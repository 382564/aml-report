create function Cv_riskcode( tRiskcode in varchar2,
                                      tPayEndYear in integer,
                                      tSex in varchar2,
                                      tAge in integer,
                                      tInsuredYear in integer,
                                      tAmnt in number)
--????  tRiskcode in varchar2
--????  tPayEndYear in integer
--?????  tSex in varchar2
--????  tAge in integer
--????  tInsuredYear in integer




return NUMBER is
  result NUMBER;
  tNum   integer;
  tcashvalue number;
  tVpu   number;
begin
  select  (case when tRiskCode in('TLA11','TLA12','TLA13')
               then 5
/*               when tRiskCode in('LSEA11','LSEA12','LSEA13','LSEA14')
               then 2
               when tRiskCode in('EA11','EA12','EA13')
               then 3
               when tRiskCode in('DA11','DA12','DA13')
               then 4*/
               else 5
            end )
            into tNum from dual;

/*   if tNum= 1 then
       select nvl(max(cashvalue),0) into tcashvalue from cv_TLA where payendyear=tPayEndYear and sex=tSex and age=tAge and duration=tInsuredYear;
   end if;

   if tNum= 2 then
       select nvl(max(cashvalue),0) into tcashvalue from cv_LSEA where payendyear=tPayEndYear and sex=tSex and age=tAge and duration=tInsuredYear;
   end if;

   if tNum= 3 then
       select nvl(max(cashvalue),0) into tcashvalue from cv_EA where payendyear=tPayEndYear and sex=tSex and age=tAge and duration=tInsuredYear;
   end if;

   if tNum= 4 then
       select nvl(max(cashvalue),0) into tcashvalue from cv_DA where payendyear=tPayEndYear and sex=tSex and age=tAge and duration=tInsuredYear;
   end if;*/

   if tNum= 5 then
      tcashvalue:=0;
   end if;

   select nvl(max(vpu),0) into tVpu from lmduty where dutycode in(select dutycode from lmriskduty where riskcode =tRiskcode);

   if tVpu= 0 then
       result:=0;
   else
       result:=tAmnt*tcashvalue/tVpu;
   end if;

   return (result);


end Cv_riskcode;


/

