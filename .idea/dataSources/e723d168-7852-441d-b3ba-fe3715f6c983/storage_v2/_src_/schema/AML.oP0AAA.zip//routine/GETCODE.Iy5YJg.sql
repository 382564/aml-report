create function GETCODE(tPmPam in VARCHAR2, tPm2 in VARCHAR2) return varchar is
  rCode varchar(20);
  temp char(10);
begin
  temp :=tPm2;
  if  trim(lower(tPmPam)) = 'com' then
     select comcodeisc into rCode
     from lfcomtoisccom2
     where comcode like  substr(tPm2,0,4)||'%'
     and rownum = 1;
  else
     if (length(trim(tPm2))<>2 and tPmPam ='salechnl') then
         temp := '0' || tPm2;
     end if;
     Begin
     select SHORTNAME into rCode from ldcode2 where trim(codetype) = trim(tPmPam) and trim(code) = trim(temp);
      EXCEPTION
       WHEN NO_DATA_FOUND THEN
       NULL;
      END;
  end if;

  return(rCode);
end GETCODE;


/

