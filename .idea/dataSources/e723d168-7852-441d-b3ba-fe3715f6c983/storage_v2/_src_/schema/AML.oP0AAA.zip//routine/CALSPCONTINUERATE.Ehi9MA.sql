create FUNCTION calSPContinueRate(vAgentCode  IN VARCHAR2,
                                             vAgentGrade IN VARCHAR2,
                                             vIndexCalNo IN VARCHAR2) RETURN NUMBER IS
  RESULT NUMBER := 1;
BEGIN
  RETURN(RESULT);
END calSPContinueRate;


/

