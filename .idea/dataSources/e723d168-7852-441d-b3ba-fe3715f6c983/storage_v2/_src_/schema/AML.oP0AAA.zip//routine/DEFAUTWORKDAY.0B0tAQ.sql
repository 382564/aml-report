create function defautWorkDay(vDate in DATE) return Varchar2 is
  Result Varchar2(10); --返回值 Y-工作日 N-非工作日
begin
  if to_char(vDate, 'D') in ('1', '7') then
    --默认规则周六周日为非工作日
    Result := 'N';
  else
    Result := 'Y';
  end if;
  return(Result);
end defautWorkDay;


/

