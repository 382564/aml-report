create function checkRebate(tManageCom in VARCHAR2,tBranchType in VARCHAR2,tIndexCalNo in VARCHAR2) return integer IS
-------------------??A02??A02?????????????---------------------------
  ADDCOUNT   INTEGER;

begin

  select nvl(count(*),0) into ADDCOUNT from lacommision,latree where
  lacommision.agentcode=latree.agentcode
  and latree.agentgrade>='A02'
  and lacommision.commdire='1'
  and lacommision.payyear<1
  and lacommision.branchtype=tBranchType
  and to_char(latree.startdate,'yyyyMM')<=tIndexCalNo
  and lacommision.wageno = tIndexCalNo
  and lacommision.directwage<>lacommision.fyc
  and lacommision.managecom like concat(trim(tManageCom),'%');

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkRebate;


/

