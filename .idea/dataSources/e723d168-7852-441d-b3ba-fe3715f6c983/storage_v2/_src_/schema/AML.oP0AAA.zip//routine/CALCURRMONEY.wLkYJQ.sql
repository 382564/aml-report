create FUNCTION CALCURRMONEY (tAgentCode in varchar2,tIndexCalNo in varchar2) return number is

  Result         number := 0;

begin

  select nvl(InitPension,0)
  +nvl(StartCareerRwd,0)
  +nvl(ToFormalRwd,0)
  +nvl(FirstPension,0)
  +nvl(ContiuePension,0)
  +nvl(WiseBonus,0)
  +nvl(PersonBonus,0)
  +nvl(RearBonus,0)
  +nvl(AddBonus,0)
  +nvl(SpecialPension,0)
  +nvl(PosSdy,0)
  +nvl(TeamDirManaSdy,0)
  +nvl(RearedSdy,0)
  +nvl(TeamBonus,0)
  +nvl(DepDirManaSdy,0)
  +nvl(AddDepSdy,0)
  +nvl(DepBonus,0)
  +nvl(BaseWage,0)
  +nvl(RearAreaSdy,0)
  +nvl(DisBaseWage,0)
  +nvl(AddFYC,0)
  +nvl(T31,0)
  +nvl(T32,0)
  +nvl(T33,0)
  +nvl(T17,0)
  +nvl(T29,0)
  ---nvl(T6,0)
  -nvl(T8,0)
  -nvl(T28,0)
  +nvl(T17,0)
  +nvl(T16,0)
  +nvl(T40,0)----?????
  +nvl(T41,0)----????????
  into Result from laindexinfo where trim(agentcode) = tAgentCode and trim(indexcalno)=trim(tIndexCalNo) and trim(indextype)='01';


  return(Result);
end CALCURRMONEY;


/

