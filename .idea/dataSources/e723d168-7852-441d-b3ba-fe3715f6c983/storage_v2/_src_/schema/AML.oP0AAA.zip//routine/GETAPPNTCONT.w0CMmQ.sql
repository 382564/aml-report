create function getappntcont(v_AppntNo IN varchar) RETURN NUMBER IS
  v_Count NUMBER := 0;
BEGIN
  select count(1)
    into v_Count
    from contrelaappnt
   where appntno = v_AppntNo;
  RETURN v_Count;
END;

/

