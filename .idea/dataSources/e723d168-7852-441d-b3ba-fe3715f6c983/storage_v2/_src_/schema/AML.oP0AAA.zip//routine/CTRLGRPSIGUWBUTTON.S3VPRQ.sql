create Function ctrlGrpSigUWButton(t_ContNo in lccont.contno%type,tLoadFlag varchar2) return CHAR is
  t_str_arr         VARCHAR2(1000);

  t_sql        LMCalMode.calsql%TYPE;
  t_result          VARCHAR2(100);
  begin
--tLoadFlag --4-???? ,

if(tLoadFlag='4') then
--??????
 select count(*) into t_result
  from lldutyctrl where grpcontno= t_Contno ;

  t_str_arr:='buttonClaimDutyCtrl'||'|'||t_result;

--?????
  select count(*) into t_result
  from lcgrpfee where grpcontno= t_Contno ;

  t_str_arr:= t_str_arr||'^'||'buttonManageFee'||'|'||t_result;

 --??????
 /*select count(*) into t_result
  from lcgrpfee where grpcontno= t_Contno ;
  */
  t_str_arr:= t_str_arr||'^'||'buttonShowManageFee'||'|'||t_result;
  --???????
  select count(*) into t_result
  from es_doc_relation where bussno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'buttonScanDoc'||'|'||t_result;

  --??????
  --
  select count(*) into t_result
  from lccontplan where grpcontno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'buttonContPlan'||'|'||t_result;

  --???????
  select count(*) into t_result
  from lcgrpissuepol where grpcontno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'buttonIssueQuery'||'|'||t_result;

  else

  --??????
  --?????? autoCheck
  select count(*) into t_result
  from LCGUWError where grpcontno= t_Contno ;

  t_str_arr:='autoCheck'||'|'||t_result;

  --???????
  select count(*) into t_result
  from es_doc_relation where bussno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'scan'||'|'||t_result;

 --t_str_arr:=t_str_arr||'^'||'buttonManageFee'||'|'||t_result;

  --??????
   select count(*) into t_result
  from lcgrpfee where grpcontno= t_Contno ;

  t_str_arr:= t_str_arr||'^'||'grpManageFee'||'|'||t_result;

  --????? manageFeeQuery
  t_str_arr:= t_str_arr||'^'||'manageFeeQuery'||'|'||t_result;

  --????? grpPolReason
  select count(*) into t_result
  from lcgrpissuepol where grpcontno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'grpPolReason'||'|'||t_result;

  --??????  RealFee
  select count(*) into t_result
  from lccontplan where grpcontno= t_Contno and rownum=1;
  t_str_arr:=t_str_arr||'^'||'RealFee'||'|'||t_result;
end if;


  ----------????
  return(t_str_arr);
End ctrlGrpSigUWButton;


/

