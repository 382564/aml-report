create FUNCTION getSqlColumn
(
cComCodeISC in varchar2,
cItemCode in varchar2,
cRepType in varchar2,
cStatYear in varchar2,
cStatMon in varchar2,
cUpItemCode in varchar2,
cParentComCodeISC in varchar2,
cLayer in varchar2,
cStatValue in varchar2,
cRemark in varchar2,
cComCode in varchar2
)
  return varchar2 as
  tComCodeISC varchar2(10);
  tParentComCodeISC varchar2(10);
  tUpItemCode varchar2(10);
  tLayer varchar2(10);
  tReMark varchar2(10);

  begin
  tComCodeISC:=cComCodeISC;
  tUpItemCode:=cUpItemCode;
  tParentComCodeISC:=cParentComCodeISC;
  tLayer:=cLayer;
  tRemark:=cRemark;


  select max(ComCodeISC) into tComCodeISC from ComToISCCom where trim(ComCode)=trim(cComCode);
  select max(ParentComCodeISC) into tParentComCodeISC from LDCOMISC where trim(ComCodeISC)= trim(cComCodeISC);

  select max(UpItemCode),max(Layer),max(ReMark)
  into tUpItemCode,tLayer,tReMark
  from LFItemRela
  where ItemCode=cItemCode;

  return('||'||tComCodeISC||'||'||','||cItemCode||','||cRepType||','||cStatYear||','||cStatMon||',''||'||tParentComCodeISC||'||'','||tParentComCodeISC||','||tLayer||','||cStatValue||','||tRemark||' ');

  end;


/

