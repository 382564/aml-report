create function checkbefwageseries1(tManageCom in VARCHAR2
                                              ,tIndexCalNo in VARCHAR2)
return integer is
  --????:2006-10-16 LL
  --????:????????lacommision??branchattr,branchcode,agentgroup2-4??
  tCount    integer;
 begin
  --?8621,8637?????????
  /*
  if substr(tManageCom,1,4) = '8637' then
    return 1;
  end if;
  */

  --??lacommision ??agentgroup2-4??tIndexCalNo?????
  select count(1) into tCount from lacommision a where a.branchtype = '1'
   and a.wageno = tIndexCalNo and (a.agentgroup2 is null or a.agentgroup3 is null or a.agentgroup4 is null)
   --and substr(a.managecom,1,4) not in ('8637')
   and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
   and a.managecom like tManageCom||'%'
   and  not exists (select c.agentcode
          from laagent c, labranchgroup d
         where c.branchcode = d.agentgroup
         and a.agentcode=c.agentcode
           and d.state = '1'
           and d.branchtype = '1');

  if tCount > 0 then
    return -1;
  end if;

  --??lacommision ??branchcode ???agentcode?laagent??branchcode???????
  select count(1) into tCount from lacommision a where a.branchtype = '1' and a.branchcode <>(
    select branchcode from laagent where agentcode = a.agentcode)
   and a.wageno = tIndexCalNo
    and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
   and a.managecom like tManageCom||'%';

  if tCount > 0 then
    return -1;
  end if;

  --??lacommision ??branchattr ?branchcode??????
  select count(1) into tCount from lacommision a where  a.branchtype = '1' and a.branchcode <> (
     select agentgroup from labranchgroup where branchtype = '1' and branchattr= a.branchattr
     union
     select agentgroup from labranchgroupb where branchtype = '1' and branchattr= a.branchattr
   ) and a.branchattr not in
   ('861100000106002035','861100000501002021','861300020501001014','861301020101002017',
    '861302000105002043','863203000103003032','863203230101001022','863203820101001020',
    '863212030101001006','863301810102001016','863305000102005039','863305000102005040',
    '863310240102004014','863310810101010003','863500000103001009','863500000103001010',
    '863500000104001022','863502000102001021','863502000102001022','861300030101004018',
    '863210840102001003')
    and a.wageno = tIndexCalNo
    and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
    and a.managecom like tManageCom||'%';

  if tCount > 0 then
    return -1;
  end if;

  --??lacommision ??branchattr ?agentgroup2??????
  --modify by renhl 2009-03-19 ??rpad 70
  select count(1) into tCount from lacommision a where  a.branchtype = '1' and (a.agentgroup2 is not null
    and a.agentgroup2 <> (
     select agentgroup from labranchgroup where branchtype = '1' and branchattr= substr(a.branchattr,1,15)
      and branchlevel = '02'
     union
     select agentgroup from labranchgroupb where branchtype = '1' and branchattr= substr(a.branchattr,1,15)
      and branchlevel = '02' )
  )
  and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
  and a.branchattr not in
  ('861100000106002035','861100000501002021','861300020501001014','861301020101002017',
   '861302000105002043','863203000103003032','863203230101001022','863203820101001020',
   '863212030101001006','863301810102001016','863305000102005039','863305000102005040',
   '863310240102004014','863310810101010003','863500000103001009','863500000103001010',
   '863500000104001022','863502000102001021','863502000102001022','861300030101004018',
   '863210840102001003')
   and a.wageno = tIndexCalNo
   and a.managecom like tManageCom||'%'
   and  not exists (select c.agentcode
          from laagent c, labranchgroup d
         where c.branchcode = d.agentgroup
         and a.agentcode=c.agentcode
           and d.state = '1'
           and d.branchtype = '1');

  if tCount > 0 then
    return -1;
  end if;

  --??lacommision ??branchattr ?agentgroup3??????
  select count(1) into tCount from lacommision a where  a.branchtype = '1' and (a.agentgroup3 is not null
    and a.agentgroup3 <> (
    select agentgroup from labranchgroup where branchtype = '1' and branchattr= substr(a.branchattr,1,12)
     and branchlevel = '03'
    union
    select agentgroup from labranchgroupb where branchtype = '1' and branchattr= substr(a.branchattr,1,12)
     and branchlevel = '03' )
  )
  and a.branchattr not in
  ('861100000106002035','861100000501002021','861300020501001014','861301020101002017',
   '861302000105002043','863203000103003032','863203230101001022','863203820101001020',
   '863212030101001006','863301810102001016','863305000102005039','863305000102005040',
   '863310240102004014','863310810101010003','863500000103001009','863500000103001010',
   '863500000104001022','863502000102001021','863502000102001022','861300030101004018',
   '863210840102001003')
   and a.wageno = tIndexCalNo
   and a.managecom like tManageCom||'%'
   and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
   and  not exists (select c.agentcode
          from laagent c, labranchgroup d
         where c.branchcode = d.agentgroup
         and a.agentcode=c.agentcode
           and d.state = '1'
           and d.branchtype = '1');

  if tCount > 0 then
    return -1;
  end if;

  --??lacommision ??branchattr ?agentgroup4??????
  select count(1) into tCount from lacommision a where  a.branchtype = '1' and (a.agentgroup4 is not null
    and a.agentgroup4 <> (
    select agentgroup from labranchgroup where branchtype = '1' and branchattr= substr(a.branchattr,1,10)
      and branchlevel = '04'
    union
    select agentgroup from labranchgroupb where branchtype = '1' and branchattr= substr(a.branchattr,1,10)
      and branchlevel = '04' )
  )
  and a.branchattr not in
  ('861100000106002035','861100000501002021','861300020501001014','861301020101002017',
   '861302000105002043','863203000103003032','863203230101001022','863203820101001020',
   '863212030101001006','863301810102001016','863305000102005039','863305000102005040',
   '863310240102004014','863310810101010003','863500000103001009','863500000103001010',
   '863500000104001022','863502000102001021','863502000102001022','861300030101004018',
   '863210840102001003')
   and a.wageno = tIndexCalNo
   and a.managecom like tManageCom||'%'
   and exists (select '1' from laagent where branchtype='1' and agentcode=a.agentcode)
   and  not exists (select c.agentcode
          from laagent c, labranchgroup d
         where c.branchcode = d.agentgroup
         and a.agentcode=c.agentcode
           and d.state = '1'
           and d.branchtype = '1');

  if tCount > 0 then
    return -1;
  end if;

  return 1;
end checkbefwageseries1;


/

