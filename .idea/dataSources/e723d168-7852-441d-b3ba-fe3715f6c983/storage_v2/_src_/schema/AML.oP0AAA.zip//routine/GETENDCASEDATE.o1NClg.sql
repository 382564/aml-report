create function GETENDCASEDATE(tCaseNo in VARCHAR) return date is
  Result date;
begin
  select endcasedate into Result from llcase where caseno = tCaseNo;
  return(Result);
end GETENDCASEDATE;


/

