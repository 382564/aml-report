create function AdvanceMonthNum(tagentcode in varchar2, tempend in date,tReturnType in varchar2)
                                   return integer  is --??????
  MonthNum                      integer ;
  tStart                        date;
  days                          varchar2(2);
  monthbegin                    date;
  tstartdate                    date;
  tEmployLimit                  number(10,2):=0;
  tLimitLine                    date;
begin
  ---??????
  if tReturnType='S' then
  select employdate into tStart from laagent where agentcode=tagentcode;
  else
  ---??????
    if tReturnType='G' then
       select startdate into tStart from latree where agentcode=tagentcode;
    end if;
  end if;
  days:=to_char(tstart,'dd');
  monthbegin:=tempend;--to_date(concat(twageno,'01'),'yyyy-mm-dd');
  tstartdate:=trunc(tStart,'month');

  --?????
  select to_date(varvalue,'yyyy-mm-dd') into tLimitLine from lasysvar where vartype='LimitLine';
  if tStart<=tLimitLine then
     select to_number(varvalue) into tEmployLimit from Lasysvar where vartype='EmployLimit';
  else
     select to_number(varvalue) into tEmployLimit from Lasysvar where vartype='EmployLimitNew';
  end if;
  --select to_number(varvalue) into tEmployLimit from Lasysvar where vartype='EmployLimit';
  if days<=tEmployLimit then
    MonthNum:=months_between(monthbegin,tstartdate)+1;
  else
    MonthNum:=months_between(monthbegin,tstartdate);
  end if;
  return(MonthNum);
end AdvanceMonthNum;


/

