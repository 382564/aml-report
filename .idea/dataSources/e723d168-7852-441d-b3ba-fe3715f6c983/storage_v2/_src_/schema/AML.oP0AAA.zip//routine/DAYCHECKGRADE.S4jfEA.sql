create function DayCheckGrade(cAgentCode in varchar2, cCalDate in date, cAgentGrade in varchar2) return integer is
--pragma autonomous_transaction;
--??cAgentCode???cCalDate????cAgentGrade??,???????????
  Result integer; -- 1:???? 0:????
  --????:
  --    1???cAgentCode?????????cCalDate??
  --    2???cAgentCode????cCalDate????????cAgentGrade
  --?????????:
  --    1?cAgentGrade?????tStartDate?cCalDate??,???
  --    2??cAgentGrade?????tStartDate?cCalDate??,cAgentCode???????
  tFlag varchar2(1);
  --trow temagentcode%rowtype;
begin

  Result:=0;
  tFlag:='N';

  --??cAgentCode????????????cCalDate??
  select 'Y'
  into tFlag
  from latree
  where agentgrade=cAgentGrade
  and startdate<=cCalDate
  and agentcode=cAgentCode;

  if tFlag='Y' then
     Result:=1;
  else
      tFlag:='N';
      --??cAgentCode????cCalDate????????cAgentGrade
      select 'Y'
      into tFlag
      from dual
      where
             (
              select max(distinct(agentgrade))
              from latreeb
              where startdate=
               (
                select max(startdate)
                from latreeb
                where startdate<=cCalDate
                and agentcode=cAgentCode
               )--????????????
              --and enddate>=cCalDate
              and agentcode=cAgentCode
             )=cAgentGrade --???????????????????cAgentGrade
             and
             (
              select startdate
              from latree
              where agentcode=cAgentCode
             )>cCalDate
            ;
      if tFlag='Y' then
         Result:=1;
      end if;
  end if;
  /*if Result=1 then
     trow.agentcode:=cAgentCode;
     insert into temagentcode values trow;
     commit;
  end if;            */
  return(Result);
end DayCheckGrade;


/

