create FUNCTION getcurrname
 (
 currency VARCHAR default 24
 )
  RETURN VARCHAR IS
   Vcurrname VARCHAR(24);
  BEGIN

    select currname into Vcurrname from ldcurrency where currcode=currency;
    return Vcurrname;
end getcurrname;


/

