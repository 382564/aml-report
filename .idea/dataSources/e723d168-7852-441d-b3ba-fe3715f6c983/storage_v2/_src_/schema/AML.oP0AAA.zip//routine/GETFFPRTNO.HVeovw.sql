create function getFFPrtNo(p_actugetno   varchar2,
                                      p_otherno     varchar2,
                                      p_othernotype varchar2)
  return varchar2 is
  tempPrtNo INTEGER;
  Result    varchar2(20);
begin
  select count(1)
    into tempPrtNo
    from ljagetendorse a
   where a.actugetno = p_actugetno
     and a.otherno = p_otherno
     and a.othernotype = p_othernotype;
  -- 参数从ljaget表中获取
  if tempPrtNo = 0 then

     -- 暂收费退费
    if p_othernotype = '4' then
      select ljt.otherno
        into Result
        from ljtempfee ljt
       where ljt.tempfeeno = p_otherno;
      -- 理赔付费
    elsif p_othernotype = '5' then
      select lc.prtno
        into Result
        from ljagetclaim lp, lccont lc
       where lp.actugetno = p_actugetno
         and lp.contno = lc.contno
         and rownum = 1;
      -- 溢缴退费  -- 个险
    elsif p_othernotype = '6' then
      select lct.prtno
        into Result
        from lccont lct
       where lct.contno = p_otherno;
      -- 溢缴退费  -- 团险
    elsif p_othernotype = '8' then
      select lct.prtno
        into Result
        from lcgrpcont lct
       where lct.grpcontno = p_otherno;
       ---续期实收回退
    elsif p_othernotype='14' then
      select lct.prtno
        into Result
        from lccont lct
       where lct.contno = p_otherno;
      -- 保全付费
      -- 为了满期金/生存金需求改造
    elsif p_othernotype = '10' then
      select decode((select lcc.prtno
                      from ljagetendorse lja, lccont lcc
                     where lja.actugetno = p_actugetno
                       and lja.contno = lcc.contno
                       and rownum = 1),
                    '',
                    (select lcc.prtno
                       from ljagetdraw lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.contno = lcc.contno
                        and rownum = 1),
                    (select lcc.prtno
                       from ljagetendorse lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.contno = lcc.contno
                        and rownum = 1))
        into Result
        from dual;
        -- 红利付费
        elsif p_othernotype = '7' then
           select decode((select lcc.prtno
                      from ljagetendorse lja, lccont lcc
                     where lja.actugetno = p_actugetno
                       and lja.contno = lcc.contno
                       and rownum = 1),
                    '',
                    (select lcc.prtno
                       from LJABONUSGET lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.otherno = lcc.contno
                        and rownum = 1),
                    (select lcc.prtno
                       from ljagetendorse lja, lccont lcc
                      where lja.actugetno = p_actugetno
                        and lja.contno = lcc.contno
                        and rownum = 1))
           into Result
           from dual;
      -- 网销手续费支付
    elsif p_othernotype = '12' then
      select lct.prtno
        into Result
        from lccont lct
       where lct.contno = p_otherno;
     --团险保全付费
   elsif p_othernotype = '3' then
       select lcc.prtno
        into Result
        from lpgrpedoritem a, lccont lcc
       where a.edoracceptno = p_otherno
        and a.grpcontno = lcc.grpcontno
         and rownum=1;

    else
      select lct.prtno
        into Result
        from lccont lct
       where lct.contno = p_otherno;
    end if;
  else
    -- 参数直接从ljagetendorse表中获取
    select lcc.prtno
      into Result
      from ljagetendorse lja, lccont lcc
     where lja.actugetno = p_actugetno
       and lja.contno = lcc.contno
       and rownum = 1;
  end if;
  return(Result);
end getFFPrtNo;

/

