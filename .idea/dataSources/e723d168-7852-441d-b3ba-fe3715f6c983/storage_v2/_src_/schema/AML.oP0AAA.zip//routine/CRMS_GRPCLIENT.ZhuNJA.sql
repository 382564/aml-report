create PROCEDURE CRMS_GRPCLIENT(TSTRATDATE  IN VARCHAR2,
                                           TENDDATE    IN VARCHAR2,
                                           tCustomerNo IN VARCHAR2,
                                           ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (tCustomerNo IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Client A
       WHERE a.clientno = tCustomerNo
         AND a.conttype = '02'
         AND NOT EXISTS
       (SELECT 1 FROM LCCONT B WHERE A.Clientno = B.APPNTNO);
      --开始提数
      INSERT INTO MID_CR_Client
        SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                        A.GRPNAME NAME,
                        NULL BIRTHDAY,
                        NULL AGE,
                        NULL SEX,
                        NULL CARDTYPE,
                        NULL CARDID,
                        '' CardExpireDate,
                        '02' CLIENTTYPE,
                        '' WORKPHONE,
                        '' FAMILYPHONE,
                        '' TELEPHONE,
                        '' OCCUPATION,
                        A.BUSINESSTYPE BusinessType， '' INCOME,
                        A.Grpname GrpName,
                        LC.GRPADDRESS ADDRESS, --单位地址
                        LC.GRPZIPCODE ZipCode, --邮编
                        '' NATIONALITY,
                        LP.MANAGECOM ComCode,
                        '02' ContType,
                        A.BUSREGNUM BusinessLicenseNo,
                        A.Comno OrgComCode, --组织机构代码
                        A.Taxregnum TAXREGNUM, --税务登记号
                        A.CORPORATION COMCORPORATIONNO, --单位法人代表
                        '' LegalPersonCardType,
                        A.Corporationidno LegalPersonCardID, --法人代表证件号码
                        A.SATRAP LinkMan,
                        '' ComRegistArea,
                        A.GRPNATURE ComRegistType,
                        '' ComBusinessArea,
                        A.MAINBUSSINESS ComBusinessScope,
                        '' AppntNum,
                        A.Peoples ComStaffSize,
                        A.GRPNATURE GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        A.Contrshar HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,
                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC
         WHERE A.CUSTOMERNO = LP.APPNTNO
           AND EXISTS (SELECT 1
                  FROM LCGRPCONT C
                 WHERE C.APPNTNO = A.CUSTOMERNO
                   AND C.APPFLAG <> '0'
                   AND A.CUSTOMERNO = LC.CUSTOMERNO
                   AND a.customerno = tCustomerNo) --有客户号时，只通过客户号查询
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           and LC.ADDRESSNO =
               (select max(addressno)
                  from LCGRPADDRESS
                 where A.CUSTOMERNO = CUSTOMERNO)

        union

        SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                        A.GRPNAME NAME,
                        NULL BIRTHDAY,
                        NULL AGE,
                        NULL SEX,
                        NULL CARDTYPE,
                        NULL CARDID,
                        '' CardExpireDate,
                        '02' CLIENTTYPE,
                        '' WORKPHONE,
                        '' FAMILYPHONE,
                        '' TELEPHONE,
                        '' OCCUPATION,
                        A.BUSINESSTYPE BusinessType， '' INCOME,
                        A.Grpname GrpName,
                        LC.GRPADDRESS ADDRESS, --单位地址
                        LC.GRPZIPCODE ZipCode, --邮编
                        '' NATIONALITY,
                        LP.MANAGECOM ComCode,
                        '02' ContType,
                        A.BUSREGNUM BusinessLicenseNo,
                        A.Comno OrgComCode, --组织机构代码
                        A.Taxregnum TAXREGNUM, --税务登记号
                        A.CORPORATION COMCORPORATIONNO, --单位法人代表
                        '' LegalPersonCardType,
                        A.Corporationidno LegalPersonCardID, --法人代表证件号码
                        A.SATRAP LinkMan,
                        '' ComRegistArea,
                        A.GRPNATURE ComRegistType,
                        '' ComBusinessArea,
                        A.MAINBUSSINESS ComBusinessScope,
                        '' AppntNum,
                        A.Peoples ComStaffSize,
                        A.GRPNATURE GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        A.Contrshar HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,
                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC, LPEDORITEM e
         WHERE A.CUSTOMERNO = LP.APPNTNO
           AND EXISTS (SELECT 1
                  FROM LCGRPCONT C
                 WHERE C.APPNTNO = A.CUSTOMERNO
                   AND C.APPFLAG <> '0'
                   AND A.CUSTOMERNO = LC.CUSTOMERNO
                   AND a.customerno = tCustomerNo) --有客户号时，只通过客户号查询
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           and lp.grpcontno = e.grpcontno
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           and LC.ADDRESSNO =
               (select max(addressno)
                  from LCGRPADDRESS
                 where A.CUSTOMERNO = CUSTOMERNO)

        union

        SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                        A.GRPNAME NAME,
                        NULL BIRTHDAY,
                        NULL AGE,
                        NULL SEX,
                        NULL CARDTYPE,
                        NULL CARDID,
                        '' CardExpireDate,
                        '02' CLIENTTYPE,
                        '' WORKPHONE,
                        '' FAMILYPHONE,
                        '' TELEPHONE,
                        '' OCCUPATION,
                        A.BUSINESSTYPE BusinessType， '' INCOME,
                        A.Grpname GrpName,
                        LC.GRPADDRESS ADDRESS, --单位地址
                        LC.GRPZIPCODE ZipCode, --邮编
                        '' NATIONALITY,
                        LP.MANAGECOM ComCode,
                        '02' ContType,
                        A.BUSREGNUM BusinessLicenseNo,
                        A.Comno OrgComCode, --组织机构代码
                        A.Taxregnum TAXREGNUM, --税务登记号
                        A.CORPORATION COMCORPORATIONNO, --单位法人代表
                        '' LegalPersonCardType,
                        A.Corporationidno LegalPersonCardID, --法人代表证件号码
                        A.SATRAP LinkMan,
                        '' ComRegistArea,
                        A.GRPNATURE ComRegistType,
                        '' ComBusinessArea,
                        A.MAINBUSSINESS ComBusinessScope,
                        '' AppntNum,
                        A.Peoples ComStaffSize,
                        A.GRPNATURE GrpNature,
                        '' FoundDate,
                        '' HolderKey,
                        A.Contrshar HolderName,
                        '' HolderCardType,
                        '' HolderCardID,
                        '' HolderOccupation,
                        '' HolderRadio,
                        '' HolderOtherInfo,
                        '' RelaSpecArea,
                        TRUNC(SYSDATE, 'dd') MAKEDATE,
                        TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

          FROM LDGRP          A,
               LCGRPCONT      LP,
               LCGRPADDRESS   LC,
               lxreportdetail lp,
               lxihtrademain  lx
         WHERE A.CUSTOMERNO = LP.APPNTNO
           AND EXISTS (SELECT 1
                  FROM LCGRPCONT C
                 WHERE C.APPNTNO = A.CUSTOMERNO
                   AND C.APPFLAG <> '0'
                   AND A.CUSTOMERNO = LC.CUSTOMERNO
                   AND a.customerno = tCustomerNo) --有客户号时，只通过客户号查询
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           and lp.dealno = lx.dealno
           and lx.csnm = a.customerno
           AND A.CUSTOMERNO = LC.CUSTOMERNO
           and LC.ADDRESSNO =
               (select max(addressno)
                  from LCGRPADDRESS
                 where A.CUSTOMERNO = CUSTOMERNO);

      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Client d
         WHERE d.clientno IN
               (SELECT a.customerno
                  FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC
                 WHERE A.CUSTOMERNO = LP.APPNTNO
                   AND EXISTS (SELECT 1
                          FROM LCGRPCONT C
                         WHERE C.APPNTNO = A.CUSTOMERNO
                           AND C.APPFLAG <> '0'
                           AND GREATEST(C.CVALIDATE, C.SIGNDATE) BETWEEN
                               TCDATE AND TMDATE) --没有客户号时，通过时间查询
                   AND LC.CUSTOMERNO = A.CUSTOMERNO
                   and lp.addressNo =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)
                   AND LC.ADDRESSNO =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)

                union
                SELECT a.customerno
                  FROM LDGRP          A,
                       LCGRPCONT      LP,
                       LCGRPADDRESS   LC,
                       lxreportdetail lp,
                       lxihtrademain  lx
                 WHERE A.CUSTOMERNO = LP.APPNTNO
                   AND EXISTS
                 (SELECT 1
                          FROM LCGRPCONT C
                         WHERE C.APPNTNO = A.CUSTOMERNO
                           AND C.APPFLAG <> '0'
                           AND lx.dealdate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
                   and lp.dealno = lx.dealno
                   and lx.csnm = a.customerno
                   AND LC.CUSTOMERNO = A.CUSTOMERNO
                   and lp.addressNo =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)
                   AND LC.ADDRESSNO =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)

                union
                SELECT a.customerno
                  FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC, lpedoritem e
                 WHERE A.CUSTOMERNO = LP.APPNTNO
                   AND EXISTS
                 (SELECT 1
                          FROM LCGRPCONT C
                         WHERE C.APPNTNO = A.CUSTOMERNO
                           AND C.APPFLAG <> '0'
                           AND e.edorvalidate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
                   and e.grpcontno = lp.grpcontno
                   AND LC.CUSTOMERNO = A.CUSTOMERNO
                   and lp.addressNo =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)
                   AND LC.ADDRESSNO =
                       (select max(addressno)
                          from LCGRPADDRESS
                         where A.CUSTOMERNO = CUSTOMERNO)); --没有客户号时，通过时间查询*\
        --开始提数
        INSERT INTO MID_CR_Client
          SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                          A.GRPNAME NAME,
                          NULL BIRTHDAY,
                          NULL AGE,
                          NULL SEX,
                          NULL CARDTYPE,
                          NULL CARDID,
                          '' CardExpireDate,
                          '02' CLIENTTYPE,
                          '' WORKPHONE,
                          '' FAMILYPHONE,
                          '' TELEPHONE,
                          '' OCCUPATION,
                          A.BUSINESSTYPE BusinessType， '' INCOME,
                          A.Grpname GrpName,
                          LC.GRPADDRESS ADDRESS, --单位地址
                          LC.GRPZIPCODE ZipCode, --邮编
                          '' NATIONALITY,
                          LP.MANAGECOM ComCode,
                          '02' ContType,
                          A.BUSREGNUM BusinessLicenseNo,
                          A.Comno OrgComCode, --组织机构代码
                          A.Taxregnum TAXREGNUM, --税务登记号
                          A.CORPORATION COMCORPORATIONNO, --单位法人代表
                          '' LegalPersonCardType,
                          A.Corporationidno LegalPersonCardID, --法人代表证件号码
                          A.SATRAP LinkMan,
                          '' ComRegistArea,
                          A.GRPNATURE ComRegistType,
                          '' ComBusinessArea,
                          A.MAINBUSSINESS ComBusinessScope,
                          '' AppntNum,
                          A.Peoples ComStaffSize,
                          A.GRPNATURE GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          A.Contrshar HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,
                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

            FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC
           WHERE A.CUSTOMERNO = LP.APPNTNO
             AND EXISTS (SELECT 1
                    FROM LCGRPCONT C
                   WHERE C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND GREATEST(C.CVALIDATE, C.SIGNDATE) BETWEEN
                         TCDATE AND TMDATE) --没有客户号时，通过时间查询
             AND LC.CUSTOMERNO = A.CUSTOMERNO
             and lp.addressNo =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO)
             AND LC.ADDRESSNO =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO)

          union

          SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                          A.GRPNAME NAME,
                          NULL BIRTHDAY,
                          NULL AGE,
                          NULL SEX,
                          NULL CARDTYPE,
                          NULL CARDID,
                          '' CardExpireDate,
                          '02' CLIENTTYPE,
                          '' WORKPHONE,
                          '' FAMILYPHONE,
                          '' TELEPHONE,
                          '' OCCUPATION,
                          A.BUSINESSTYPE BusinessType， '' INCOME,
                          A.Grpname GrpName,
                          LC.GRPADDRESS ADDRESS, --单位地址
                          LC.GRPZIPCODE ZipCode, --邮编
                          '' NATIONALITY,
                          LP.MANAGECOM ComCode,
                          '02' ContType,
                          A.BUSREGNUM BusinessLicenseNo,
                          A.Comno OrgComCode, --组织机构代码
                          A.Taxregnum TAXREGNUM, --税务登记号
                          A.CORPORATION COMCORPORATIONNO, --单位法人代表
                          '' LegalPersonCardType,
                          A.Corporationidno LegalPersonCardID, --法人代表证件号码
                          A.SATRAP LinkMan,
                          '' ComRegistArea,
                          A.GRPNATURE ComRegistType,
                          '' ComBusinessArea,
                          A.MAINBUSSINESS ComBusinessScope,
                          '' AppntNum,
                          A.Peoples ComStaffSize,
                          A.GRPNATURE GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          A.Contrshar HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,
                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

            FROM LDGRP          A,
                 LCGRPCONT      LP,
                 LCGRPADDRESS   LC,
                 lxreportdetail lp,
                 lxihtrademain  lx
           WHERE A.CUSTOMERNO = LP.APPNTNO
             AND EXISTS (SELECT 1
                    FROM LCGRPCONT C
                   WHERE C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND lx.dealdate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
             and lp.dealno = lx.dealno
             and lx.csnm = a.customerno
             AND LC.CUSTOMERNO = A.CUSTOMERNO
             and lp.addressNo =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO)
             AND LC.ADDRESSNO =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO)

          union

          SELECT DISTINCT A.CUSTOMERNO CLIENTNO,
                          A.GRPNAME NAME,
                          NULL BIRTHDAY,
                          NULL AGE,
                          NULL SEX,
                          NULL CARDTYPE,
                          NULL CARDID,
                          '' CardExpireDate,
                          '02' CLIENTTYPE,
                          '' WORKPHONE,
                          '' FAMILYPHONE,
                          '' TELEPHONE,
                          '' OCCUPATION,
                          A.BUSINESSTYPE BusinessType， '' INCOME,
                          A.Grpname GrpName,
                          LC.GRPADDRESS ADDRESS, --单位地址
                          LC.GRPZIPCODE ZipCode, --邮编
                          '' NATIONALITY,
                          LP.MANAGECOM ComCode,
                          '02' ContType,
                          A.BUSREGNUM BusinessLicenseNo,
                          A.Comno OrgComCode, --组织机构代码
                          A.Taxregnum TAXREGNUM, --税务登记号
                          A.CORPORATION COMCORPORATIONNO, --单位法人代表
                          '' LegalPersonCardType,
                          A.Corporationidno LegalPersonCardID, --法人代表证件号码
                          A.SATRAP LinkMan,
                          '' ComRegistArea,
                          A.GRPNATURE ComRegistType,
                          '' ComBusinessArea,
                          A.MAINBUSSINESS ComBusinessScope,
                          '' AppntNum,
                          A.Peoples ComStaffSize,
                          A.GRPNATURE GrpNature,
                          '' FoundDate,
                          '' HolderKey,
                          A.Contrshar HolderName,
                          '' HolderCardType,
                          '' HolderCardID,
                          '' HolderOccupation,
                          '' HolderRadio,
                          '' HolderOtherInfo,
                          '' RelaSpecArea,
                          TRUNC(SYSDATE, 'dd') MAKEDATE,
                          TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME

            FROM LDGRP A, LCGRPCONT LP, LCGRPADDRESS LC, lpedoritem e
           WHERE A.CUSTOMERNO = LP.APPNTNO
             AND EXISTS
           (SELECT 1
                    FROM LCGRPCONT C
                   WHERE C.APPNTNO = A.CUSTOMERNO
                     AND C.APPFLAG <> '0'
                     AND e.edorvalidate BETWEEN TCDATE AND TMDATE) --没有客户号时，通过时间查询
             and e.grpcontno = lp.grpcontno
             AND LC.CUSTOMERNO = A.CUSTOMERNO
             and lp.addressNo =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO)
             AND LC.ADDRESSNO =
                 (select max(addressno)
                    from LCGRPADDRESS
                   where A.CUSTOMERNO = CUSTOMERNO);

        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_GRPCLIENT;


/

