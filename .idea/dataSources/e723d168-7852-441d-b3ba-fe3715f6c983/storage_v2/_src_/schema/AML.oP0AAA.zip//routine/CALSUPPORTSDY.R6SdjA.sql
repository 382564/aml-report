create FUNCTION "CALSUPPORTSDY" (tAgentCode in varchar2 , tAgentGrade in varchar2, tAreaType in varchar2,TempBegin in date,TempEnd in date) return number is
  tED           date;
  tID           date;
  tStartDate    date;
  tCount        integer := 0;
  tPremium      number  := 0;
  tAgentState   varchar2(2);
  tPremStand    number  := 0;

  Result        number  := 0;
---???????
begin
  select employdate,indueformdate,startdate,agentstate into tED,tID,tStartDate,tAgentState
  from laagenttreeview
  where trim(agentcode) = trim(tAgentCode);

  --????
  if tAgentState >= '02' then
    return(0);
  end if;

  --?????????
  if tID = tED then
    return(0);
  end if;

  --??A01??
  if tID <> tStartDate then
   return(0);
  end if;

  --???????2003-02-23 ??????
  --zsj Delete-2004-2-24 :??????????
  /*select nvl(count(*),0) into tCount from LACommision
  where trim(CommDire) = '1'
        and caldate >= TempBegin
        and caldate <= TempEnd
        and RiskCode in (select distinct RiskCode from LMRiskApp where trim(RiskPeriod) = 'L')
        and trim(AgentCode) = trim(tAgentCode)
        ;

  if tCount = 0 then
    return(0);
  end if;*/

  tPremium := JUDGEPREM(TempBegin,TempEnd,tAgentCode);
  --???????????
  select nvl(premstand,0),nvl(rewardmoney,0) into tPremStand,Result from LAWageRadix
  where trim(AgentGrade) = trim(tAgentGrade)
        and trim(AreaType)   = trim(tAreaType)
        and trim(WageCode) = 'W00001'
        ;

  if tPremium < tPremStand then
    return(0);
  end if;

  return(Result);
end CALSUPPORTSDY;


/

