create function getMoney_by_LJAGetEndorse(p_getMoney  in NUMBER,
                                                     p_actugetNo in varchar2,
                                                     p_riskCode  in varchar2)
  return NUMBER is
  Result        NUMBER(12, 2);
  v_getMoney_GB NUMBER(12, 2);
  v_riskCode    varchar2(10);
begin

  select nvl(get_RiskCode_byLJAGetEndorse(p_actugetNo), p_riskCode)
    into v_riskCode
    from dual;

  select SUM(ABS(GetMoney))
    into v_getMoney_GB
    from LJAGetEndorse
   where actugetno = p_actugetNo
     and feefinatype = 'GB';

  select nvl(v_getMoney_GB, 0) into v_getMoney_GB from dual;

  if v_riskCode = p_riskCode then
    Result := p_getMoney - v_getMoney_GB;
  else
    Result := p_getMoney;
  end if;

  return(Result);

end getMoney_by_LJAGetEndorse;


/

