create function calworkdate(s_StartDate date, s_Day integer)
  return date is
  Result date;
  flag   integer;
begin
  if s_Day > 0 then
    select count(1)
      into flag
      from LDHoliday
     where Holidays = s_StartDate + 1;
  else
    select count(1)
      into flag
      from LDHoliday
     where Holidays = s_StartDate - 1;
  end if;

  if flag = 0 and s_Day > 0 then
    select s_StartDate + 1 into Result from dual;
  elsif flag = 0 and s_Day < 0 then
    select s_StartDate - 1 into Result from dual;
  elsif flag > 0 and s_Day > 0 then
    select calworkdate(s_StartDate + 1, 1) into Result from dual;
  elsif flag > 0 and s_Day < 0 then
    select calworkdate(s_StartDate - 1, -1) into Result from dual;
  end if;

  if s_Day > 1 then
    select calworkdate(Result, s_Day - 1) into Result from dual;
  elsif s_Day < -1 then
    select calworkdate(Result, s_Day + 1) into Result from dual;
  end if;
  return(Result);
end calworkdate;


/

