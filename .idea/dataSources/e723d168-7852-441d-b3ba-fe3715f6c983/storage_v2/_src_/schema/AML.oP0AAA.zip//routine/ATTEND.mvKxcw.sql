create FUNCTION ATTEND(vAgentCode  in varchar2,
                                  vIndexCalNo in varchar2,
                                  vmanagecom  in varchar2,
                                  vAgentgrade in varchar2) RETURN NUMBER IS
  Result number := 0;
  attend number := 0;
  tmonth number := 0;
BEGIN
  --职务津贴=领取金额*出席率系数  （于晋升之月起发放，期限为一年，发放期间若降级不予发放。即最多发放12个月）
  select MONTHS_BETWEEN(to_date(vIndexCalNo, 'yyyymm'),trunc(a.startdate, 'mm'))
    into tmonth
    from latree a
   where a.agentcode = vAgentCode
     and a.AgentSeries in ('B', 'C');
  if tmonth <= 11 then
    SELECT CASE WHEN PRESENCERATE < 0.5 THEN
              0
             WHEN 0.5 <= PRESENCERATE AND PRESENCERATE < 0.8 THEN
              0.8
             WHEN 0.8 <= PRESENCERATE THEN
              1
             ELSE
              0
           END
      INTO attend
      FROM LATTENDANCE
     where agentcode = vAgentCode
       and years = vIndexCalNo
       and vmanagecom like managecom || '%';
    if vAgentgrade = 'B01' then
      Result := round(2000 * attend, 2);
    elsif vAgentgrade = 'B02' then
      Result := round(4000 * attend, 2);
    else
      Result := round(8000 * attend, 2);
    end if;
  end if;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
END;

/

