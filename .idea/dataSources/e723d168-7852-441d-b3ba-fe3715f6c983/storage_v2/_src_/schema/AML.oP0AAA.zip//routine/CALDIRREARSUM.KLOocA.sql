create FUNCTION calDirRearSum(tAgentCode in varchar2,tAgentGrade in varchar2,StartDate in date,EndDate in date,tType in varchar2) return number is
  tValue    number := 0;
  Result    number := 0;
  tBranchAttr varchar2(255);

  cursor c_View is
    select * from latreeaccessory
    where (trim(agentgrade) = trim(tAgentGrade) or trim(agentgrade)=concat(substr(trim(tAgentGrade),0,2),decode(mod(substr(trim(tAgentGrade),3,1),2),0,substr(trim(tAgentGrade),3,1)+1,1,substr(trim(tAgentGrade),3,1)-1)))
      and commbreakflag = '0' and trim(rearagentcode) = trim(tAgentCode);

--????????????FYC
begin

  for v_View in c_View Loop
    ---tjj change 0101---
    tBranchAttr:= getbranchattr(v_View.agentgroup);
    --tType:'p'- ????;'F'- ??FYC
    if tType = 'P' then
     select nvl(sum(StandPrem),0) into tValue from lacommision
      where commdire = '1'
        and trim(branchattr) like concat(trim(tBranchAttr),'%')
        and payyear < 1
        and caldate >= StartDate
        and caldate <= EndDate;
    else
      select nvl(sum(fyc),0) into tValue from lacommision
      where commdire = '1'
        and trim(branchattr) like concat(trim(tBranchAttr),'%')
        and payyear < 1
        and caldate >= StartDate
        and caldate <= EndDate;
   end if;

   Result := Result + tValue;
  end loop;

  return(Result);
end calDirRearSum;


/

