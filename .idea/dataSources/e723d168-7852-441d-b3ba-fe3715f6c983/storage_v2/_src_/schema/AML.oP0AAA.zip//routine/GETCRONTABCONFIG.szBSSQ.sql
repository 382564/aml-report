create function getCrontabConfig(
tString varchar2,tPos integer)
return  varchar2 is
Result varchar2(1000);

tTempPos integer;
begin


return(getStringBySymbol(tString,'#',tPos));
end getCrontabConfig;


/

