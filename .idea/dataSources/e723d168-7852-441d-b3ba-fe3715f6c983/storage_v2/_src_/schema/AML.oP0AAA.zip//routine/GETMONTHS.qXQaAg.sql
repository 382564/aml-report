create function GetMonths( CalBegin in date,CalEnd in date) return integer is
  MonthNum                integer ;
  days                    varchar2(2);
  monthbegin              date;
  tstartdate              date;
  tEmployLimit            number(20,6):=0;
  tLimitLine              date;
begin
  ---??????
  days:=to_char(CalBegin,'dd');
  --monthbegin:=trunc(CalEnd,'month');
  --tstartdate:=trunc(CalBegin,'month');
  --???trunc,??lastatsegment???????? 2006-1-20 zxs
  select to_date(yearmonth||'01','yyyy-mm-dd') into tstartdate from lastatsegment where stattype='5' and startdate<=CalBegin and enddate>=CalBegin;
  select to_date(yearmonth||'01','yyyy-mm-dd') into monthbegin from lastatsegment where stattype='5' and startdate<=CalEnd and enddate>=CalEnd;
  select to_date(varvalue,'yyyy-mm-dd') into tLimitLine from lasysvar where vartype='LimitLine';
  if CalBegin<=tLimitLine then
   if days >= 26 then
      days := 1;
   end if;
   select to_number(varvalue) into tEmployLimit from lasysvar where vartype='EmployLimit';
  else
   select to_number(varvalue) into tEmployLimit from lasysvar where vartype='EmployLimitNew';
  end if;
  if days<=tEmployLimit then
    MonthNum:=months_between(monthbegin,tstartdate) + 1;
  else
    MonthNum:=months_between(monthbegin,tstartdate);
  end if;
  return(MonthNum);
  end GetMonths;


/

