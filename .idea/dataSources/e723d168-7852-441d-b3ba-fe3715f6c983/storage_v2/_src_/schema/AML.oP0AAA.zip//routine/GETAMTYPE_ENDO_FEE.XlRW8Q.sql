create function getAmtype_Endo_Fee(EndorseMentno In Char,FeeoperationType In Char,feefinatype In char,c_RiskCode In varchar2) return Varchar2 is
  Result_Amntype varchar2(10) := '99';
begin

  Declare
  v_ActuGetNo Char(20);
  c_StandByFlag1 Char(20);
  c_RiskPeriod Char(1);


  Begin

  --???????
  If FeeoperationType In ('CT','PT') Then
   Select riskperiod Into c_RiskPeriod From lmriskapp Where riskcode = c_RiskCode;
  Select standbyflag1 Into c_StandByFlag1 From lpedoritem Where edorno = EndorseMentno;

   If Trim(c_StandByFlag1) = '1' Then
     Result_Amntype := '03';
   End If;

   If Trim(c_StandByFlag1) = '2' Then
     If c_RiskPeriod = 'L' Then
       Result_Amntype := '04';
      Else
       Result_Amntype := '05';
      End If;
     End If;
  End If;


    if FeeoperationType = 'RE' Then
     Result_Amntype := '02';
    End If;

    if FeeoperationType In('NS','AA') Then
     Result_Amntype := '01';
    End If;

    if FeeoperationType = 'AG' Then
     If feefinatype = 'EF' Then
       Result_Amntype := '06';
       Else
       Result_Amntype := '07';
    End If;
  End If;

  End;

  return(Result_Amntype);
end getAmtype_Endo_Fee;


/

