create FUNCTION fnc_zt3_1_3(payendyear in number) return varchar2
is
tR number;
begin

  tR := 1;
                if payendyear >= 30 then
			tR := 0.05;
                end if;
		if payendyear >= 20 and payendyear < 30 then
			tR := 0.1;
		end if;
		if payendyear >= 10 and payendyear < 20 then
			tR := 0.25;
		end if;
		if payendyear < 10 then
			tR := 0.35;
		end if;
	return(tR);
end;


/

