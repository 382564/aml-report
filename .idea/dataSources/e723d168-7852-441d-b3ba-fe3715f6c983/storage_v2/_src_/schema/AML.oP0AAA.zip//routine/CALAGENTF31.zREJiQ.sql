create FUNCTION calAgentF31(vAgentCode  in varchar2,
                                       vIndexCalNo in varchar2,
                                       vmanagecom  in varchar2,
                                       vbranchtype in varchar2)
  RETURN NUMBER IS
  Result        number := 0;
  attend        number := 0;
  FirstPensions number := 0;
  amoney        number := 0;
  agentnum      number := 0;
BEGIN
  --成长津贴：入司半年内可享，即最多发6个月, 二次入职不享用成长津贴
  select count(1)
    into agentnum
    from laagent
   where agentcode = vAgentCode
     and agentstate = '01'
     and last_day(to_date(vIndexCalNo, 'yyyymm')) <=
         to_date(to_char(add_months(EmployDate, 6), 'YYYY-MM-dd'),
                 'YYYY-MM-dd');

  if agentnum <> 0 then
    select nvl(sum(FirstPension), 0)
      into FirstPensions
      from LAIndexInfo a
     where a.agentcode = vAgentCode
       and branchtype = vbranchtype
       and indextype = '00'
       and IndexCalNo = vIndexCalNo;

    select case
             when FirstPensions >= 1500 and FirstPensions < 3000 then
              500
             when FirstPensions >= 3000 and FirstPensions < 6000 then
              800
             when FirstPensions >= 6000 and FirstPensions < 12000 then
              1500
             when FirstPensions >= 12000 then
              2000
             else
              0
           end
      into amoney
      from dual;

    SELECT CASE
             WHEN PRESENCERATE < 0.5 THEN
              0
             WHEN 0.5 <= PRESENCERATE AND PRESENCERATE < 0.8 THEN
              0.8
             WHEN 0.8 <= PRESENCERATE THEN
              1
             ELSE
              0
           END
      INTO attend
      FROM LATTENDANCE
     where agentcode = vAgentCode
       and years = vIndexCalNo
       and vmanagecom like managecom || '%';

    Result := round(amoney * attend, 2);
  end if;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return 0;
END;

/

