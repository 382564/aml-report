create function checkDoubleBranchType(tManageCom in VARCHAR2,tBranchType in varchar2 ,tIndexCalNo in VARCHAR2) return integer IS
-------------------??????????????????????????---------------------------
  ADDCOUNT   INTEGER;
begin
return 1;
  select nvl(sum(count(distinct lacommision.branchtype)),0) into ADDCOUNT
  from lacommision,laagent
  where wageno=tIndexCalNo  and commdire='1'
  and lacommision.managecom like concat(tManageCom,'%')
  and lacommision.agentcode=laagent.agentcode
  and laagent.branchtype=tBranchType
 --??????
 -- and lacommision.branchtype<>'X'
  and lacommision.branchtype=laagent.branchtype
  group by lacommision.agentcode having count(distinct lacommision.branchtype)>1;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkDoubleBranchType;


/

