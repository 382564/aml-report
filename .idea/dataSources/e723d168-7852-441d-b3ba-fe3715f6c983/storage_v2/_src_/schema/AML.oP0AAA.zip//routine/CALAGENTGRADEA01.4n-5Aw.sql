create FUNCTION CalAgentgradeA01(
       tBranchAttr labranchgroup.branchattr%TYPE,--????
       tCalDate date,   --????
       tAgentGrade latree.agentgrade%TYPE --????
       ) return number as   --????
v_Num number;


begin
select count(distinct agentcode) into v_Num from (
  select agentcode from LAtree a where agentgrade=tAgentGrade and startdate<=tCalDate
  and exists (select 'X' from labranchgroup b,laagent c where branchcode=b.agentgroup
  and c.branchtype='1' and branchattr like tBranchAttr||'%'
  and c.agentcode=a.agentcode and c.agentstate<'03')
  union
  select agentcode from latreeb a where agentgrade=tAgentGrade and startdate<=tCalDate
  and removetype <> '05'
  and edorno = (select max(edorno) from latreeb where trim(agentcode) = a.agentcode)
  and exists (select 'X' from labranchgroup b,laagent c where branchcode=b.agentgroup
  and c.branchtype='1' and branchattr like tBranchAttr||'%'
  and c.agentcode=a.agentcode and c.agentstate<'03')
  )
  ;

return v_Num;
End CalAgentgradeA01;


/

