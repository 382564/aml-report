create function         getVersionName(p_polno in varchar2) 			 
	return varchar2 is  
	v_RiskPeriod varchar2(1);
	v_SignDate Date;
	v_CValiDate Date;
	v_VersionName varchar2(120);
	v_RiskCode varchar2(20);
	ResultStr varchar2(20);
	Result varchar2(120);
begin
   /*判断险种是长短险*/
  select riskcode into v_Riskcode from lcpol where polno = p_polno;
  select RiskPeriod
    into v_RiskPeriod
    from lmriskapp
   where riskcode = v_Riskcode;
   
   /*判断是否是长期限*/
	if v_RiskPeriod = 'L' then
		select SignDate into v_SignDate from lccont where contno in (select contno from lcpol where polno = p_polno);
		select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_SignDate and v_SignDate <= (case when enddate is null then date'9999-01-01' else enddate end);
		Result := v_VersionName;
	else
		select count(*) into ResultStr from lpedoritem a where a.edorstate ='0' and a.edortype='LR' and exists (select 1 from lcpol b where a.contno=b.contno and b.polno = p_polno);
		/*判断是否做过保单补发保全项目*/
		if ResultStr >0 then
			select cvalidate into v_CValiDate from lcpol where polno = p_polno;
			select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_CValiDate and v_CValiDate <= (case when enddate is null then date'9999-01-01' else enddate end);
			Result := v_VersionName;
		else
			select SignDate into v_SignDate from lccont where contno in (select contno from lcpol where polno = p_polno);
			select versionname  into v_VersionName from lmversion where riskcode = v_Riskcode and startdate <= v_SignDate and v_SignDate <= (case when enddate is null then date'9999-01-01' else enddate end);
			Result := v_VersionName;
		end if;
	end if;
  return(Result);
end getVersionName;


/

