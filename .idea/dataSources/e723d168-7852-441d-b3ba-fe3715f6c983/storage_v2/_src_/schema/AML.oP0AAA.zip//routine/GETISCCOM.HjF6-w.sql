create FUNCTION getISCCom(cComCode in varchar2)
return varchar2 as
tComCodeISC varchar2(10);
begin
select max(ComCodeISC) into tComCodeISC from ComToISCCom where trim(ComCode)=trim(cComCode);
return(tComCodeISC);
end;


/

