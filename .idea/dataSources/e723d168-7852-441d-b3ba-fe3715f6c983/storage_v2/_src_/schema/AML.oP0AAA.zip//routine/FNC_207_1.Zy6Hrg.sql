create FUNCTION fnc_207_1(clmNo number,dutyFeeStaNo number,dutyFeeCode number) return number is
  Result number;
  fee number;
  limitDate Date;
  startDate Date;
  endDate Date;
  dayCount number;
begin
  --????????????????
  select to_date((min(startDate)+59),'YYYY-MM-DD HH24:MI:SS') into limitDate from LLClaimDutyFee where Clmno=clmNo and DutyFeeType=dutyFeeType and DutyFeeCode=DutyFeeCode;
--????????dutyFeeStaNo???????
  select StartDate into startDate from Llclaimdutyfee where Clmno=clmNo and DutyFeeStaNo=dutyFeeStaNo and DutyFeeType=dutyFeeType and DutyFeeCode=DutyFeeCode;
--????????dutyFeeStaNo???????
  select EndDate into EndDate from Llclaimdutyfee where Clmno=clmNo and DutyFeeStaNo=dutyFeeStaNo and DutyFeeType=dutyFeeType and DutyFeeCode=DutyFeeCode;
--????????????????
  select (AdjSum-OutDutyAmnt) into fee from Llclaimdutyfee where Clmno=clmNo and DutyFeeStaNo=dutyFeeStaNo and DutyFeeType=dutyFeeType and DutyFeeCode=DutyFeeCode;
--????????dutyFeeStaNo?????
  select DayCount into dayCount from Llclaimdutyfee where Clmno=clmNo and DutyFeeStaNo=dutyFeeStaNo and DutyFeeType=dutyFeeType and DutyFeeCode=DutyFeeCode;
--?Result??
  Result:=0;

  if limitDate>endDate then  --????????60??
    if (fee/dayCount)>10 then   --???????10
      select 10*(endDate-startDate+1) into Result from Dual;
    else
      select fee into Result from Dual;
    end if ;
  else                       --????????60??
    if (fee/dayCount)>10 then
        select 10*(limitDate-startDate) into Result from Dual;
    else
        select fee*(limitDate-startDate)/(endDate-startDate) into Result from Dual;
    end if;
  end if;
  return(Result);
end fnc_207_1;


/

