create FUNCTION chgmult214( Mult number ) return number
is
tR number;
begin
 if Mult > 10 then
  tR := 10;
 else
  tR := Mult;
 end if;

 return(tR);
end;


/

