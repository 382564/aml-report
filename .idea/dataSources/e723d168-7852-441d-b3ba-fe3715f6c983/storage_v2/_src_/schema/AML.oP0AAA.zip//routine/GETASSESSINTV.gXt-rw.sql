create function getAssessIntv(cAgentGrade       in varchar2,
                                         cAssessType       in varchar2,
                                         cAreaType         in varchar2,
                                         cBranchType       in varchar2,
                                         cConnManagerState in varchar2)
  return varchar2 is
  Result varchar2(2) := '-1';
begin
  if cConnManagerState is null or cConnManagerState = '0' /*or cConnManagerState='2'*/
     or cConnManagerState = '4' then
    --????????????????????
    select TO_CHAR(AssessMonths)
      into Result
      from LAAssessPeriod
     where AgentGrade = cAgentGrade
       and AssessType = cAssessType
       and AreaType = cAreaType
       and trim(BranchType) = cBranchType;
  end if;

  if (cConnManagerState = 1 or cConnManagerState = 3 or
     cConnManagerState = 2) and
     (cAreaType = '01' or cAreaType = '02' or cAreaType = '03') then
    --?????????????????3??
    Result := '3';
  end if;
  if (cConnManagerState = 1 or cConnManagerState = 3 or
     cConnManagerState = 2) and cAgentGrade = 'A201' and
     (cAreaType = '04' or cAreaType = '05' or cAreaType = '06') then
    --?????????????????3??
    Result := '3';
  end if;

  if (cConnManagerState = 3 or cConnManagerState = 2) and
     (cAgentGrade = 'A301' or cAgentGrade = 'A302') and
     (cAreaType = '04' or cAreaType = '05' or cAreaType = '06') then
    --?????????????????3??
    Result := '3';
  end if;

  if cConnManagerState = 1 and cAgentGrade = 'A301'
  and (cAreaType = '04' or cAreaType = '05' or cAreaType = '06') then
    --?????????????????6??
    Result := '6';
  end if;

  /*if cAssessType='01' then
  --????
     if cAgentGrade='A301' and cConnManagerState=2 then
     --??????A301???????3??
     --20050713 zxs ??????A301???????6??
        Result:='3';
     end if;
  end if;  */
  return(Result);
end getAssessIntv;


/

