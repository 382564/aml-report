create PROCEDURE CRMS_PAYTRANS(TSTRATDATE  IN VARCHAR2,
                                            TENDDATE    IN VARCHAR2,
                                            TCUSTOMERNO IN VARCHAR2,
                                            ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
       DELETE FROM MID_CR_Trans D
         WHERE D.TRANSNO IN
               (SELECT C.PAYNO
                  FROM LCCONT A, LJAPAY C
                 WHERE A.CONTTYPE = '1'
                   AND A.APPFLAG <> '0'
                   AND (A.PRTNO = C.OTHERNO or a.contno = c.otherno)
                   AND A.APPNTNO =TCUSTOMERNO
                UNION
                SELECT C.PAYNO
                  FROM LJAPAY C, LPEDORITEM LP, LCCONT A
                 WHERE LP.EDORACCEPTNO = C.OTHERNO
                   AND LP.CONTNO = A.CONTNO
                   AND LP.GRPCONTNO = '00000000000000000000'
                    AND A.APPNTNO =TCUSTOMERNO
                UNION
                SELECT C.PAYNO
                  from ljapay c, ljagetclaim lj, lccont a
                 WHERE lj.actugetno = c.payno
                   AND a.contno = lj.contno
                    AND A.APPNTNO =TCUSTOMERNO
                       );
      --开始提数
      INSERT INTO MID_CR_Trans
          select c.payno transno,
       a.contno contno,
       '01' conttype,
        A.Salechnl TransMethod,
      c.othernotype transtype,
       c.enteraccdate transdate,
       'RMB' curetype,
       c.sumactupaymoney payamt,
       '1' payway,
       (select d.paymode
          from ljtempfeeclass d, ljtempfee e
         where e.otherno = a.contno
           and e.tempfeeno = d.tempfeeno
           and rownum = 1) paymode,
       c.bankcode accbank,
       c.bankaccno accno,
       '' channel,
       '' oper,
       '' amltctc,
       c.accname amlaccname,
       '' acctype,
       '' agentname,
       '' agentcardtype,
       '' agentcardid,
       '' agentnationality,
       '' tradecusname,
       '' tradecuscardtype,
       '' tradecuscardid,
       '' tradecusacctype,
       '' tradecusaccno,
       trunc(sysdate, 'dd') makedate,
       to_char(sysdate, 'HH24:Mi:SS') maketime
  from lccont a, ljapay c
 where a.conttype = '1'
   and a.appflag <> '0'
   and a.prtno = c.otherno
  -- and a.contno <> c.otherno
   and not exists (SELECT 1 FROM ljagetclaim lj WHERE lj.actugetno = c.payno)
   AND c.APPNTNO = TCUSTOMERNO
   union
   select c.payno transno,
       a.contno contno,
       '01' conttype,
        (SELECT apptype FROM lpedorapp WHERE edoracceptno = a.edoracceptno) TransMethod,
        c.othernotype transtype,
       c.enteraccdate transdate,
        'RMB' curetype,
       c.sumactupaymoney payamt,
       '1' payway,
       (select d.paymode
          from ljtempfeeclass d, ljtempfee e
         where e.otherno = a.contno
           and e.tempfeeno = d.tempfeeno
           and rownum = 1) paymode,
       c.bankcode accbank,
       c.bankaccno accno,
       '' channel,
       '' oper,
       '' amltctc,
       c.accname amlaccname,
       '' acctype,
       '' agentname,
       '' agentcardtype,
       '' agentcardid,
       '' agentnationality,
       '' tradecusname,
       '' tradecuscardtype,
       '' tradecuscardid,
       '' tradecusacctype,
       '' tradecusaccno,
       trunc(sysdate, 'dd') makedate,
       to_char(sysdate, 'HH24:Mi:SS') maketime
  from lpedoritem a, ljapay c,LCCONT B
  where  a.edoracceptno = c.otherno
  and a.grpcontno ='00000000000000000000'
  AND A.CONTNO = B.CONTNO
  AND B.APPNTNO =TCUSTOMERNO
  union
  select c.payno transno,
       a.contno contno,
       '01' conttype,
        a.salechnl TransMethod,
        c.othernotype transtype,
       c.enteraccdate transdate,
        'RMB' curetype,
       c.sumactupaymoney payamt,
       '1' payway,
       (select d.paymode
          from ljtempfeeclass d, ljtempfee e
         where e.otherno = a.contno
           and e.tempfeeno = d.tempfeeno
           and rownum = 1) paymode,
       c.bankcode accbank,
       c.bankaccno accno,
       '' channel,
       '' oper,
       '' amltctc,
       c.accname amlaccname,
       '' acctype,
       '' agentname,
       '' agentcardtype,
       '' agentcardid,
       '' agentnationality,
       '' tradecusname,
       '' tradecuscardtype,
       '' tradecuscardid,
       '' tradecusacctype,
       '' tradecusaccno,
       trunc(sysdate, 'dd') makedate,
       to_char(sysdate, 'HH24:Mi:SS') maketime
  from ljapay c,ljagetclaim lj,lccont a
  where c.payno = lj.actugetno
  and a.contno = lj.contno
  and a.grpcontno ='00000000000000000000'
  AND c.APPNTNO = TCUSTOMERNO
  union
  select c.payno transno,
       a.contno contno,
       '01' conttype,
        a.salechnl TransMethod,
        c.othernotype transtype,
       c.enteraccdate transdate,
        'RMB' curetype,
       c.sumactupaymoney payamt,
       '1' payway,
       (select d.paymode
          from ljtempfeeclass d, ljtempfee e
         where e.otherno = a.contno
           and e.tempfeeno = d.tempfeeno
           and rownum = 1) paymode,
       c.bankcode accbank,
       c.bankaccno accno,
       '' channel,
       '' oper,
       '' amltctc,
       c.accname amlaccname,
       '' acctype,
       '' agentname,
       '' agentcardtype,
       '' agentcardid,
       '' agentnationality,
       '' tradecusname,
       '' tradecuscardtype,
       '' tradecuscardid,
       '' tradecusacctype,
       '' tradecusaccno,
       trunc(sysdate, 'dd') makedate,
       to_char(sysdate, 'HH24:Mi:SS') maketime
  from ljapay c,lccont a
  where  a.contno = c.otherno
  and a.grpcontno ='00000000000000000000'
  and not exists (SELECT 1 FROM ljagetclaim lj WHERE lj.actugetno = c.payno)
  --and a.prtno <> c.otherno
  AND c.APPNTNO =TCUSTOMERNO;

      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Trans D
         WHERE D.TRANSNO IN
               (SELECT C.PAYNO
                  FROM LCCONT A, LJAPAY C
                 WHERE A.CONTTYPE = '1'
                   AND A.APPFLAG <> '0'
                   AND (A.PRTNO = C.OTHERNO or a.contno = c.otherno)
                   AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                       TMDATE
                UNION
                SELECT C.PAYNO
                  FROM LJAPAY C, LPEDORITEM LP, LCCONT A
                 WHERE LP.EDORACCEPTNO = C.OTHERNO
                   AND LP.CONTNO = A.CONTNO
                   AND LP.GRPCONTNO = '00000000000000000000'
                   AND LP.EDORVALIDATE BETWEEN TCDATE AND
                       TMDATE
                UNION
                SELECT C.PAYNO
                  from ljapay c, ljagetclaim lj, lccont a
                 WHERE lj.actugetno = c.payno
                   AND a.contno = lj.contno
                   AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                       TMDATE
                       );
        --开始提数
        INSERT INTO MID_CR_Trans
          select c.payno transno,
                 a.contno contno,
                 '01' conttype,
                 A.Salechnl TransMethod,
                 c.othernotype transtype,
                 c.enteraccdate transdate,
                 'RMB' curetype,
                 c.sumactupaymoney payamt,
                 '1' payway,
                 (select d.paymode
                    from ljtempfeeclass d, ljtempfee e
                   where e.otherno = a.contno
                     and e.tempfeeno = d.tempfeeno
                     and rownum = 1) paymode,
                 c.bankcode accbank,
                 c.bankaccno accno,
                 '' channel,
                 '' oper,
                 '' amltctc,
                 c.accname amlaccname,
                 '' acctype,
                 '' agentname,
                 '' agentcardtype,
                 '' agentcardid,
                 '' agentnationality,
                 '' tradecusname,
                 '' tradecuscardtype,
                 '' tradecuscardid,
                 '' tradecusacctype,
                 '' tradecusaccno,
                 trunc(sysdate, 'dd') makedate,
                 to_char(sysdate, 'HH24:Mi:SS') maketime
            from lccont a, ljapay c
           where a.conttype = '1'
             and a.appflag <> '0'
             and a.prtno = c.otherno
           -- and a.contno <> c.otherno
             and not exists (SELECT 1 FROM ljagetclaim lj WHERE lj.actugetno = c.payno)
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE --没有客户号时，通过时间查询
          union
          select c.payno transno,
                 a.contno contno,
                 '01' conttype,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = a.edoracceptno) TransMethod,
                 c.othernotype transtype,
                 c.enteraccdate transdate,
                 'RMB' curetype,
                 c.sumactupaymoney payamt,
                 '1' payway,
                 (select d.paymode
                    from ljtempfeeclass d, ljtempfee e
                   where e.otherno = a.contno
                     and e.tempfeeno = d.tempfeeno
                     and rownum = 1) paymode,
                 c.bankcode accbank,
                 c.bankaccno accno,
                 '' channel,
                 '' oper,
                 '' amltctc,
                 c.accname amlaccname,
                 '' acctype,
                 '' agentname,
                 '' agentcardtype,
                 '' agentcardid,
                 '' agentnationality,
                 '' tradecusname,
                 '' tradecuscardtype,
                 '' tradecuscardid,
                 '' tradecusacctype,
                 '' tradecusaccno,
                 trunc(sysdate, 'dd') makedate,
                 to_char(sysdate, 'HH24:Mi:SS') maketime
            from lpedoritem a, ljapay c,lccont b
           where a.edoracceptno = c.otherno
             and a.grpcontno = '00000000000000000000'
             and a.contno = b.contno
             AND a.EDORVALIDATE BETWEEN TCDATE AND
                 TMDATE --没有客户号时，通过时间查询
          union
          select c.payno transno,
                 a.contno contno,
                 '01' conttype,
                 a.salechnl TransMethod,
                 c.othernotype transtype,
                 c.enteraccdate transdate,
                 'RMB' curetype,
                 c.sumactupaymoney payamt,
                 '1' payway,
                 (select d.paymode
                    from ljtempfeeclass d, ljtempfee e
                   where e.otherno = a.contno
                     and e.tempfeeno = d.tempfeeno
                     and rownum = 1) paymode,
                 c.bankcode accbank,
                 c.bankaccno accno,
                 '' channel,
                 '' oper,
                 '' amltctc,
                 c.accname amlaccname,
                 '' acctype,
                 '' agentname,
                 '' agentcardtype,
                 '' agentcardid,
                 '' agentnationality,
                 '' tradecusname,
                 '' tradecuscardtype,
                 '' tradecuscardid,
                 '' tradecusacctype,
                 '' tradecusaccno,
                 trunc(sysdate, 'dd') makedate,
                 to_char(sysdate, 'HH24:Mi:SS') maketime
            from ljapay c, ljagetclaim lj, lccont a
           where c.payno = lj.actugetno
             and a.contno = lj.contno
             and a.grpcontno = '00000000000000000000'
            AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                TMDATE --没有客户号时，通过时间查询
          union
          select c.payno transno,
                 a.contno contno,
                 '01' conttype,
                 a.salechnl TransMethod,
                 c.othernotype transtype,
                 c.enteraccdate transdate,
                 'RMB' curetype,
                 c.sumactupaymoney payamt,
                 '1' payway,
                 (select d.paymode
                    from ljtempfeeclass d, ljtempfee e
                   where e.otherno = a.contno
                     and e.tempfeeno = d.tempfeeno
                     and rownum = 1) paymode,
                 c.bankcode accbank,
                 c.bankaccno accno,
                 '' channel,
                 '' oper,
                 '' amltctc,
                 c.accname amlaccname,
                 '' acctype,
                 '' agentname,
                 '' agentcardtype,
                 '' agentcardid,
                 '' agentnationality,
                 '' tradecusname,
                 '' tradecuscardtype,
                 '' tradecuscardid,
                 '' tradecusacctype,
                 '' tradecusaccno,
                 trunc(sysdate, 'dd') makedate,
                 to_char(sysdate, 'HH24:Mi:SS') maketime
            from ljapay c, lccont a
           where a.contno = c.otherno
             and a.grpcontno = '00000000000000000000'
             and not exists (SELECT 1 FROM ljagetclaim lj WHERE lj.actugetno = c.payno)
           --  and a.prtno <> c.otherno
          AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE; --没有客户号时，通过时间查询
           COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_PAYTRANS;


/

