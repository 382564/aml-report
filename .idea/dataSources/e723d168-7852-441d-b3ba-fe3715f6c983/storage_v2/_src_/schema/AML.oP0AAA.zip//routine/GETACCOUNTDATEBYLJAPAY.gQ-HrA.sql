create function         GetAccountDateByLJAPay(tconfdate in date,
                                                       tpolno    in varchar2,
                                                       tconttype in varchar2)
 return date is
  Result      date;
  tcvalidate date;
  tsigndate date;
  newdate date;
begin

  if tconfdate  is null then 
     return(Result);
     end if ;
  if tconttype = 'G' then 
   
   
    --?个单号
    select cvalidate,signdate
      into tcvalidate,tsigndate
      from (select cvalidate, polno,signdate
              from lcpol
            union
            select cvalidate, polno,signdate from lbpol)
     where polno = tpolno;
  else
    --团单险种号
    select cvalidate,signdate
      into tcvalidate,tsigndate
      from (select cvalidate, grppolno,(select signdate from lcgrpcont where lcgrpcont.grpcontno=lcgrppol.grpcontno) signdate
              from lcgrppol
            union
            select cvalidate, grppolno,(select signdate from lbgrpcont where lbgrpcont.grpcontno=lbgrppol.grpcontno) signdate from lbgrppol)
     where grppolno = tpolno;
  end if;

  --生效日与签单日,财务确认日，取大者
  if tcvalidate > tconfdate then
    newdate := tcvalidate;
       if newdate>tsigndate then
       newdate:=newdate;
       else
       newdate:=tsigndate;
       end if;
  else
        newdate := tconfdate;
        if newdate>tsigndate then
           newdate:=newdate;
        else
          newdate:=tsigndate;
        end if;
  end if;
 Result:=newdate;
  return(Result);
end GetAccountDateByLJAPay;


/

