create function getParentComisc(cComCode in varchar2)
return  varchar2 as
tParentComCodeISC varchar2(10);
begin
select trim(max(ParentComCodeISC)) into tParentComCodeISC from LFComISC where trim(ComCodeISC)= trim(cComCode);
return(tParentComCodeISC);
end;


/

