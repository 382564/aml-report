create FUNCTION getEmpState(cEmployDate in date,cIndexCalno in varchar2) return integer is
  Result integer;
  tLimitLine   date;
  tEmployLimit number(10,2):=0;
begin
  if to_char(cEmployDate,'yyyymm') <> cIndexCalNo then
    Result := 1;
  else
    select to_date(varvalue,'yyyy-mm-dd') into tLimitLine from lasysvar where vartype='LimitLine';
    if cEmployDate<=tLimitLine then
       select to_number(varvalue) into tEmployLimit from Lasysvar where vartype='EmployLimit';
    else
        select to_number(varvalue) into tEmployLimit from Lasysvar where vartype='EmployLimitNew';
    end if;
    if to_number(to_char(cEmployDate,'dd')) > tEmployLimit then
       Result := -1;
    else
       Result := 1;
    end if;
   end if;
  return(Result);
end getEmpState;


/

