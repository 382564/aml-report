create FUNCTION CALTOFORMAL
(tAgentGrade in varchar2,
 tBranchAttr lawage.branchattr%TYPE,
 Flag in varchar2,
 tIndexcalno1 integer,
 tIndexcalnO2 integer
) return number is
  tAgentcode LAwage.Agentcode%TYPE;
  tID           Date;
  tED           Date;
  tBottom3      varchar2(12);  --????????
  tBottom6      varchar2(12);  --????????
  tEDay         varchar2(6);
  tFlagIn       varchar2(2);
  --tLimit        integer;
  v_turn3  number:=0;
  v_turn6  number:=0;

  v_F03  number:=0;
  --v_F036  number:=0;
  Result number:=0;
  ---?????
  --????????
  TYPE CalCursor IS REF CURSOR;
  t_cursor CalCursor;

begin

  if (tAgentGrade is null)  then

    open t_cursor for
      select agentcode,f03 from LAwage
       where f03<>0 and BranchType='1' and indexcalno>=tIndexcalno1 and indexcalno<=tIndexcalno2 and Branchattr like tBranchAttr||'%';

  else

      open t_cursor for
      select agentcode,f03 from LAwage
       where f03<>0 and BranchType='1' and agentgrade=tAgentGrade and Branchattr like tBranchAttr||'%' and indexcalno>=tIndexcalno1 and indexcalno<=tIndexcalno2;
  end if;




  loop
      fetch t_cursor into tAgentcode,v_F03;
      exit when t_cursor%notfound;
  -- ?????????????
  select indueformdate,employdate into tID,tED from laagent
  where trim(agentcode) = tAgentcode;

  -- ??????????,???10?
  tEDay := to_char(tED,'dd');
  if tEDay > trim(getEmployLimit('EmployLimit')) then
  --?????
    if to_char(tED,'mm') <> to_char(tID,'mm')-1 then
      tFlagIn := 'N';
    end if;

    if tFlagIn = 'N' then
      tBottom3 := to_char(add_months(tED,4),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,7),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    else--????
      tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
      tBottom3 := concat(substr(tBottom3,1,8),'01');

      tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
      tBottom6 := concat(substr(tBottom6,1,8),'01');
    end if;
  else
    tBottom3 := to_char(add_months(tED,3),'yyyy-mm-dd');
    tBottom3 := concat(substr(tBottom3,1,8),'01');

    tBottom6 := to_char(add_months(tED,6),'yyyy-mm-dd');
    tBottom6 := concat(substr(tBottom6,1,8),'01');
  end if;

  if tID <= to_date(tBottom3,'yyyy-mm-dd') then
   v_turn3:=v_turn3 +v_F03;
       --??????
  else
    if tID > to_date(tBottom3,'yyyy-mm-dd') and tID <= to_date(tBottom6,'yyyy-mm-dd') then
        --??????
      v_turn6:=v_turn6+v_F03;
    end if;
  end if;
  end loop;
  close t_cursor;

 if Flag=3 then

 Result:=v_turn3 ;
 else
 Result:=v_turn6;
 end if;


  return(Result);
end CALTOFORMAL;


/

