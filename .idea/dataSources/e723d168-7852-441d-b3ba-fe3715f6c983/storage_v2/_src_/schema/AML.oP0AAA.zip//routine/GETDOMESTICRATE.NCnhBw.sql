create function GETDomesticRate(tCurCurrency in varchar,tDestMoneyType in VARCHAR) return char is
  rRate number(10,4);

  tCurrency varchar2(10);
  tCurCurrency1 varchar2(10);

begin

   begin
     if tCurCurrency is null or tCurCurrency='' then
       tCurCurrency1 := '01';
     end if;
     if tDestMoneyType is null or tDestMoneyType='' then
     select codename into tCurrency from ldcode1 where codetype='dateformat'
           and code1 = (select sysvarvalue from LDSysVar where SysVar='nativeplace' );
     else
      select codename into tCurrency from ldcode1 where codetype='dateformat'
           and code1 = tDestMoneyType;
     end if;

     select middle/per into rRate from LDExRate where currcode = tCurCurrency1 and destcode = tCurrency;

  exception  when NO_DATA_FOUND THEN
        rRate := 1;

   end;
     return(rRate);
end GETDomesticRate;


/

