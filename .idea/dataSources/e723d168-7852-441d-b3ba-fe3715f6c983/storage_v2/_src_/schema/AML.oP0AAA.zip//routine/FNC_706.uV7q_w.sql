create FUNCTION fnc_706(c_cureType char ,n_daysInHos number,d_accidentDate date,d_startDate date,d_endDate date,d_lcgetStartDate date,d_lcgetEndDate date,n_caseNo char) return number is
  Result number;
  d_limitDate Date;

begin

Result:=0;                               --?Result??

select least((min(startdate)+90),(d_lcgetEndDate+30)) into d_limitDate from LLCaseReceipt where CaseNo=n_CaseNo;

-------------------------------------------------------------------------------------------------------------


if c_cureType<>'A' and d_accidentDate<=d_startDate then     --??????,???????????????

-------------------------------------------------------------------------------------------------------------
--??????????????,???????????????,????????? --
  if  d_lcgetStartDate<=d_startDate  and d_startDate<d_limitDate then

    if d_endDate<=d_limitDate then       --??????????????(??????????,???????????????????)
        	select 10*n_daysInHos into Result from Dual;
    else                                 --??????????????
        	select 10*(d_limitDate-d_startDate) into Result from Dual;
    end if;

  end if ;
----------------------------------------------------------------------------------------------------------------
end if;
  return(Result);

end fnc_706;


/

