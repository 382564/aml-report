create FUNCTION calStandPrem(cPayIntv  IN lcpol.payintv%TYPE,
                                        cPayYears IN lcpol.payyears%TYPE,
                                        cYears    IN lcpol.years%TYPE,
                                        cPrem     IN lcpol.prem%TYPE,
                                        cRiskCode IN lcpol.riskcode%TYPE)
  RETURN NUMBER IS
  RESULT         NUMBER;
  cStandPremRate NUMBER;
BEGIN

  SELECT nvl(MAX(a.rate), 0)
    INTO cStandPremRate
    FROM (SELECT rate,
                 CASE
                   WHEN payintv = '#' OR payintv = cPayIntv THEN
                    0
                   ELSE
                    1
                 END + CASE
                   WHEN payyears = '#' OR payyears = cPayYears THEN
                    0
                   ELSE
                    1
                 END + CASE
                   WHEN years = '#' OR years = cYears THEN
                    0
                   ELSE
                    1
                 END AS flag
            FROM laratestandprem3 b
           WHERE b.riskcode = cRiskCode
             AND b.branchtype = '3') a
   WHERE a.flag = 0;

  RESULT := round(nvl(cPrem * cStandPremRate, 0), 2);

  RETURN(RESULT);
END calStandPrem;


/

