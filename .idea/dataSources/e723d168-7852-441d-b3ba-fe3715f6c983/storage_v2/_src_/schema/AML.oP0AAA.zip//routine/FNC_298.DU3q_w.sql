create FUNCTION FNC_298(F_TYPE        CHAR,
                                   C_POLNO       CHAR,
                                   C_GETDUTYCODE CHAR,
                                   N_FEE         NUMBER,
                                   C_CASENO      CHAR) RETURN NUMBER IS
  RESULT NUMBER;
  --  d_limitDate Date;
  -- d_minDate Date;
  --c_planCode CHAR;
  -- c_kind CHAR(1);
  N_GETRATE NUMBER;
  N_THIRD   NUMBER;
  N_LIMIT   NUMBER;
  N_JF      NUMBER;
  /*c_minGet CHAR;
  c_maxGet CHAR;*/
  C_FEEFLAG CHAR(1);
  C_FLAG    CHAR(1);

BEGIN
  RESULT    := 0; --?Result??
  C_FEEFLAG := 'B';
  N_JF      := N_FEE;

  IF SUBSTR(C_GETDUTYCODE, 6, 1) > '3' THEN
      C_FEEFLAG := 'A';
    END IF;
  IF F_TYPE = 'FILTER' THEN

    SELECT NVL(SUM(ADJSUM), -1)
      INTO N_JF
      FROM LLCASERECEIPT
     WHERE CLMNO = C_CASENO
       AND FEEITEMTYPE = C_FEEFLAG;
  END IF;

  ---??(??)
  IF C_FEEFLAG = 'A' THEN
    SELECT MAX(TO_NUMBER(STANDBYFLAG2))
      INTO N_LIMIT
      FROM LCDUTY
     WHERE DUTYCODE IN ('298104', '298105', '298106')
       AND POLNO = C_POLNO;

    --- ?? ?????
    SELECT NVL(SUM(ADJSUM), 0)
      INTO N_THIRD
      FROM LLOTHERFACTOR
     WHERE FACTORCODE IN ('B001A', 'B002A')
       AND CLMNO = C_CASENO;
  END IF;

  IF C_FEEFLAG = 'B' THEN
    SELECT MAX(TO_NUMBER(STANDBYFLAG2))
      INTO N_LIMIT
      FROM LCDUTY
     WHERE DUTYCODE IN ('298100', '298101', '298102', '298103')
       AND POLNO = C_POLNO;
    --- ?? ?????
    SELECT NVL(SUM(ADJSUM), 0)
      INTO N_THIRD
      FROM LLOTHERFACTOR
     WHERE FACTORCODE IN ('B001B', 'B002B')
       AND CLMNO = C_CASENO;
  END IF;

  IF N_LIMIT < N_JF THEN
    N_JF := N_LIMIT;
    --RESULT := 1;---???????? ?????????
  END IF;

  SELECT COUNT(*)
    INTO C_FLAG
    FROM LCDUTY
   WHERE TO_NUMBER(STANDBYFLAG2) > N_JF
     AND TO_NUMBER(STANDBYFLAG3) <= N_JF
     AND DUTYCODE IN (SELECT DUTYCODE
                        FROM LMDUTYGETRELA
                       WHERE GETDUTYCODE = C_GETDUTYCODE)
     AND POLNO = C_POLNO;

     IF C_FLAG = '0' THEN
         SELECT COUNT(*)
    INTO C_FLAG
    FROM LCDUTY
   WHERE TO_NUMBER(STANDBYFLAG2) = N_JF
         AND DUTYCODE IN (SELECT DUTYCODE
                        FROM LMDUTYGETRELA
                       WHERE GETDUTYCODE = C_GETDUTYCODE)
     AND POLNO = C_POLNO;
     END IF;

  IF F_TYPE = 'FILTER' THEN
    ---??
    IF C_FLAG <> '0' THEN
      ---???????
      RESULT := 1; ---???????
    END IF;
  END IF;

--  IF F_TYPE = 'CAL' AND C_FLAG <> '0' THEN
  IF F_TYPE = 'CAL'  THEN

    ---????
    SELECT GETRATE
      INTO N_GETRATE
      FROM LCGET
     WHERE GETDUTYCODE = C_GETDUTYCODE
       AND POLNO = C_POLNO;

    SELECT N_GETRATE * (N_JF - N_THIRD) / 100 INTO RESULT FROM DUAL;

  END IF;

  IF RESULT < 0 THEN
    RESULT := 0;
  END IF;

  RETURN(RESULT);
END FNC_298;


/

