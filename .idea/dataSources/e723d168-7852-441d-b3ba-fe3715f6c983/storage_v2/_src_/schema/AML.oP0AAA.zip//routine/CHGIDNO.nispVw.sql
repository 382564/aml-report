create function ChgIDNo(IDNo in varchar2, IDNoType in varchar2)
  return varchar2 is
  Result varchar2(100);
begin
  if (length(IDNo) = 18 and IDNoType = '0') then
    Result := substr(IDNo, 1, 6) || substr(IDNo, 9, 9);
  else
    return(IDNo);
  end if;
  return(Result);
end ChgIDNo;


/

