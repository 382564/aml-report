create FUNCTION FM265(PolNo1 char,PayEndYearold char,PayEndYearnew char) return number is
  Result number;
  t1 char;
  t2 number;
begin
   select insuredsex into t1 from lcpol where polno=PolNo1 and riskcode='00265000';
  if t1='0' then
   select insuredappage into t2 from lcpol where polno=PolNo1 and riskcode='00265000';
    if (t2>=46 and t2<=50 and PayEndYearold='20' and PayEndYearnew='15') or (t2>=31 and t2<=40 and PayEndYearold='30' and PayEndYearnew='20') then
      Result:=1;
    else
      Result:=0;
    end if;
  end if;
  if t1='1' then
   select insuredappage into t2 from lcpol where polno=PolNo1 and riskcode='00265000';
    if (t2>=48 and t2<=50 and PayEndYearold='20' and PayEndYearnew='15') or (t2>=32 and t2<=40 and PayEndYearold='30' and PayEndYearnew='20') then
      Result:=1;
    else
      Result:=0;
    end if;
  end if;
  return(Result);
  end FM265;


/

