create FUNCTION GetAvoirdupoisp(ContNo1 char, CustomerNo1 char,EdorNo1 char) return integer is
  Result integer;
begin
  select distinct ImpartParam into result from LpCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 and EdorNo=EdorNo1 And Impartver='02' and Impartcode='000' and ImpartParamNo='2';
  return(Result);
end GetAvoirdupoisp;


/

