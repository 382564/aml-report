create function getSerialNo return VARCHAR2 is
  tSerialNo VARCHAR2(30);
begin
  select lpad(SEQ_EVENT_ID.nextval,20,0) into tSerialNo from dual  ;
  return tSerialNo;
end getSerialNo;


/

