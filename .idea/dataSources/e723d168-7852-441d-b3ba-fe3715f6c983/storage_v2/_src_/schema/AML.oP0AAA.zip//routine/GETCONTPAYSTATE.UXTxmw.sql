create FUNCTION         GETCONTPAYSTATE(V_PrtNo in VARCHAR2)
  RETURN VARCHAR2 AS
  V_Result           VARCHAR2(20);
  V_Prem             NUMBER(20, 2);
  V_PayMoney         NUMBER(12, 2);
  V_BankOnTheWayFlag VARCHAR2(10);
  V_PayMode          VARCHAR2(10);
  V_BankSuccFlag     VARCHAR2(10);
  V_SendBankCount    NUMBER(10, 0);
  V_PrtNoteState     VARCHAR2(10);

BEGIN
  select NewPayMode
    into V_PayMode --缴费方式
    from Lccont a
   where a.prtno = V_PrtNo;

   select sum(prem)--应收
     into V_Prem
     from lcpol
     where prtno = V_PrtNo
     and uwflag not in('1','2','a');

  select nvl(sum(PayMoney), 0) --实收
    into V_PayMoney
    from ljtempfee
   where otherno = V_PrtNo
     and othernotype = '4'
     and Tempfeetype = '1'
     and EnterAccDate is not null;

  if   V_PayMode is null then
    return '付费方式不明';
  elsiF V_PayMode = '0' THEN
    select sendbankcount, BankOnTheWayFlag, banksuccflag,prtnotestate
      into V_SendBankCount, V_BankOnTheWayFlag, V_BankSuccFlag,V_PrtNoteState
      from ljspay
     where otherno = V_PrtNo
       and othernotype = '9'
       and rownum = 1
     order by GetNoticeNo desc;
    IF ((V_BankSuccFlag = '0' and V_SendBankCount = 0) or (V_BankOnTheWayFlag != '1' and V_BankSuccFlag='0' and V_PrtNoteState = '1')) THEN
      V_Result := '待转账';
    elsIF V_BankOnTheWayFlag = '1' THEN
      V_Result := '转账途中';
    elsif (V_BankSuccFlag = '0' and V_SendBankCount > 0 and V_PrtNoteState != '1') then
      V_Result := '转账不成功';
    elsiF V_PayMoney > V_Prem THEN
      V_Result := '保费多交';
    ELSIF V_PayMoney = V_Prem THEN
      V_Result := '交费一致';
    ELSIF V_PayMoney < V_Prem THEN
      V_Result := '交费不足';
    END IF;
  else
    select case
             when exists (select 'y'
                     from ljtempfee
                    where otherno = V_PrtNo
                      and othernotype = '4'
                      and Tempfeetype = '1') then
              (case
                when V_PayMoney > V_Prem then
                 '保费多交'
                when V_PayMoney = V_Prem then
                 '交费一致'
                else
                 '交费不足'
              end)
             else
              '待收费'
           end
      into V_Result
      from dual;
  END IF;
    return V_Result;
  exception
    when others then
    return '状态查询失败';

end;


/

