create function GetAmnt(tRiskCode     in varchar2,
																	 tSumAmnt      in varchar2,
																	 tInsuredCount in varchar2,
																	 tInsuredGrade in varchar2,
																	 tPlanCode     in varchar2)
	return varchar2 is
	tAmnt NUMBER;
begin
	tAmnt := 0;

	IF trim(tRiskCode) = '241801' THEN
		IF trim(tPlanCode) = 'A' THEN
			IF (tInsuredGrade = '00' or tInsuredGrade is NULL) THEN
				tAmnt := tSumAmnt * 2 / (tInsuredCount + 2);
			END IF;
			IF (tInsuredGrade != '00' And tInsuredGrade is not NULL) THEN
				tAmnt := tSumAmnt / (tInsuredCount + 2);
			END IF;
		END IF;
		IF trim(tPlanCode) = 'B' THEN
			IF (tInsuredGrade = '00' or tInsuredGrade is NULL) THEN
				tAmnt := tSumAmnt * 2 / (tInsuredCount + 2);
			END IF;
			IF (tInsuredGrade != '00' And tInsuredGrade is not NULL) THEN
				tAmnt := tSumAmnt / (tInsuredCount + 2);
			END IF;
		END IF;
	END IF;

	--241805?????????????????????
	IF trim(tRiskCode) = '241805' THEN
		IF trim(tPlanCode) = 'A' THEN
			IF (tInsuredGrade = '00' or tInsuredGrade is  NULL) THEN
				tAmnt := tSumAmnt * 2 / (tInsuredCount + 2);
			END IF;
			IF (tInsuredGrade != '00' And tInsuredGrade is not NULL) THEN
				tAmnt := tSumAmnt / (tInsuredCount + 2);
			END IF;
		END IF;
		IF trim(tPlanCode) = 'B' THEN
			IF (tInsuredGrade = '00' or tInsuredGrade is NULL) THEN
				tAmnt := tSumAmnt * 2 / (tInsuredCount + 2);
			END IF;
			IF (tInsuredGrade != '00' And tInsuredGrade is not NULL) THEN
				tAmnt := tSumAmnt / (tInsuredCount + 2);
			END IF;
		END IF;
	END IF;

	IF trim(tRiskCode) not in ('241801', '241805') THEN
		tAmnt := tSumAmnt;
	END IF;

	IF tAmnt < 1 THEN
		return TO_CHAR(tAmnt, '0D99');
	END IF;

	return trim(TO_CHAR(tAmnt, '9999999999D99'));
END;


/

