create function DimmisionRate(twagenoend in varchar2,tbranchcode in varchar2) return number is
-----------------??????----------------------------
  DimmisionRate number(12,6):=0;
  cnum          Integer;
  num           Integer;
begin
  ----?????????
  select count(distinct agentcode) into num from laassessaccessory
  where IndexCalNo=twagenoend and AssessType='00' and agentgroup=tbranchcode;

  ----???????????????
  select count(distinct agentcode) into cnum from laassessaccessory
  where indexcalno=twagenoend and AssessType='00' and agentgroup=tbranchcode
  and agentgrade1='00';

 if(num=0)
  then
  DimmisionRate:=0;
  else
  DimmisionRate:=cnum/num;
end if;

  return(DimmisionRate);
end DimmisionRate;


/

