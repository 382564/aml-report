create function AgentCalDirectWage
(sPolno in char,sContno in char,sRiskCode in VARCHAR2,sMakedate in Date,sManageCom in VARCHAR2,sPayYears in integer,sPayIntv in integer,sBranchType in char)
return number is Result number;
  --sPolno ljtempfee.otherno
  --sContno ljtempfee.otherno
  tWageRate number(10,4) := 0;
  tScanDate Date;
  tSignDate Date;
  tCount integer;
  --?????,?lcpol??prtno
  tPrtno VARCHAR2(20);
  tRiskRateVersion VARCHAR2(2);
  tComVersion VARCHAR2(4);
  --authored by jiaqiangli 2008-03-15 ??ljtempfee??????
 begin
  tCount := 0;
  select count(polno) into tCount from lcpol where polno=sPolno;

  --??????? ljtempfee.otherno????contno
  if (tCount = 0) then
     begin
     select nvl(signdate,sMakedate),trim(prtno) into tSignDate,tPrtno from lcpol where contno=sContno and riskcode=sRiskCode;
     exception
     when NO_DATA_FOUND then
       tSignDate:=sMakedate;
     end;
     select count(doccode) into tCount from es_doc_main where doccode=tPrtno;
     --???????
     if (tCount = 0) then
        tScanDate:=sMakedate;
     else
        select max(makedate) into tScanDate from es_doc_main where doccode=tPrtno;
     end if;
  else
     begin
     select nvl(signdate,sMakedate),trim(prtno) into tSignDate,tPrtno from lcpol where polno=sPolno;
     exception
     when NO_DATA_FOUND then
      return 0;
     end;
     tCount := 0;
     select count(doccode) into tCount from es_doc_main where doccode=tPrtno;
     if (tCount = 0) then
        return 0;
     else
        --??prtno?????????
        select max(makedate) into tScanDate from es_doc_main where doccode=tPrtno;
     end if;
  end if;
  select getRiskRateVersion(tScanDate,tSignDate,sRiskCode,sBranchType) into tRiskRateVersion from dual;
  --left to trim vs right to rpad
  select trim(code2) into tComVersion from ldcoderela where relatype='fycareatype' and code1 = rpad(substr(sManageCom,0,4),length(code1))
  and code3 = '1';

  --see also in lmcalmode.calcode='AR0001'
  if (sPayIntv != 0) then
     begin
     select nvl(max(rate),0) into tWageRate from laratecommision where  F06= '1'
     and trim(branchtype)=sBranchType and riskcode = sRiskCode
     and ((year = sPayYears and sPayYears <= 20) or (year = 20 and sPayYears > 20))
     and sPayIntv <> '0'
     and curyear = 1 and trim(managecom)=tComVersion
     and versiontype=tRiskRateVersion;
     exception
     when NO_DATA_FOUND then
      return 0;
     end;
  else
     begin
     select nvl(max(rate),0) into tWageRate from laratecommision where F06= '1' and trim(branchtype)=sBranchType
     and riskcode = sRiskCode and year = 1 and curyear = 1
     and sPayIntv = '0'
     and trim(managecom)=tComVersion and versiontype=tRiskRateVersion;
     exception
     when NO_DATA_FOUND then
      return 0;
     end;
  end if;

  Result := tWageRate;
  return(Result);

end AgentCalDirectWage;


/

