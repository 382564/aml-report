create function getActuGrpContState(pFlag in varchar2 ,dEvlDateStr in DATE,dEvlDateEnd in DATE,vManComCode in VARCHAR2) return integer is
  Result integer;
  pragma autonomous_transaction;
  v_total integer:=0;
  v_debug_flag char(10);
begin
  DECLARE
  strContno char(20);
  tmp_ContNo varchar2(20);
  tmp_PolNo char(20);
  tmp_RiskCode char(3);
  flag integer:=1;
  v_int_count2 integer:=0;
  strInsuredNo char(24);
  strRiskCode VARCHAR2(10);
  v_int_tmp integer;
  v_int_temp2 integer;
  v_count_watnum integer :=0;
  v_state integer:=0;
  vsummoney number(12,2);
  vChangeReason integer :=0;
  CurrentDate date;
  fen char(10); --fgs
  writeFlag integer; --xsl,00001,20060314,??????????,??????????????
  v_contno char(20);

  v_row_ActuGrpContState ActuGrpContState%rowtype;
  v_row_LCContState LCContState%rowtype;

  cursor choose is select * from ActuGrpContState where changereason in ('3','4','5','6','8');--00004


  /*_________________________???????_______________________________*/
  cursor v_cur_LCContState is
  --????,?riskcode?? 2006-03-06 liuzhao
  select CONTNO,INSUREDNO,POLNO,STATETYPE,STATE,STATEREASON,STARTDATE,ENDDATE,REMARK,OPERATOR,MAKEDATE,MAKETIME,MODIFYDATE,MODIFYTIME from
  (
    --????????Available??? 2006-03-03 liuzhao
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    and exists (select 1 FROM ActuGrpContData where contno=a.contno and managecom like vManComCode || '%')
    and statetype not in('Available','Terminate','BankLoan','Loan','Lost','PayPrem','RPU')
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno in('HB010226071000037')

    --2006-04-13 liuzhao ?? Terminate and state ='1' ???
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    and exists (select 1 FROM ActuGrpContData where contno=a.contno and managecom like vManComCode || '%')
    and statetype in('Terminate')
    and state ='1'
    and STATEREASON not in('04')
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno in('HB010226071000037')

    --??????? 2006-03-03 liuzhao
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    and exists (select 1 FROM ActuGrpContData where contno=a.contno and managecom like vManComCode || '%')
    and statetype  in('Available')
    and state ='1'
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
        --???
    --and contno in('HB010226071000037')

    --??????? 2006-03-03 liuzhao
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    and exists (select 1 FROM ActuGrpContData where contno=a.contno and managecom like vManComCode || '%')
    and statetype  in('Available')
    and state ='0'
    --???? 2006-03-06 liuzhao edorvalidate=a.startdate
    and exists(select 1 from lpedoritem where edorvalidate=a.startdate and edortype ='RE' and contno=a.contno)
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno in('HB010226071000037')
    ) a
    order by contno ,a.riskcode ,startdate
    ;





  /*_________________________???????_______________________________*/
    cursor v_cur_LCContState_sel is
  --????,?riskcode?? 2006-03-06 liuzhao
  select CONTNO,INSUREDNO,POLNO,STATETYPE,STATE,STATEREASON,STARTDATE,ENDDATE,REMARK,OPERATOR,MAKEDATE,MAKETIME,MODIFYDATE,MODIFYTIME from
  (
    --????????Available??? 2006-03-03 liuzhao
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    --for test
    and exists (select 1 FROM SelGrpCont where contno=a.contno and default3 like vManComCode || '%')
    and statetype not in('Available','BankLoan','Terminate','Loan','Lost','PayPrem','RPU')
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno = v_contno
    --order by contno


    --2006-04-13 liuzhao ?? Terminate and state ='1' ???
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    and exists (select 1 FROM SelGrpCont where contno=a.contno and default3 like vManComCode || '%')
    and statetype in('Terminate')
    and state ='1'
    and STATEREASON not in('04')
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno in('HB010226071000037')

    --??????? 2006-03-03 liuzhao
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    --for test
    and exists (select 1 FROM SelGrpCont where contno=a.contno and default3 like vManComCode || '%')
    and statetype  in('Available')
    and state ='1'
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --and contno = v_contno
    --??????? 2006-03-03 liuzhao
    union
    select a.*,(select riskcode from lcpol where polno=a.polno) as riskcode from lccontstate a
    where 1=1
    and polno<>'000000'
    --for test
    --and contno = v_contno
    and exists (select 1 FROM SelGrpCont where contno=a.contno and default3 like vManComCode || '%')
    and statetype  in('Available')
    and state ='0'
    and exists(select 1 from lccont where contno = a.contno and grpcontno <>'00000000000000000000')
    --???? 2006-03-03 liuzhao
    --???? 2006-03-06 liuzhao edorvalidate=a.startdate
    and exists(select 1 from lpedoritem where edorvalidate=a.startdate and edortype ='RE' and contno=a.contno)
    --and contno = v_contno
    ) a
    order by contno ,a.riskcode ,startdate
    ;


  begin
  execute immediate 'alter session set nls_date_format = ''YYYY-MM-DD''';
   if pFlag = '0' then
   if length(vManComCode)>=4 then
     --execute immediate 'TRUNCATE TABLE ActuGrpContState';
     execute immediate 'DELETE FROM ActuGrpContState WHERE fgs = '''||substr(vManComCode,3,2)||''''  ;
     commit;
    else
     execute immediate 'TRUNCATE TABLE ActuGrpContState'  ;
   end if;
   end if;
  select contno into strContno from lccont where rownum=1;
  select to_date(Sysdate,'YYYY-MM-DD') into CurrentDate from dual;


     if pFlag ='1' then
       open v_cur_LCContState_sel;
     else
       open v_cur_LCContState;
     end if;

  loop
    if pFlag = '1' then
     fetch v_cur_LCContState_sel into v_row_LCContState;
     exit when v_cur_LCContState_sel%notfound;
    else
     fetch v_cur_LCContState into v_row_LCContState;
     exit when v_cur_LCContState%notfound;
    end if;

    writeFlag :=1; --xsl,00001,20060314


    select count(1) into v_int_tmp from lcpol where polno=v_row_LCContState.polno;
    if v_int_tmp <> 0 then
    --????
    v_int_tmp := 0;
    --?????,00005,xsl,20060321
    begin
     select salechnl into v_row_ActuGrpContState.salechnl from lcpol where polno =v_row_LCContState.polno;
    exception when NO_DATA_FOUND then null;
    end;
    --????fgs
    begin
    select managecom into fen from lccont where contno =v_row_LCContState.contno;
    exception when NO_DATA_FOUND then null;
    end;
    if fen is not null and length(trim(fen))>4 then
     v_row_ActuGrpContState.fgs :=substr(fen, 3, 2);--fgs
    end if;


    --????????,?????????????
    if flag = 1 then --?????
      tmp_ContNo:= v_row_LCContState.ContNo;
      tmp_PolNo := v_row_LCContState.PolNo;
      select riskcode into strRiskCode  from lcpol where polno=v_row_LCContState.polno;
      tmp_RiskCode := substr(strRiskCode,3,3);
      flag:=0;
    end if;

      v_count_watnum:= v_count_watnum+1;
      v_row_ActuGrpContState.WatNum := v_count_watnum; --??????,??????????
  --???
      v_row_ActuGrpContState.ContNo := v_row_LCContState.ContNo;

   --???
      select insuredno into strInsuredNo from lccont where contno=v_row_LCContState.ContNo;
      v_row_ActuGrpContState.customerno := strInsuredNo;

      --????
       v_row_ActuGrpContState.CompanyNo := '';


   --????
    /*  if v_row_LCContState.polno<>'000000' then*/
      select count(1) into v_int_tmp from lcpol where polno=v_row_LCContState.polno;
     if v_int_tmp<>0 then
        select riskcode into strRiskCode  from lcpol where polno=v_row_LCContState.polno;
        v_row_ActuGrpContState.riskcode := substr(strRiskCode,3,3);
      end if;



   --????
       v_int_tmp :=0;
       if v_row_LCContState.polno<>'000000' then
        select count(1) into v_int_tmp from lcpol where polno=v_row_LCContState.polno and polno=mainpolno;
        if v_int_tmp<>0 then
         v_row_ActuGrpContState.mainflag:= 1;
         else
         v_row_ActuGrpContState.mainflag:= 2;
        end if;
        else
         v_row_ActuGrpContState.mainflag:= '';
       end if;



   --??????
   if  v_row_LCContState.StateType = 'Terminate' then
    if v_row_LCContState.State = '1' then
     if  v_row_LCContState.StateReason = '01' then
      v_row_ActuGrpContState.changereason:='3';--??
      vChangeReason := 1;
    end if;

     if  v_row_LCContState.StateReason = '02' then
     select count(1) into v_state from lpedoritem where edortype='CT'  and
     polno=v_row_LCContState.polno
     and standbyflag1='1';
     if v_state<>0 then
      v_row_ActuGrpContState.changereason:='6';--?????
       vChangeReason := 1;
     else
      v_row_ActuGrpContState.changereason:='5'; --??
       vChangeReason := 1;
      end if;
     end if;

  --????
      if  /*v_row_LCContState.StateReason = '01' or*/ --zx
          v_row_LCContState.StateReason = '08' or
          v_row_LCContState.StateReason = '05' or
          v_row_LCContState.StateReason = '06' or v_row_LCContState.StateReason = '03' then
      if v_row_LCContState.State<>0 then
        v_row_ActuGrpContState.changereason:='8';
        vChangeReason := 1;
      end if;
     end if;

     if  v_row_LCContState.StateReason = '07' then
      if v_row_LCContState.State<>0 then
        v_row_ActuGrpContState.changereason:='7'; --????
        vChangeReason := 1;
      end if;
     end if;
  --????
     if  v_row_LCContState.StateReason = '04' then
     if v_row_LCContState.polno<>'000000' then
      select count(1) into v_state from llbalance where polno=v_row_LCContState.polno and FeeOperationType like 'D%';
      if v_state <>0 then
        select count(1) into v_state from llclaimpolicy where polno=v_row_LCContState.polno and GiveType='1';
        if v_state<>0 then
         v_row_ActuGrpContState.changereason:='4';--????
         vChangeReason := 1;
         else
         v_row_ActuGrpContState.changereason:='8';
         vChangeReason := 1;
        end if;
      else
        v_row_ActuGrpContState.changereason:='8';--xsl,060309
        writeFlag :=0;
        vChangeReason := 1;
     end if;
     else
      select count(1) into v_state from llbalance where contno=v_row_LCContState.contno and FeeOperationType like 'D%';
       if v_state <>0 then
        select count(1) into v_state from llclaimpolicy where contno=v_row_LCContState.contno and GiveType='1';
        if v_state<>0 then
         v_row_ActuGrpContState.changereason:='4';--????
         vChangeReason := 1;
        end if;
     end if;
     end if;

     end if;
    end if;
   end if;

   if  v_row_LCContState.StateType = 'Available' then

    if v_row_LCContState.State = '1' then
    --???????????????????????,????????
/*      select count(1) into v_state from lpedoritem
      where edortype='RE' and contno=v_row_LCContState.contno
      and makedate between v_row_LCContState.startdate
      and Add_months(v_row_LCContState.startdate,24)
      ;
      if v_state=0 then
       v_row_ActuGrpContState.changereason:='????';
      else
       v_row_ActuGrpContState.changereason:='??';
      end if;*/
      if v_row_LCContState.enddate is null then
        v_row_ActuGrpContState.changereason:='1';--??
              vChangeReason := 1;
        else
        if v_row_LCContState.enddate <=Add_months(v_row_LCContState.startdate,24) then
         v_row_ActuGrpContState.changereason:='1'; --??
               vChangeReason := 1;
         else
          v_row_ActuGrpContState.changereason:='7'; --????
                vChangeReason := 1;
        end if;
      end if;
      else
      --???? liuzhao 2006-03-06 edorvalidate=v_row_LCContState.startdate;
      select count(1) into v_state from lpedoritem where contno=v_row_LCContState.contno
       and edortype='RE' and edorvalidate=v_row_LCContState.startdate;
      if v_state<>0 then
       v_row_ActuGrpContState.changereason:='2';--??
      vChangeReason := 1;
      end if;
    end if;
   end if;


 if  vChangeReason = 0 then
  v_row_ActuGrpContState.changereason:='';
  else
   vChangeReason := 0;
 end if;

   --????
   if v_row_LCContState.StateType = 'Terminate' and v_row_LCContState.State = '1' and v_row_LCContState.StateReason = '02' then
    if v_row_LCContState.polno<>'000000' then
    select nvl(sum(-getmoney),0) into vsummoney from ljagetendorse
    where feeoperationtype='CT' AND feefinatype in('TB','TF','GB') AND polno= v_row_LCContState.polno ;
     v_row_ActuGrpContState.ctmoney := vsummoney;
   else
    select nvl(sum(-getmoney),0) into vsummoney from ljagetendorse
    where feeoperationtype='CT' AND feefinatype in('TB','TF','GB') AND contno= v_row_LCContState.contno and riskcode=strRiskCode;
     v_row_ActuGrpContState.ctmoney := vsummoney;
     end if;
    else
     v_row_ActuGrpContState.ctmoney :=0;
   end if;


   --????
   if v_row_LCContState.startdate is not null then
    v_row_ActuGrpContState.changedate := v_row_LCContState.startdate;
   end if;

      --??????--00002
    if v_row_LCContState.StateType = 'RPU' then
     writeFlag :=0;
    end if;

   if writeFlag <>0 then --00003
        --????
   if tmp_ContNo = v_row_LCContState.ContNo
      --and tmp_PolNo = v_row_LCContState.PolNo
      and tmp_RiskCode = substr(strRiskCode,3,3)
      then
     v_int_count2 := v_int_count2+1;
      v_row_ActuGrpContState.ChangeNo := v_int_count2;
     else
      v_int_count2 :=0;
      v_int_count2 := v_int_count2+1;
      v_row_ActuGrpContState.ChangeNo := v_int_count2;
      tmp_ContNo:= v_row_LCContState.ContNo;
      --tmp_PolNo:= v_row_LCContState.PolNo;
      tmp_RiskCode := substr(strRiskCode,3,3);
   end if;
   end if;


   if writeFlag <>0 then --00001
     insert into ActuGrpContState values v_row_ActuGrpContState;
   end if;
    commit;

     v_total:=v_total+1;
     end if;
   end loop;

   if pFlag = '1' then
    close  v_cur_LCContState_sel;
   else
    close v_cur_LCContState;
   end if;

  open choose;--00004,???????????
  loop
     fetch choose into v_row_ActuGrpContState;
     exit when choose%notfound;
     v_state :=0;
     select count(1)
       into v_state
       from ActuGrpContState
      where contno = v_row_ActuGrpContState.contno
        and riskcode = v_row_ActuGrpContState.riskcode
        and changedate > v_row_ActuGrpContState.changedate;
     if v_state >0 then
     delete from ActuGrpContState
      where contno = v_row_ActuGrpContState.contno
        and riskcode = v_row_ActuGrpContState.riskcode
        and watnum > v_row_ActuGrpContState.watnum;
     end if;
  end loop;
  close choose;

   v_count_watnum := 0;
  end;
  COMMIT;
 return(v_total);


exception
   when others then
   dbms_output.put_line('????:GetActuGrpContState' || ' ???????: ' || sqlerrm);
   return('E???????: ' || sqlerrm);
   --return(v_debug_flag || 'E???????: ' || sqlerrm);
end getActuGrpContState;


/

