create function chgpaymode810(paymode in varchar2) return varchar2
is
tR varchar2(20);
begin
 if paymode = '0' then
  tR := '1';
 end if;
 if paymode = '12' then
  tR := '1';
 end if;
 if paymode = '1' then
  tR := '0.09';
 end if;

 return(tR);
end;


/

