create function calEmployeeIncomeTax(Commission in number)
  return number is
  Tax number;
begin
  if Commission <= 0 then
    Tax := 0;
  elsif Commission < 1500 then
    Tax := Commission * 0.03;
  elsif Commission <= 4500 then
    Tax := Commission * 0.1 - 105;
  elsif Commission <= 9000 then
    Tax := Commission * 0.2 - 555;
  elsif Commission <= 35000 then
    Tax := Commission * 0.25 - 1005;
  elsif Commission <= 55000 then
    Tax := Commission * 0.3 - 2755;
  elsif Commission <= 80000 then
    Tax := Commission * 0.35 - 5505;
  else
    Tax := Commission * 0.45 - 13505;
  end if;
  return round(Tax,2);
end calEmployeeIncomeTax;


/

