create function getCommisionMNGRate(cCommisionsn in varchar2,cAgentgrade in varchar2)
  return number is
  Result number;
begin
  select nvl(b.rate,0)
  into Result
    from LACommision a, LARATECOMMISION b
   where a.riskcode = b.riskcode
     and b.f01 = cAgentgrade
     and a.commisionsn = cCommisionsn;
return(Result);
end getCommisionMNGRate;

/

