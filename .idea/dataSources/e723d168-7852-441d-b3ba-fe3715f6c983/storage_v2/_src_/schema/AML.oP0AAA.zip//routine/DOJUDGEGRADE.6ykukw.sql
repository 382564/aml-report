create function doJudgeGrade(tAgentCode in varchar2) return varchar2 is
  tCount      integer:=0;
  tCount1     integer:=0;
  tOldGrade   varchar2(3);
  tStrEmployDate varchar2(10);
  tEmployDate LAAgent.Employdate%TYPE;
  tStartDate  LATree.Startdate%TYPE;

  Result      varchar2(1);
begin
  select employdate,startdate into tEmployDate,tStartDate from laagenttreeview
  where agentcode = trim(tAgentCode);
  if tEmployDate = tStartDate then
    return('Y');
  end if;

  select nvl(count(*),0) into tCount from latreeb
  where removetype <> '05' and agentcode = trim(tAgentCode);

  select to_char(employdate,'yyyy-mm-dd') into tStrEmployDate from laagent
  where agentcode = trim(tAgentCode);

  if tCount = 0 then
    Result := 'Y';
  else
    select count(*) into tCount1 from latreeb
    where agentcode = trim(tAgentCode)
      and startdate = tEmployDate
      and edorno = (select max(edorno) from latreeb
                    where agentcode = trim(tAgentCode)
                    and startdate = tEmployDate
                   );

    if tCount1 = 0 then
      return('Y');
    end if;

    select agentgrade into tOldGrade from latreeb
    where agentcode = trim(tAgentCode)
      and startdate = tEmployDate
      and edorno = (select max(edorno) from latreeb
                    where agentcode = tAgentCode
                    and startdate = tEmployDate);

    if tOldGrade < 'A04' then
      Result := 'N';
    else
      Result := 'Y';
    end if;
  end if;

  return(Result);
end doJudgeGrade;


/

