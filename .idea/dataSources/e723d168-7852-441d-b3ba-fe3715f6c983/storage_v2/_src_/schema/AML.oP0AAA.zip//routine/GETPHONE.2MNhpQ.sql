create function GETPHONE(tAppntNo in VARCHAR2) return VARCHAR is
  Result     VARCHAR(20);
  tphone     varchar(20);
  thomephone varchar(20);
  tmobile    varchar(20);
  tcompanyphone  varchar(20);
begin
  select phone, homephone, mobile, companyphone
    into tphone, thomephone, tmobile, tcompanyphone
    from LCAddress
   where (AddressNo in
         (select min(AddressNo) from LCAddress where CustomerNo = tAppntNo))
     and CustomerNo = tAppntNo;

  if (tphone is null) then
    if (thomephone is null) then
      if (tmobile is null) then
        if (tcompanyphone is null) then
          Result := '';
        else
          Result := tcompanyphone;
        end if;
      else
        Result := tmobile;
      end if;
    else
      Result := thomephone;
    end if;
  else
    Result := tphone;
  end if;

  return(Result);
end GETPHONE;


/

