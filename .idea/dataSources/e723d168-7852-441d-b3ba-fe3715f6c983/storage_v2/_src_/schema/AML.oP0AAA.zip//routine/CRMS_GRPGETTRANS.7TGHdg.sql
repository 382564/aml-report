create PROCEDURE CRMS_GRPGETTRANS(TSTRATDATE  IN VARCHAR2,
                                               TENDDATE    IN VARCHAR2,
                                               TCUSTOMERNO IN VARCHAR2,
                                               ERRORMSG    OUT VARCHAR2) AS

  TMDATE DATE; --月末
  TCDATE DATE; --月初
  TEDATE DATE; --结束日期
  --TMODULE VARCHAR2(10); --提数模块

BEGIN
  --TMODULE  := '06'; --准备金
  ERRORMSG := 'Y';

  --有客户号时，只通过客户号查询
  IF (TCUSTOMERNO IS NOT NULL) THEN
    BEGIN
      --可能会有主键冲突，所以需要先删除，再提数
      DELETE FROM MID_CR_Trans D
       WHERE D.TRANSNO IN (SELECT C.ACTUGETNO
                             FROM LCGRPCONT A, LJAGET C
                            WHERE A.APPFLAG <> '0'
                              AND A.GRPCONTNO = C.OTHERNO
                              AND A.APPNTNO = TCUSTOMERNO
                           UNION
                           SELECT C.ACTUGETNO
                             FROM LJAGET C, LPEDORITEM LP, LCGRPCONT B
                            WHERE LP.EDORACCEPTNO = C.OTHERNO
                              and LP.grpcontno = B.grpcontno
                              AND C.APPNTNO = TCUSTOMERNO
                           UNION
                           SELECT A.EDORACCEPTNO
                             FROM LPEDORITEM A, LCGRPCONT B
                            WHERE A.grpcontno = B.grpcontno
                              AND A.EDORTYPE = 'PC'
                              AND B.APPNTNO = TCUSTOMERNO);
      --开始提数
      INSERT INTO MID_CR_Trans
        SELECT C.ACTUGETNO TRANSNO,
               A.GRPCONTNO ContNo,
               '02' ContType,
               '1' transmethod,
               case c.othernotype
                 when '1' then
                  '1'
                 when '2' then
                  'BQ'
                 when '4' then
                  'BQ'
                 when '5' then
                  'BQ'
                 when '6' then
                  'BQ'
                 when '7' then
                  'BQ'
                 when '9' then
                  'BQ'
                 else
                  c.othernotype
               end transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               (SELECT D.PAYMODE
                  FROM LJTEMPFEECLASS D, LJTEMPFEE E
                 WHERE E.OTHERNO = A.grpcontno
                   AND E.TEMPFEENO = D.TEMPFEENO
                   AND ROWNUM = 1) PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM LCGRPCONT A, LJAGET C,lpedoritem lp
         WHERE A.APPFLAG <> '0'
           AND A.GRPCONTNO = C.OTHERNO
           and a.grpcontno = lp.grpcontno
           and A.GRPCONTNO <> '00000000000000000000'
           AND A.APPNTNO = TCUSTOMERNO --有客户号时，只通过客户号查询

        UNION
        SELECT C.ACTUGETNO TRANSNO,
               A.GRPCONTNO ContNo,
               '02' ContType,
               (SELECT apptype
                  FROM lpedorapp
                 WHERE edoracceptno = B.edoracceptno) transmethod,
               case B.edortype
                 when 'LN' THEN
                  '07'
                 when 'CT' THEN
                  '05'
                 when 'PD' THEN
                  '08'
                 when 'PT' THEN
                  '09'
                 when 'XT' THEN
                  '13'
                 when 'WT' THEN
                  '11'
                 when 'PC' THEN
                  '14'
                 ELSE
                  B.edortype

               end transtype,
               C.ENTERACCDATE TRANSDATE,
               'RMB' CURETYPE,
               C.SUMGETMONEY PAYAMT,
               '2' PAYWAY,
               (SELECT D.PAYMODE
                  FROM LJTEMPFEECLASS D, LJTEMPFEE E
                 WHERE E.OTHERNO = A.grpcontno
                   AND E.TEMPFEENO = D.TEMPFEENO
                   AND ROWNUM = 1) PayMode,
               C.BANKCODE AccBank,
               C.Bankaccno AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               C.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM lpedoritem b, LJAGET C, LCGRPCONT A
         WHERE b.edoracceptno = C.OTHERNO
           and b.grpcontno = a.grpcontno
           and b.uwflag = '9'
           and A.GRPCONTNO <> '00000000000000000000'
           AND A.APPNTNO = TCUSTOMERNO

        UNION
        SELECT B.EDORACCEPTNO TRANSNO,
               A.GRPCONTNO ContNo,
               '02' ContType,
               (SELECT apptype
                  FROM lpedorapp
                 WHERE edoracceptno = B.edoracceptno) transmethod,
               '14' transtype,
               B.EDORVALIDATE TRANSDATE,
               'RMB' CURETYPE,
               to_number('0') PAYAMT,
               '' PAYWAY,
               (SELECT payform
                  FROM lpedorapp
                 WHERE edoracceptno = B.edoracceptno) PayMode,
               A.BANKCODE AccBank,
               A.BANKACCNO AccNo,
               '' CHANNEL,
               '' OPER,
               '' AMLTCTC,
               A.ACCNAME AMLACCNAME,
               '' AccType,
               '' AgentName,
               '' AgentCardType,
               '' AgentCardID,
               '' AgentNationality,
               '' TradeCusName,
               '' TradeCusCardType,
               '' TradeCusCardID,
               '' TradeCusAccType,
               '' TradeCusAccNo,
               TRUNC(SYSDATE, 'dd') MAKEDATE,
               TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
          FROM lpedoritem B, LCGRPCONT A
         WHERE b.grpcontno = a.grpcontno
           and b.uwflag = '9'
           and A.GRPCONTNO <> '00000000000000000000'
           AND B.EDORTYPE = 'PC'
           AND A.APPNTNO = TCUSTOMERNO;

      COMMIT;
    END;

  ELSE
    --没有客户号，通过时间查询
    BEGIN
      SELECT TO_DATE(TSTRATDATE, 'yyyy-MM-dd') INTO TCDATE FROM DUAL; --月初
      SELECT LEAST(TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') - 1,
                   TO_DATE(TENDDATE, 'yyyy-MM-dd'))
        INTO TMDATE
        FROM DUAL; --月末
      SELECT TO_DATE(TENDDATE, 'yyyy-MM-dd') INTO TEDATE FROM DUAL; --结束日期

      --循环提取数据
      WHILE TMDATE <= TEDATE LOOP
        --可能会有主键冲突，所以需要先删除，再提数
        DELETE FROM MID_CR_Trans D
         WHERE D.TRANSNO IN (SELECT C.ACTUGETNO
                               FROM LCGRPCONT A, LJAGET C
                              WHERE A.APPFLAG <> '0'
                                AND A.GRPCONTNO = C.OTHERNO
                                AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN
                                    TCDATE AND TMDATE
                             UNION
                             SELECT C.ACTUGETNO
                               FROM LJAGET C, LPEDORITEM LP, LCGRPCONT B
                              WHERE LP.EDORACCEPTNO = C.OTHERNO
                                and LP.grpcontno = B.grpcontno
                                AND LP.EDORVALIDATE BETWEEN
                                    TCDATE AND TMDATE
                             UNION
                             SELECT A.EDORACCEPTNO
                               FROM LPEDORITEM A, LCGRPCONT B
                              WHERE A.grpcontno = B.grpcontno
                                AND A.EDORTYPE = 'PC'
                                AND A.EDORVALIDATE BETWEEN
                                    TCDATE AND TMDATE

                             ); --没有客户号时，通过时间查询

        --开始提数
        INSERT INTO MID_CR_Trans
          SELECT C.ACTUGETNO TRANSNO,
                 A.GRPCONTNO ContNo,
                 '02' ContType,
                 '1' transmethod,
                 case c.othernotype
                   when '1' then
                    '1'
                   when '2' then
                    'BQ'
                   when '4' then
                    'BQ'
                   when '5' then
                    'BQ'
                   when '6' then
                    'BQ'
                   when '7' then
                    'BQ'
                   when '9' then
                    'BQ'
                   else
                    c.othernotype
                 end transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 (SELECT D.PAYMODE
                    FROM LJTEMPFEECLASS D, LJTEMPFEE E
                   WHERE E.OTHERNO = A.grpcontno
                     AND E.TEMPFEENO = D.TEMPFEENO
                     AND ROWNUM = 1) PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM LCGRPCONT A, LJAGET C
           WHERE A.APPFLAG <> '0'
             AND A.GRPCONTNO = C.OTHERNO
             and A.GRPCONTNO <> '00000000000000000000'
             AND GREATEST(A.CVALIDATE, A.SIGNDATE) BETWEEN TCDATE AND
                 TMDATE --没有客户号时，通过时间查询

          UNION
          SELECT C.ACTUGETNO TRANSNO,
                 A.GRPCONTNO ContNo,
                 '02' ContType,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = B.edoracceptno) transmethod,
                 case B.edortype
                   when 'LN' THEN
                    '07'
                   when 'CT' THEN
                    '05'
                   when 'PD' THEN
                    '08'
                   when 'PT' THEN
                    '09'
                   when 'XT' THEN
                    '13'
                   when 'WT' THEN
                    '11'
                   when 'PC' THEN
                    '14'
                   ELSE
                    'BQ'

                 end transtype,
                 C.ENTERACCDATE TRANSDATE,
                 'RMB' CURETYPE,
                 C.SUMGETMONEY PAYAMT,
                 '2' PAYWAY,
                 (SELECT D.PAYMODE
                    FROM LJTEMPFEECLASS D, LJTEMPFEE E
                   WHERE E.OTHERNO = A.grpcontno
                     AND E.TEMPFEENO = D.TEMPFEENO
                     AND ROWNUM = 1) PayMode,
                 C.BANKCODE AccBank,
                 C.Bankaccno AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 C.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM lpedoritem b, LJAGET C, LCGRPCONT A
           WHERE b.edoracceptno = C.OTHERNO
             and b.grpcontno = a.grpcontno
             and b.uwflag = '9'
             AND b.edorvalidate BETWEEN TCDATE AND
                 TMDATE

          UNION
          SELECT B.EDORACCEPTNO TRANSNO,
                 A.GRPCONTNO ContNo,
                 '02' ContType,
                 (SELECT apptype
                    FROM lpedorapp
                   WHERE edoracceptno = B.edoracceptno) transmethod,
                 '14' transtype,
                 B.EDORVALIDATE TRANSDATE,
                 'RMB' CURETYPE,
                 to_number('0') PAYAMT,
                 '' PAYWAY,
                 (SELECT payform
                    FROM lpedorapp
                   WHERE edoracceptno = B.edoracceptno) PayMode,
                 A.BANKCODE AccBank,
                 A.BANKACCNO AccNo,
                 '' CHANNEL,
                 '' OPER,
                 '' AMLTCTC,
                 A.ACCNAME AMLACCNAME,
                 '' AccType,
                 '' AgentName,
                 '' AgentCardType,
                 '' AgentCardID,
                 '' AgentNationality,
                 '' TradeCusName,
                 '' TradeCusCardType,
                 '' TradeCusCardID,
                 '' TradeCusAccType,
                 '' TradeCusAccNo,
                 TRUNC(SYSDATE, 'dd') MAKEDATE,
                 TO_CHAR(SYSDATE, 'HH24:Mi:SS') MAKETIME
            FROM lpedoritem B, LCGRPCONT A
           WHERE b.grpcontno = a.grpcontno
             and b.uwflag = '9'
             AND B.EDORTYPE = 'PC'
             and A.GRPCONTNO <> '00000000000000000000'
             AND b.edorvalidate BETWEEN TCDATE AND
                 TMDATE;

        COMMIT;
        SELECT TRUNC(ADD_MONTHS(TCDATE, 1), 'MM') INTO TCDATE FROM DUAL; --下月月初
        SELECT CASE
                 WHEN TEDATE = TMDATE THEN
                  TMDATE + 1
                 ELSE
                  LEAST(ADD_MONTHS(TCDATE, 1) - 1, TEDATE)
               END
          INTO TMDATE
          FROM DUAL; --下月月末
      END LOOP; --结束循环
    END;
  END IF;

EXCEPTION
  --异常处理
  WHEN TOO_MANY_ROWS THEN
    BEGIN
      SELECT TO_CHAR(TCDATE, 'yyyy-MM-dd') || 'TOO_MANY_ROWS!!!'
        INTO ERRORMSG
        FROM DUAL;
    END;
  WHEN OTHERS THEN
    BEGIN
      ERRORMSG := SQLCODE || '---' || SQLERRM;
      SELECT (TO_CHAR(TCDATE, 'yyyy-MM-dd') || ERRORMSG)
        INTO ERRORMSG
        FROM DUAL;
      --DBMS_OUTPUT.PUT_LINE(tExtractDate||SQLCODE||'---'||SQLERRM);
    END;

END CRMS_GRPGETTRANS;


/

