create function BC_UW(PolNo in varchar2, EdorNo in varchar2) return number is
  Result number;
  PolNo1 char(20);
  EdorNo1 char(20);
  Name1 LPbnf.Name%type;
  RelationToInsured1 LPbnf.Relationtoinsured%type;
  InsuredNo1 LPbnf.Insuredno%type;
  BnfGrade1 LPbnf.BnfGrade%type;
  BnfType1 LPbnf.BnfType%type;
  BnfNo1 LPbnf.BnfNo%type;
  Name0 LCbnf.Name%type;
  RelationToInsured0 LCbnf.Relationtoinsured%type;
  --c????????0,p????????1
begin
PolNo1:=PolNo;
EdorNo1:=EdorNo;
--???
  Result:=0;
  declare
  cursor bc_order is
  select Name,BnfGrade,BnfType,BnfNo,RelationToInsured,InsuredNo into Name1,BnfGrade1,BnfType1,BnfNo1,RelationToInsured1,InsuredNo1 from lpbnf where trim(polno)=trim(PolNo1) and trim(edorno)=trim(EdorNo1) and trim(edortype)='BC';
  --???????????BC????lpbnf???????
  begin
     open bc_order;
        loop
           fetch bc_order into Name1,BnfGrade1,BnfType1,BnfNo1,RelationToInsured1,InsuredNo1;
           if bc_order%notfound then
              exit;
           else
              if RelationToInsured1 not in ('00','01','02','03','04','05','07','08','09','10','11','23') then
                 --????????????????????????,???????
                  select nvl((select Name from lcbnf where polno=PolNo1 and InsuredNo=InsuredNo1 and BnfGrade=BnfGrade1 and BnfType=BnfType1 and BnfNo=BnfNo1),0) into Name0 from dual;
                  select nvl((select RelationToInsured from lcbnf where polno=PolNo1 and InsuredNo=InsuredNo1 and BnfGrade=BnfGrade1 and BnfType=BnfType1 and BnfNo=BnfNo1),0) into RelationToInsured0 from dual;
                  --if Name0 is null then
                      --Result:=1;
                      --exit;
                  --else
                      --select Name,RelationToInsured into Name0,RelationToInsured0 from lcbnf where polno=PolNo1 and InsuredNo=InsuredNo1 and BnfNo=BnfNo1 and BnfType=BnfType1;
                  --????polno,insuredno?bnfno?c????,????????c????????,???????0??
                      if trim(Name1)<>trim(Name0) or RelationToInsured1<>RelationToInsured0 then
                          Result:=1;
                          exit;
                      end if;
                   end if;
                  --???????????????,????????????
               end if;
            --end if;
          end loop;
    close bc_order;
  end;
  return(Result);
end BC_UW;


/

