create Function getBirthdayByID(v_idno in varchar2) Return varchar2 is
  Result varchar2(30);

  v_length Number;

begin
  select length(v_idno) into v_length from dual;
  if v_length=18 then
    select substr(v_idno,7,4)||'-'||substr(v_idno,11,2)||'-'||substr(v_idno,13,2) into Result from dual;
  else if v_length=15 then
    select '19'||substr(v_idno,7,2)||'-'||substr(v_idno,9,2)||'-'||substr(v_idno,11,2) into Result from dual;
  else
    Result:= '';
  END IF;
  END IF;
return(Result);
End getBirthdayByID;


/

