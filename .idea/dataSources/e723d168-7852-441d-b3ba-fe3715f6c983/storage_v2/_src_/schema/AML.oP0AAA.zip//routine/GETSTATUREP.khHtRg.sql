create FUNCTION GetStaturep(ContNo1 char, CustomerNo1 char,EdorNo1 char) return number is
  Result number;
begin
  select distinct ImpartParam into Result from LpCustomerImpartParams where ContNo=ContNo1 And CustomerNo=CustomerNo1 and EdorNo=EdorNo1 And Impartver='02' and Impartcode='000' and ImpartParamNo='1';
  return(Result);
end GetStaturep;


/

