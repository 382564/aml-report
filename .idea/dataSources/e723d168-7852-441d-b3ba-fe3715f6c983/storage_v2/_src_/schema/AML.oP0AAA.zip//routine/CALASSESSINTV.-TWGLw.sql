create function CalAssessIntv
(tAgentCode latree.agentcode%TYPE ,tIndexCalNo laassess.indexcalno%TYPE)
return  VARCHAR2 is
  Result VARCHAR2(2);
  --??????????????????????????
  --????
  tStartDate Date; --??????????
  tDayLimit VARCHAR2(2);--???????,???10???????,
                 --??????????????
  tBeginDate Date;
  tIntv VARCHAR2(2);

begin
  begin
  --1 ?????????????
  select startdate into tStartDate from latree where agentcode = tAgentCode;

  exception
  when NO_DATA_FOUND then
   tStartDate := to_date('2999-01-01','YYYY-MM-DD');
  end;

  select trim(varvalue) into tDayLimit from lasysvar where vartype = 'EmployLimit';
     tBeginDate := to_Date(substr(to_char(tStartDate,'YYYY-MM-DD'),0,8)||'01','YYYY-MM-DD');
  if(substr(to_char(tStartDate,'YYYY-MM-DD'),9,2)>tDayLimit) then
     tBeginDate := to_date(substr(to_char(add_months(tStartDate,1),'YYYY-MM-DD'),0,8)||'01','YYYY-MM-DD');
  end if;
      select months_between(add_months(to_date((substr(tIndexCalNo,0,4)||'-'||substr(tIndexCalNo,5,2)||'-01'),'YYYY-MM-DD'),1),tBeginDate)
      into tIntv from dual;

     Result:= tIntv;
  return(Result);
end CalAssessIntv;


/

