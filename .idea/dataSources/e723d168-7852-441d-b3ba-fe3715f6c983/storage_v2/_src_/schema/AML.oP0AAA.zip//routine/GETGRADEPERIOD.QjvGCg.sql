create FUNCTION getGradePeriod(cAgentCode  in varchar2,
                                          cAgentGrade in varchar2,
                                          cStartDate  in date,
                                          cEndDate    in date) return number is
------ ??????????????? ------
  iMonthCount number;
  sLimitBase  varchar2(2);
  sExist      varchar2(5) := 'false';
  dEmployDate Date;
begin
  iMonthCount := 0;
  --????????
  SELECT 'true' INTO sExist FROM dual
   WHERE EXISTS(SELECT * FROM LATreeb WHERE AgentCode = cAgentCode AND StartDate BETWEEN cStartDate AND cEndDate)
      OR EXISTS(SELECT * FROM LATree WHERE AgentCode = cAgentCode AND StartDate BETWEEN cStartDate AND cEndDate);
  IF sExist = 'false' THEN
    return(iMonthCount);
  END IF;
  --???????????
    SELECT EmployDate INTO dEmployDate FROM LAAgent WHERE AgentCode = cAgentCode;
  --?????????
    SELECT trim(varvalue) INTO sLimitBase FROM LASysvar
     WHERE vartype = 'EmployLimit';
  DECLARE
    tAgentGrade     varchar2(3);
    tLastAgentGrade varchar2(3) := '';
    tStartDate      Date;
    tLastStartDate  Date;
    tTempDate       Date;
    bStatFlag       boolean := false; --????????:true ??:false
  CURSOR C_Tree IS
    SELECT DISTINCT AgentGrade,StartDate FROM LATreeB
    WHERE StartDate BETWEEN cStartDate AND cEndDate and AgentCode = cAgentCode
    UNION
    SELECT AgentGrade,StartDate FROM LATree
    WHERE StartDate BETWEEN cStartDate AND cEndDate and AgentCode = cAgentCode
    ORDER BY StartDate;
  BEGIN
    OPEN C_Tree;
    LOOP
      FETCH C_Tree INTO tAgentGrade,tStartDate;
      EXIT WHEN C_Tree%NOTFOUND;
      --?????????????cAgentGrade???
      IF bStatFlag AND tLastAgentGrade <> tAgentGrade THEN
        bStatFlag := false;
        --????????
        IF tLastStartDate <> dEmployDate THEN
          iMonthCount := iMonthCount + round(months_between(tStartDate,tLastStartDate));
        ELSE
          tTempDate := trunc(add_months(dEmployDate,1),'MM');
          iMonthCount := iMonthCount + round(months_between(tStartDate,tTempDate));
          IF to_char(dEmployDate,'DD') <= sLimitBase THEN
            iMonthCount := iMonthCount + 1;
          END IF;
        END IF;
      --????cAgentGrade???
      ELSIF NOT bStatFlag AND tAgentGrade = cAgentGrade THEN
        bStatFlag := true;
        tLastAgentGrade := tAgentGrade;
        tLastStartDate := tStartDate;
      END IF;
    END LOOP;

    IF bStatFlag THEN
        --????????
        IF tLastStartDate <> dEmployDate THEN
          iMonthCount := iMonthCount + round(months_between(cEndDate,tLastStartDate));
        ELSE
          tTempDate := trunc(add_months(dEmployDate,1),'MM');
          iMonthCount := iMonthCount + round(months_between(cEndDate,tTempDate));
          IF to_char(dEmployDate,'DD') <= sLimitBase THEN
            iMonthCount := iMonthCount + 1;
          END IF;
        END IF;
    END IF;
    CLOSE C_Tree;
  END;
  return(iMonthCount);
end getGradePeriod;


/

