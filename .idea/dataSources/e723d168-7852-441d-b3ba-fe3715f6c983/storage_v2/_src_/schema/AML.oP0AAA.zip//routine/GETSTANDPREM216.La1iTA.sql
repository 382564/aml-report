create FUNCTION getStandPrem216(prem in number,floatRate in number) return number
is
tR number ;
begin

 if prem <= 200 then
  tR := 200;
 end if;
 if prem <= 400 and prem>200 then
  tR := 400;
 end if;
 if prem <= 800 and prem>400 then
  tR := 800;
 end if;


 return(tR);
end;


/

