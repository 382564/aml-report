create function checkclaim(P_ContNo varchar2) return varchar2 is
  Result     varchar2(20);
  claimcount int;
  rptcount   int;
begin
  select count(1)
    into claimcount
    from llregister a
   where ClmState in ('20', '30', '40')
     and rgtno in (select caseno
                     from llcase b
                    where exists (select 1
                             from lccont
                            where contno = P_ContNo
                              and insuredno = b.customerno)
                      and not exists (select 1
                             from llclaimdetail
                            where clmno = b.caseno
                              and contno = P_ContNo)
                   union all
                   select clmno
                     from llclaimpolicy b
                    where contno = P_ContNo
                      and exists (select 1
                             from llclaimdetail
                            where clmno = b.clmno
                              and contno = P_ContNo));

  if claimcount > 0 then
    Result := '1';
  else
    select count(1)
      into rptcount
      from llsubreport a
     where exists (select 1
              from lccont
             where contno = P_ContNo
               and insuredno = a.customerno)
       and not exists
     (select 1 from llregister where rgtno = a.subrptno);
    if rptcount > 0 then
      Result := '1';
    else

      Result := '0';
    end if;
  end if;

  return(Result);
end checkclaim;

/

