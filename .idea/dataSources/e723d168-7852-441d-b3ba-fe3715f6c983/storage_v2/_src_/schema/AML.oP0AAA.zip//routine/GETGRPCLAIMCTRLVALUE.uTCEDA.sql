create function getGrpClaimCtrlValue(tGrpContNo in lcgrpcont.grpcontno%type,
    --???????
    tInsuredNo in lcinsured.insuredno%type,
    --??????
    tDutyCode in lmriskduty.dutycode%type,
    tGetDutyCode in lmdutyget.getdutycode%type,
    tValueName in varchar2,
    --????
    tCtrlProl in lldutyctrl.ctrlprop%type,
    --???? 0-???? 1-????
    --???? ??????? TotalLimit
    tCtrlLevel in lldutyctrl.ctrllevel%type
    ) return number is

  tCtrlValue number(10,4);
  t_cursor_sql  NUMBER;

  t_cursor_sql1  NUMBER;
  t_tempValue  NUMBER(10,4);
  t_temp        NUMBER;

  tSQL_Query varchar2(4000);
  tCtrlBatchNo lldutyctrl.ctrlbatchno%type;
  tempCtrlBatchNo lldutyctrl.ctrlbatchno%type;

  tOccupationType ldperson.occupationtype%type;

  tContPlanCode lcinsured.contplancode%type;

begin
  DBMS_OUTPUT.PUT_LINE('Begin');
tOccupationType := ' ';
tContPlanCode := ' ';
--???????????????????.
  if(tInsuredNo is not null and tInsuredNo<>' ') then
      begin
      select nvl(occupationtype,' '),nvl(contplancode,' ') into tOccupationType,tContPlanCode from lcinsured where insuredno=tInsuredNo
      and grpcontno=tGrpContNo and rownum=1;
      exception when NO_DATA_FOUND then
      tOccupationType := ' ';
      tContPlanCode  := ' ';
      end;

  end if;

DBMS_OUTPUT.PUT_LINE('tOccupationType--'||tOccupationType);
t_cursor_sql    := DBMS_SQL.OPEN_CURSOR;

--??????? ??  ???? ????


--????  ??  ????  ????  ??

/*
		 1.	????
		 2.	????
	 	 //3.	????(0-????,1-????) ??????????????!
	     4.	????
		 5.	??
		 6.	??
		 7.	????
*/
if(lower(tValueName) <>'totallimit') then

tSQL_Query := 'select B.x from
           ( select A.x x,A.y y,A.z z from
           (

            select a.ctrlbatchno x,a.ctrllevel y,''9'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ?CtrlValuName? = ''1'' and ctrllevel=''1''
            union
            select a.ctrlbatchno x,a.ctrllevel y,''8'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ?CtrlValuName? = ''1'' and occupationtype='''||tOccupationType||'''  and ctrllevel=''2''
            and  (( '''||tContPlanCode||'''='' '' and contplancode=''*'') or
            ( '''||tContPlanCode||'''<>'' ''  and contplancode='''||tContPlanCode||'''))
            union
            select a.ctrlbatchno x,a.ctrllevel y,''7'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ?CtrlValuName? = ''1'' and contplancode='''||tContPlanCode||'''
            and  (( '''||tOccupationType||'''='' '' and occupationtype=''*'') or
            ( '''||tOccupationType||'''<>'' ''  and occupationtype='''||tOccupationType||'''))
            and ctrllevel=''4''
            union
            select a.ctrlbatchno x,a.ctrllevel y,''1'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ?CtrlValuName? = ''1''
             and  (( contplancode='''||tContPlanCode||''' or contplancode=''*''))
            and  ((occupationtype='''||tOccupationType||''' or occupationtype=''*''))

            ) A order by A.z desc ,A.y
            ) B where rownum=1';

else


tSQL_Query := 'select A.x from ( select a.ctrlbatchno x,a.ctrllevel y from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ctrlprop='''||tCtrlProl||'''
            and ?CtrlValuName? = ''1''  and ctrllevel='''||tCtrlLevel||'''
            order by a.ctrllevel
            ) A where rownum=1';

end if;

/*
if(tOccupationType =' ') then
tSQL_Query := 'select A.x from ( select a.ctrlbatchno x,a.ctrllevel y from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ctrlprop='''||tCtrlProl||'''
            and ?CtrlValuName? = ''1''
            order by a.ctrllevel desc
            ) A where rownum=1';

else
tSQL_Query := 'select B.x from
           ( select A.x x,A.y y,A.z z from
           ( select a.ctrlbatchno x,a.ctrllevel y,''9'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ?CtrlValuName? = ''1'' and occupationtype='''||tOccupationType||'''
            and ctrlprop='''||tCtrlProl||'''
            union
            select a.ctrlbatchno x,a.ctrllevel y,''1'' z from lldutyctrlindex a where dutycode='''||
            tDutyCode||'''and getdutycode='''||tGetDutyCode||''' and grpcontno='''||tGrpContNo||'''
            and ctrlprop='''||tCtrlProl||'''
            and ?CtrlValuName? = ''1''

            ) A order by A.z desc ,A.y desc
            ) B where rownum=1';


end if;
*/



  tSQL_Query :=  REPLACE(trim(tSQL_Query), '?CtrlValuName?', trim(tValueName)||'flag');
  DBMS_OUTPUT.PUT_LINE('tSQL_Query--'||tSQL_Query);

   DBMS_SQL.PARSE(t_cursor_sql, tSQL_Query, DBMS_SQL.native);
      --???????????t_tempCtrlBatchNo?
      DBMS_SQL.DEFINE_COLUMN(t_cursor_sql, 1, tempCtrlBatchNo,20);
      --????SQL??
      t_temp := DBMS_SQL.EXECUTE(t_cursor_sql);

      LOOP
        --?????????? tempCtrlBatchNo
        IF DBMS_SQL.FETCH_ROWS(t_cursor_sql) > 0 THEN
          DBMS_SQL.COLUMN_VALUE(t_cursor_sql, 1, tempCtrlBatchNo);
          IF tempCtrlBatchNo is not null and tempCtrlBatchNo > 0 THEN
            tCtrlBatchNo :=  tempCtrlBatchNo;
            exit;
          END IF;
        ELSE
          EXIT;
        END IF;
      END LOOP;
      DBMS_SQL.CLOSE_CURSOR(t_cursor_sql);
      DBMS_OUTPUT.PUT_LINE('tCtrlBatchNo--'||tCtrlBatchNo);
--??????????,??????????
  if(tCtrlBatchNo is not null and tCtrlBatchNo<>'') then
     return -2;
  end if;

 t_cursor_sql1    := DBMS_SQL.OPEN_CURSOR;
 tSQL_Query := 'select ?CtrlValuName? from lldutyctrl where ctrlbatchno='''||tCtrlBatchNo||
             ''' and grpcontno='''||tGrpContNo||'''';

  tSQL_Query :=  REPLACE(trim(tSQL_Query), '?CtrlValuName?', trim(tValueName));
   DBMS_OUTPUT.PUT_LINE('tSQL_Query1--'||tSQL_Query);

   DBMS_SQL.PARSE(t_cursor_sql1, tSQL_Query, DBMS_SQL.native);
      --???????????t_tempValue?
      DBMS_SQL.DEFINE_COLUMN(t_cursor_sql1, 1, t_tempValue);
      --????SQL??
      t_temp := DBMS_SQL.EXECUTE(t_cursor_sql1);

      LOOP
        --?????????? t_temp_SumAmnt,?????
        IF DBMS_SQL.FETCH_ROWS(t_cursor_sql1) > 0 THEN
          DBMS_SQL.COLUMN_VALUE(t_cursor_sql1, 1, t_tempValue);
          IF t_tempValue is not null and t_tempValue > 0 THEN
            tCtrlValue :=  t_tempValue;
            exit;
          END IF;
        ELSE
          EXIT;
        END IF;
      END LOOP;
      DBMS_SQL.CLOSE_CURSOR(t_cursor_sql1);

  return tCtrlValue;
end getGrpClaimCtrlValue
;


/

