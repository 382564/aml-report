create FUNCTION gettempfeecount(cpolno in varchar2,cprtno in varchar2,cproposalno in varchar2,cstartmakedate in date,cendmakedate in date) return number
is
tR number;
tR1 number;
begin
 select count(*) into tR from ljtempfee where trim(otherno) in
 (cpolno,trim(cprtno),cproposalno
 )
 and enteraccdate is not null
 and makedate>=cstartmakedate and makedate<=cendmakedate
 ;
 return(tR);
end;


/

