create function getdutytype(P_ContNo varchar2) return varchar2 is
  Result     varchar2(20);
  claimcount int;
begin
  select count(1)
    into claimcount
    from lccont a
   where a.contno = P_ContNo
     and not exists (select 1
            from LCCONTHANGUPSTATE
           where hanguptype = '2'
             and contno = a.contno)
     and not exists (select 1
            from llreportapply
           where STATE in ('0', '1')
             and CUSTOMERNO = a.insuredno)
     and not exists (select 1
            from llclaimpolicy llp, llclaim llc
           where llp.INSUREDNO = a.insuredno
             and llc.clmstate not in ('50', '60')
             and llp.clmno = llc.clmno)
     and not exists
   (select 1
            from llreportapply llr, llregister llg
           where llr.CUSTOMERNO = a.insuredno
             and llr.state = '2'
             and llg.rgtno = llr.appno
             and not exists
           (select 1 from llclaim where rgtno = llg.rgtno));

  if claimcount < 1 then
    Result := '0';
  else
    Result := '1';
  end if;

  return(Result);
end getdutytype;

/

