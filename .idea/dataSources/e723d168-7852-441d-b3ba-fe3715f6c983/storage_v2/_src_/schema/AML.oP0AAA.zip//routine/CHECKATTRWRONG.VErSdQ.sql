create function checkAttrWrong(tManageCom in VARCHAR2,tBranchType in varchar2 ,tIndexCalNo in VARCHAR2) return integer IS
-------------------???????????????????LAAgent???????????---------------------------
  ADDCOUNT   INTEGER;
begin
  select count(*) into ADDCOUNT
  from lacommision,laagent
  where wageno=tIndexCalNo  and commdire='1'
  and lacommision.managecom like concat(tManageCom,'%')
  and lacommision.agentcode=laagent.agentcode
  and lacommision.branchcode<>laagent.branchcode
  and lacommision.branchtype=laagent.branchtype
  and laagent.branchtype=tBranchType;

  if (ADDCOUNT>0)
  then return -1;
  else
  return 1;
  end if;

end checkAttrWrong;


/

