create function fnc_280(tMainPolNo char, tMult char)
  return number is
  Result number;

  t_riskcode number;
begin

  --t_riskcode??????????
  t_riskcode := 0;
  select riskcode into t_riskcode from lcpol where PolNo = tMainPolNo;

  if t_riskcode = '00608000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((InsuYear = '10' and tMult <= 5 * mult)
        or (InsuYear in ('15', '20', '30') and tMult <= 10 * mult));
  end if;

  if t_riskcode in ('00904000','00903000') then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and (tMult <= mult);
  end if;

  if t_riskcode = '00609000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and tMult <= 3 * mult;
  end if;

  if t_riskcode = '00613000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((InsuYear = '10' and tMult <= 8 * mult)
        or (InsuYear in ('15', '20', '30') and tMult <= 10 * mult));
  end if;

  if t_riskcode = '00615000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((PayIntv = '0' and tMult <= 2 * mult)
        or (PayIntv <> '0' and InsuYear = '50' and tMult <= 10 * mult)
        or (PayIntv <> '0' and InsuYear = '55' and tMult <= 15 * mult)
        or (PayIntv <> '0' and insuyear in ('60', '65', '70') and
           tMult <= 20 * mult));
  end if;

  if t_riskcode = '00629000' then
    select 1
      into result
      from lcpol
     where PolNo = tMainPolNo
       and ((InsuYear in ('15', '20', '30') and tMult <= 10 * mult)
        or (InsuYear = '10' and tMult <= 5 * mult));
  end if;
  return(result);
end fnc_280;


/

