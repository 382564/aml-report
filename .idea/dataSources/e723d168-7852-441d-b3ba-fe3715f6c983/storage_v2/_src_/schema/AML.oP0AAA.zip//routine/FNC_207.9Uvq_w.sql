create FUNCTION fnc_207(Je_gf in varchar2) return varchar2
is
tR varchar2(20);
begin
  tR := '1';
  	if Je_gf >= '0' and Je_gf<= '2000' then
			tR := Je_gf*0.6;
		end if;
		if Je_gf >= '2001' and Je_gf<= '5000' then
			tR := Je_gf*0.7;
		end if;
		if Je_gf >= '5001' and Je_gf<= '8000' then
			tR := Je_gf*0.75;
		end if;
		if Je_gf >= '8001' and Je_gf<= '10000' then
			tR := Je_gf*0.8;
		end if;
		if Je_gf >= '10001' and Je_gf<= '60000' then
			tR := Je_gf*0.9;
		end if;
	return(tR);
end fnc_207;


/

