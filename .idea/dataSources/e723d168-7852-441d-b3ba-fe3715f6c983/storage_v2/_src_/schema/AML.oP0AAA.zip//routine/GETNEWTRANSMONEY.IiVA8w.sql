create function getNewTransMoney(TempBegin in Date, TempEnd in Date,aBranchAttr in varchar2,tAgentGrade in varchar2,tAgentCode in varchar2,tFlag in varchar2) return number is
  tPremium        number(12,2):=0;
  tRearPremium    number(12,2):=0;
  tFYC1           number(12,2):=0;
  tRearFYC1       number(12,2):=0;
	tBranchAttr varchar2(255);
  Result          number(12,2):=0;
  Result1         number(12,2):=0;

  cursor c_View is
    --tjj change 0101 ---select a.*,(select trim(branchattr) from labranchgroup where agentgroup = a.agentgroup) branchattr


     select agentgroup
     from latreeaccessory
     where  (commbreakflag is null or commbreakflag <> '1')
      and (agentgrade = trim(tAgentGrade) or
            agentgrade = decode(trim(tAgentGrade),'A08','A08','A09','A09',
            concat(substr(trim(tAgentGrade), 0, 2),
                   decode(mod(substr(trim(tAgentGrade), 3, 1), 2),
                          0,
                          substr(trim(tAgentGrade), 3, 1) + 1,
                          1,
                          substr(trim(tAgentGrade), 3, 1) - 1)))
                          )
        and rearagentcode = trim(tAgentCode);


begin
  --????:2006-03-14 LL
  --????:?????????(??????????)
  --??????
if tFlag = 'P' then
  --?????
  select nvl(sum(StandPrem),0) into tPremium from lacommision
  where commdire = '1'
    and payyear < 1
    and caldate >= TempBegin
    and caldate <= TempEnd and branchattr like concat(trim(aBranchAttr),'%')
    and branchtype='1';

  Result := tPremium;

--??FYC
else
  --??FYC?
  select nvl(sum(fyc),0) into tFYC1 from lacommision
  where commdire = '1'
    and payyear < 1
    and caldate >= TempBegin
    and caldate <= TempEnd and branchattr like concat(trim(aBranchAttr),'%')
    and branchtype='1';


  Result := tFYC1;

  --????FYC?
  if trim(tAgentGrade) in ('A05','A07','A09') then
    for v_View in c_View loop
	     ---tjj change 0101---
      tBranchAttr:= getbranchattr(v_View.agentgroup);
      select nvl(sum(fyc),0) into tRearFYC1 from lacommision
      where commdire = '1'
        and payyear < 1
        and caldate >= TempBegin
        and caldate <= TempEnd and branchattr like trim(concat(trim(tBranchAttr),'%'))
        and branchtype='1';

      Result1 := Result1 + tRearFYC1;
    end loop;
  end if;
end if;

  Result := Result + Result1;
  return(Result);
end getNewTransMoney;


/

